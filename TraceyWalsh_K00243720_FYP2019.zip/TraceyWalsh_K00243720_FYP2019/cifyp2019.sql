-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2019 at 02:50 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cifyp2019`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('57fae166f04b7fba6d4f1f992da2c30c', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1556368800, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:15:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:14:\"Queen Potatoes\";s:15:\"longDescription\";s:18:\"€4.00 per basket\";s:10:\"largeImage\";s:12:\"potatoes.jpg\";s:10:\"smallImage\";s:12:\"potatoes.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-23\";s:7:\"dateExp\";s:10:\"2019-06-14\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic carrots \";s:15:\"longDescription\";s:14:\"€2.36 per kg\";s:10:\"largeImage\";s:11:\"carrots.jpg\";s:10:\"smallImage\";s:11:\"carrots.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-05-31\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:10:\"Courgettes\";s:15:\"longDescription\";s:16:\"€3.89 for five\";s:10:\"largeImage\";s:13:\"courgette.jpg\";s:10:\"smallImage\";s:13:\"courgette.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2014-07-10\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:18:\"Organic large eggs\";s:15:\"longDescription\";s:15:\"€2.65 for six\";s:10:\"largeImage\";s:8:\"eggs.jpg\";s:10:\"smallImage\";s:8:\"eggs.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:4;a:9:{s:8:\"noticeId\";s:1:\"5\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Sweet peppers\";s:15:\"longDescription\";s:15:\"€1.49 for two\";s:10:\"largeImage\";s:11:\"Peppers.jpg\";s:10:\"smallImage\";s:11:\"Peppers.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:5;a:9:{s:8:\"noticeId\";s:1:\"6\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Fresh Cabbage\";s:15:\"longDescription\";s:16:\"€1.39 per head\";s:10:\"largeImage\";s:11:\"cabbage.jpg\";s:10:\"smallImage\";s:11:\"cabbage.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-23\";}i:6;a:9:{s:8:\"noticeId\";s:1:\"7\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:6:\"Squash\";s:15:\"longDescription\";s:14:\"€4.30 per kg\";s:10:\"largeImage\";s:10:\"squash.jpg\";s:10:\"smallImage\";s:10:\"squash.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:7;a:9:{s:8:\"noticeId\";s:1:\"8\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic Turnips\";s:15:\"longDescription\";s:12:\"€0.89 each\";s:10:\"largeImage\";s:11:\"turnips.jpg\";s:10:\"smallImage\";s:11:\"turnips.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-11\";}i:8;a:9:{s:8:\"noticeId\";s:1:\"9\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic Tomatoes\";s:15:\"longDescription\";s:14:\"€2.99 per kg\";s:10:\"largeImage\";s:11:\"tomatos.jpg\";s:10:\"smallImage\";s:11:\"tomatos.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-08-22\";}i:9;a:9:{s:8:\"noticeId\";s:2:\"10\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:15:\"Organic Lettuce\";s:15:\"longDescription\";s:16:\"€0.89 per head\";s:10:\"largeImage\";s:11:\"lettuce.jpg\";s:10:\"smallImage\";s:11:\"lettuce.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-16\";}i:10;a:9:{s:8:\"noticeId\";s:2:\"11\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:21:\"Gluten-free Sourdough\";s:15:\"longDescription\";s:12:\"€3.00 each\";s:10:\"largeImage\";s:13:\"sourdough.jpg\";s:10:\"smallImage\";s:13:\"sourdough.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-12-05\";}i:11;a:9:{s:8:\"noticeId\";s:2:\"12\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Burren Honey\";s:15:\"longDescription\";s:15:\"€3.59 per pot\";s:10:\"largeImage\";s:10:\"Boirne.jpg\";s:10:\"smallImage\";s:10:\"Boirne.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:12;a:9:{s:8:\"noticeId\";s:2:\"13\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:9:\"Preserves\";s:15:\"longDescription\";s:15:\"€3.59 per jar\";s:10:\"largeImage\";s:7:\"jam.jpg\";s:10:\"smallImage\";s:7:\"jam.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-09-30\";}i:13;a:9:{s:8:\"noticeId\";s:2:\"14\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:27:\"Freshly pressed Apple Juice\";s:15:\"longDescription\";s:15:\"€3.49 per ltr\";s:10:\"largeImage\";s:14:\"appleJuice.jpg\";s:10:\"smallImage\";s:14:\"appleJuice.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:14;a:9:{s:8:\"noticeId\";s:2:\"15\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Course Honey\";s:15:\"longDescription\";s:25:\"12oz jars at €4.20 each\";s:10:\"largeImage\";s:12:\"IvyHoney.jpg\";s:10:\"smallImage\";s:12:\"IvyHoney.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-08-30\";}}}'),
('75ffa99f814022e1595204ca4e26aec8', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1556363314, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:15:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:14:\"Queen Potatoes\";s:15:\"longDescription\";s:18:\"€4.00 per basket\";s:10:\"largeImage\";s:12:\"potatoes.jpg\";s:10:\"smallImage\";s:12:\"potatoes.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-23\";s:7:\"dateExp\";s:10:\"2019-06-14\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic carrots\";s:15:\"longDescription\";s:14:\"€2.35 per kg\";s:10:\"largeImage\";s:11:\"carrots.jpg\";s:10:\"smallImage\";s:11:\"carrots.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-05-31\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:10:\"Courgettes\";s:15:\"longDescription\";s:16:\"€3.89 for five\";s:10:\"largeImage\";s:13:\"courgette.jpg\";s:10:\"smallImage\";s:13:\"courgette.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2014-07-10\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:18:\"Organic large eggs\";s:15:\"longDescription\";s:15:\"€2.65 for six\";s:10:\"largeImage\";s:8:\"eggs.jpg\";s:10:\"smallImage\";s:8:\"eggs.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:4;a:9:{s:8:\"noticeId\";s:1:\"5\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Sweet peppers\";s:15:\"longDescription\";s:15:\"€1.49 for two\";s:10:\"largeImage\";s:11:\"Peppers.jpg\";s:10:\"smallImage\";s:11:\"Peppers.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:5;a:9:{s:8:\"noticeId\";s:1:\"6\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Fresh Cabbage\";s:15:\"longDescription\";s:16:\"€1.39 per head\";s:10:\"largeImage\";s:11:\"cabbage.jpg\";s:10:\"smallImage\";s:11:\"cabbage.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-23\";}i:6;a:9:{s:8:\"noticeId\";s:1:\"7\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:6:\"Squash\";s:15:\"longDescription\";s:14:\"€4.30 per kg\";s:10:\"largeImage\";s:10:\"squash.jpg\";s:10:\"smallImage\";s:10:\"squash.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:7;a:9:{s:8:\"noticeId\";s:1:\"8\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic Turnips\";s:15:\"longDescription\";s:12:\"€0.89 each\";s:10:\"largeImage\";s:11:\"turnips.jpg\";s:10:\"smallImage\";s:11:\"turnips.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-11\";}i:8;a:9:{s:8:\"noticeId\";s:1:\"9\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic Tomatoes\";s:15:\"longDescription\";s:14:\"€2.99 per kg\";s:10:\"largeImage\";s:11:\"tomatos.jpg\";s:10:\"smallImage\";s:11:\"tomatos.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-08-22\";}i:9;a:9:{s:8:\"noticeId\";s:2:\"10\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:15:\"Organic Lettuce\";s:15:\"longDescription\";s:16:\"€0.89 per head\";s:10:\"largeImage\";s:11:\"lettuce.jpg\";s:10:\"smallImage\";s:11:\"lettuce.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-16\";}i:10;a:9:{s:8:\"noticeId\";s:2:\"11\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:21:\"Gluten-free Sourdough\";s:15:\"longDescription\";s:12:\"€3.00 each\";s:10:\"largeImage\";s:13:\"sourdough.jpg\";s:10:\"smallImage\";s:13:\"sourdough.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-12-05\";}i:11;a:9:{s:8:\"noticeId\";s:2:\"12\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Burren Honey\";s:15:\"longDescription\";s:15:\"€3.59 per pot\";s:10:\"largeImage\";s:10:\"Boirne.jpg\";s:10:\"smallImage\";s:10:\"Boirne.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:12;a:9:{s:8:\"noticeId\";s:2:\"13\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:9:\"Preserves\";s:15:\"longDescription\";s:15:\"€3.59 per jar\";s:10:\"largeImage\";s:7:\"jam.jpg\";s:10:\"smallImage\";s:7:\"jam.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-09-30\";}i:13;a:9:{s:8:\"noticeId\";s:2:\"14\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:27:\"Freshly pressed Apple Juice\";s:15:\"longDescription\";s:15:\"€3.49 per ltr\";s:10:\"largeImage\";s:14:\"appleJuice.jpg\";s:10:\"smallImage\";s:14:\"appleJuice.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:14;a:9:{s:8:\"noticeId\";s:2:\"15\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Course Honey\";s:15:\"longDescription\";s:25:\"12oz jars at €4.20 each\";s:10:\"largeImage\";s:12:\"IvyHoney.jpg\";s:10:\"smallImage\";s:12:\"IvyHoney.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-08-30\";}}}'),
('9c51b959e4b20c217f0995d6d64433ce', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1556363299, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:15:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:14:\"Queen Potatoes\";s:15:\"longDescription\";s:18:\"€4.00 per basket\";s:10:\"largeImage\";s:12:\"potatoes.jpg\";s:10:\"smallImage\";s:12:\"potatoes.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-23\";s:7:\"dateExp\";s:10:\"2019-06-14\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic carrots\";s:15:\"longDescription\";s:14:\"€2.35 per kg\";s:10:\"largeImage\";s:11:\"carrots.jpg\";s:10:\"smallImage\";s:11:\"carrots.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-05-31\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:10:\"Courgettes\";s:15:\"longDescription\";s:16:\"€3.89 for five\";s:10:\"largeImage\";s:13:\"courgette.jpg\";s:10:\"smallImage\";s:13:\"courgette.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2014-07-10\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:18:\"Organic large eggs\";s:15:\"longDescription\";s:15:\"€2.65 for six\";s:10:\"largeImage\";s:8:\"eggs.jpg\";s:10:\"smallImage\";s:8:\"eggs.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:4;a:9:{s:8:\"noticeId\";s:1:\"5\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Sweet peppers\";s:15:\"longDescription\";s:15:\"€1.49 for two\";s:10:\"largeImage\";s:11:\"Peppers.jpg\";s:10:\"smallImage\";s:11:\"Peppers.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:5;a:9:{s:8:\"noticeId\";s:1:\"6\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Fresh Cabbage\";s:15:\"longDescription\";s:16:\"€1.39 per head\";s:10:\"largeImage\";s:11:\"cabbage.jpg\";s:10:\"smallImage\";s:11:\"cabbage.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-23\";}i:6;a:9:{s:8:\"noticeId\";s:1:\"7\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:6:\"Squash\";s:15:\"longDescription\";s:14:\"€4.30 per kg\";s:10:\"largeImage\";s:10:\"squash.jpg\";s:10:\"smallImage\";s:10:\"squash.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:7;a:9:{s:8:\"noticeId\";s:1:\"8\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic Turnips\";s:15:\"longDescription\";s:12:\"€0.89 each\";s:10:\"largeImage\";s:11:\"turnips.jpg\";s:10:\"smallImage\";s:11:\"turnips.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-11\";}i:8;a:9:{s:8:\"noticeId\";s:1:\"9\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic Tomatoes\";s:15:\"longDescription\";s:14:\"€2.99 per kg\";s:10:\"largeImage\";s:11:\"tomatos.jpg\";s:10:\"smallImage\";s:11:\"tomatos.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-08-22\";}i:9;a:9:{s:8:\"noticeId\";s:2:\"10\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:15:\"Organic Lettuce\";s:15:\"longDescription\";s:16:\"€0.89 per head\";s:10:\"largeImage\";s:11:\"lettuce.jpg\";s:10:\"smallImage\";s:11:\"lettuce.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-16\";}i:10;a:9:{s:8:\"noticeId\";s:2:\"11\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:21:\"Gluten-free Sourdough\";s:15:\"longDescription\";s:12:\"€3.00 each\";s:10:\"largeImage\";s:13:\"sourdough.jpg\";s:10:\"smallImage\";s:13:\"sourdough.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-12-05\";}i:11;a:9:{s:8:\"noticeId\";s:2:\"12\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Burren Honey\";s:15:\"longDescription\";s:15:\"€3.59 per pot\";s:10:\"largeImage\";s:10:\"Boirne.jpg\";s:10:\"smallImage\";s:10:\"Boirne.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:12;a:9:{s:8:\"noticeId\";s:2:\"13\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:9:\"Preserves\";s:15:\"longDescription\";s:15:\"€3.59 per jar\";s:10:\"largeImage\";s:7:\"jam.jpg\";s:10:\"smallImage\";s:7:\"jam.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-09-30\";}i:13;a:9:{s:8:\"noticeId\";s:2:\"14\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:27:\"Freshly pressed Apple Juice\";s:15:\"longDescription\";s:15:\"€3.49 per ltr\";s:10:\"largeImage\";s:14:\"appleJuice.jpg\";s:10:\"smallImage\";s:14:\"appleJuice.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:14;a:9:{s:8:\"noticeId\";s:2:\"15\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Course Honey\";s:15:\"longDescription\";s:25:\"12oz jars at €4.20 each\";s:10:\"largeImage\";s:12:\"IvyHoney.jpg\";s:10:\"smallImage\";s:12:\"IvyHoney.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-08-30\";}}}'),
('d7bb1b4067c6121d84c65874cb77fd68', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36', 1556367797, 'a:2:{s:9:\"user_data\";s:0:\"\";s:13:\"AllNoticeData\";a:15:{i:0;a:9:{s:8:\"noticeId\";s:1:\"1\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:14:\"Queen Potatoes\";s:15:\"longDescription\";s:18:\"€4.00 per basket\";s:10:\"largeImage\";s:12:\"potatoes.jpg\";s:10:\"smallImage\";s:12:\"potatoes.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-23\";s:7:\"dateExp\";s:10:\"2019-06-14\";}i:1;a:9:{s:8:\"noticeId\";s:1:\"2\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic carrots \";s:15:\"longDescription\";s:14:\"€2.36 per kg\";s:10:\"largeImage\";s:11:\"carrots.jpg\";s:10:\"smallImage\";s:11:\"carrots.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-05-31\";}i:2;a:9:{s:8:\"noticeId\";s:1:\"3\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:10:\"Courgettes\";s:15:\"longDescription\";s:16:\"€3.89 for five\";s:10:\"largeImage\";s:13:\"courgette.jpg\";s:10:\"smallImage\";s:13:\"courgette.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2014-07-10\";}i:3;a:9:{s:8:\"noticeId\";s:1:\"4\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:18:\"Organic large eggs\";s:15:\"longDescription\";s:15:\"€2.65 for six\";s:10:\"largeImage\";s:8:\"eggs.jpg\";s:10:\"smallImage\";s:8:\"eggs.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:4;a:9:{s:8:\"noticeId\";s:1:\"5\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Sweet peppers\";s:15:\"longDescription\";s:15:\"€1.49 for two\";s:10:\"largeImage\";s:11:\"Peppers.jpg\";s:10:\"smallImage\";s:11:\"Peppers.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:5;a:9:{s:8:\"noticeId\";s:1:\"6\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:13:\"Fresh Cabbage\";s:15:\"longDescription\";s:16:\"€1.39 per head\";s:10:\"largeImage\";s:11:\"cabbage.jpg\";s:10:\"smallImage\";s:11:\"cabbage.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-23\";}i:6;a:9:{s:8:\"noticeId\";s:1:\"7\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:6:\"Squash\";s:15:\"longDescription\";s:14:\"€4.30 per kg\";s:10:\"largeImage\";s:10:\"squash.jpg\";s:10:\"smallImage\";s:10:\"squash.jpg\";s:4:\"area\";s:7:\"Kinvara\";s:12:\"dateUploaded\";s:10:\"2019-04-04\";s:7:\"dateExp\";s:10:\"2019-09-27\";}i:7;a:9:{s:8:\"noticeId\";s:1:\"8\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:15:\"Organic Turnips\";s:15:\"longDescription\";s:12:\"€0.89 each\";s:10:\"largeImage\";s:11:\"turnips.jpg\";s:10:\"smallImage\";s:11:\"turnips.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-11\";}i:8;a:9:{s:8:\"noticeId\";s:1:\"9\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:16:\"Organic Tomatoes\";s:15:\"longDescription\";s:14:\"€2.99 per kg\";s:10:\"largeImage\";s:11:\"tomatos.jpg\";s:10:\"smallImage\";s:11:\"tomatos.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-08-22\";}i:9;a:9:{s:8:\"noticeId\";s:2:\"10\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:15:\"Organic Lettuce\";s:15:\"longDescription\";s:16:\"€0.89 per head\";s:10:\"largeImage\";s:11:\"lettuce.jpg\";s:10:\"smallImage\";s:11:\"lettuce.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-08-16\";}i:10;a:9:{s:8:\"noticeId\";s:2:\"11\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:21:\"Gluten-free Sourdough\";s:15:\"longDescription\";s:12:\"€3.00 each\";s:10:\"largeImage\";s:13:\"sourdough.jpg\";s:10:\"smallImage\";s:13:\"sourdough.jpg\";s:4:\"area\";s:12:\"Ballyvaughan\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-12-05\";}i:11;a:9:{s:8:\"noticeId\";s:2:\"12\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Burren Honey\";s:15:\"longDescription\";s:15:\"€3.59 per pot\";s:10:\"largeImage\";s:10:\"Boirne.jpg\";s:10:\"smallImage\";s:10:\"Boirne.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:12;a:9:{s:8:\"noticeId\";s:2:\"13\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:9:\"Preserves\";s:15:\"longDescription\";s:15:\"€3.59 per jar\";s:10:\"largeImage\";s:7:\"jam.jpg\";s:10:\"smallImage\";s:7:\"jam.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-05\";s:7:\"dateExp\";s:10:\"2019-09-30\";}i:13;a:9:{s:8:\"noticeId\";s:2:\"14\";s:6:\"userId\";s:1:\"3\";s:16:\"shortDescription\";s:27:\"Freshly pressed Apple Juice\";s:15:\"longDescription\";s:15:\"€3.49 per ltr\";s:10:\"largeImage\";s:14:\"appleJuice.jpg\";s:10:\"smallImage\";s:14:\"appleJuice.jpg\";s:4:\"area\";s:11:\"North Clare\";s:12:\"dateUploaded\";s:10:\"2019-04-03\";s:7:\"dateExp\";s:10:\"2019-10-31\";}i:14;a:9:{s:8:\"noticeId\";s:2:\"15\";s:6:\"userId\";s:1:\"4\";s:16:\"shortDescription\";s:12:\"Course Honey\";s:15:\"longDescription\";s:25:\"12oz jars at €4.20 each\";s:10:\"largeImage\";s:12:\"IvyHoney.jpg\";s:10:\"smallImage\";s:12:\"IvyHoney.jpg\";s:4:\"area\";s:12:\"South Galway\";s:12:\"dateUploaded\";s:10:\"2019-04-06\";s:7:\"dateExp\";s:10:\"2019-08-30\";}}}');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `noticeId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `shortDescription` varchar(50) NOT NULL,
  `longDescription` varchar(250) NOT NULL,
  `largeImage` varchar(50) NOT NULL,
  `smallImage` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `dateUploaded` date NOT NULL,
  `dateExp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`noticeId`, `userId`, `shortDescription`, `longDescription`, `largeImage`, `smallImage`, `area`, `dateUploaded`, `dateExp`) VALUES
(1, 4, 'Queen Potatoes', '€4.00 per basket', 'potatoes.jpg', 'potatoes.jpg', 'North Clare', '2019-04-23', '2019-06-14'),
(2, 3, 'Organic carrots ', '€2.36 per kg', 'carrots.jpg', 'carrots.jpg', 'North Clare', '2019-04-04', '2019-05-31'),
(3, 3, 'Courgettes', '€3.89 for five', 'courgette.jpg', 'courgette.jpg', 'Kinvara', '2019-04-06', '2014-07-10'),
(4, 4, 'Organic large eggs', '€2.65 for six', 'eggs.jpg', 'eggs.jpg', 'Ballyvaughan', '2019-04-05', '2019-10-31'),
(5, 3, 'Sweet peppers', '€1.49 for two', 'Peppers.jpg', 'Peppers.jpg', 'North Clare', '2019-04-06', '2019-09-27'),
(6, 3, 'Fresh Cabbage', '€1.39 per head', 'cabbage.jpg', 'cabbage.jpg', 'South Galway', '2019-04-05', '2019-08-23'),
(7, 4, 'Squash', '€4.30 per kg', 'squash.jpg', 'squash.jpg', 'Kinvara', '2019-04-04', '2019-09-27'),
(8, 3, 'Organic Turnips', '€0.89 each', 'turnips.jpg', 'turnips.jpg', 'North Clare', '2019-04-06', '2019-10-11'),
(9, 3, 'Organic Tomatoes', '€2.99 per kg', 'tomatos.jpg', 'tomatos.jpg', 'North Clare', '2019-04-03', '2019-08-22'),
(10, 4, 'Organic Lettuce', '€0.89 per head', 'lettuce.jpg', 'lettuce.jpg', 'South Galway', '2019-04-05', '2019-08-16'),
(11, 3, 'Gluten-free Sourdough', '€3.00 each', 'sourdough.jpg', 'sourdough.jpg', 'Ballyvaughan', '2019-04-05', '2019-12-05'),
(12, 4, 'Burren Honey', '€3.59 per pot', 'Boirne.jpg', 'Boirne.jpg', 'North Clare', '2019-04-06', '2019-10-31'),
(13, 3, 'Preserves', '€3.59 per jar', 'jam.jpg', 'jam.jpg', 'North Clare', '2019-04-05', '2019-09-30'),
(14, 3, 'Freshly pressed Apple Juice', '€3.49 per ltr', 'appleJuice.jpg', 'appleJuice.jpg', 'North Clare', '2019-04-03', '2019-10-31'),
(15, 4, 'Course Honey', '12oz jars at €4.20 each', 'IvyHoney.jpg', 'IvyHoney.jpg', 'South Galway', '2019-04-06', '2019-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `ID` int(11) NOT NULL,
  `Customer` int(11) NOT NULL,
  `Details` varchar(300) NOT NULL,
  `CollectionPoint` varchar(50) NOT NULL,
  `Producer` int(11) NOT NULL,
  `largeImage` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ID`, `Customer`, `Details`, `CollectionPoint`, `Producer`, `largeImage`) VALUES
(1, 1, '1kg Carrots', 'Ballyvaughan', 3, 'carrots.jpg'),
(2, 1, '2 Sweet Peppers', 'Ballyvaughan', 3, 'Peppers.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `SurName` varchar(50) NOT NULL,
  `Mobile` varchar(50) NOT NULL,
  `AddressLine1` varchar(50) NOT NULL,
  `AddressLine2` varchar(50) NOT NULL,
  `AddressLine3` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `type` int(11) NOT NULL,
  `Pickup` varchar(100) NOT NULL,
  `Portrait` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `Password`, `FirstName`, `SurName`, `Mobile`, `AddressLine1`, `AddressLine2`, `AddressLine3`, `Email`, `type`, `Pickup`, `Portrait`) VALUES
(1, 'Lisa', 'e9803a706f81a40884b8aeafafb2cfd3', 'Lisa', 'Bailey        ', '065 6823457       ', 'Belharbour       ', 'Ballyvaughan        ', 'County Clare       ', 'lisa@bally.ie        ', 2, 'Ballyvaughan', 'lisa.jpg'),
(2, 'Mike', '4c3e1ec04215f69d6a8e9c023c9e4572', 'Mike', 'Ryan', '091 9612345', 'Main Street', 'Kinvara', 'County Galway', 'mike@galway.ie', 2, 'Kinvara', 'mike.jpg'),
(3, 'John', '6e0b7076126a29d5dfcbd54835387b7b', 'John', 'Connolly', '087 4523456', 'Kinvara', 'Galway', 'County Galway', 'john@gmail.com', 1, 'Kinvara', 'john.jpg'),
(4, 'Tom', '5caf72868c94f184650f43413092e82c', 'Tom ', 'O\'Reilly', '0871234567', 'Finavarra', 'Ballyvaughan', 'Clare', 'tom@burren.ie', 1, 'Ballyvaughan', 'tom.jpg'),
(5, 'Susan', 'eeb50840eb970f391ed41303229772be', 'Susan', 'Whelan', '065 68923467', 'Ballindeeren', 'Kinvara', 'Galway', 'susan@kinvara.ie', 2, 'Kinvara', 'susan.jpg'),
(6, 'Burren Kitchen ', '28d7cfb0d66ce351962436f341b2efb1 ', 'Deborah ', 'Evers ', '087 86574384 ', 'Clareville ', 'Doolin ', 'Co Clare ', 'deborah@burrenkitchenfarm.ie ', 1, 'Ballyvaughan ', ''),
(9, 'AngelaJ', 'c435347baf6476441f132355c566637e', 'Angela', 'Janzen', '087 86574346', 'Ballyvaughan', 'Co Clare', '', 'luella@gmail.com', 1, 'Ballyvaughan', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`noticeId`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `noticeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notice`
--
ALTER TABLE `notice`
  ADD CONSTRAINT `notice_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
