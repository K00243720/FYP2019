<?php
$this->load->helper('url');
$base = base_url() . index_page();
$this->load->view('header'); 
$this->load->helper('url');
$cssbase = base_url();
$jsbase = base_url();
?>

<div class="limiter">
		<div class="container-login">
			<div class="wrap-login">
				<form class="login-form" id="form1" name="form1" method="post" onsubmit="return validateForm()" action="<?php echo "$base/User/RegisterUser"; ?>">
					<span class="login-form-title">
						Register 
					</span>
					
					<div class="wrap-input">
						<input class="input" id="FirstName" type="text" name="FirstName" placeholder="First Name"> 
					</div>
					
					<div class="wrap-input">
                    <input class="input" id="Surname" type="text" name="Surname" placeholder="Surname">
					</div>
					
                    <div class="wrap-input">
						<input class="input" id="AddressLine1" type="text" name="AddressLine1" placeholder="Address 1">
					</div>
                    
                    <div class="wrap-input">
						<input class="input" id="AddressLine2" type="text" name="AddressLine2" placeholder="Address 2">
					</div>
                    
                    <div class="wrap-input">
						<input class="input" id="AddressLine3" type="text" name="AddressLine3" placeholder="Address 3">
					</div>
                    
                    <div class="wrap-input">
						<input class="input" id="Mobile" type="text" name="Mobile" placeholder="Mobile">
					</div>

					<div class="wrap-input">
						<input class="input" id="email" type="text" name="email" placeholder="Email">
					</div>
					
					 <div class="wrap-input">
						<input class="input" id="UserName" type="text" name="UserName" placeholder="User Name">
					</div>

					<div class="wrap-input">
						<input class="input" id="Password" type="password" name="Password" placeholder="Password">
					</div>
                    <div class="wrap-input">
						<input class="input" id="Pickup" type="text" name="Pickup" placeholder="Collection Point">
					</div>
					
                    <br>
                    <div class="txt3">
                    <input type="radio"  name="type" value="1" required>Click here if you are a producer<br>
					<input type="radio"  name="type" value="2">Click here if you are a customer<br>
                        </div>

					<div class="container-login-form-btn">
						<button class="login-form-btn" id="button" value="submit">
							Register
						</button>
					</div>

					<div class="text-center">
						<span class="txt1">
							Already have an account?
						</span>

						<a href="<?php echo "$base/User/doLogon"; ?>" class="txt2 hov1">
							Sign in
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>




<?php
$this->load->view('footer'); 
?>