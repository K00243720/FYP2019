<?php
$this->load->view('header'); 
?>

<?php
echo $msg;
?>

<?php
$this->load->view('footer'); 
?>