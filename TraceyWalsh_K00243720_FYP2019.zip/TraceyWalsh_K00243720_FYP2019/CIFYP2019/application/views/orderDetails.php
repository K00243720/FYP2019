<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
//$Detail = str_replace("%20"," ",$Detail);
?>

<?php $user = $this->session->userdata('user');
$o = $this->session->userdata('AllOrderData');
?>

<?php
if(!$o==null){
?>
	<table border="0" class="center">
		<th></th>
        <th>Details</th>
        <th>Collection Point</th>
		<th></th>

<?php
		foreach ($o as $order){
			echo "<tr>";
				echo "<td>" . "<img src=\"$img_base/assets/images/notices/". $order['largeImage']. "\" /> " . "</td>";
				echo "<td>" . urldecode($order['Details']) . "</td>";
				echo "<td>" . urldecode($order['CollectionPoint']) . "</td>";
				echo "<td>" . "<a href=\"$base/Order/deleteOrder/". $order['orderId'] . "\" />Delete " . "</td>"; 
			echo "</tr>";
			}
?>
	</table>
            

<?php } ?>
  
  
<?php
$this->load->view('footer'); 
?> 