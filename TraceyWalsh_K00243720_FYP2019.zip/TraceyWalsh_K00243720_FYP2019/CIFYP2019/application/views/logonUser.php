<?php
$this->load->helper('url');
$base = base_url() . index_page();
$this->load->view('header'); 
?>


 <div class="limiter">
		<div class="container-login">
			<div class="wrap-login">
				<form class="login-form" id="form1" name="form1" method="post" action="<?php echo "$base/User/getUser"; ?>">
					<span class="login-form-title">
						Login
					</span>

					<div class="wrap-input">
						<input class="input" id="username" type="text" name="UserName" placeholder="Name" required>
					</div>

					<div class="wrap-input validate-input">
						<input class="input" id="password" type="password" name="password" placeholder="Password" required>
					</div>

					<div class="container-login-form-btn">
						<button class="login-form-btn" name="button" id="button" value="submit">
							Sign in
						</button>
					</div>

					<div class="text-center">
						<span class="txt1">
							Don't have an account?
						</span>

						<a href="<?php echo "$base/User/doRegister"; ?>" class="txt2 hov1">
							Sign up
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

	

<?php
$this->load->view('footer'); 
?>