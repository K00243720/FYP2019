<?php
$this->load->view('header'); 
$this->load->helper('url');
$img_base = base_url();
$base = base_url() . index_page();
$sd = $notice['shortDescription'];
$ld = $notice['longDescription'];
$area = $notice['area'];
$dateExp = $notice['dateExp'];
$image = $notice['largeImage'];
?>

<div class="limiter notice">
	<div class="wrap-login forms2">

  <form id="form1" name="form1" class="noticeForm" method="post" enctype="multipart/form-data"  action="<?php echo "$base/Notice/saveNoticeDetails/" . $notice['noticeId']; ?>">
  <h2 class="userHead">Edit product</h2>
 
 <div class="wrap-input insertForms">
    <label for="shortDescription">Description:</label>
    <input type="text" name="shortDescription" value="<?php echo $sd ?>"/>
  </div>
   <div class="wrap-input insertForms">
    <label for="area">Area:</label> 
    <input type="text" name="area" id="area" value="<?php echo $area?>"/>
 </div>
   <div class="wrap-input insertForms">
    <label for="dateExp">Expiry Date:</label>
    <input type="text" name="dateExp" id="dateExp" value="<?php echo $dateExp ?>"/>
</div>
  <div class="wrap-input insertForms">
    <label for="longDescription">Price and quantity:</label>
    <input type="text" name="longDescription" id="longDescription" value="<?php echo $ld ?>"/>
  </div>
  <div class="wrap-input">
	<img src="<?php echo $img_base . "/assets/images/notices/$image"?>">
	<br>
	<p class="insertForms">
		<label for="userfile">Image:</label>
		<input name="userfile" type="file" id="userfile" size="45" />
	</p>
   </div>
  <br>
   <input type="submit" name="button" id="button" class="login-form-btn" value="Submit" />
</form>
</div>
</div>

<?php
$this->load->view('footer'); 
?>