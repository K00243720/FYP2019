<?php 
$img_base = base_url();
$cssbase = base_url();
$base = base_url() . index_page();
?>

<footer>
            
	<a class="logo" title="The Market Hall" href="<?php echo "$base/User/index"; ?>"><span>The Market Hall</span></a>
   
	<div class="footer_img">
	<a href="http://www.facebook.com" target="_blank"><img src="<?php echo $img_base . "assets/images/facebook.jpg"?>" alt="facebook logo" width="40" height="40"></a>
	<a href="http://www.twitter.com" target="_blank"><img src="<?php echo $img_base . "assets/images/twitter.jpg"?>" alt="twitter logo" width="40" height="40"></a>
	<a href="http://www.instagram.com" target="_blank"><img src="<?php echo $img_base . "assets/images/instagram.jpg"?>" alt="instagram logo" width="40" height="40"></a>
	<a href="http://www.snapchat.com" target="_blank"><img src="<?php echo $img_base . "assets/images/snapchat.jpg"?>" alt="snapchat logo" width="40" height="40"></a> 
	</div>
                
	<div class="content_contact">
         Call us: 065-1234567
         <p>K00243720@student.lit.ie</p>
    </div>      
    <div class="content_bottom">
        &copy; K00243720 2019
    </div>
</footer>
	
</div>	
</body>
</html>