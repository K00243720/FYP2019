<?php
$this->load->view('header');  
$this->load->helper('url'); 
$cssbase = base_url();
$img_base = base_url();
$base = base_url() . index_page();
$n = $this->session->userdata('AllNoticeData');
?>

    <br>
    <br>
            
       <section class="producersMain">
            <article>
            <h2>Meet our producers</h2>
            <figure>  
            <img alt="Deborah Evers" src="<?php echo $img_base . "assets/images/burren.jpg"?>" width="700"> 
                <figcaption>Deborah Evers of Clareville House Kitchen Garden</figcaption>
            </figure>  
            <h3>Clareville House Kitchen Garden</h3>
            <p>Clareville House Kitchen Garden is a grower and artisan food producer in the Burren and Cliffs of Moher Geopark in County Clare, which has become internationally-recognised due to its geological importance and the existence of a network of businesses and environment agencies that oversee tourism in the area, as well as providing ecology education and conservation efforts.</p>
            <p>Central to Clareville House is Deborah Evers, who puts a huge amount of time and effort into not only running her own business and producing organic jams, chutneys and relishes, but is also a key member of the Burren Food Trail and Burren Ecotourism Network.</p>
            <p>The Burren Food Trail, which has 54 members, won the EU EDEN European Destination of Excellence - Tourism and Gastronomy Award in 2015 and followed this up in 2016 with the National Geographic Legacy Award for Leadership in Responsible Tourism.</p>
            <p>Clareville House's range of sweet and savory preserves, which is named ‘Burren Kitchen Garden', includes jams, jellies, chutney, relish, dressings and sauces. They grow much of their own soft fruit, vegetables and herbs using organic methods and all other local produce is carefully selected for their preserves for seasonal freshness and nutritional value.</p>
            <p>Clareville House also hosts cookery workshops and foraging walks and is a member of Ballyvaughan Farmers' Market. The business has adopted the Geopark Sustainable Code of Practice for Tourism and the Leave No Trace Code for Outdoor Ethics. They operate a Green Purchasing Policy and have an Environment Action Plan to manage their use of water and energy and minimise waste.</p>    
            </article>
           
                </section>
            
             <section class="producers">
            <article class="second">
            <h2>Burren Kitchen Garden</h2>
			<p>There are only a few pots of Burren Kitchen Garden's winter jelly, jams and relish left. Choose from sloe, blackberry, apple, elderberry,  haws and rosehip.</p>
            <p>There are also a number of chutney and relish varieties still available, so get them before they are gone.</p>
            <a class="btn" title="Shop Now" href="<?php echo "$base/User/doMarketBasic"; ?>">Shop Now</a>
            </article>
                </section>

<?php
$this->load->view('footer'); 
?>