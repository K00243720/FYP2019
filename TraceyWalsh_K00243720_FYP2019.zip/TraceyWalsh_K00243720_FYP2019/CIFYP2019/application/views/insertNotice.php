<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
?>

<div class="limiter notice">
<div class="wrap-login forms">
	
<form id="form1" class="notice" name="form1" class="noticeForm" method="post" enctype="multipart/form-data"  action="<?php echo "$base/Notice/insertNotice"; ?>">

<h2 class="userHead">Add product</h2>

  <div class="wrap-input insertForm">
    <label for="shortDescription">Description:</label>
    <input type="text" name="shortDescription" id="shortDescription" />
  </div>
  <div class="wrap-input insertForm">
    <label for="longDescription">Price and quantity:</label>
    <input type="text" name="longDescription" id="longDescription" />
  </div>
   <div class="wrap-input insertForm">
    <label for="userfile">Image:</label>
	<input name="userfile" type="file" id="userfile" size="45" />
  </div>
   <div class="wrap-input insertForm">
    <label for="area">Area:</label>
    <input type="text" name="area" id="area" />
  </div>
   <div class="wrap-input insertForm">
    <label for="dateExp">Expiry Date: </label>
    <input type="text" name="dateExp" id="dateExp" />
  </div>
  <p>
    <input type="submit" name="button" id="button" class="login-form-btn" value="Submit" />
  </p>
</form>
	</div>
	</div>
	
<?php
$this->load->view('footer'); 
?>