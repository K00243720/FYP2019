 <?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$n = $this->session->userdata('AllNoticeData');
$countdivs = -1;
$user = $this->session->userdata('user');

if(!$n==null){ ?>


<div class="marketarea">
<h2 class="userHead">Hello <?php $user = $this->session->userdata('user'); 
echo $user['FirstName']; ?> </h2>
</div>

        <?php foreach ($n as $notice){
			$countdivs++;
			if ($countdivs%3==0){
				echo "<div class='firstdiv'>";
			} else {
				echo "<div class='floatdiv'>";
			}
			echo "<div id='columns' class='columns_3'>";
			echo "<figure>";
			    echo "<img src=\"$img_base/assets/images/notices/". $notice['largeImage']. "\" /> ";
				echo "<figcaption>";
					echo $notice['shortDescription'];
					echo "</figcaption>";
				echo "<div class='price'>";
					echo $notice['longDescription'];
					echo "</div>";
					echo "<div class='place'>";
					echo $notice['area'];
					echo "</div>";
					echo "<a class='button' value='submit' href=\"$base/User/doOrder/".
					$notice['shortDescription']. '/'. 
					$notice['area']. '/'. 
					$notice['userId']. '/'. 
					$user['UserID'] . '/'.
					$notice['largeImage'] 
					."\">Place Order</a>";
		
				echo "</figure>";
			echo "</div>";
			echo "</div>";
			
		}?>

<?php } ?>    
          

   
<?php
$this->load->view('footer'); 
?>