<?php 
$this->load->helper('url'); 
$cssbase = base_url();
$img_base = base_url();
$jsbase = base_url();
$base = base_url() . index_page();
$user = $this->session->userdata('user');
?>

<!DOCTYPE>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CMP FYP 2019</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="market, farmers' market, food purchasing, organic food" />
<meta name="description" content="Connecting organic growers and producers directly with the local community and their customer base." />
<link href="<?php echo $cssbase . "/assets/css/default.css"?>" rel="stylesheet" type="text/css" media="all" />
<script src="<?php echo $jsbase. "/assets/js/mainScript.js"?>"></script>
</head>

<body>

<div id="page">
    <header>
	<div id="menu">
	<div class="nav"> 
		<div class="nav-header">
		<div class="nav-title">
			<a class="logo" title="The Market Hall" href="<?php echo "$base/User/"; ?>"><span>The Market Hall</span></a>
        </div>
        </div>
		<div class="nav-btn">
			<label for="nav-check">
				<span></span>
                <span></span>
                <span></span>
            </label>
            </div>
			<input type="checkbox" id="nav-check">
			
			<div class="nav-links">
			
		<?php if ($user['UserID'] > 0) {?>
				<?php if ($user['type'] == 1) {?>
					<a href="<?php echo "$base/User/userHomePage/". $user['UserID']; ?>">MY HOME</a>
					<a href="<?php echo "$base/User/doMarket"; ?>">MARKET</a>
				<?php } else { ?>
					<a href="<?php echo "$base/User/doMarket"; ?>">SHOP</a>
				<?php } ?>
				
				<?php if ($user['type'] == 1) {?>
					<a href="<?php echo "$base/User/doOrders/". $user['UserID']; ?>">ORDERS</a>
				<?php } else { ?>
					<a href="<?php echo "$base/User/doOrdersCust/". $user['UserID']; ?>">ORDERS</a>
				<?php } ?>
				
				<a href="<?php echo "$base/User/doProfile/". $user['UserID']; ?>">PROFILE</a>
				<a href="<?php echo "$base/User/logout"; ?>">LOGOUT</a>
				
			<?php } else { ?>
				<a title="Home" href="<?php echo "$base/User/"; ?>">HOME</a>
				<a title="The Market" href="<?php echo "$base/User/doMarketBasic"; ?>">MARKET</a>
				<a title="Producers" href="<?php echo "$base/User/doProducers"; ?>">PRODUCERS</a>
				<a title="Login" href="<?php echo "$base/User/doLogon"; ?>">LOGIN</a>
				<a title="Register" href="<?php echo "$base/User/doRegister"; ?>">REGISTER</a>
			<?php } ?>
			
			</div>
    </div>
	</div>
			 
		<div class="mainHead">
			<h1>The Market Hall</h1>
			<h2 class="secondHead">Try a new way of eating</h2>
			<?php if ($user['UserID'] > 0) {?>
				
			<?php } else {?>
				<a class="btn front" title="Register Now" href="<?php echo "$base/User/doRegister"; ?>">Join the market</a>  
			<?php } ?>
		</div>
        <div class="topImage">
            <img alt="sunflower" src="<?php echo $img_base . "assets/images/sun.png"?>" width="240">
        </div>
    </header>
			 
		  
	<p>&nbsp;</p>