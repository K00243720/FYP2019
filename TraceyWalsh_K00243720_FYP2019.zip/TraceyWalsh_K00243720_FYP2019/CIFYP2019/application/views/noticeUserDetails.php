<?php
$this->load->view('header'); 
$this->load->helper('url');
$img_base = base_url();
$cssbase = base_url();
$base = base_url() . index_page();
$sd = $notice['shortDescription'];
$ld = $notice['longDescription'];
$area = $notice['area'];
$dateExp = $notice['dateExp'];
$image = $notice['largeImage'];
$firstname=$userNotice['FirstName'];
$surname=$userNotice['SurName'];
$mobile=$userNotice['Mobile']; 		
?>

<div class="limiter notice">
<div class="wrap-login forms">

<h2 class="userHead">Product details</h2>

<form id="form1" name="form1" action="<?php echo "$base/User/doProducers"; ?>" >
 <p>
	<img width="300" src="<?php echo $img_base . "assets/images/notices/$image"?>">
  </p>
  <p>
    <label for="shortDescription">Description:</label>
    <input type="text" name="shortDescription" id="shortDescription" value="<?php echo $sd ?>" readonly />
  </p>
  <p>
    <label for="longDescription">Price and quantity:</label>
    <input type="text" name="longDescription" id="longDescription"  value="<?php echo $ld ?>" readonly />
  </p>
  <p>
    <label for="dateExp">Expiry Date:</label>
    <input type="text" name="dateExp" id="dateExp" value="<?php echo $dateExp ?>" readonly />
  </p>
 <p>
    <label for="supplier">Supplier:</label>
    <input type="text" value ="<?php echo $firstname ." " . $surname ?>" readonly />
  </p>
   <p>
    <label for="area">Area:</label> 
    <input type="text" name="area" id="area" value="<?php echo $area?>" readonly />
  </p>
   <input type="submit" name="button" id="button" class="login-form-btn" value="Read more on <?php echo $firstname?>" />
</form>
</div>
	</div>

<?php
$this->load->view('footer'); 
?>