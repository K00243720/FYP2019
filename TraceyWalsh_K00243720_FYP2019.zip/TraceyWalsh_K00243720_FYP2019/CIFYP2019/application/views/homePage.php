<?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$n = $this->session->userdata('AllNoticeData');

if(!$n==null){ ?>

<section class="main">
    
	<h2 class="howto">How it works!</h2>
         <aside> 
            <div class="content order">
            <h3>You place an order</h3>
			<p>Pick your food and chose the collection point where you would like to pick it up.</p>
                    
            </div>
         </aside>
                
        <aside> 
            <div class="content harvest">
                <h3>Harvest time</h3>
				<p>The producer prepares your organically-produced food.</p>       
            </div>
        </aside>
                
        <aside> 
            <div class="content collect">
                <h3>Collect and go</h3>
				<p>Your food will be delivered to the collection point at a specified time.</p>  
            </div>
        </aside>
            
            </section>
            
    <section class="producers">
        <article>
            <h2>Meet our producers</h2>
			<p>Clareville House Kitchen Garden is a grower and artisan food producer in the Burren and Cliffs of Moher Geopark in County Clare, which has become internationally-recognised due to its geological importance and the existence of a network of businesses and environment agencies that oversee tourism in the area, as well as providing ecology education and conservation efforts.</p>
            <a class="btn" title="Meet the producers" href="<?php echo "$base/User/doProducers"; ?>">Learn more</a>
        </article>
    </section>
           
    <section class="products">
        <aside> 
            <div class="content"> 
			<img alt="honey pots" src="<?php echo $img_base . "assets/images/notices/honey.jpg"?>">
            <h4>Highlight of the week</h4>
			<p>100% pure raw, coarse filtered honey available in 12oz jars. Get them before they're gone.</p>
			<a title="Offer of the week" href="<?php echo "$base/User/doMarketBasic"; ?>">Learn more</a>
            </div>
        </aside>
                
        <aside>  
            <div class="content"> 
             <img alt="jam" src="<?php echo $img_base . "assets/images/notices/jam.jpg"?>">
            <h4>There are only a few pots of Burren Kitchen Garden's winter jelly, jams and relish left. Choose from sloe, blackberry, apple, elderberry,  haws and rosehip.</h4>
			<a title="Special Offer" href="<?php echo "$base/User/doMarketBasic"; ?>">Learn more</a>
             </div>
        </aside>
                
         <blockquote>
            <p class="quote">Couldn't believe how easy this site is to use. I listed my produce and within three days the orders started coming in.</p>
			<p class="credit"><strong>Dervla</strong><br> <em>Producer</em><br>Clare Jam Company</p>
        </blockquote>
    
	</section> 	
	
<?php } ?>  

<?php
$this->load->view('footer'); 
?>