 <?php
$this->load->view('header'); 
$this->load->helper('url'); 
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
$n = $this->session->userdata('AllNoticeData');
$countdivs = -1;
$user = $this->session->userdata('user');

if(!$n==null){ ?>


<div class="marketarea">
<h2>Browse our produce</h2>
<a href="<?php echo "$base/User/doLogon"; ?>"><h3>Please sign in to place an order</h3></a>
<br>
</div>

        <?php foreach ($n as $notice){
			$countdivs++;
			if ($countdivs%3==0){
				echo "<div class='firstdiv'>";
			} else {
				echo "<div class='floatdiv'>";
			}
			echo "<div id='columns' class='columns_3'>";
			echo "<figure>";
			 echo "<a href=\"$base/Notice/getDrillDownNoticeAndUser/". 
					$notice['noticeId'] . "\"><img src=\"$img_base/assets/images/notices/". 
					$notice['largeImage']. "\" /> </a>";
				echo "<figcaption>";
					echo $notice['shortDescription'];
					echo "</figcaption>";
				echo "<div class='price'>";
					echo $notice['longDescription'];
					echo "</div>";
					echo "<div class='place'>";
					echo $notice['area'];
					echo "</div>";
				echo "</figure>";
			echo "</div>";
			echo "</div>";
			
		}?>

<?php } ?>    
          

   
<?php
$this->load->view('footer'); 
?>