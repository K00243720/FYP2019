<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$cssbase = base_url();
$img_base = base_url();
?>

<section class="main">
	
<h2 class="userHead">Hello <?php $user = $this->session->userdata('user'); 
$n = $this->session->userdata('noticeData');
echo $user['FirstName']; ?> </h2>
        
				<div class="flex-grid">
				<div class="col1">
				<img class="profileImg" src="<?php echo $img_base . "assets/images/" . $user['Portrait']?>" alt="image profile" width="360">
				<!-- <h4 class="profile">About Me</h4>
				<p>"I love home-made produce, especially jam, bread and honey. I always buy my veg locally."</p>-->
				</div>
				
              <div class="col2">
            <form class="bio-form" id="form1" name="form1" method="post" action="<?php echo "$base/User/saveUserDetails/" . $User['UserID']; ?>">
				<div class="wrap-input">
						<input class="input" id="FirstName" type="text" name="FirstName" placeholder="First Name" value ="<?php echo $User['FirstName'] ?> "/>
				</div>
				<div class="wrap-input">
						<input class="input" id="Surname" type="text" name="Surname" placeholder="Surname" value ="<?php echo $User['SurName'] ?> "/>
				</div>
                    
                    <div class="wrap-input">
						<input class="input" id="AddressLine1" type="text" name="AddressLine1" placeholder="Address 1" value ="<?php echo $User['AddressLine1'] ?> "/>
					</div>
					<div class="wrap-input">
						<input class="input" id="AddressLine2" type="text" name="AddressLine2" placeholder="Address 2" value ="<?php echo $User['AddressLine2'] ?> "/> 
					</div>
					<div class="wrap-input">
						<input class="input" id="AddressLine3" type="text" name="AddressLine3" placeholder="Address 3" value ="<?php echo $User['AddressLine3'] ?> "/> 
					</div>
                    <div class="wrap-input">
						<input class="input" id="Mobile" type="text" name="Mobile" placeholder="Mobile" value ="<?php echo $User['Mobile'] ?> "/>
					</div>

					<div class="wrap-input">
						<input class="input" id="UserName" type="text" name="UserName" placeholder="User Name" value ="<?php echo $User['UserName'] ?> " />
					</div>
					
					<div class="wrap-input">
						<input class="input" id="email" type="text" name="email" placeholder="Email" value ="<?php echo $User['Email'] ?> " />
					</div>
					
					<div class="wrap-input">
						<input class="input" id="Password" type="hidden" name="Password" placeholder="Password" value ="<?php echo $User['Password'] ?> "/>
					</div>
					
					<div class="wrap-input">
						<input class="input" id="Pickup" type="text" name="Pickup" placeholder="Collection Point" value ="<?php echo $User['Pickup'] ?> "/>
					</div>
					
					 <div class="wrap-input insertForms">
					 <label for="userfile">Image:</label>
					 <input name="userfile" type="file" id="userfile" size="45" />
					 </div>
					 
				
			<br>
			<br>
					<div class="form-btn">
						<button class="login-form-btn" name="button" id="button" value="submit">
							Submit changes
						</button>
					</div>
					</form>
			</div>
				</div>	
            </section>
			

<?php
$this->load->view('footer'); 
?>