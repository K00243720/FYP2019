<?php
$this->load->view('header'); 
$this->load->helper('url');
$img_base = base_url();
$cssbase = base_url();
$base = base_url() . index_page();
$sd = $notice['shortDescription'];
$ld = $notice['longDescription'];
$area = $notice['area'];
$dateExp = $notice['dateExp'];
$image = $notice['largeImage'];
?>

<div class="limiter notice">
<div class="wrap-login forms">

<h2 class="userHead">Product details</h2>
<form id="form1" name="form1" method="post" class="noticeForm" enctype="multipart/form-data"  action="<?php echo "$base/Notice/insertNotice"; ?>">
  <p>
    <label for="shortDescription">Description:</label>
    <input type="text" name="shortDescription" id="shortDescription" value="<?php echo $sd ?>" readonly />
  </p>
  <p>
    <label for="longDescription">Price and quantity:</label>
    <input type="text" name="longDescription" id="longDescription" value="<?php echo $ld ?>" readonly />
  </p>
  <p>
	<img width="300" src="<?php echo $img_base . "/assets/images/notices/$image"?>">
  </p>
  <p>
    <label for="area">Area:</label> 
    <input type="text" name="area" id="area" value="<?php echo $area?>" readonly />
  </p>
  <p>
    <label for="dateExp">Expiry Date:</label>
    <input type="text" name="dateExp" id="dateExp" value="<?php echo $dateExp ?>" readonly />
  </p>
 
</form>
</div>
	</div>

<?php
$this->load->view('footer'); 
?>
