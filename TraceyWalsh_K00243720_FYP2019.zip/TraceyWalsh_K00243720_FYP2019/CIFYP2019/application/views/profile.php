<?php
$this->load->view('header');  
$this->load->helper('url'); 
$cssbase = base_url();
$img_base = base_url();
$base = base_url() . index_page();
?>

<section class="main">
	
<h2 class="userHead">Hello <?php $user = $this->session->userdata('user'); 
$n = $this->session->userdata('noticeData');
echo $user['FirstName']; ?> </h2>
<p class="userLink"><a href="<?php echo "$base/User/getUpdateDetails/" . $user['UserID']; ?>">Edit Profile</a></p>
        
				<div class="flex-grid">
				<div class="col1">
				<img class="profileImg" src="<?php echo $img_base . "assets/images/" . $user['Portrait']?>" alt="image profile" width="360">
				<h4 class="profile">About Me</h4>
				<p>"I love homemade produce, especially jam and honey. I always buy my veg locally."</p>
				</div>
				
    <div class="col2">
        <form class="bio-form" id="form1" name="form1" method="post" action="<?php echo "$base/User/saveUserDetails/" . $User['UserID']; ?>" >
				<div class="wrap-input">
						<input class="input" id="FirstName" type="text" name="FirstName" value ="<?php echo $User['FirstName'] ?> "/>
				</div>
				<div class="wrap-input">
						<input class="input" id="Surname" type="text" name="Surname" value ="<?php echo $User['SurName'] ?>" />
				</div>
                    
                    <div class="wrap-input">
						<input class="input" id="AddressLine1" type="text" name="AddressLine1" value ="<?php echo $User['AddressLine1'] ?> "/>
					</div>
					<div class="wrap-input">
						<input class="input" id="AddressLine2" type="text" name="AddressLine2" value ="<?php echo $User['AddressLine2'] ?> "/> 
					</div>
					<div class="wrap-input">
						<input class="input" id="AddressLine3" type="text" name="AddressLine3" value ="<?php echo $User['AddressLine3'] ?> "/> 
					</div>
                    <div class="wrap-input">
						<input class="input" id="Mobile" type="text" name="Mobile" value ="<?php echo $User['Mobile'] ?> "/>
					</div>

					<div class="wrap-input">
						<input class="input" id="UserName" type="text" name="UserName" value ="<?php echo $User['UserName'] ?> " />
					</div>
					
					<div class="wrap-input">
						<input class="input" id="email" type="text" name="email" value ="<?php echo $User['Email'] ?> " />
					</div>
					
					<div class="wrap-input">
						<input class="input" id="Password" type="hidden" name="Password" value ="<?php echo $User['Password'] ?> "/>
					</div>
					
					<div class="wrap-input">
						<input class="input" id="Pickup" type="text" name="Pickup" value ="<?php echo $User['Pickup'] ?> "/>
					</div>
					
				
				</form>
			</div>
				</div>	
			
            </section>

<?php
$this->load->view('footer'); 
?>