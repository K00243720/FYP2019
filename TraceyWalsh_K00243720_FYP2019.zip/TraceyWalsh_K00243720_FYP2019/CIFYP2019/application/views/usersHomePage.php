<?php
$this->load->view('header'); 
$this->load->helper('url');
$base = base_url() . index_page();
$img_base = base_url();
$cssbase = base_url();
?>

<h2 class="userHead">Hello <?php $user = $this->session->userdata('user');

$n = $this->session->userdata('noticeData');
echo $user['FirstName']; ?> </h2>

<?php if ($user['type'] == 1) {?>

<p class="userLink"><a href="<?php echo "$base/Notice/doInsertNotice/"?>">Add Item</a></p>
<?php
if(!$n==null){
?>
	<table class="center" border="0">
		
<?php
		foreach ($n as $notice){
			echo "<tr>";
				echo "<td> <a href=\"$base/Notice/getDrillDownNotice/". 
					$notice['noticeId'] . "\"><img src=\"$img_base/assets/images/notices/". 
					$notice['largeImage']. "\" /> </a> </td>";
				echo "<td>" . $notice['shortDescription'] . "</td>";
				echo "<td>" . $notice['area'] . "</td>";
				echo "<td>	<a href=\"$base/Notice/doEditNotice/". $notice['noticeId'] . "\">Edit" ."<br>";
				echo "<a href=\"$base/Notice/deleteNotice/". $notice['noticeId'] . "\">Delete	</td>" ;  
			echo "</tr>";
		}
?>
	</table>
  <?php } ?>              

<?php } ?>
  
  
<?php
$this->load->view('footer'); 
?>