<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-05 11:44:45 --> Config Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Hooks Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Utf8 Class Initialized
DEBUG - 2019-04-05 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-05 11:44:45 --> URI Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Router Class Initialized
DEBUG - 2019-04-05 11:44:45 --> No URI present. Default controller set.
DEBUG - 2019-04-05 11:44:45 --> Output Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Security Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Input Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-05 11:44:45 --> Language Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Loader Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Controller Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Model Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Model Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Database Driver Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Session Class Initialized
DEBUG - 2019-04-05 11:44:45 --> Helper loaded: string_helper
DEBUG - 2019-04-05 11:44:45 --> A session cookie was not found.
DEBUG - 2019-04-05 11:44:46 --> Session routines successfully run
DEBUG - 2019-04-05 11:44:46 --> Model Class Initialized
DEBUG - 2019-04-05 11:44:46 --> Helper loaded: url_helper
DEBUG - 2019-04-05 11:44:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-05 11:44:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-05 11:44:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-05 11:44:46 --> Final output sent to browser
DEBUG - 2019-04-05 11:44:46 --> Total execution time: 1.6537
