<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-01 09:31:22 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:22 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:22 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:22 --> No URI present. Default controller set.
DEBUG - 2019-05-01 09:31:22 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:22 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:23 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:23 --> A session cookie was not found.
DEBUG - 2019-05-01 09:31:24 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:24 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:24 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:24 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:25 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:25 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 09:31:25 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:25 --> Total execution time: 3.0302
DEBUG - 2019-05-01 09:31:34 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:34 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:34 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:34 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:34 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:34 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:34 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:34 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:34 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:34 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:34 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 09:31:34 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:34 --> Total execution time: 0.1889
DEBUG - 2019-05-01 09:31:41 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:41 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:42 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:42 --> Session garbage collection performed.
DEBUG - 2019-05-01 09:31:42 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:42 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:42 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:42 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:42 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:42 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:42 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 09:31:42 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:42 --> Total execution time: 0.6475
DEBUG - 2019-05-01 09:31:45 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:45 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:45 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:45 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:45 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:45 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:45 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:45 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:45 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:46 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:46 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:46 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:31:46 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:46 --> Total execution time: 0.2574
DEBUG - 2019-05-01 09:31:51 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:51 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:51 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:51 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:51 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:51 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:51 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:52 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:52 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:52 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:52 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:52 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:52 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:52 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:52 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:52 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:31:52 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:52 --> Total execution time: 0.2242
DEBUG - 2019-05-01 09:31:58 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:58 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:58 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:58 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:58 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:58 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:58 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:58 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:31:58 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:31:58 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:31:58 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 09:31:58 --> Final output sent to browser
DEBUG - 2019-05-01 09:31:58 --> Total execution time: 0.0780
DEBUG - 2019-05-01 09:31:59 --> Config Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:31:59 --> URI Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Router Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Output Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Security Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Input Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:31:59 --> Language Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Loader Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Controller Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Session Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:31:59 --> Session routines successfully run
DEBUG - 2019-05-01 09:31:59 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Model Class Initialized
DEBUG - 2019-05-01 09:31:59 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:31:59 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:31:59 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Config Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:32:00 --> URI Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Router Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Output Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Security Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Input Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:32:00 --> Language Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Loader Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Controller Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Session Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:32:00 --> Session garbage collection performed.
DEBUG - 2019-05-01 09:32:00 --> Session routines successfully run
DEBUG - 2019-05-01 09:32:00 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:00 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:32:00 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:32:00 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:32:00 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:32:00 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:32:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:32:00 --> Final output sent to browser
DEBUG - 2019-05-01 09:32:00 --> Total execution time: 0.1388
DEBUG - 2019-05-01 09:32:23 --> Config Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:32:23 --> URI Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Router Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Output Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Security Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Input Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:32:23 --> Language Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Loader Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Controller Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Session Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:32:23 --> Session routines successfully run
DEBUG - 2019-05-01 09:32:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Model Class Initialized
DEBUG - 2019-05-01 09:32:23 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:32:23 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:32:23 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:32:23 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:32:23 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:32:23 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:32:23 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:32:23 --> Final output sent to browser
DEBUG - 2019-05-01 09:32:23 --> Total execution time: 0.3245
DEBUG - 2019-05-01 09:34:44 --> Config Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:34:44 --> URI Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Router Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Output Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Security Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Input Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:34:44 --> Language Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Loader Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Controller Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Session Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:34:44 --> Session routines successfully run
DEBUG - 2019-05-01 09:34:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:34:44 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:34:44 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:34:44 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:34:45 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:34:45 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:35:10 --> Config Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:35:10 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:35:10 --> URI Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Router Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Output Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Security Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Input Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:35:10 --> Language Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Loader Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Controller Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Session Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:35:10 --> Session routines successfully run
DEBUG - 2019-05-01 09:35:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:10 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:35:10 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:35:10 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:35:10 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:35:10 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:35:50 --> Config Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:35:50 --> URI Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Router Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Output Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Security Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Input Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:35:50 --> Language Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Loader Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Controller Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Session Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:35:50 --> Session routines successfully run
DEBUG - 2019-05-01 09:35:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:35:50 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:35:50 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:35:50 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:35:50 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:35:50 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:36:30 --> Config Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:36:30 --> URI Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Router Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Output Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Security Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Input Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:36:30 --> Language Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Loader Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Controller Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Session Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:36:30 --> Session routines successfully run
DEBUG - 2019-05-01 09:36:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:30 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:36:30 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:36:30 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:36:30 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:36:30 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:36:41 --> Config Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:36:41 --> URI Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Router Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Output Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Security Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Input Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:36:41 --> Language Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Loader Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Controller Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Session Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:36:41 --> Session routines successfully run
DEBUG - 2019-05-01 09:36:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:36:41 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:36:41 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:36:41 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Config Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:38:24 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:38:24 --> URI Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Router Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Output Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Security Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Input Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:38:24 --> Language Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Loader Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Controller Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Session Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:38:24 --> Session routines successfully run
DEBUG - 2019-05-01 09:38:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:24 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:38:24 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:38:24 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:38:24 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:38:24 --> Severity: Notice  --> Undefined variable: str C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-05-01 09:38:24 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-05-01 09:38:24 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:38:24 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:38:24 --> Final output sent to browser
DEBUG - 2019-05-01 09:38:24 --> Total execution time: 0.5018
DEBUG - 2019-05-01 09:38:58 --> Config Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:38:58 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:38:58 --> URI Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Router Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Output Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Security Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Input Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:38:58 --> Language Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Loader Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Controller Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Session Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:38:58 --> Session routines successfully run
DEBUG - 2019-05-01 09:38:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Model Class Initialized
DEBUG - 2019-05-01 09:38:58 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:38:58 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:38:58 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:38:58 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:38:58 --> Severity: Notice  --> Undefined variable: str C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
DEBUG - 2019-05-01 09:38:58 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:38:58 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:38:58 --> Final output sent to browser
DEBUG - 2019-05-01 09:38:58 --> Total execution time: 0.2093
DEBUG - 2019-05-01 09:40:10 --> Config Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:40:10 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:40:10 --> URI Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Router Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Output Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Security Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Input Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:40:10 --> Language Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Loader Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Controller Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Session Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:40:10 --> Session routines successfully run
DEBUG - 2019-05-01 09:40:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:40:10 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:40:10 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:40:10 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:40:10 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:40:10 --> Severity: Notice  --> Undefined variable: str C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
DEBUG - 2019-05-01 09:40:10 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:40:10 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:40:10 --> Final output sent to browser
DEBUG - 2019-05-01 09:40:10 --> Total execution time: 0.1819
DEBUG - 2019-05-01 09:41:02 --> Config Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:41:02 --> URI Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Router Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Output Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Security Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Input Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:41:02 --> Language Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Loader Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Controller Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Model Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Model Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Session Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:41:02 --> Session routines successfully run
DEBUG - 2019-05-01 09:41:02 --> Model Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Model Class Initialized
DEBUG - 2019-05-01 09:41:02 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:41:02 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:41:02 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:41:02 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:41:02 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
DEBUG - 2019-05-01 09:41:02 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:41:02 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:41:02 --> Final output sent to browser
DEBUG - 2019-05-01 09:41:02 --> Total execution time: 0.2071
DEBUG - 2019-05-01 09:42:35 --> Config Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:42:35 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:42:35 --> URI Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Router Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Output Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Security Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Input Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:42:35 --> Language Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Loader Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Controller Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Model Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Model Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Session Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:42:35 --> Session routines successfully run
DEBUG - 2019-05-01 09:42:35 --> Model Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Model Class Initialized
DEBUG - 2019-05-01 09:42:35 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:42:35 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:42:35 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:42:35 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:42:35 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 9
DEBUG - 2019-05-01 09:42:35 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:42:35 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:42:35 --> Final output sent to browser
DEBUG - 2019-05-01 09:42:35 --> Total execution time: 0.1805
DEBUG - 2019-05-01 09:43:13 --> Config Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:43:13 --> URI Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Router Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Output Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Security Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Input Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:43:13 --> Language Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Loader Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Controller Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Session Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:43:13 --> Session routines successfully run
DEBUG - 2019-05-01 09:43:13 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:13 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:43:13 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:43:13 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:43:13 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:43:13 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 9
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
ERROR - 2019-05-01 09:43:13 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 27
DEBUG - 2019-05-01 09:43:13 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:43:13 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:43:13 --> Final output sent to browser
DEBUG - 2019-05-01 09:43:13 --> Total execution time: 0.1383
DEBUG - 2019-05-01 09:43:50 --> Config Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:43:50 --> URI Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Router Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Output Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Security Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Input Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:43:50 --> Language Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Loader Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Controller Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Session Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:43:50 --> Session routines successfully run
DEBUG - 2019-05-01 09:43:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Model Class Initialized
DEBUG - 2019-05-01 09:43:50 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:43:50 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:43:50 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:43:50 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:43:50 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 9
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:43:50 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
DEBUG - 2019-05-01 09:43:50 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:43:50 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:43:50 --> Final output sent to browser
DEBUG - 2019-05-01 09:43:50 --> Total execution time: 0.1406
DEBUG - 2019-05-01 09:44:10 --> Config Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:44:10 --> URI Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Router Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Output Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Security Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Input Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:44:10 --> Language Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Loader Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Controller Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Session Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:44:10 --> Session routines successfully run
DEBUG - 2019-05-01 09:44:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Model Class Initialized
DEBUG - 2019-05-01 09:44:10 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:44:10 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:44:10 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:44:10 --> File loaded: application/views/header.php
ERROR - 2019-05-01 09:44:10 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 9
ERROR - 2019-05-01 09:44:10 --> Severity: Notice  --> Undefined variable: Detail C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 10
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
ERROR - 2019-05-01 09:44:10 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 28
DEBUG - 2019-05-01 09:44:10 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:44:10 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:44:10 --> Final output sent to browser
DEBUG - 2019-05-01 09:44:10 --> Total execution time: 0.1412
DEBUG - 2019-05-01 09:45:16 --> Config Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:45:16 --> URI Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Router Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Output Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Security Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Input Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:45:16 --> Language Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Loader Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Controller Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Session Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:45:16 --> Session routines successfully run
DEBUG - 2019-05-01 09:45:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:45:16 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:45:16 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:45:16 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:45:16 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:45:16 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:45:16 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:45:16 --> Final output sent to browser
DEBUG - 2019-05-01 09:45:16 --> Total execution time: 0.0887
DEBUG - 2019-05-01 09:46:25 --> Config Class Initialized
DEBUG - 2019-05-01 09:46:25 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:46:26 --> URI Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Router Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Output Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Security Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Input Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:46:26 --> Language Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Loader Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Controller Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Session Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:46:26 --> Session routines successfully run
DEBUG - 2019-05-01 09:46:26 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:26 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:46:26 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:46:26 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:46:26 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:46:26 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:46:26 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:46:26 --> Final output sent to browser
DEBUG - 2019-05-01 09:46:26 --> Total execution time: 0.1203
DEBUG - 2019-05-01 09:46:56 --> Config Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:46:56 --> URI Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Router Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Output Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Security Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Input Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:46:56 --> Language Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Loader Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Controller Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Session Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:46:56 --> Session routines successfully run
DEBUG - 2019-05-01 09:46:56 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:56 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:46:56 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:46:56 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:46:56 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:46:56 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:46:56 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:46:56 --> Final output sent to browser
DEBUG - 2019-05-01 09:46:56 --> Total execution time: 0.1346
DEBUG - 2019-05-01 09:46:57 --> Config Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:46:57 --> URI Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Router Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Output Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Security Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Input Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:46:57 --> Language Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Loader Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Controller Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Session Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:46:57 --> Session routines successfully run
DEBUG - 2019-05-01 09:46:57 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Model Class Initialized
DEBUG - 2019-05-01 09:46:57 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:46:57 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:46:57 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:46:57 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:46:57 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:46:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 09:46:57 --> Final output sent to browser
DEBUG - 2019-05-01 09:46:57 --> Total execution time: 0.1308
DEBUG - 2019-05-01 09:47:14 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:14 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:14 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:14 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:14 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:14 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:14 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:14 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:14 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:14 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:14 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:47:14 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:14 --> Total execution time: 0.1350
DEBUG - 2019-05-01 09:47:16 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:16 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:16 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:16 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:16 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:16 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:16 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:16 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:16 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:16 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 09:47:16 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:16 --> Total execution time: 0.0454
DEBUG - 2019-05-01 09:47:18 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:18 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:18 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:18 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:18 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:18 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:18 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:18 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:18 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:18 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:18 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:18 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:18 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:47:18 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:18 --> Total execution time: 0.1119
DEBUG - 2019-05-01 09:47:19 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:19 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:19 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:19 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:19 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:19 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:19 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:19 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:19 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:19 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:19 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:47:19 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:19 --> Total execution time: 0.1450
DEBUG - 2019-05-01 09:47:44 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:44 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:44 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:44 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:44 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:44 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:44 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:44 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:44 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:44 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:44 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:44 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:44 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:44 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:44 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:47:44 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:44 --> Total execution time: 0.1199
DEBUG - 2019-05-01 09:47:48 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:48 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:48 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:48 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:48 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:48 --> Config Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:47:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:47:48 --> URI Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Router Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Output Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Security Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Input Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:47:48 --> Language Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Loader Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Controller Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Session Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:47:48 --> Session routines successfully run
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Model Class Initialized
DEBUG - 2019-05-01 09:47:48 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:47:48 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:47:48 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:47:48 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:47:48 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:47:48 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:47:48 --> Final output sent to browser
DEBUG - 2019-05-01 09:47:48 --> Total execution time: 0.1035
DEBUG - 2019-05-01 09:48:05 --> Config Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:48:05 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:48:05 --> URI Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Router Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Output Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Security Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Input Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:48:05 --> Language Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Loader Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Controller Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Model Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Model Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Session Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:48:05 --> Session routines successfully run
DEBUG - 2019-05-01 09:48:05 --> Model Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Model Class Initialized
DEBUG - 2019-05-01 09:48:05 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:48:05 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:48:05 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:48:05 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:48:05 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:48:05 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 09:48:05 --> Final output sent to browser
DEBUG - 2019-05-01 09:48:05 --> Total execution time: 0.1381
DEBUG - 2019-05-01 09:49:11 --> Config Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:49:11 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:49:11 --> URI Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Router Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Output Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Security Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Input Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:49:11 --> Language Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Loader Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Controller Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Session Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:49:11 --> Session routines successfully run
DEBUG - 2019-05-01 09:49:11 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:11 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:49:11 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:49:11 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:49:11 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:49:11 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:49:11 --> File loaded: application/views/profile.php
DEBUG - 2019-05-01 09:49:11 --> Final output sent to browser
DEBUG - 2019-05-01 09:49:11 --> Total execution time: 0.0633
DEBUG - 2019-05-01 09:49:15 --> Config Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:49:15 --> URI Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Router Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Output Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Security Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Input Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:49:15 --> Language Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Loader Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Controller Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Session Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:49:15 --> Session routines successfully run
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:49:15 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Config Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:49:15 --> URI Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Router Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Output Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Security Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Input Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:49:15 --> Language Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Loader Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Controller Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Session Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:49:15 --> A session cookie was not found.
DEBUG - 2019-05-01 09:49:15 --> Session routines successfully run
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Model Class Initialized
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:49:15 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:49:15 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:49:15 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:49:15 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:49:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 09:49:15 --> Final output sent to browser
DEBUG - 2019-05-01 09:49:15 --> Total execution time: 0.1072
DEBUG - 2019-05-01 09:57:30 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:30 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:30 --> No URI present. Default controller set.
DEBUG - 2019-05-01 09:57:30 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:30 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:30 --> A session cookie was not found.
DEBUG - 2019-05-01 09:57:30 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:30 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:30 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:30 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:31 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:57:31 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:57:31 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 09:57:31 --> Final output sent to browser
DEBUG - 2019-05-01 09:57:31 --> Total execution time: 0.2463
DEBUG - 2019-05-01 09:57:36 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:36 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:36 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:36 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:36 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:36 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:36 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:36 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:36 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:36 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:57:36 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:57:36 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 09:57:36 --> Final output sent to browser
DEBUG - 2019-05-01 09:57:36 --> Total execution time: 0.0648
DEBUG - 2019-05-01 09:57:41 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:41 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:41 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:41 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:41 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:41 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:41 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:41 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:57:41 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:57:41 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 09:57:41 --> Final output sent to browser
DEBUG - 2019-05-01 09:57:41 --> Total execution time: 0.1443
DEBUG - 2019-05-01 09:57:42 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:42 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:42 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:42 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:42 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:42 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:42 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:42 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:42 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:57:42 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:57:42 --> File loaded: application/views/profile.php
DEBUG - 2019-05-01 09:57:42 --> Final output sent to browser
DEBUG - 2019-05-01 09:57:42 --> Total execution time: 0.0682
DEBUG - 2019-05-01 09:57:44 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:44 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:44 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:44 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:44 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Config Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Hooks Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Utf8 Class Initialized
DEBUG - 2019-05-01 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 09:57:44 --> URI Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Router Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Output Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Security Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Input Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 09:57:44 --> Language Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Loader Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Controller Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Database Driver Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Session Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: string_helper
DEBUG - 2019-05-01 09:57:44 --> A session cookie was not found.
DEBUG - 2019-05-01 09:57:44 --> Session routines successfully run
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Model Class Initialized
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: url_helper
DEBUG - 2019-05-01 09:57:44 --> Helper loaded: form_helper
DEBUG - 2019-05-01 09:57:44 --> Form Validation Class Initialized
DEBUG - 2019-05-01 09:57:44 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 09:57:44 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 09:57:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 09:57:44 --> Final output sent to browser
DEBUG - 2019-05-01 09:57:44 --> Total execution time: 0.1731
DEBUG - 2019-05-01 11:14:56 --> Config Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:14:56 --> URI Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Router Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Output Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Security Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Input Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:14:56 --> Language Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Loader Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Controller Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Model Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Model Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Session Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:14:56 --> Session garbage collection performed.
DEBUG - 2019-05-01 11:14:56 --> Session routines successfully run
DEBUG - 2019-05-01 11:14:56 --> Model Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Model Class Initialized
DEBUG - 2019-05-01 11:14:56 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:14:56 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:14:56 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:14:56 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:14:56 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:14:56 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-05-01 11:14:56 --> Final output sent to browser
DEBUG - 2019-05-01 11:14:56 --> Total execution time: 0.1599
DEBUG - 2019-05-01 11:15:02 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:02 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:02 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:02 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:02 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:02 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:02 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:02 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:02 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:02 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:02 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:15:02 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:02 --> Total execution time: 0.1188
DEBUG - 2019-05-01 11:15:16 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:16 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:16 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:16 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:16 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:16 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:16 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:16 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:16 --> File loaded: application/views/insertUser.php
DEBUG - 2019-05-01 11:15:16 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:16 --> Total execution time: 0.0571
DEBUG - 2019-05-01 11:15:20 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:20 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:20 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:20 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:20 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:20 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:20 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:20 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:20 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:20 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:20 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:15:20 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:20 --> Total execution time: 0.0981
DEBUG - 2019-05-01 11:15:22 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:22 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:22 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:22 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:22 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:22 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:22 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:22 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:22 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:22 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:15:22 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:22 --> Total execution time: 0.1816
DEBUG - 2019-05-01 11:15:23 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:23 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:23 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:23 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:24 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:24 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:24 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:24 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:24 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:24 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:24 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:24 --> File loaded: application/views/producers.php
DEBUG - 2019-05-01 11:15:24 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:24 --> Total execution time: 0.0572
DEBUG - 2019-05-01 11:15:29 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:29 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:29 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:29 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:29 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:29 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:29 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:29 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:29 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:15:29 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:29 --> Total execution time: 0.0991
DEBUG - 2019-05-01 11:15:32 --> Config Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:15:32 --> URI Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Router Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Output Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Security Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Input Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:15:32 --> Language Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Loader Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Controller Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Session Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:15:32 --> Session routines successfully run
DEBUG - 2019-05-01 11:15:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:15:32 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:15:32 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:15:32 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:15:32 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:15:32 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:15:32 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-05-01 11:15:32 --> Final output sent to browser
DEBUG - 2019-05-01 11:15:32 --> Total execution time: 0.0601
DEBUG - 2019-05-01 11:18:13 --> Config Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:18:13 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:18:13 --> URI Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Router Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Output Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Security Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Input Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:18:13 --> Language Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Loader Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Controller Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Session Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:18:13 --> Session routines successfully run
DEBUG - 2019-05-01 11:18:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:13 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:18:13 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:18:13 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:18:13 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:18:13 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:18:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 11:18:13 --> Final output sent to browser
DEBUG - 2019-05-01 11:18:13 --> Total execution time: 0.0576
DEBUG - 2019-05-01 11:18:25 --> Config Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:18:25 --> URI Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Router Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Output Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Security Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Input Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:18:25 --> Language Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Loader Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Controller Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Session Class Initialized
DEBUG - 2019-05-01 11:18:25 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:18:25 --> Session routines successfully run
DEBUG - 2019-05-01 11:18:25 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:18:25 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:18:25 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:18:25 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-05-01 11:18:25 --> Final output sent to browser
DEBUG - 2019-05-01 11:18:25 --> Total execution time: 0.0665
DEBUG - 2019-05-01 11:18:51 --> Config Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:18:51 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:18:51 --> URI Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Router Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Output Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Security Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Input Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:18:51 --> Language Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Loader Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Controller Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Session Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:18:51 --> Session routines successfully run
DEBUG - 2019-05-01 11:18:51 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Model Class Initialized
DEBUG - 2019-05-01 11:18:51 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:18:51 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:18:51 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:18:51 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:18:51 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:18:51 --> File loaded: application/views/producers.php
DEBUG - 2019-05-01 11:18:51 --> Final output sent to browser
DEBUG - 2019-05-01 11:18:51 --> Total execution time: 0.0545
DEBUG - 2019-05-01 11:19:01 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:01 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:01 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:01 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:01 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:01 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:01 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:01 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:01 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:01 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:01 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:01 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-05-01 11:19:01 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:01 --> Total execution time: 0.0686
DEBUG - 2019-05-01 11:19:07 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:07 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:07 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:07 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:07 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:07 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:07 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:07 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:07 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:07 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:07 --> File loaded: application/views/producers.php
DEBUG - 2019-05-01 11:19:07 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:07 --> Total execution time: 0.0640
DEBUG - 2019-05-01 11:19:42 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:42 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:42 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:42 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:42 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:42 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:42 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:42 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:42 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:42 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:42 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-05-01 11:19:42 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:42 --> Total execution time: 0.0719
DEBUG - 2019-05-01 11:19:43 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:43 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:43 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:43 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:43 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:43 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:43 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:43 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:43 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:43 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-05-01 11:19:43 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:43 --> Total execution time: 0.0626
DEBUG - 2019-05-01 11:19:45 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:45 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:45 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:45 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:45 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:45 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:45 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:45 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:45 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:45 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:45 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:45 --> File loaded: application/views/producers.php
DEBUG - 2019-05-01 11:19:45 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:45 --> Total execution time: 0.0550
DEBUG - 2019-05-01 11:19:48 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:48 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:48 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:48 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:48 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:48 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:48 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:48 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:48 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:48 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 11:19:48 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:48 --> Total execution time: 0.0566
DEBUG - 2019-05-01 11:19:49 --> Config Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:19:49 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:19:49 --> URI Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Router Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Output Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Security Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Input Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:19:49 --> Language Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Loader Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Controller Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Session Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:19:49 --> Session garbage collection performed.
DEBUG - 2019-05-01 11:19:49 --> Session routines successfully run
DEBUG - 2019-05-01 11:19:49 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Model Class Initialized
DEBUG - 2019-05-01 11:19:49 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:19:49 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:19:49 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:19:49 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:19:49 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:19:49 --> File loaded: application/views/insertUser.php
DEBUG - 2019-05-01 11:19:49 --> Final output sent to browser
DEBUG - 2019-05-01 11:19:49 --> Total execution time: 0.0553
DEBUG - 2019-05-01 11:21:02 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:02 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:02 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:02 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:02 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:02 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:02 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:21:02 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:21:02 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:21:02 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:21:02 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-05-01 11:21:02 --> Final output sent to browser
DEBUG - 2019-05-01 11:21:02 --> Total execution time: 0.2742
DEBUG - 2019-05-01 11:21:16 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:16 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:16 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:16 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:21:16 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:16 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:16 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:16 --> A session cookie was not found.
DEBUG - 2019-05-01 11:21:16 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:16 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:21:16 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:21:17 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:21:17 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:21:17 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:21:17 --> Final output sent to browser
DEBUG - 2019-05-01 11:21:17 --> Total execution time: 0.2085
DEBUG - 2019-05-01 11:21:21 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:21 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:21 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:21 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:21 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:21 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:21 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:21:21 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:21:21 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:21:21 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:21:21 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 11:21:21 --> Final output sent to browser
DEBUG - 2019-05-01 11:21:21 --> Total execution time: 0.0721
DEBUG - 2019-05-01 11:21:27 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:27 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:27 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:27 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:27 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:27 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:27 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:21:27 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:21:27 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:21:27 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:21:27 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-05-01 11:21:27 --> Final output sent to browser
DEBUG - 2019-05-01 11:21:27 --> Total execution time: 0.1606
DEBUG - 2019-05-01 11:21:43 --> Config Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:21:43 --> URI Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Router Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Output Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Security Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Input Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:21:43 --> Language Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Loader Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Controller Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Session Class Initialized
DEBUG - 2019-05-01 11:21:43 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:21:43 --> Session routines successfully run
DEBUG - 2019-05-01 11:21:43 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:21:43 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:21:43 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:21:43 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-05-01 11:21:43 --> Final output sent to browser
DEBUG - 2019-05-01 11:21:43 --> Total execution time: 0.0646
DEBUG - 2019-05-01 11:24:32 --> Config Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:24:32 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:24:32 --> URI Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Router Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Output Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Security Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Input Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:24:32 --> Language Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Loader Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Controller Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Session Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:24:32 --> Session routines successfully run
DEBUG - 2019-05-01 11:24:32 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:24:32 --> Upload Class Initialized
DEBUG - 2019-05-01 11:24:32 --> Image Lib Class Initialized
DEBUG - 2019-05-01 11:24:32 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:24:32 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:24:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-05-01 11:24:32 --> Final output sent to browser
DEBUG - 2019-05-01 11:24:32 --> Total execution time: 0.1929
DEBUG - 2019-05-01 11:24:41 --> Config Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:24:41 --> URI Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Router Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Output Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Security Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Input Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:24:41 --> Language Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Loader Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Controller Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Session Class Initialized
DEBUG - 2019-05-01 11:24:41 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:24:41 --> Session routines successfully run
DEBUG - 2019-05-01 11:24:41 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:24:41 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:24:41 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:24:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-05-01 11:24:41 --> Final output sent to browser
DEBUG - 2019-05-01 11:24:41 --> Total execution time: 0.1643
DEBUG - 2019-05-01 11:24:46 --> Config Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:24:46 --> URI Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Router Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Output Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Security Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Input Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:24:46 --> Language Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Loader Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Controller Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Session Class Initialized
DEBUG - 2019-05-01 11:24:46 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:24:46 --> Session routines successfully run
DEBUG - 2019-05-01 11:24:46 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:24:46 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:24:46 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:24:46 --> File loaded: application/views/editNotice.php
DEBUG - 2019-05-01 11:24:46 --> Final output sent to browser
DEBUG - 2019-05-01 11:24:46 --> Total execution time: 0.0522
DEBUG - 2019-05-01 11:25:13 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:13 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:13 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:13 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:13 --> Session garbage collection performed.
DEBUG - 2019-05-01 11:25:13 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:13 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:13 --> Upload Class Initialized
DEBUG - 2019-05-01 11:25:13 --> Image Lib Class Initialized
DEBUG - 2019-05-01 11:25:14 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:25:14 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:25:14 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-05-01 11:25:14 --> Final output sent to browser
DEBUG - 2019-05-01 11:25:14 --> Total execution time: 0.1589
DEBUG - 2019-05-01 11:25:21 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:21 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:21 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:21 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:21 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:21 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:25:21 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:25:21 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:25:21 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:25:21 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-05-01 11:25:21 --> Final output sent to browser
DEBUG - 2019-05-01 11:25:21 --> Total execution time: 0.1618
DEBUG - 2019-05-01 11:25:41 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:41 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:41 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:41 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:41 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:41 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:41 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:41 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:41 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:41 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:41 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:25:41 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:25:41 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:25:41 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:25:41 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 11:25:41 --> Final output sent to browser
DEBUG - 2019-05-01 11:25:41 --> Total execution time: 0.0694
DEBUG - 2019-05-01 11:25:46 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:46 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:46 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:46 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:46 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:46 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:25:46 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:25:46 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:25:46 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:25:46 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 11:25:46 --> Final output sent to browser
DEBUG - 2019-05-01 11:25:46 --> Total execution time: 0.0571
DEBUG - 2019-05-01 11:25:53 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:53 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:53 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:53 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:25:53 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Config Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:25:53 --> URI Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Router Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Output Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Security Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Input Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:25:53 --> Language Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Loader Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Controller Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Session Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:25:53 --> Session routines successfully run
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Model Class Initialized
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:25:53 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:25:53 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:25:53 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:25:53 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:25:53 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 11:25:53 --> Final output sent to browser
DEBUG - 2019-05-01 11:25:53 --> Total execution time: 0.1043
DEBUG - 2019-05-01 11:26:39 --> Config Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:26:39 --> URI Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Router Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Output Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Security Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Input Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:26:39 --> Language Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Loader Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Controller Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Session Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:26:39 --> Session routines successfully run
DEBUG - 2019-05-01 11:26:39 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:26:39 --> Config Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:26:39 --> URI Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Router Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Output Class Initialized
DEBUG - 2019-05-01 11:26:39 --> Security Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Input Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:26:40 --> Language Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Loader Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Controller Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Session Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:26:40 --> Session routines successfully run
DEBUG - 2019-05-01 11:26:40 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:40 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:26:40 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:26:40 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:26:40 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:26:40 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:26:40 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 11:26:40 --> Final output sent to browser
DEBUG - 2019-05-01 11:26:40 --> Total execution time: 0.0892
DEBUG - 2019-05-01 11:26:43 --> Config Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:26:43 --> URI Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Router Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Output Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Security Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Input Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:26:43 --> Language Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Loader Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Controller Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Session Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:26:43 --> Session routines successfully run
DEBUG - 2019-05-01 11:26:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Model Class Initialized
DEBUG - 2019-05-01 11:26:43 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:26:43 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:26:43 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:26:43 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:26:43 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:26:43 --> File loaded: application/views/profile.php
DEBUG - 2019-05-01 11:26:43 --> Final output sent to browser
DEBUG - 2019-05-01 11:26:43 --> Total execution time: 0.0597
DEBUG - 2019-05-01 11:27:22 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:22 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:22 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:22 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:22 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:22 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:22 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:22 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:22 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:27:22 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:27:22 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-05-01 11:27:22 --> Final output sent to browser
DEBUG - 2019-05-01 11:27:22 --> Total execution time: 0.0591
DEBUG - 2019-05-01 11:27:34 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:34 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:34 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:34 --> Session garbage collection performed.
DEBUG - 2019-05-01 11:27:34 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:34 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:34 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:34 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:34 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:48 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:48 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:48 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:48 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:48 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:48 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:48 --> A session cookie was not found.
DEBUG - 2019-05-01 11:27:48 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:48 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:48 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:49 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:27:49 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:27:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:27:49 --> Final output sent to browser
DEBUG - 2019-05-01 11:27:49 --> Total execution time: 0.1926
DEBUG - 2019-05-01 11:27:52 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:52 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:52 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:52 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:52 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:52 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:52 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:52 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:52 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:27:52 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:27:52 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-01 11:27:52 --> Final output sent to browser
DEBUG - 2019-05-01 11:27:52 --> Total execution time: 0.0551
DEBUG - 2019-05-01 11:27:58 --> Config Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:27:58 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:27:58 --> URI Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Router Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Output Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Security Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Input Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:27:58 --> Language Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Loader Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Controller Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Session Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:27:58 --> Session routines successfully run
DEBUG - 2019-05-01 11:27:58 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Model Class Initialized
DEBUG - 2019-05-01 11:27:58 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:27:58 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:27:58 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:27:58 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:27:58 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:27:58 --> File loaded: application/views/market.php
DEBUG - 2019-05-01 11:27:58 --> Final output sent to browser
DEBUG - 2019-05-01 11:27:58 --> Total execution time: 0.1312
DEBUG - 2019-05-01 11:28:05 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:05 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:05 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:05 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:05 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:05 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:05 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:28:05 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:28:05 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:28:05 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:28:05 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 11:28:05 --> Final output sent to browser
DEBUG - 2019-05-01 11:28:05 --> Total execution time: 0.1313
DEBUG - 2019-05-01 11:28:22 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:22 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:22 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:22 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:22 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:22 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:22 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:22 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:22 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:22 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:22 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:28:22 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:28:22 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:28:22 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:28:22 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-05-01 11:28:22 --> Final output sent to browser
DEBUG - 2019-05-01 11:28:22 --> Total execution time: 0.1167
DEBUG - 2019-05-01 11:28:26 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:26 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:26 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:26 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:26 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:26 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:26 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:28:26 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:28:26 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:28:26 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:28:26 --> File loaded: application/views/profile.php
DEBUG - 2019-05-01 11:28:26 --> Final output sent to browser
DEBUG - 2019-05-01 11:28:26 --> Total execution time: 0.0738
DEBUG - 2019-05-01 11:28:28 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:28 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:28 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:28 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:28 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:28:28 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Config Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:28:28 --> URI Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Router Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Output Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Security Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Input Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:28:28 --> Language Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Loader Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Controller Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:28 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:28:29 --> Session Class Initialized
DEBUG - 2019-05-01 11:28:29 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:28:29 --> A session cookie was not found.
DEBUG - 2019-05-01 11:28:29 --> Session routines successfully run
DEBUG - 2019-05-01 11:28:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:29 --> Model Class Initialized
DEBUG - 2019-05-01 11:28:29 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:28:29 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:28:29 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:28:29 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:28:29 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:28:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 11:28:29 --> Final output sent to browser
DEBUG - 2019-05-01 11:28:29 --> Total execution time: 0.1812
DEBUG - 2019-05-01 11:29:47 --> Config Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Hooks Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Utf8 Class Initialized
DEBUG - 2019-05-01 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 11:29:47 --> URI Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Router Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Output Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Security Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Input Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 11:29:47 --> Language Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Loader Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Controller Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Model Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Model Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Database Driver Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Session Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Helper loaded: string_helper
DEBUG - 2019-05-01 11:29:47 --> Session routines successfully run
DEBUG - 2019-05-01 11:29:47 --> Model Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Model Class Initialized
DEBUG - 2019-05-01 11:29:47 --> Helper loaded: url_helper
DEBUG - 2019-05-01 11:29:47 --> Helper loaded: form_helper
DEBUG - 2019-05-01 11:29:47 --> Form Validation Class Initialized
DEBUG - 2019-05-01 11:29:47 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 11:29:47 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 11:29:47 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-05-01 11:29:47 --> Final output sent to browser
DEBUG - 2019-05-01 11:29:47 --> Total execution time: 0.0509
DEBUG - 2019-05-01 14:49:35 --> Config Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Hooks Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Utf8 Class Initialized
DEBUG - 2019-05-01 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2019-05-01 14:49:35 --> URI Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Router Class Initialized
DEBUG - 2019-05-01 14:49:35 --> No URI present. Default controller set.
DEBUG - 2019-05-01 14:49:35 --> Output Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Security Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Input Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-01 14:49:35 --> Language Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Loader Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Controller Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Model Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Model Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Database Driver Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Session Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Helper loaded: string_helper
DEBUG - 2019-05-01 14:49:35 --> A session cookie was not found.
DEBUG - 2019-05-01 14:49:35 --> Session routines successfully run
DEBUG - 2019-05-01 14:49:35 --> Model Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Model Class Initialized
DEBUG - 2019-05-01 14:49:35 --> Helper loaded: url_helper
DEBUG - 2019-05-01 14:49:35 --> Helper loaded: form_helper
DEBUG - 2019-05-01 14:49:35 --> Form Validation Class Initialized
DEBUG - 2019-05-01 14:49:35 --> File loaded: application/views/header.php
DEBUG - 2019-05-01 14:49:35 --> File loaded: application/views/footer.php
DEBUG - 2019-05-01 14:49:35 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-01 14:49:35 --> Final output sent to browser
DEBUG - 2019-05-01 14:49:35 --> Total execution time: 0.2625
