<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-11 11:14:15 --> Config Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:14:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:14:15 --> URI Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Router Class Initialized
DEBUG - 2019-04-11 11:14:15 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:14:15 --> Output Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Security Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Input Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:14:15 --> Language Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Loader Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Controller Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Session Class Initialized
DEBUG - 2019-04-11 11:14:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:14:15 --> A session cookie was not found.
DEBUG - 2019-04-11 11:14:15 --> Session routines successfully run
DEBUG - 2019-04-11 11:14:16 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:14:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:14:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:14:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:14:16 --> Final output sent to browser
DEBUG - 2019-04-11 11:14:16 --> Total execution time: 1.1184
DEBUG - 2019-04-11 11:14:35 --> Config Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:14:35 --> URI Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Router Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Output Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Security Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Input Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:14:35 --> Language Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Loader Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Controller Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Session Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:14:35 --> Session routines successfully run
DEBUG - 2019-04-11 11:14:35 --> Model Class Initialized
DEBUG - 2019-04-11 11:14:35 --> Helper loaded: url_helper
ERROR - 2019-04-11 11:14:35 --> 404 Page Not Found --> User/index_page%22%3Cspan
DEBUG - 2019-04-11 11:15:52 --> Config Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:15:52 --> URI Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Router Class Initialized
DEBUG - 2019-04-11 11:15:52 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:15:52 --> Output Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Security Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Input Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:15:52 --> Language Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Loader Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Controller Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Session Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:15:52 --> Session routines successfully run
DEBUG - 2019-04-11 11:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:15:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:15:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:15:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:15:52 --> Final output sent to browser
DEBUG - 2019-04-11 11:15:52 --> Total execution time: 0.1457
DEBUG - 2019-04-11 11:15:55 --> Config Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:15:55 --> URI Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Router Class Initialized
DEBUG - 2019-04-11 11:15:55 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:15:55 --> Output Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Security Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Input Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:15:55 --> Language Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Loader Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Controller Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Session Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:15:55 --> Session routines successfully run
DEBUG - 2019-04-11 11:15:55 --> Model Class Initialized
DEBUG - 2019-04-11 11:15:55 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:15:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:15:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:15:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:15:55 --> Final output sent to browser
DEBUG - 2019-04-11 11:15:55 --> Total execution time: 0.1287
DEBUG - 2019-04-11 11:16:52 --> Config Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:16:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:16:52 --> URI Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Router Class Initialized
DEBUG - 2019-04-11 11:16:52 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:16:52 --> Output Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Security Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Input Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:16:52 --> Language Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Loader Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Controller Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Session Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:16:52 --> Session routines successfully run
DEBUG - 2019-04-11 11:16:52 --> Model Class Initialized
DEBUG - 2019-04-11 11:16:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:16:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:16:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:16:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:16:52 --> Final output sent to browser
DEBUG - 2019-04-11 11:16:52 --> Total execution time: 0.1251
DEBUG - 2019-04-11 11:18:33 --> Config Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:18:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:18:33 --> URI Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Router Class Initialized
DEBUG - 2019-04-11 11:18:33 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:18:33 --> Output Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Security Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Input Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:18:33 --> Language Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Loader Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Controller Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Session Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:18:33 --> Session routines successfully run
DEBUG - 2019-04-11 11:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 11:18:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:18:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:18:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:18:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:18:33 --> Final output sent to browser
DEBUG - 2019-04-11 11:18:33 --> Total execution time: 0.1247
DEBUG - 2019-04-11 11:19:14 --> Config Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:19:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:19:14 --> URI Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Router Class Initialized
DEBUG - 2019-04-11 11:19:14 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:19:14 --> Output Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Security Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Input Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:19:14 --> Language Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Loader Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Controller Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Model Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Model Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Session Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:19:14 --> Session routines successfully run
DEBUG - 2019-04-11 11:19:14 --> Model Class Initialized
DEBUG - 2019-04-11 11:19:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:19:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:19:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:19:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:19:15 --> Final output sent to browser
DEBUG - 2019-04-11 11:19:15 --> Total execution time: 0.1451
DEBUG - 2019-04-11 11:30:10 --> Config Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:30:10 --> URI Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Router Class Initialized
DEBUG - 2019-04-11 11:30:10 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:30:10 --> Output Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Security Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Input Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:30:10 --> Language Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Loader Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Controller Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Session Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:30:10 --> Session routines successfully run
DEBUG - 2019-04-11 11:30:10 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:30:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:30:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:30:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:30:10 --> Final output sent to browser
DEBUG - 2019-04-11 11:30:10 --> Total execution time: 0.1818
DEBUG - 2019-04-11 11:30:12 --> Config Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:30:12 --> URI Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Router Class Initialized
DEBUG - 2019-04-11 11:30:12 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:30:12 --> Output Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Security Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Input Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:30:12 --> Language Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Loader Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Controller Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Session Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:30:12 --> Session routines successfully run
DEBUG - 2019-04-11 11:30:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:30:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:30:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:30:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:30:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:30:12 --> Final output sent to browser
DEBUG - 2019-04-11 11:30:12 --> Total execution time: 0.1078
DEBUG - 2019-04-11 11:33:54 --> Config Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:33:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:33:54 --> URI Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Router Class Initialized
DEBUG - 2019-04-11 11:33:54 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:33:54 --> Output Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Security Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Input Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:33:54 --> Language Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Loader Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Controller Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Model Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Model Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Session Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:33:54 --> Session routines successfully run
DEBUG - 2019-04-11 11:33:54 --> Model Class Initialized
DEBUG - 2019-04-11 11:33:54 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:33:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:33:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:33:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:33:54 --> Final output sent to browser
DEBUG - 2019-04-11 11:33:54 --> Total execution time: 0.1093
DEBUG - 2019-04-11 11:50:41 --> Config Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:50:41 --> URI Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Router Class Initialized
DEBUG - 2019-04-11 11:50:41 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:50:41 --> Output Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Security Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Input Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:50:41 --> Language Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Loader Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Controller Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Model Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Model Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Session Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:50:41 --> Session routines successfully run
DEBUG - 2019-04-11 11:50:41 --> Model Class Initialized
DEBUG - 2019-04-11 11:50:41 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:50:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:50:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:50:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:50:41 --> Final output sent to browser
DEBUG - 2019-04-11 11:50:41 --> Total execution time: 0.1908
DEBUG - 2019-04-11 11:55:12 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:12 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:12 --> No URI present. Default controller set.
DEBUG - 2019-04-11 11:55:12 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:12 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:12 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:12 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:12 --> Total execution time: 0.1387
DEBUG - 2019-04-11 11:55:39 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:39 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:39 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:39 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:39 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:39 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:39 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:39 --> Total execution time: 0.1360
DEBUG - 2019-04-11 11:55:42 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:42 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:42 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:42 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:42 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:42 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:42 --> Total execution time: 0.1801
DEBUG - 2019-04-11 11:55:43 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:43 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:43 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:43 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:43 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:43 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:43 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:43 --> Total execution time: 0.0639
DEBUG - 2019-04-11 11:55:44 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:44 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:44 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:44 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:44 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:44 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:44 --> Total execution time: 0.0645
DEBUG - 2019-04-11 11:55:45 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:45 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:45 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:45 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:45 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:45 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:45 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 11:55:45 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:45 --> Total execution time: 0.0516
DEBUG - 2019-04-11 11:55:47 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:47 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:47 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:47 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:47 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:47 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 11:55:47 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:47 --> Total execution time: 0.1421
DEBUG - 2019-04-11 11:55:53 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:53 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:53 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:53 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:53 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:53 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:53 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:53 --> Total execution time: 0.0685
DEBUG - 2019-04-11 11:55:57 --> Config Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 11:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 11:55:57 --> URI Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Router Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Output Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Security Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Input Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 11:55:57 --> Language Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Loader Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Controller Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Database Driver Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Session Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Helper loaded: string_helper
DEBUG - 2019-04-11 11:55:57 --> Session routines successfully run
DEBUG - 2019-04-11 11:55:57 --> Model Class Initialized
DEBUG - 2019-04-11 11:55:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 11:55:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 11:55:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 11:55:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 11:55:57 --> Final output sent to browser
DEBUG - 2019-04-11 11:55:57 --> Total execution time: 0.1031
DEBUG - 2019-04-11 12:43:18 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:18 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:18 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:18 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:43:18 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:18 --> Total execution time: 0.1991
DEBUG - 2019-04-11 12:43:20 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:20 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:20 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:20 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:20 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 12:43:20 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:20 --> Total execution time: 0.0621
DEBUG - 2019-04-11 12:43:22 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:22 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:22 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:22 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:22 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:22 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:43:22 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:22 --> Total execution time: 0.0793
DEBUG - 2019-04-11 12:43:23 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:23 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:23 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:23 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:23 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:23 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:43:23 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:23 --> Total execution time: 0.0985
DEBUG - 2019-04-11 12:43:24 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:24 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:24 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:24 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:43:24 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:24 --> Total execution time: 0.0796
DEBUG - 2019-04-11 12:43:24 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:24 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:24 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:24 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:24 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:24 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 12:43:24 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:24 --> Total execution time: 0.0464
DEBUG - 2019-04-11 12:43:25 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:25 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:25 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:25 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:25 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:25 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:25 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 12:43:25 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:25 --> Total execution time: 0.0620
DEBUG - 2019-04-11 12:43:26 --> Config Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:43:26 --> URI Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Router Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Output Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Security Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Input Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:43:26 --> Language Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Loader Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Controller Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Session Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:43:26 --> Session routines successfully run
DEBUG - 2019-04-11 12:43:26 --> Model Class Initialized
DEBUG - 2019-04-11 12:43:26 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:43:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:43:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:43:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:43:27 --> Final output sent to browser
DEBUG - 2019-04-11 12:43:27 --> Total execution time: 0.1458
DEBUG - 2019-04-11 12:47:55 --> Config Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:47:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:47:55 --> URI Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Router Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Output Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Security Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Input Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:47:55 --> Language Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Loader Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Controller Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Session Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:47:55 --> Session routines successfully run
DEBUG - 2019-04-11 12:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 12:47:55 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:51:52 --> Config Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:51:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:51:52 --> URI Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Router Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Output Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Security Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Input Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:51:52 --> Language Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Loader Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Controller Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Session Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:51:52 --> Session routines successfully run
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:51:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:51:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:51:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:51:52 --> Final output sent to browser
DEBUG - 2019-04-11 12:51:52 --> Total execution time: 0.1866
DEBUG - 2019-04-11 12:51:52 --> Config Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Config Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:51:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:51:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:51:52 --> URI Class Initialized
DEBUG - 2019-04-11 12:51:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:51:52 --> Router Class Initialized
DEBUG - 2019-04-11 12:51:52 --> URI Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Router Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Output Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Output Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Security Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Input Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:51:52 --> Security Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Language Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Input Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:51:52 --> Loader Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Language Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Controller Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Loader Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Controller Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Session Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:51:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Session routines successfully run
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Session Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: string_helper
ERROR - 2019-04-11 12:51:52 --> 404 Page Not Found --> User/img
DEBUG - 2019-04-11 12:51:52 --> Session routines successfully run
DEBUG - 2019-04-11 12:51:52 --> Model Class Initialized
DEBUG - 2019-04-11 12:51:52 --> Helper loaded: url_helper
ERROR - 2019-04-11 12:51:52 --> 404 Page Not Found --> User/img
DEBUG - 2019-04-11 12:55:14 --> Config Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:55:14 --> URI Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Router Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Output Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Security Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Input Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:55:14 --> Language Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Loader Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Controller Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Session Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:55:14 --> Session routines successfully run
DEBUG - 2019-04-11 12:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:55:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:55:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:55:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:55:14 --> Final output sent to browser
DEBUG - 2019-04-11 12:55:14 --> Total execution time: 0.1244
DEBUG - 2019-04-11 12:55:18 --> Config Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:55:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:55:18 --> URI Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Router Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Output Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Security Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Input Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:55:18 --> Language Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Loader Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Controller Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Session Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:55:18 --> Session routines successfully run
DEBUG - 2019-04-11 12:55:18 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:55:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:55:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:55:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:55:18 --> Final output sent to browser
DEBUG - 2019-04-11 12:55:18 --> Total execution time: 0.1123
DEBUG - 2019-04-11 12:55:19 --> Config Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:55:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:55:19 --> URI Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Router Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Output Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Security Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Input Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:55:19 --> Language Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Loader Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Controller Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Session Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:55:19 --> Session routines successfully run
DEBUG - 2019-04-11 12:55:19 --> Model Class Initialized
DEBUG - 2019-04-11 12:55:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:55:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:55:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:55:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:55:19 --> Final output sent to browser
DEBUG - 2019-04-11 12:55:19 --> Total execution time: 0.1156
DEBUG - 2019-04-11 12:57:03 --> Config Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:57:03 --> URI Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Router Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Output Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Security Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Input Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:57:03 --> Language Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Loader Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Controller Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Session Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:57:03 --> Session routines successfully run
DEBUG - 2019-04-11 12:57:03 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:03 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:57:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:57:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:57:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:57:03 --> Final output sent to browser
DEBUG - 2019-04-11 12:57:03 --> Total execution time: 0.1730
DEBUG - 2019-04-11 12:57:04 --> Config Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Hooks Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Utf8 Class Initialized
DEBUG - 2019-04-11 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 12:57:04 --> URI Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Router Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Output Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Security Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Input Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 12:57:04 --> Language Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Loader Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Controller Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Database Driver Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Session Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Helper loaded: string_helper
DEBUG - 2019-04-11 12:57:04 --> Session routines successfully run
DEBUG - 2019-04-11 12:57:04 --> Model Class Initialized
DEBUG - 2019-04-11 12:57:04 --> Helper loaded: url_helper
DEBUG - 2019-04-11 12:57:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 12:57:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 12:57:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 12:57:04 --> Final output sent to browser
DEBUG - 2019-04-11 12:57:04 --> Total execution time: 0.1324
DEBUG - 2019-04-11 13:03:57 --> Config Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 13:03:57 --> URI Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Router Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Output Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Security Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Input Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 13:03:57 --> Language Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Loader Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Controller Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Model Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Model Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Database Driver Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Session Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Helper loaded: string_helper
DEBUG - 2019-04-11 13:03:57 --> Session routines successfully run
DEBUG - 2019-04-11 13:03:57 --> Model Class Initialized
DEBUG - 2019-04-11 13:03:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 13:03:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 13:03:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 13:03:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 13:03:57 --> Final output sent to browser
DEBUG - 2019-04-11 13:03:57 --> Total execution time: 0.1627
DEBUG - 2019-04-11 14:19:12 --> Config Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:19:12 --> URI Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Router Class Initialized
DEBUG - 2019-04-11 14:19:12 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:19:12 --> Output Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Security Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Input Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:19:12 --> Language Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Loader Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Controller Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Model Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Model Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Session Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:19:12 --> Session routines successfully run
DEBUG - 2019-04-11 14:19:12 --> Model Class Initialized
DEBUG - 2019-04-11 14:19:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:19:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:19:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:19:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:19:12 --> Final output sent to browser
DEBUG - 2019-04-11 14:19:12 --> Total execution time: 0.1675
DEBUG - 2019-04-11 14:23:14 --> Config Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:23:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:23:14 --> URI Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Router Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Output Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Security Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Input Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:23:14 --> Language Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Loader Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Controller Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Session Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:23:14 --> Session routines successfully run
DEBUG - 2019-04-11 14:23:14 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:14 --> Helper loaded: url_helper
ERROR - 2019-04-11 14:23:14 --> 404 Page Not Found --> User/index_page%22%3Cspan
DEBUG - 2019-04-11 14:23:58 --> Config Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:23:58 --> URI Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Router Class Initialized
DEBUG - 2019-04-11 14:23:58 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:23:58 --> Output Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Security Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Input Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:23:58 --> Language Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Loader Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Controller Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Session Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:23:58 --> Session routines successfully run
DEBUG - 2019-04-11 14:23:58 --> Model Class Initialized
DEBUG - 2019-04-11 14:23:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:23:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:23:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:23:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:23:58 --> Final output sent to browser
DEBUG - 2019-04-11 14:23:58 --> Total execution time: 0.1049
DEBUG - 2019-04-11 14:24:01 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:01 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:01 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:01 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:01 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:01 --> Helper loaded: url_helper
ERROR - 2019-04-11 14:24:01 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 14:24:04 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:04 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:04 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:24:04 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:04 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:04 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:04 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:04 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:24:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:24:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:24:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:24:04 --> Final output sent to browser
DEBUG - 2019-04-11 14:24:04 --> Total execution time: 0.0793
DEBUG - 2019-04-11 14:24:07 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:07 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:07 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:07 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:07 --> Helper loaded: url_helper
ERROR - 2019-04-11 14:24:07 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 14:24:37 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:37 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:37 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:24:37 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:37 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:37 --> Session garbage collection performed.
DEBUG - 2019-04-11 14:24:37 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:37 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:37 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:24:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:24:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:24:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:24:38 --> Final output sent to browser
DEBUG - 2019-04-11 14:24:38 --> Total execution time: 0.3084
DEBUG - 2019-04-11 14:24:39 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:39 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:39 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:39 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:39 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:39 --> Helper loaded: url_helper
ERROR - 2019-04-11 14:24:39 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 14:24:43 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:43 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:43 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:24:43 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:43 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:43 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:43 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:24:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:24:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:24:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:24:43 --> Final output sent to browser
DEBUG - 2019-04-11 14:24:43 --> Total execution time: 0.0901
DEBUG - 2019-04-11 14:24:44 --> Config Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:24:44 --> URI Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Router Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Output Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Security Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Input Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:24:44 --> Language Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Loader Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Controller Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Session Class Initialized
DEBUG - 2019-04-11 14:24:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:24:45 --> Session routines successfully run
DEBUG - 2019-04-11 14:24:45 --> Model Class Initialized
DEBUG - 2019-04-11 14:24:45 --> Helper loaded: url_helper
ERROR - 2019-04-11 14:24:45 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 14:51:21 --> Config Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:51:21 --> URI Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Router Class Initialized
DEBUG - 2019-04-11 14:51:21 --> No URI present. Default controller set.
DEBUG - 2019-04-11 14:51:21 --> Output Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Security Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Input Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:51:21 --> Language Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Loader Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Controller Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Session Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:51:21 --> Session routines successfully run
DEBUG - 2019-04-11 14:51:21 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:51:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:51:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:51:21 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:51:21 --> Final output sent to browser
DEBUG - 2019-04-11 14:51:21 --> Total execution time: 0.1476
DEBUG - 2019-04-11 14:51:24 --> Config Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 14:51:24 --> URI Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Router Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Output Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Security Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Input Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 14:51:24 --> Language Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Loader Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Controller Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Session Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 14:51:24 --> Session routines successfully run
DEBUG - 2019-04-11 14:51:24 --> Model Class Initialized
DEBUG - 2019-04-11 14:51:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 14:51:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 14:51:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 14:51:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 14:51:24 --> Final output sent to browser
DEBUG - 2019-04-11 14:51:24 --> Total execution time: 0.1141
DEBUG - 2019-04-11 15:12:16 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:16 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:16 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:16 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:12:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:12:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:12:17 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:12:17 --> Final output sent to browser
DEBUG - 2019-04-11 15:12:17 --> Total execution time: 0.1485
DEBUG - 2019-04-11 15:12:18 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:18 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:18 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:18 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:12:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:12:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:12:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:12:18 --> Final output sent to browser
DEBUG - 2019-04-11 15:12:18 --> Total execution time: 0.0981
DEBUG - 2019-04-11 15:12:19 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:19 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:19 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:19 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:12:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:12:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:12:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:12:20 --> Final output sent to browser
DEBUG - 2019-04-11 15:12:20 --> Total execution time: 0.1187
DEBUG - 2019-04-11 15:12:20 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:20 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:20 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:20 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:20 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:12:20 --> 404 Page Not Found --> User/doProducer
DEBUG - 2019-04-11 15:12:24 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:24 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:24 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:24 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:24 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:12:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:12:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:12:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:12:24 --> Final output sent to browser
DEBUG - 2019-04-11 15:12:24 --> Total execution time: 0.0657
DEBUG - 2019-04-11 15:12:25 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:25 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:25 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:25 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:25 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:12:25 --> 404 Page Not Found --> User/doProducer
DEBUG - 2019-04-11 15:12:26 --> Config Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:12:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:12:26 --> URI Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Router Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Output Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Security Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Input Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:12:26 --> Language Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Loader Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Controller Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Session Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:12:26 --> Session routines successfully run
DEBUG - 2019-04-11 15:12:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:12:26 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:12:26 --> 404 Page Not Found --> User/doProducer
DEBUG - 2019-04-11 15:15:19 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:19 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:19 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:19 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:19 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:19 --> Total execution time: 0.1106
DEBUG - 2019-04-11 15:15:25 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:25 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:25 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:26 --> No URI present. Default controller set.
DEBUG - 2019-04-11 15:15:26 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:26 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:26 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:26 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:26 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:26 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:26 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:26 --> Total execution time: 0.1122
DEBUG - 2019-04-11 15:15:27 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:27 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:27 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:27 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:27 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:15:27 --> 404 Page Not Found --> User/doProducer
DEBUG - 2019-04-11 15:15:31 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:31 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:31 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:31 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:31 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:31 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:31 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:31 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:31 --> Total execution time: 0.0679
DEBUG - 2019-04-11 15:15:42 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:42 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:42 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:42 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:42 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:42 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 15:15:42 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:42 --> Total execution time: 0.0711
DEBUG - 2019-04-11 15:15:44 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:44 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:44 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:44 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:44 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 15:15:44 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:44 --> Total execution time: 0.0516
DEBUG - 2019-04-11 15:15:45 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:45 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:45 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:45 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:45 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:45 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:45 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 15:15:45 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:45 --> Total execution time: 0.0605
DEBUG - 2019-04-11 15:15:47 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:47 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:47 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:47 --> Session garbage collection performed.
DEBUG - 2019-04-11 15:15:47 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:47 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:47 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:15:47 --> 404 Page Not Found --> User/doProducer
DEBUG - 2019-04-11 15:15:50 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:50 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:50 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:50 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:50 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:50 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:50 --> Total execution time: 0.1206
DEBUG - 2019-04-11 15:15:52 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:52 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:52 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:52 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:52 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:52 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:52 --> Total execution time: 0.0598
DEBUG - 2019-04-11 15:15:53 --> Config Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:15:53 --> URI Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Router Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Output Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Security Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Input Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:15:53 --> Language Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Loader Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Controller Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Session Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:15:53 --> Session routines successfully run
DEBUG - 2019-04-11 15:15:53 --> Model Class Initialized
DEBUG - 2019-04-11 15:15:53 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:15:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:15:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:15:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:15:53 --> Final output sent to browser
DEBUG - 2019-04-11 15:15:53 --> Total execution time: 0.0656
DEBUG - 2019-04-11 15:22:44 --> Config Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:22:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:22:44 --> URI Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Router Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Output Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Security Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Input Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:22:44 --> Language Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Loader Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Controller Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Session Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:22:44 --> Session routines successfully run
DEBUG - 2019-04-11 15:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:22:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:22:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:22:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:22:44 --> Final output sent to browser
DEBUG - 2019-04-11 15:22:44 --> Total execution time: 0.1270
DEBUG - 2019-04-11 15:22:48 --> Config Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:22:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:22:48 --> URI Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Router Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Output Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Security Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Input Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:22:48 --> Language Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Loader Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Controller Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Session Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:22:48 --> Session routines successfully run
DEBUG - 2019-04-11 15:22:48 --> Model Class Initialized
DEBUG - 2019-04-11 15:22:48 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:22:48 --> File loaded: application/views/header.php
ERROR - 2019-04-11 15:22:48 --> Severity: Notice  --> Undefined variable: img_base C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\producers.php 12
DEBUG - 2019-04-11 15:22:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:22:48 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:22:48 --> Final output sent to browser
DEBUG - 2019-04-11 15:22:48 --> Total execution time: 0.0569
DEBUG - 2019-04-11 15:23:05 --> Config Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:23:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:23:05 --> URI Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Router Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Output Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Security Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Input Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:23:05 --> Language Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Loader Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Controller Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Session Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:23:05 --> Session routines successfully run
DEBUG - 2019-04-11 15:23:05 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:05 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:23:05 --> File loaded: application/views/header.php
ERROR - 2019-04-11 15:23:05 --> Severity: Notice  --> Undefined variable: img_base C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\producers.php 12
DEBUG - 2019-04-11 15:23:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:23:05 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:23:05 --> Final output sent to browser
DEBUG - 2019-04-11 15:23:05 --> Total execution time: 0.0609
DEBUG - 2019-04-11 15:23:37 --> Config Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:23:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:23:37 --> URI Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Router Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Output Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Security Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Input Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:23:37 --> Language Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Loader Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Controller Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Session Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:23:37 --> Session routines successfully run
DEBUG - 2019-04-11 15:23:37 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:37 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:23:37 --> File loaded: application/views/header.php
ERROR - 2019-04-11 15:23:37 --> Severity: Notice  --> Undefined variable: img_base C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\producers.php 12
DEBUG - 2019-04-11 15:23:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:23:37 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:23:37 --> Final output sent to browser
DEBUG - 2019-04-11 15:23:37 --> Total execution time: 0.0717
DEBUG - 2019-04-11 15:23:38 --> Config Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:23:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:23:38 --> URI Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Router Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Output Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Security Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Input Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:23:38 --> Language Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Loader Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Controller Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Session Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:23:38 --> Session routines successfully run
DEBUG - 2019-04-11 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-11 15:23:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:23:38 --> File loaded: application/views/header.php
ERROR - 2019-04-11 15:23:38 --> Severity: Notice  --> Undefined variable: img_base C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\producers.php 12
DEBUG - 2019-04-11 15:23:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:23:38 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:23:38 --> Final output sent to browser
DEBUG - 2019-04-11 15:23:38 --> Total execution time: 0.0545
DEBUG - 2019-04-11 15:24:21 --> Config Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:24:21 --> URI Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Router Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Output Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Security Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Input Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:24:21 --> Language Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Loader Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Controller Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Session Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:24:21 --> Session routines successfully run
DEBUG - 2019-04-11 15:24:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:24:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:24:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:24:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:24:21 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:24:21 --> Final output sent to browser
DEBUG - 2019-04-11 15:24:21 --> Total execution time: 0.0596
DEBUG - 2019-04-11 15:27:16 --> Config Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:27:16 --> URI Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Router Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Output Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Security Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Input Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:27:16 --> Language Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Loader Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Controller Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Session Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:27:16 --> Session routines successfully run
DEBUG - 2019-04-11 15:27:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:27:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:27:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:27:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:27:16 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:27:16 --> Final output sent to browser
DEBUG - 2019-04-11 15:27:16 --> Total execution time: 0.0666
DEBUG - 2019-04-11 15:30:13 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:13 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:13 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:13 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:14 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:14 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:14 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:30:14 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:14 --> Total execution time: 0.1151
DEBUG - 2019-04-11 15:30:16 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:16 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:16 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:16 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:16 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:30:16 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:16 --> Total execution time: 0.2757
DEBUG - 2019-04-11 15:30:17 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:17 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:17 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:17 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:17 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:17 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:30:17 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:17 --> Total execution time: 0.0923
DEBUG - 2019-04-11 15:30:18 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:18 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:18 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:18 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:30:18 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:18 --> Total execution time: 0.0938
DEBUG - 2019-04-11 15:30:19 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:19 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:19 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:19 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:19 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 15:30:19 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:19 --> Total execution time: 0.0467
DEBUG - 2019-04-11 15:30:21 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:21 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:21 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:21 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:21 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 15:30:21 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:21 --> Total execution time: 0.0476
DEBUG - 2019-04-11 15:30:22 --> Config Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:30:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:30:22 --> URI Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Router Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Output Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Security Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Input Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:30:22 --> Language Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Loader Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Controller Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Session Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:30:22 --> Session routines successfully run
DEBUG - 2019-04-11 15:30:22 --> Model Class Initialized
DEBUG - 2019-04-11 15:30:22 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:30:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:30:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:30:22 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:30:22 --> Final output sent to browser
DEBUG - 2019-04-11 15:30:22 --> Total execution time: 0.0520
DEBUG - 2019-04-11 15:58:20 --> Config Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:58:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:58:20 --> URI Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Router Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Output Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Security Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Input Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:58:20 --> Language Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Loader Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Controller Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Session Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:58:20 --> Session routines successfully run
DEBUG - 2019-04-11 15:58:20 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:20 --> Helper loaded: url_helper
ERROR - 2019-04-11 15:58:20 --> 404 Page Not Found --> User/Market.html
DEBUG - 2019-04-11 15:58:25 --> Config Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:58:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:58:25 --> URI Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Router Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Output Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Security Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Input Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:58:25 --> Language Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Loader Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Controller Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Session Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:58:25 --> Session routines successfully run
DEBUG - 2019-04-11 15:58:25 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:25 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:58:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:58:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:58:25 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 15:58:25 --> Final output sent to browser
DEBUG - 2019-04-11 15:58:25 --> Total execution time: 0.0556
DEBUG - 2019-04-11 15:58:27 --> Config Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:58:27 --> URI Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Router Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Output Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Security Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Input Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:58:27 --> Language Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Loader Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Controller Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Session Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:58:27 --> Session routines successfully run
DEBUG - 2019-04-11 15:58:27 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:58:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:58:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:58:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 15:58:27 --> Final output sent to browser
DEBUG - 2019-04-11 15:58:27 --> Total execution time: 0.0840
DEBUG - 2019-04-11 15:58:28 --> Config Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 15:58:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 15:58:28 --> URI Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Router Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Output Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Security Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Input Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 15:58:28 --> Language Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Loader Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Controller Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Session Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 15:58:28 --> Session routines successfully run
DEBUG - 2019-04-11 15:58:28 --> Model Class Initialized
DEBUG - 2019-04-11 15:58:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 15:58:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 15:58:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 15:58:28 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 15:58:28 --> Final output sent to browser
DEBUG - 2019-04-11 15:58:28 --> Total execution time: 0.0512
DEBUG - 2019-04-11 16:03:28 --> Config Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:03:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:03:28 --> URI Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Router Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Output Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Security Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Input Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:03:28 --> Language Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Loader Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Controller Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Session Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:03:28 --> Session routines successfully run
DEBUG - 2019-04-11 16:03:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:03:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:03:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:03:28 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 16:03:28 --> Final output sent to browser
DEBUG - 2019-04-11 16:03:28 --> Total execution time: 0.1066
DEBUG - 2019-04-11 16:03:32 --> Config Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:03:32 --> URI Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Router Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Output Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Security Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Input Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:03:32 --> Language Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Loader Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Controller Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Session Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:03:32 --> Session routines successfully run
DEBUG - 2019-04-11 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:03:32 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:03:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:03:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:03:32 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:03:32 --> Final output sent to browser
DEBUG - 2019-04-11 16:03:32 --> Total execution time: 0.0605
DEBUG - 2019-04-11 16:13:38 --> Config Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:13:38 --> URI Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Router Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Output Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Security Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Input Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:13:38 --> Language Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Loader Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Controller Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Session Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:13:38 --> Session routines successfully run
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 16:13:38 --> Final output sent to browser
DEBUG - 2019-04-11 16:13:38 --> Total execution time: 0.1186
DEBUG - 2019-04-11 16:13:38 --> Config Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:13:38 --> URI Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Router Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Output Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Security Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Input Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:13:38 --> Language Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Loader Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Controller Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Session Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:13:38 --> Session routines successfully run
DEBUG - 2019-04-11 16:13:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:13:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:13:38 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:13:38 --> Final output sent to browser
DEBUG - 2019-04-11 16:13:38 --> Total execution time: 0.0390
DEBUG - 2019-04-11 16:17:07 --> Config Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:17:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:17:07 --> URI Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Router Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Output Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Security Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Input Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:17:07 --> Language Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Loader Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Controller Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Session Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:17:07 --> Session routines successfully run
DEBUG - 2019-04-11 16:17:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:17:07 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:17:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:17:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:17:07 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:17:07 --> Final output sent to browser
DEBUG - 2019-04-11 16:17:07 --> Total execution time: 0.0698
DEBUG - 2019-04-11 16:18:44 --> Config Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:18:44 --> URI Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Router Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Output Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Security Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Input Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:18:44 --> Language Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Loader Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Controller Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Session Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:18:44 --> Session routines successfully run
DEBUG - 2019-04-11 16:18:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:18:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:18:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:18:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:18:44 --> Final output sent to browser
DEBUG - 2019-04-11 16:18:44 --> Total execution time: 0.1454
DEBUG - 2019-04-11 16:18:47 --> Config Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:18:47 --> URI Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Router Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Output Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Security Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Input Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:18:47 --> Language Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Loader Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Controller Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Session Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:18:47 --> Session routines successfully run
DEBUG - 2019-04-11 16:18:47 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:18:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:18:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:18:47 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:18:47 --> Final output sent to browser
DEBUG - 2019-04-11 16:18:47 --> Total execution time: 0.1083
DEBUG - 2019-04-11 16:18:49 --> Config Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:18:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:18:49 --> URI Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Router Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Output Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Security Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Input Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:18:49 --> Language Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Loader Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Controller Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Session Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:18:49 --> Session routines successfully run
DEBUG - 2019-04-11 16:18:49 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:49 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:18:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:18:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:18:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:18:49 --> Final output sent to browser
DEBUG - 2019-04-11 16:18:49 --> Total execution time: 0.1087
DEBUG - 2019-04-11 16:18:50 --> Config Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:18:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:18:50 --> URI Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Router Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Output Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Security Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Input Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:18:50 --> Language Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Loader Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Controller Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Session Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:18:50 --> Session routines successfully run
DEBUG - 2019-04-11 16:18:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:18:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:18:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:18:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:18:50 --> Final output sent to browser
DEBUG - 2019-04-11 16:18:50 --> Total execution time: 0.0561
DEBUG - 2019-04-11 16:18:56 --> Config Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:18:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:18:56 --> URI Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Router Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Output Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Security Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Input Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:18:56 --> Language Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Loader Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Controller Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Session Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:18:56 --> Session routines successfully run
DEBUG - 2019-04-11 16:18:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:18:56 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:18:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:18:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:18:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:18:56 --> Final output sent to browser
DEBUG - 2019-04-11 16:18:56 --> Total execution time: 0.1019
DEBUG - 2019-04-11 16:19:03 --> Config Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:19:03 --> URI Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Router Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Output Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Security Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Input Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:19:03 --> Language Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Loader Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Controller Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Session Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:19:03 --> Session garbage collection performed.
DEBUG - 2019-04-11 16:19:03 --> Session routines successfully run
DEBUG - 2019-04-11 16:19:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:03 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:19:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:19:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:19:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:19:03 --> Final output sent to browser
DEBUG - 2019-04-11 16:19:03 --> Total execution time: 0.1111
DEBUG - 2019-04-11 16:19:05 --> Config Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:19:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:19:05 --> URI Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Router Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Output Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Security Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Input Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:19:05 --> Language Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Loader Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Controller Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Session Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:19:05 --> Session routines successfully run
DEBUG - 2019-04-11 16:19:05 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:05 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:19:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:19:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:19:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:19:05 --> Final output sent to browser
DEBUG - 2019-04-11 16:19:05 --> Total execution time: 0.0772
DEBUG - 2019-04-11 16:19:29 --> Config Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:19:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:19:29 --> URI Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Router Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Output Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Security Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Input Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:19:29 --> Language Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Loader Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Controller Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Session Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:19:29 --> Session routines successfully run
DEBUG - 2019-04-11 16:19:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:19:29 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:19:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:19:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:19:29 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:19:29 --> Final output sent to browser
DEBUG - 2019-04-11 16:19:29 --> Total execution time: 0.0502
DEBUG - 2019-04-11 16:20:28 --> Config Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:20:28 --> URI Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Router Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Output Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Security Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Input Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:20:28 --> Language Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Loader Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Controller Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Session Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:20:28 --> Session routines successfully run
DEBUG - 2019-04-11 16:20:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:20:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:20:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:20:28 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:20:28 --> Final output sent to browser
DEBUG - 2019-04-11 16:20:28 --> Total execution time: 0.0520
DEBUG - 2019-04-11 16:20:48 --> Config Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:20:48 --> URI Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Router Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Output Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Security Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Input Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:20:48 --> Language Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Loader Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Controller Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Session Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:20:48 --> Session routines successfully run
DEBUG - 2019-04-11 16:20:48 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:48 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:20:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:20:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:20:48 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:20:48 --> Final output sent to browser
DEBUG - 2019-04-11 16:20:48 --> Total execution time: 0.0653
DEBUG - 2019-04-11 16:20:56 --> Config Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:20:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:20:56 --> URI Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Router Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Output Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Security Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Input Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:20:56 --> Language Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Loader Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Controller Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Session Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:20:56 --> Session routines successfully run
DEBUG - 2019-04-11 16:20:56 --> Model Class Initialized
DEBUG - 2019-04-11 16:20:56 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:20:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:20:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:20:56 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:20:56 --> Final output sent to browser
DEBUG - 2019-04-11 16:20:56 --> Total execution time: 0.0504
DEBUG - 2019-04-11 16:21:33 --> Config Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:21:33 --> URI Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Router Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Output Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Security Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Input Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:21:33 --> Language Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Loader Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Controller Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Session Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:21:33 --> Session routines successfully run
DEBUG - 2019-04-11 16:21:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:21:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:21:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:21:33 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:21:33 --> Final output sent to browser
DEBUG - 2019-04-11 16:21:33 --> Total execution time: 0.0648
DEBUG - 2019-04-11 16:21:38 --> Config Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:21:38 --> URI Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Router Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Output Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Security Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Input Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:21:38 --> Language Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Loader Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Controller Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Session Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:21:38 --> Session routines successfully run
DEBUG - 2019-04-11 16:21:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:21:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:21:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:21:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:21:38 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:21:38 --> Final output sent to browser
DEBUG - 2019-04-11 16:21:38 --> Total execution time: 0.0419
DEBUG - 2019-04-11 16:22:01 --> Config Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:22:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:22:01 --> URI Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Router Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Output Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Security Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Input Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:22:01 --> Language Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Loader Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Controller Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Session Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:22:01 --> Session routines successfully run
DEBUG - 2019-04-11 16:22:01 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:01 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:22:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:22:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:22:01 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:22:01 --> Final output sent to browser
DEBUG - 2019-04-11 16:22:01 --> Total execution time: 0.0558
DEBUG - 2019-04-11 16:22:03 --> Config Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:22:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:22:03 --> URI Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Router Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Output Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Security Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Input Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:22:03 --> Language Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Loader Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Controller Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Session Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:22:03 --> Session routines successfully run
DEBUG - 2019-04-11 16:22:03 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:03 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:22:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:22:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:22:03 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 16:22:03 --> Final output sent to browser
DEBUG - 2019-04-11 16:22:03 --> Total execution time: 0.0503
DEBUG - 2019-04-11 16:22:07 --> Config Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:22:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:22:07 --> URI Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Router Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Output Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Security Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Input Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:22:07 --> Language Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Loader Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Controller Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Session Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:22:07 --> Session routines successfully run
DEBUG - 2019-04-11 16:22:07 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:07 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:22:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:22:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:22:07 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 16:22:07 --> Final output sent to browser
DEBUG - 2019-04-11 16:22:07 --> Total execution time: 0.0495
DEBUG - 2019-04-11 16:22:10 --> Config Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:22:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:22:10 --> URI Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Router Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Output Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Security Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Input Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:22:10 --> Language Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Loader Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Controller Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Session Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:22:10 --> Session routines successfully run
DEBUG - 2019-04-11 16:22:10 --> Model Class Initialized
DEBUG - 2019-04-11 16:22:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:22:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:22:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:22:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:22:10 --> Final output sent to browser
DEBUG - 2019-04-11 16:22:10 --> Total execution time: 0.1418
DEBUG - 2019-04-11 16:39:09 --> Config Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:39:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:39:09 --> URI Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Router Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Output Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Security Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Input Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:39:09 --> Language Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Loader Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Controller Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Model Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Model Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Session Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:39:09 --> Session routines successfully run
DEBUG - 2019-04-11 16:39:09 --> Model Class Initialized
DEBUG - 2019-04-11 16:39:09 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:39:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:39:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:39:09 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 16:39:09 --> Final output sent to browser
DEBUG - 2019-04-11 16:39:09 --> Total execution time: 0.1244
DEBUG - 2019-04-11 16:46:20 --> Config Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:46:20 --> URI Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Router Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Output Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Security Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Input Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:46:20 --> Language Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Loader Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Controller Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Session Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:46:20 --> Session routines successfully run
DEBUG - 2019-04-11 16:46:20 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:46:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:46:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:46:20 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 16:46:20 --> Final output sent to browser
DEBUG - 2019-04-11 16:46:20 --> Total execution time: 0.1266
DEBUG - 2019-04-11 16:46:34 --> Config Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:46:34 --> URI Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Router Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Output Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Security Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Input Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:46:34 --> Language Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Loader Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Controller Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Session Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:46:34 --> Session garbage collection performed.
DEBUG - 2019-04-11 16:46:34 --> Session routines successfully run
DEBUG - 2019-04-11 16:46:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:34 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:46:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:46:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:46:34 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 16:46:34 --> Final output sent to browser
DEBUG - 2019-04-11 16:46:34 --> Total execution time: 0.0450
DEBUG - 2019-04-11 16:46:42 --> Config Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:46:42 --> URI Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Router Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Output Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Security Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Input Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:46:42 --> Language Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Loader Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Controller Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Session Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:46:42 --> Session routines successfully run
DEBUG - 2019-04-11 16:46:42 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:46:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:46:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:46:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:46:43 --> Final output sent to browser
DEBUG - 2019-04-11 16:46:43 --> Total execution time: 0.2639
DEBUG - 2019-04-11 16:46:51 --> Config Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:46:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:46:51 --> URI Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Router Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Output Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Security Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Input Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:46:51 --> Language Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Loader Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Controller Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Session Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:46:51 --> Session routines successfully run
DEBUG - 2019-04-11 16:46:51 --> Model Class Initialized
DEBUG - 2019-04-11 16:46:51 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:46:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:46:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:46:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:46:51 --> Final output sent to browser
DEBUG - 2019-04-11 16:46:51 --> Total execution time: 0.1186
DEBUG - 2019-04-11 16:47:44 --> Config Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:47:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:47:44 --> URI Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Router Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Output Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Security Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Input Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:47:44 --> Language Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Loader Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Controller Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Session Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:47:44 --> Session routines successfully run
DEBUG - 2019-04-11 16:47:44 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:47:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:47:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:47:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:47:45 --> Final output sent to browser
DEBUG - 2019-04-11 16:47:45 --> Total execution time: 0.2811
DEBUG - 2019-04-11 16:47:46 --> Config Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:47:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:47:46 --> URI Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Router Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Output Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Security Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Input Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:47:46 --> Language Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Loader Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Controller Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Session Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:47:46 --> Session routines successfully run
DEBUG - 2019-04-11 16:47:46 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:46 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:47:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:47:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:47:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:47:46 --> Final output sent to browser
DEBUG - 2019-04-11 16:47:46 --> Total execution time: 0.1213
DEBUG - 2019-04-11 16:47:55 --> Config Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:47:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:47:55 --> URI Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Router Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Output Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Security Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Input Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:47:55 --> Language Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Loader Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Controller Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Session Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:47:55 --> Session routines successfully run
DEBUG - 2019-04-11 16:47:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:55 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:47:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:47:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:47:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:47:56 --> Final output sent to browser
DEBUG - 2019-04-11 16:47:56 --> Total execution time: 0.0982
DEBUG - 2019-04-11 16:47:57 --> Config Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:47:57 --> URI Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Router Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Output Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Security Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Input Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:47:57 --> Language Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Loader Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Controller Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Session Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:47:57 --> Session routines successfully run
DEBUG - 2019-04-11 16:47:57 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:47:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:47:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:47:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:47:57 --> Final output sent to browser
DEBUG - 2019-04-11 16:47:57 --> Total execution time: 0.1411
DEBUG - 2019-04-11 16:47:58 --> Config Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:47:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:47:58 --> URI Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Router Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Output Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Security Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Input Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:47:58 --> Language Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Loader Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Controller Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Session Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:47:58 --> Session routines successfully run
DEBUG - 2019-04-11 16:47:58 --> Model Class Initialized
DEBUG - 2019-04-11 16:47:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:47:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:47:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:47:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:47:58 --> Final output sent to browser
DEBUG - 2019-04-11 16:47:58 --> Total execution time: 0.1998
DEBUG - 2019-04-11 16:51:29 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:29 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:29 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:29 --> Session garbage collection performed.
DEBUG - 2019-04-11 16:51:29 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:29 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:51:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:51:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:51:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:51:29 --> Final output sent to browser
DEBUG - 2019-04-11 16:51:29 --> Total execution time: 0.2264
DEBUG - 2019-04-11 16:51:32 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:32 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:32 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:32 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:32 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:32 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:51:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:51:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:51:32 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:51:32 --> Final output sent to browser
DEBUG - 2019-04-11 16:51:32 --> Total execution time: 0.0662
DEBUG - 2019-04-11 16:51:33 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:33 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:33 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:33 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:51:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:51:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:51:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:51:33 --> Final output sent to browser
DEBUG - 2019-04-11 16:51:33 --> Total execution time: 0.1021
DEBUG - 2019-04-11 16:51:34 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:34 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:34 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:34 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:51:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:51:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:51:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:51:34 --> Final output sent to browser
DEBUG - 2019-04-11 16:51:34 --> Total execution time: 0.0843
DEBUG - 2019-04-11 16:51:34 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:34 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:34 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:34 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:35 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:35 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:35 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:35 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:35 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:51:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:51:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:51:35 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:51:35 --> Final output sent to browser
DEBUG - 2019-04-11 16:51:35 --> Total execution time: 0.0788
DEBUG - 2019-04-11 16:51:36 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:36 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:36 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:36 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:36 --> Helper loaded: url_helper
ERROR - 2019-04-11 16:51:36 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 16:51:38 --> Config Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:51:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:51:38 --> URI Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Router Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Output Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Security Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Input Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:51:38 --> Language Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Loader Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Controller Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Session Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:51:38 --> Session routines successfully run
DEBUG - 2019-04-11 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-11 16:51:38 --> Helper loaded: url_helper
ERROR - 2019-04-11 16:51:38 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 16:52:50 --> Config Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:52:50 --> URI Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Router Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Output Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Security Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Input Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:52:50 --> Language Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Loader Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Controller Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Session Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:52:50 --> Session routines successfully run
DEBUG - 2019-04-11 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:52:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:52:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:52:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:52:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:52:50 --> Final output sent to browser
DEBUG - 2019-04-11 16:52:50 --> Total execution time: 0.1092
DEBUG - 2019-04-11 16:59:21 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:21 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:21 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:21 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:21 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:21 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:59:21 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:21 --> Total execution time: 0.1802
DEBUG - 2019-04-11 16:59:28 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:28 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:28 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:28 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:28 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:59:28 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:28 --> Total execution time: 0.1122
DEBUG - 2019-04-11 16:59:29 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:29 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:29 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:29 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:29 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:29 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:59:29 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:29 --> Total execution time: 0.1240
DEBUG - 2019-04-11 16:59:30 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:30 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:30 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:30 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:30 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:30 --> Helper loaded: url_helper
ERROR - 2019-04-11 16:59:30 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 16:59:33 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:33 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:33 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:33 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:33 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:33 --> Helper loaded: url_helper
ERROR - 2019-04-11 16:59:33 --> 404 Page Not Found --> User/doLogout
DEBUG - 2019-04-11 16:59:36 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:36 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:36 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:36 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:36 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:36 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:36 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:59:36 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:36 --> Total execution time: 0.0867
DEBUG - 2019-04-11 16:59:50 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:50 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:50 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:50 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:50 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:59:50 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:50 --> Total execution time: 0.0769
DEBUG - 2019-04-11 16:59:52 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:52 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:52 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:52 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 16:59:52 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:52 --> Total execution time: 0.0953
DEBUG - 2019-04-11 16:59:52 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:52 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:52 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:52 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:52 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:59:52 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:52 --> Total execution time: 0.1006
DEBUG - 2019-04-11 16:59:55 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:55 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:55 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:55 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:55 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:55 --> Helper loaded: url_helper
ERROR - 2019-04-11 16:59:55 --> 404 Page Not Found --> User/dologout
DEBUG - 2019-04-11 16:59:59 --> Config Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Hooks Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Utf8 Class Initialized
DEBUG - 2019-04-11 16:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 16:59:59 --> URI Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Router Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Output Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Security Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Input Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 16:59:59 --> Language Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Loader Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Controller Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Database Driver Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Session Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Helper loaded: string_helper
DEBUG - 2019-04-11 16:59:59 --> Session routines successfully run
DEBUG - 2019-04-11 16:59:59 --> Model Class Initialized
DEBUG - 2019-04-11 16:59:59 --> Helper loaded: url_helper
DEBUG - 2019-04-11 16:59:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 16:59:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 16:59:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 16:59:59 --> Final output sent to browser
DEBUG - 2019-04-11 16:59:59 --> Total execution time: 0.0849
DEBUG - 2019-04-11 17:00:24 --> Config Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 17:00:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 17:00:24 --> URI Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Router Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Output Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Security Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Input Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 17:00:24 --> Language Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Loader Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Controller Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Session Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 17:00:24 --> Session routines successfully run
DEBUG - 2019-04-11 17:00:24 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 17:00:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 17:00:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 17:00:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 17:00:24 --> Final output sent to browser
DEBUG - 2019-04-11 17:00:24 --> Total execution time: 0.1143
DEBUG - 2019-04-11 17:00:26 --> Config Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Hooks Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Utf8 Class Initialized
DEBUG - 2019-04-11 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 17:00:26 --> URI Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Router Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Output Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Security Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Input Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 17:00:26 --> Language Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Loader Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Controller Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Session Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 17:00:26 --> Session routines successfully run
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Helper loaded: url_helper
DEBUG - 2019-04-11 17:00:26 --> Config Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Hooks Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Utf8 Class Initialized
DEBUG - 2019-04-11 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 17:00:26 --> URI Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Router Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Output Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Security Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Input Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 17:00:26 --> Language Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Loader Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Controller Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Session Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 17:00:26 --> A session cookie was not found.
DEBUG - 2019-04-11 17:00:26 --> Session routines successfully run
DEBUG - 2019-04-11 17:00:26 --> Model Class Initialized
DEBUG - 2019-04-11 17:00:26 --> Helper loaded: url_helper
DEBUG - 2019-04-11 17:00:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 17:00:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 17:00:26 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 17:00:26 --> Final output sent to browser
DEBUG - 2019-04-11 17:00:26 --> Total execution time: 0.1343
DEBUG - 2019-04-11 20:24:33 --> Config Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:24:33 --> URI Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Router Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Output Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Security Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Input Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:24:33 --> Language Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Loader Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Controller Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Session Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:24:33 --> Session routines successfully run
DEBUG - 2019-04-11 20:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:24:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:24:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:24:33 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 20:24:33 --> Final output sent to browser
DEBUG - 2019-04-11 20:24:33 --> Total execution time: 0.0963
DEBUG - 2019-04-11 20:24:38 --> Config Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:24:38 --> URI Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Router Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Output Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Security Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Input Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:24:38 --> Language Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Loader Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Controller Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Session Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:24:38 --> Session routines successfully run
DEBUG - 2019-04-11 20:24:38 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:24:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:24:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:24:38 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 20:24:38 --> Final output sent to browser
DEBUG - 2019-04-11 20:24:38 --> Total execution time: 0.0620
DEBUG - 2019-04-11 20:24:43 --> Config Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:24:43 --> URI Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Router Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Output Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Security Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Input Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:24:43 --> Language Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Loader Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Controller Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Session Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:24:43 --> Session routines successfully run
DEBUG - 2019-04-11 20:24:43 --> Model Class Initialized
DEBUG - 2019-04-11 20:24:43 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:24:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:24:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:24:43 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:24:43 --> Final output sent to browser
DEBUG - 2019-04-11 20:24:43 --> Total execution time: 0.0596
DEBUG - 2019-04-11 20:27:52 --> Config Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:27:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:27:52 --> URI Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Router Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Output Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Security Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Input Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:27:52 --> Language Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Loader Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Controller Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Model Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Model Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Session Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:27:52 --> Session routines successfully run
DEBUG - 2019-04-11 20:27:52 --> Model Class Initialized
DEBUG - 2019-04-11 20:27:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:27:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:27:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:27:52 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:27:52 --> Final output sent to browser
DEBUG - 2019-04-11 20:27:52 --> Total execution time: 0.0592
DEBUG - 2019-04-11 20:28:12 --> Config Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:28:12 --> URI Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Router Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Output Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Security Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Input Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:28:12 --> Language Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Loader Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Controller Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Model Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Model Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Session Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:28:12 --> Session routines successfully run
DEBUG - 2019-04-11 20:28:12 --> Model Class Initialized
DEBUG - 2019-04-11 20:28:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:28:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:28:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:28:12 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:28:12 --> Final output sent to browser
DEBUG - 2019-04-11 20:28:12 --> Total execution time: 0.0675
DEBUG - 2019-04-11 20:29:15 --> Config Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:29:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:29:15 --> URI Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Router Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Output Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Security Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Input Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:29:15 --> Language Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Loader Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Controller Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Session Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:29:15 --> Session routines successfully run
DEBUG - 2019-04-11 20:29:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:29:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:29:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:29:15 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:29:15 --> Final output sent to browser
DEBUG - 2019-04-11 20:29:15 --> Total execution time: 0.0618
DEBUG - 2019-04-11 20:29:17 --> Config Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:29:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:29:17 --> URI Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Router Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Output Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Security Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Input Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:29:17 --> Language Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Loader Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Controller Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Session Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:29:17 --> Session routines successfully run
DEBUG - 2019-04-11 20:29:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:29:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:29:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:29:17 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:29:17 --> Final output sent to browser
DEBUG - 2019-04-11 20:29:17 --> Total execution time: 0.0508
DEBUG - 2019-04-11 20:29:39 --> Config Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:29:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:29:39 --> URI Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Router Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Output Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Security Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Input Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:29:39 --> Language Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Loader Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Controller Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Session Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:29:39 --> Session routines successfully run
DEBUG - 2019-04-11 20:29:39 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:39 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:29:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:29:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:29:39 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:29:39 --> Final output sent to browser
DEBUG - 2019-04-11 20:29:39 --> Total execution time: 0.1149
DEBUG - 2019-04-11 20:29:41 --> Config Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:29:41 --> URI Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Router Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Output Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Security Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Input Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:29:41 --> Language Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Loader Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Controller Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:41 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:29:42 --> Session Class Initialized
DEBUG - 2019-04-11 20:29:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:29:42 --> Session routines successfully run
DEBUG - 2019-04-11 20:29:42 --> Model Class Initialized
DEBUG - 2019-04-11 20:29:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:29:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:29:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:29:42 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:29:42 --> Final output sent to browser
DEBUG - 2019-04-11 20:29:42 --> Total execution time: 0.0600
DEBUG - 2019-04-11 20:34:27 --> Config Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:34:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:34:27 --> URI Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Router Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Output Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Security Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Input Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:34:27 --> Language Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Loader Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Controller Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Session Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:34:27 --> Session routines successfully run
DEBUG - 2019-04-11 20:34:27 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:34:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:34:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:34:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:34:27 --> Final output sent to browser
DEBUG - 2019-04-11 20:34:27 --> Total execution time: 0.1110
DEBUG - 2019-04-11 20:34:28 --> Config Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:34:28 --> URI Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Router Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Output Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Security Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Input Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:34:28 --> Language Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Loader Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Controller Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Session Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:34:28 --> Session routines successfully run
DEBUG - 2019-04-11 20:34:28 --> Model Class Initialized
DEBUG - 2019-04-11 20:34:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:34:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:34:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:34:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:34:28 --> Final output sent to browser
DEBUG - 2019-04-11 20:34:28 --> Total execution time: 0.1011
DEBUG - 2019-04-11 20:35:05 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:05 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:05 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:05 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:05 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:05 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:05 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:05 --> Total execution time: 0.1981
DEBUG - 2019-04-11 20:35:06 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:06 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:06 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:06 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:06 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:06 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:06 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:06 --> Total execution time: 0.0670
DEBUG - 2019-04-11 20:35:11 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:11 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:11 --> No URI present. Default controller set.
DEBUG - 2019-04-11 20:35:11 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:11 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:11 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:11 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:11 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:11 --> Total execution time: 0.0713
DEBUG - 2019-04-11 20:35:13 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:13 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:13 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:13 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:13 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:13 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:13 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:13 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:13 --> Total execution time: 0.1037
DEBUG - 2019-04-11 20:35:14 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:14 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:14 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:14 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:14 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:14 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:14 --> Total execution time: 0.1071
DEBUG - 2019-04-11 20:35:15 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:15 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:15 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:15 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:15 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:15 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:15 --> Total execution time: 0.1274
DEBUG - 2019-04-11 20:35:16 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:16 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:16 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:16 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:16 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:16 --> Total execution time: 0.0703
DEBUG - 2019-04-11 20:35:16 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:16 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:16 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:16 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:16 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:16 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:35:16 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:16 --> Total execution time: 0.0563
DEBUG - 2019-04-11 20:35:17 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:17 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:17 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:17 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:17 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:17 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 20:35:17 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:17 --> Total execution time: 0.0511
DEBUG - 2019-04-11 20:35:18 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:18 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:18 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:18 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:18 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:18 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 20:35:18 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:18 --> Total execution time: 0.0486
DEBUG - 2019-04-11 20:35:19 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:19 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:19 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:19 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:19 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:19 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 20:35:19 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:19 --> Total execution time: 0.0491
DEBUG - 2019-04-11 20:35:20 --> Config Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:35:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:35:20 --> URI Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Router Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Output Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Security Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Input Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:35:20 --> Language Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Loader Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Controller Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Session Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:35:20 --> Session routines successfully run
DEBUG - 2019-04-11 20:35:20 --> Model Class Initialized
DEBUG - 2019-04-11 20:35:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:35:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:35:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:35:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:35:20 --> Final output sent to browser
DEBUG - 2019-04-11 20:35:20 --> Total execution time: 0.0830
DEBUG - 2019-04-11 20:39:22 --> Config Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:39:22 --> URI Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Router Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Output Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Security Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Input Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:39:22 --> Language Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Loader Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Controller Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Session Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:39:22 --> Session garbage collection performed.
DEBUG - 2019-04-11 20:39:22 --> Session routines successfully run
DEBUG - 2019-04-11 20:39:22 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:22 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:39:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:39:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:39:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 20:39:22 --> Final output sent to browser
DEBUG - 2019-04-11 20:39:22 --> Total execution time: 0.1618
DEBUG - 2019-04-11 20:39:25 --> Config Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 20:39:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 20:39:25 --> URI Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Router Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Output Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Security Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Input Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 20:39:25 --> Language Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Loader Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Controller Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Database Driver Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Session Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Helper loaded: string_helper
DEBUG - 2019-04-11 20:39:25 --> Session routines successfully run
DEBUG - 2019-04-11 20:39:25 --> Model Class Initialized
DEBUG - 2019-04-11 20:39:25 --> Helper loaded: url_helper
DEBUG - 2019-04-11 20:39:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 20:39:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 20:39:25 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 20:39:25 --> Final output sent to browser
DEBUG - 2019-04-11 20:39:25 --> Total execution time: 0.0627
DEBUG - 2019-04-11 21:03:58 --> Config Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:03:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:03:58 --> URI Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Router Class Initialized
DEBUG - 2019-04-11 21:03:58 --> No URI present. Default controller set.
DEBUG - 2019-04-11 21:03:58 --> Output Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Security Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Input Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:03:58 --> Language Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Loader Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Controller Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Session Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:03:58 --> Session routines successfully run
DEBUG - 2019-04-11 21:03:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:03:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:03:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:03:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:03:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:03:58 --> Final output sent to browser
DEBUG - 2019-04-11 21:03:58 --> Total execution time: 0.3865
DEBUG - 2019-04-11 21:04:03 --> Config Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:04:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:04:03 --> URI Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Router Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Output Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Security Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Input Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:04:03 --> Language Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Loader Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Controller Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Session Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:04:03 --> Session garbage collection performed.
DEBUG - 2019-04-11 21:04:03 --> Session routines successfully run
DEBUG - 2019-04-11 21:04:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:03 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:04:03 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 21:04:14 --> Config Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:04:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:04:14 --> URI Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Router Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Output Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Security Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Input Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:04:14 --> Language Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Loader Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Controller Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Session Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:04:14 --> Session routines successfully run
DEBUG - 2019-04-11 21:04:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:04:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:04:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:04:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:04:14 --> Final output sent to browser
DEBUG - 2019-04-11 21:04:14 --> Total execution time: 0.2133
DEBUG - 2019-04-11 21:04:24 --> Config Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:04:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:04:24 --> URI Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Router Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Output Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Security Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Input Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:04:24 --> Language Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Loader Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Controller Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Session Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:04:24 --> Session routines successfully run
DEBUG - 2019-04-11 21:04:24 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:24 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:04:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:04:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:04:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:04:24 --> Final output sent to browser
DEBUG - 2019-04-11 21:04:24 --> Total execution time: 0.3248
DEBUG - 2019-04-11 21:04:25 --> Config Class Initialized
DEBUG - 2019-04-11 21:04:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:04:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:04:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:04:25 --> URI Class Initialized
DEBUG - 2019-04-11 21:04:25 --> Router Class Initialized
DEBUG - 2019-04-11 21:04:25 --> Output Class Initialized
DEBUG - 2019-04-11 21:04:25 --> Security Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Input Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:04:26 --> Language Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Loader Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Controller Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Session Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:04:26 --> Session routines successfully run
DEBUG - 2019-04-11 21:04:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:26 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:04:26 --> 404 Page Not Found --> User/Market.html
DEBUG - 2019-04-11 21:04:28 --> Config Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:04:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:04:28 --> URI Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Router Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Output Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Security Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Input Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:04:28 --> Language Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Loader Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Controller Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Session Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:04:28 --> Session routines successfully run
DEBUG - 2019-04-11 21:04:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:04:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:04:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:04:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:04:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:04:28 --> Final output sent to browser
DEBUG - 2019-04-11 21:04:28 --> Total execution time: 0.2587
DEBUG - 2019-04-11 21:06:11 --> Config Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:06:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:06:11 --> URI Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Router Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Output Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Security Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Input Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:06:11 --> Language Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Loader Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Controller Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Session Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:06:11 --> Session routines successfully run
DEBUG - 2019-04-11 21:06:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:06:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:06:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:06:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:06:12 --> Final output sent to browser
DEBUG - 2019-04-11 21:06:12 --> Total execution time: 0.3115
DEBUG - 2019-04-11 21:06:14 --> Config Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:06:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:06:14 --> URI Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Router Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Output Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Security Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Input Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:06:14 --> Language Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Loader Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Controller Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Session Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:06:14 --> Session routines successfully run
DEBUG - 2019-04-11 21:06:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:14 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:06:14 --> 404 Page Not Found --> User/notice
DEBUG - 2019-04-11 21:06:27 --> Config Class Initialized
DEBUG - 2019-04-11 21:06:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:06:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:06:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:06:27 --> URI Class Initialized
DEBUG - 2019-04-11 21:06:27 --> Router Class Initialized
DEBUG - 2019-04-11 21:06:27 --> Output Class Initialized
DEBUG - 2019-04-11 21:06:27 --> Security Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Input Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:06:28 --> Language Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Loader Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Controller Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Session Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:06:28 --> Session garbage collection performed.
DEBUG - 2019-04-11 21:06:28 --> Session routines successfully run
DEBUG - 2019-04-11 21:06:28 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:06:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:06:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:06:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:06:28 --> Final output sent to browser
DEBUG - 2019-04-11 21:06:28 --> Total execution time: 0.1477
DEBUG - 2019-04-11 21:06:29 --> Config Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:06:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:06:29 --> URI Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Router Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Output Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Security Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Input Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:06:29 --> Language Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Loader Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Controller Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Session Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:06:29 --> Session routines successfully run
DEBUG - 2019-04-11 21:06:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:06:29 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:06:29 --> 404 Page Not Found --> User/doNotice
DEBUG - 2019-04-11 21:09:14 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:14 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:14 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:14 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:15 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:15 --> Total execution time: 0.3109
DEBUG - 2019-04-11 21:09:16 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:16 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:16 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:16 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:16 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:16 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 21:09:16 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:16 --> Total execution time: 0.0522
DEBUG - 2019-04-11 21:09:18 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:18 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:18 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:18 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:18 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:19 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:19 --> Total execution time: 0.1997
DEBUG - 2019-04-11 21:09:38 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:38 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:38 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:38 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:39 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:39 --> Total execution time: 0.4631
DEBUG - 2019-04-11 21:09:40 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:40 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:40 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:40 --> Session garbage collection performed.
DEBUG - 2019-04-11 21:09:40 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:40 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:41 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:41 --> Total execution time: 0.8955
DEBUG - 2019-04-11 21:09:42 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:42 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:42 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:42 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:43 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:43 --> Total execution time: 0.5610
DEBUG - 2019-04-11 21:09:44 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:44 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:44 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:44 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:44 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:09:44 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:44 --> Total execution time: 0.0586
DEBUG - 2019-04-11 21:09:46 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:46 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:46 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:46 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:46 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:46 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:46 --> Total execution time: 0.3958
DEBUG - 2019-04-11 21:09:47 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:47 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:47 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:47 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:47 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 21:09:47 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:47 --> Total execution time: 0.0577
DEBUG - 2019-04-11 21:09:48 --> Config Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:09:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:09:48 --> URI Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Router Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Output Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Security Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Input Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:09:48 --> Language Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Loader Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Controller Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Session Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:09:48 --> Session routines successfully run
DEBUG - 2019-04-11 21:09:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:09:48 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:09:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:09:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:09:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:09:49 --> Final output sent to browser
DEBUG - 2019-04-11 21:09:49 --> Total execution time: 0.3249
DEBUG - 2019-04-11 21:10:46 --> Config Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:10:46 --> URI Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Router Class Initialized
DEBUG - 2019-04-11 21:10:46 --> No URI present. Default controller set.
DEBUG - 2019-04-11 21:10:46 --> Output Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Security Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Input Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:10:46 --> Language Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Loader Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Controller Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Session Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:10:46 --> Session routines successfully run
DEBUG - 2019-04-11 21:10:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:46 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:10:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:10:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:10:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:10:46 --> Final output sent to browser
DEBUG - 2019-04-11 21:10:46 --> Total execution time: 0.3861
DEBUG - 2019-04-11 21:10:48 --> Config Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:10:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:10:48 --> URI Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Router Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Output Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Security Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Input Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:10:48 --> Language Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Loader Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Controller Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Session Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:10:48 --> Session routines successfully run
DEBUG - 2019-04-11 21:10:48 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:48 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:10:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:10:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:10:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:10:49 --> Final output sent to browser
DEBUG - 2019-04-11 21:10:49 --> Total execution time: 0.6638
DEBUG - 2019-04-11 21:10:50 --> Config Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:10:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:10:50 --> URI Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Router Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Output Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Security Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Input Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:10:50 --> Language Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Loader Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Controller Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Session Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:10:50 --> Session routines successfully run
DEBUG - 2019-04-11 21:10:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:10:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:10:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:10:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:10:51 --> Final output sent to browser
DEBUG - 2019-04-11 21:10:51 --> Total execution time: 0.5135
DEBUG - 2019-04-11 21:10:53 --> Config Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:10:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:10:53 --> URI Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Router Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Output Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Security Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Input Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:10:53 --> Language Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Loader Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Controller Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Session Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:10:53 --> Session routines successfully run
DEBUG - 2019-04-11 21:10:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:53 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:10:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:10:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:10:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:10:53 --> Final output sent to browser
DEBUG - 2019-04-11 21:10:53 --> Total execution time: 0.3657
DEBUG - 2019-04-11 21:10:55 --> Config Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:10:55 --> URI Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Router Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Output Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Security Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Input Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:10:55 --> Language Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Loader Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Controller Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Session Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:10:55 --> Session routines successfully run
DEBUG - 2019-04-11 21:10:55 --> Model Class Initialized
DEBUG - 2019-04-11 21:10:55 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:10:55 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 21:11:03 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:03 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:03 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:03 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:03 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:11:03 --> 404 Page Not Found --> User/index_page
DEBUG - 2019-04-11 21:11:05 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:05 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:05 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:05 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:05 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:05 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:11:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:11:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:11:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:11:06 --> Final output sent to browser
DEBUG - 2019-04-11 21:11:06 --> Total execution time: 0.3712
DEBUG - 2019-04-11 21:11:06 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:06 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:06 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:06 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:06 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:06 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:11:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:11:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:11:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:11:07 --> Final output sent to browser
DEBUG - 2019-04-11 21:11:07 --> Total execution time: 0.3203
DEBUG - 2019-04-11 21:11:08 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:08 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:08 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:08 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:08 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:11:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:11:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:11:08 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 21:11:08 --> Final output sent to browser
DEBUG - 2019-04-11 21:11:08 --> Total execution time: 0.0537
DEBUG - 2019-04-11 21:11:09 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:09 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:09 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:09 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:09 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:09 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:11:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:11:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:11:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:11:09 --> Final output sent to browser
DEBUG - 2019-04-11 21:11:09 --> Total execution time: 0.2385
DEBUG - 2019-04-11 21:11:10 --> Config Class Initialized
DEBUG - 2019-04-11 21:11:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:11:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:11:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:11:10 --> URI Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Router Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Output Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Security Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Input Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:11:11 --> Language Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Loader Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Controller Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Session Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:11:11 --> Session routines successfully run
DEBUG - 2019-04-11 21:11:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:11:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:11:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:11:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:11:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:11:11 --> Final output sent to browser
DEBUG - 2019-04-11 21:11:11 --> Total execution time: 0.5427
DEBUG - 2019-04-11 21:18:02 --> Config Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:18:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:18:02 --> URI Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Router Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Output Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Security Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Input Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:18:02 --> Language Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Loader Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Controller Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Session Class Initialized
DEBUG - 2019-04-11 21:18:02 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:18:03 --> Session routines successfully run
DEBUG - 2019-04-11 21:18:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:18:03 --> Config Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:18:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:18:03 --> URI Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Router Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Output Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Security Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Input Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:18:03 --> Language Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Loader Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Controller Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Session Class Initialized
DEBUG - 2019-04-11 21:18:03 --> Helper loaded: string_helper
ERROR - 2019-04-11 21:18:03 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:18:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:18:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:18:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:18:03 --> Final output sent to browser
DEBUG - 2019-04-11 21:18:03 --> Total execution time: 1.2985
DEBUG - 2019-04-11 21:18:04 --> Session routines successfully run
DEBUG - 2019-04-11 21:18:04 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:04 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:18:04 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:18:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:18:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:18:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:18:04 --> Final output sent to browser
DEBUG - 2019-04-11 21:18:04 --> Total execution time: 1.4064
DEBUG - 2019-04-11 21:18:33 --> Config Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:18:33 --> URI Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Router Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Output Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Security Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Input Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:18:33 --> Language Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Loader Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Controller Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Session Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:18:33 --> Session routines successfully run
DEBUG - 2019-04-11 21:18:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:18:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:18:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:18:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:18:33 --> Final output sent to browser
DEBUG - 2019-04-11 21:18:33 --> Total execution time: 0.5895
DEBUG - 2019-04-11 21:18:41 --> Config Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:18:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:18:41 --> URI Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Router Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Output Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Security Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Input Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:18:41 --> Language Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Loader Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Controller Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:41 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:18:42 --> Session Class Initialized
DEBUG - 2019-04-11 21:18:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:18:42 --> Session routines successfully run
DEBUG - 2019-04-11 21:18:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:18:42 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:18:42 --> 404 Page Not Found --> User/notice
DEBUG - 2019-04-11 21:21:20 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:20 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:20 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:21 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:21 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:21 --> 404 Page Not Found --> User/notice
DEBUG - 2019-04-11 21:21:23 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:23 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:23 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:23 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:23 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:23 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:23 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:23 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:21:23 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:23 --> Total execution time: 0.4026
DEBUG - 2019-04-11 21:21:27 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:27 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:27 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:27 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:27 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:27 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:27 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:21:27 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:27 --> Total execution time: 0.3099
DEBUG - 2019-04-11 21:21:29 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:29 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:29 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:29 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:29 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:29 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:21:29 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:29 --> Total execution time: 0.2008
DEBUG - 2019-04-11 21:21:30 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:30 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:30 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:30 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:30 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:30 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:21:30 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:30 --> Total execution time: 0.2163
DEBUG - 2019-04-11 21:21:32 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:32 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:32 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:32 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:32 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:32 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:32 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:21:32 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:32 --> Total execution time: 0.0615
DEBUG - 2019-04-11 21:21:35 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:35 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:35 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:35 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:35 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:35 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:35 --> 404 Page Not Found --> User/notice
DEBUG - 2019-04-11 21:21:36 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:36 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:36 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:36 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:36 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:36 --> 404 Page Not Found --> User/notice
DEBUG - 2019-04-11 21:21:50 --> Config Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:21:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:21:50 --> URI Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Router Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Output Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Security Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Input Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:21:50 --> Language Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Loader Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Controller Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Session Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:21:50 --> A session cookie was not found.
DEBUG - 2019-04-11 21:21:50 --> Session routines successfully run
DEBUG - 2019-04-11 21:21:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:21:50 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:21:51 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:21:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:21:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:21:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:21:51 --> Final output sent to browser
DEBUG - 2019-04-11 21:21:51 --> Total execution time: 0.9012
DEBUG - 2019-04-11 21:22:44 --> Config Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:22:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:22:44 --> URI Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Router Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Output Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Security Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Input Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:22:44 --> Language Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Loader Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Controller Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Session Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:22:44 --> Session routines successfully run
DEBUG - 2019-04-11 21:22:44 --> Model Class Initialized
DEBUG - 2019-04-11 21:22:44 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:22:44 --> Severity: Notice  --> Undefined variable: data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 48
DEBUG - 2019-04-11 21:22:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:22:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:22:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:22:44 --> Final output sent to browser
DEBUG - 2019-04-11 21:22:44 --> Total execution time: 0.4131
DEBUG - 2019-04-11 21:23:08 --> Config Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:23:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:23:08 --> URI Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Router Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Output Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Security Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Input Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:23:08 --> Language Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Loader Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Controller Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Session Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:23:08 --> Session routines successfully run
DEBUG - 2019-04-11 21:23:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:23:08 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:23:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:23:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:23:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:23:09 --> Final output sent to browser
DEBUG - 2019-04-11 21:23:09 --> Total execution time: 0.7009
DEBUG - 2019-04-11 21:24:07 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:07 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:07 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:07 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:07 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:07 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:24:07 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:07 --> Total execution time: 0.5785
DEBUG - 2019-04-11 21:24:08 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:08 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:08 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:08 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:08 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:08 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:24:08 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:08 --> Total execution time: 0.0633
DEBUG - 2019-04-11 21:24:12 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:12 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:12 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:12 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:12 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 21:24:12 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:12 --> Total execution time: 0.1552
DEBUG - 2019-04-11 21:24:15 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:15 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:15 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:15 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:15 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 21:24:15 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:15 --> Total execution time: 0.0402
DEBUG - 2019-04-11 21:24:19 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:19 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:19 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:19 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:24:20 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:20 --> Total execution time: 0.4460
DEBUG - 2019-04-11 21:24:29 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:29 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:29 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:29 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:29 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:29 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:24:29 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:29 --> Total execution time: 0.5951
DEBUG - 2019-04-11 21:24:32 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:32 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:32 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:32 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:32 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:32 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:32 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:24:32 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:32 --> Total execution time: 0.3406
DEBUG - 2019-04-11 21:24:33 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:33 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:33 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:33 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:33 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 21:24:33 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:33 --> Total execution time: 0.0448
DEBUG - 2019-04-11 21:24:35 --> Config Class Initialized
DEBUG - 2019-04-11 21:24:35 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:24:35 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:24:35 --> URI Class Initialized
DEBUG - 2019-04-11 21:24:35 --> Router Class Initialized
DEBUG - 2019-04-11 21:24:35 --> Output Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Security Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Input Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:24:36 --> Language Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Loader Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Controller Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Session Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:24:36 --> Session routines successfully run
DEBUG - 2019-04-11 21:24:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:24:36 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:24:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:24:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:24:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:24:36 --> Final output sent to browser
DEBUG - 2019-04-11 21:24:36 --> Total execution time: 0.4170
DEBUG - 2019-04-11 21:25:19 --> Config Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:25:19 --> URI Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Router Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Output Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Security Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Input Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:25:19 --> Language Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Loader Class Initialized
DEBUG - 2019-04-11 21:25:19 --> Controller Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Session Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:25:20 --> Session routines successfully run
DEBUG - 2019-04-11 21:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:25:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:25:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:25:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:25:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:25:20 --> Final output sent to browser
DEBUG - 2019-04-11 21:25:20 --> Total execution time: 0.6014
DEBUG - 2019-04-11 21:26:30 --> Config Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:26:30 --> URI Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Router Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Output Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Security Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Input Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:26:30 --> Language Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Loader Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Controller Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Session Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:26:30 --> Session routines successfully run
DEBUG - 2019-04-11 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:30 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:26:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:26:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:26:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:26:30 --> Final output sent to browser
DEBUG - 2019-04-11 21:26:30 --> Total execution time: 0.3468
DEBUG - 2019-04-11 21:26:33 --> Config Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:26:33 --> URI Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Router Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Output Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Security Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Input Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:26:33 --> Language Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Loader Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Controller Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Session Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:26:33 --> Session routines successfully run
DEBUG - 2019-04-11 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:26:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:26:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:26:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:26:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:26:34 --> Final output sent to browser
DEBUG - 2019-04-11 21:26:34 --> Total execution time: 0.4015
DEBUG - 2019-04-11 21:27:20 --> Config Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:27:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:27:20 --> URI Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Router Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Output Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Security Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Input Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:27:20 --> Language Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Loader Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Controller Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Session Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:27:20 --> Session routines successfully run
DEBUG - 2019-04-11 21:27:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:27:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:27:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:27:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:27:21 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:27:21 --> Final output sent to browser
DEBUG - 2019-04-11 21:27:21 --> Total execution time: 1.0592
DEBUG - 2019-04-11 21:29:18 --> Config Class Initialized
DEBUG - 2019-04-11 21:29:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:29:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:29:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:29:19 --> URI Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Router Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Output Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Security Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Input Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:29:19 --> Language Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Loader Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Controller Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Session Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:29:19 --> Session routines successfully run
DEBUG - 2019-04-11 21:29:19 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:29:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:29:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:29:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:29:19 --> Final output sent to browser
DEBUG - 2019-04-11 21:29:19 --> Total execution time: 0.9370
DEBUG - 2019-04-11 21:29:21 --> Config Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:29:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:29:21 --> URI Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Router Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Output Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Security Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Input Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:29:21 --> Language Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Loader Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Controller Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Session Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:29:21 --> Session routines successfully run
DEBUG - 2019-04-11 21:29:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:29:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:29:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:29:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:29:22 --> Final output sent to browser
DEBUG - 2019-04-11 21:29:22 --> Total execution time: 0.7110
DEBUG - 2019-04-11 21:29:54 --> Config Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:29:54 --> URI Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Router Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Output Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Security Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Input Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:29:54 --> Language Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Loader Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Controller Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Session Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:29:54 --> Session routines successfully run
DEBUG - 2019-04-11 21:29:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:29:54 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:29:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:29:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:29:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:29:54 --> Final output sent to browser
DEBUG - 2019-04-11 21:29:54 --> Total execution time: 0.4543
DEBUG - 2019-04-11 21:30:38 --> Config Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:30:38 --> URI Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Router Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Output Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Security Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Input Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:30:38 --> Language Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Loader Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Controller Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Session Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:30:38 --> Session routines successfully run
DEBUG - 2019-04-11 21:30:38 --> Model Class Initialized
DEBUG - 2019-04-11 21:30:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:30:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:30:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:30:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:30:38 --> Final output sent to browser
DEBUG - 2019-04-11 21:30:38 --> Total execution time: 0.2390
DEBUG - 2019-04-11 21:33:10 --> Config Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:33:10 --> URI Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Router Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Output Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Security Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Input Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:33:10 --> Language Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Loader Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Controller Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Session Class Initialized
DEBUG - 2019-04-11 21:33:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:33:11 --> Session routines successfully run
DEBUG - 2019-04-11 21:33:11 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:33:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:33:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:33:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:33:11 --> Final output sent to browser
DEBUG - 2019-04-11 21:33:11 --> Total execution time: 0.7683
DEBUG - 2019-04-11 21:33:15 --> Config Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:33:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:33:15 --> URI Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Router Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Output Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Security Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Input Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:33:15 --> Language Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Loader Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Controller Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Session Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:33:15 --> Session routines successfully run
DEBUG - 2019-04-11 21:33:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:33:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:33:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:33:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:33:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:33:15 --> Final output sent to browser
DEBUG - 2019-04-11 21:33:15 --> Total execution time: 0.4576
DEBUG - 2019-04-11 21:35:33 --> Config Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:35:33 --> URI Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Router Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Output Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Security Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Input Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:35:33 --> Language Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Loader Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Controller Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Session Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:35:33 --> Session routines successfully run
DEBUG - 2019-04-11 21:35:33 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:35:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:35:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:35:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:35:34 --> Final output sent to browser
DEBUG - 2019-04-11 21:35:34 --> Total execution time: 0.4681
DEBUG - 2019-04-11 21:35:36 --> Config Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:35:36 --> URI Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Router Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Output Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Security Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Input Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:35:36 --> Language Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Loader Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Controller Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Session Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:35:36 --> Session routines successfully run
DEBUG - 2019-04-11 21:35:36 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:36 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:35:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:35:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:35:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:35:36 --> Final output sent to browser
DEBUG - 2019-04-11 21:35:36 --> Total execution time: 0.3322
DEBUG - 2019-04-11 21:35:39 --> Config Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:35:39 --> URI Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Router Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Output Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Security Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Input Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:35:39 --> Language Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Loader Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Controller Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Session Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:35:39 --> Session routines successfully run
DEBUG - 2019-04-11 21:35:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:39 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:35:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:35:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:35:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:35:39 --> Final output sent to browser
DEBUG - 2019-04-11 21:35:39 --> Total execution time: 0.5243
DEBUG - 2019-04-11 21:35:42 --> Config Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:35:42 --> URI Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Router Class Initialized
DEBUG - 2019-04-11 21:35:42 --> No URI present. Default controller set.
DEBUG - 2019-04-11 21:35:42 --> Output Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Security Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Input Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:35:42 --> Language Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Loader Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Controller Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Session Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:35:42 --> Session garbage collection performed.
DEBUG - 2019-04-11 21:35:42 --> Session routines successfully run
DEBUG - 2019-04-11 21:35:42 --> Model Class Initialized
DEBUG - 2019-04-11 21:35:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:35:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:35:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:35:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:35:42 --> Final output sent to browser
DEBUG - 2019-04-11 21:35:42 --> Total execution time: 0.4984
DEBUG - 2019-04-11 21:40:53 --> Config Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:40:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:40:53 --> URI Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Router Class Initialized
DEBUG - 2019-04-11 21:40:53 --> No URI present. Default controller set.
DEBUG - 2019-04-11 21:40:53 --> Output Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Security Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Input Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:40:53 --> Language Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Loader Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Controller Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Session Class Initialized
DEBUG - 2019-04-11 21:40:53 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:40:54 --> Session routines successfully run
DEBUG - 2019-04-11 21:40:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:54 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:40:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:40:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:40:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:40:54 --> Final output sent to browser
DEBUG - 2019-04-11 21:40:54 --> Total execution time: 0.7763
DEBUG - 2019-04-11 21:40:56 --> Config Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:40:56 --> URI Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Router Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Output Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Security Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Input Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:40:56 --> Language Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Loader Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Controller Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Session Class Initialized
DEBUG - 2019-04-11 21:40:56 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:40:57 --> Session routines successfully run
DEBUG - 2019-04-11 21:40:57 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:40:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:40:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:40:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:40:57 --> Final output sent to browser
DEBUG - 2019-04-11 21:40:57 --> Total execution time: 0.4634
DEBUG - 2019-04-11 21:40:57 --> Config Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:40:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:40:57 --> URI Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Router Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Output Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Security Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Input Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:40:57 --> Language Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Loader Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Controller Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Session Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:40:57 --> Session routines successfully run
DEBUG - 2019-04-11 21:40:57 --> Model Class Initialized
DEBUG - 2019-04-11 21:40:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:40:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:40:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:40:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:40:58 --> Final output sent to browser
DEBUG - 2019-04-11 21:40:58 --> Total execution time: 0.3324
DEBUG - 2019-04-11 21:41:00 --> Config Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:41:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:41:00 --> URI Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Router Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Output Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Security Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Input Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:41:00 --> Language Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Loader Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Controller Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Session Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:41:00 --> Session routines successfully run
DEBUG - 2019-04-11 21:41:00 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:00 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:41:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:41:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:41:00 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:41:00 --> Final output sent to browser
DEBUG - 2019-04-11 21:41:00 --> Total execution time: 0.0584
DEBUG - 2019-04-11 21:41:02 --> Config Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:41:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:41:02 --> URI Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Router Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Output Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Security Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Input Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:41:02 --> Language Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Loader Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Controller Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Session Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:41:02 --> Session routines successfully run
DEBUG - 2019-04-11 21:41:02 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:02 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:41:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:41:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:41:02 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:41:02 --> Final output sent to browser
DEBUG - 2019-04-11 21:41:02 --> Total execution time: 0.0612
DEBUG - 2019-04-11 21:41:04 --> Config Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:41:04 --> URI Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Router Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Output Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Security Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Input Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:41:04 --> Language Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Loader Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Controller Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Session Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:41:04 --> Session routines successfully run
DEBUG - 2019-04-11 21:41:04 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:04 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:41:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:41:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:41:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:41:04 --> Final output sent to browser
DEBUG - 2019-04-11 21:41:04 --> Total execution time: 0.3019
DEBUG - 2019-04-11 21:41:12 --> Config Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:41:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:41:12 --> URI Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Router Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Output Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Security Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Input Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:41:12 --> Language Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Loader Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Controller Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Session Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:41:12 --> Session routines successfully run
DEBUG - 2019-04-11 21:41:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:41:12 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:41:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:41:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:41:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:41:12 --> Final output sent to browser
DEBUG - 2019-04-11 21:41:12 --> Total execution time: 0.2181
DEBUG - 2019-04-11 21:43:10 --> Config Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:43:10 --> URI Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Router Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Output Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Security Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Input Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:43:10 --> Language Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Loader Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Controller Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Session Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:43:10 --> Session routines successfully run
DEBUG - 2019-04-11 21:43:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:43:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:43:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:43:10 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:43:10 --> Final output sent to browser
DEBUG - 2019-04-11 21:43:10 --> Total execution time: 0.0665
DEBUG - 2019-04-11 21:43:20 --> Config Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:43:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:43:20 --> URI Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Router Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Output Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Security Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Input Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:43:20 --> Language Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Loader Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Controller Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Session Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:43:20 --> Session routines successfully run
DEBUG - 2019-04-11 21:43:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:20 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:43:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:43:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:43:20 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 21:43:20 --> Final output sent to browser
DEBUG - 2019-04-11 21:43:20 --> Total execution time: 0.0621
DEBUG - 2019-04-11 21:43:46 --> Config Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:43:46 --> URI Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Router Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Output Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Security Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Input Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:43:46 --> Language Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Loader Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Controller Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Session Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:43:46 --> Session routines successfully run
DEBUG - 2019-04-11 21:43:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:46 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:43:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:43:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:43:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:43:46 --> Final output sent to browser
DEBUG - 2019-04-11 21:43:46 --> Total execution time: 0.1069
DEBUG - 2019-04-11 21:43:57 --> Config Class Initialized
DEBUG - 2019-04-11 21:43:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:43:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:43:58 --> URI Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Router Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Output Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Security Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Input Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:43:58 --> Language Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Loader Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Controller Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Session Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:43:58 --> Session routines successfully run
DEBUG - 2019-04-11 21:43:58 --> Model Class Initialized
DEBUG - 2019-04-11 21:43:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:43:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:43:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:43:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 21:43:58 --> Final output sent to browser
DEBUG - 2019-04-11 21:43:58 --> Total execution time: 0.0944
DEBUG - 2019-04-11 21:47:54 --> Config Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:47:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:47:54 --> URI Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Router Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Output Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Security Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Input Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:47:54 --> Language Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Loader Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Controller Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Session Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:47:54 --> Session routines successfully run
DEBUG - 2019-04-11 21:47:54 --> Model Class Initialized
DEBUG - 2019-04-11 21:47:54 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:47:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:47:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:47:54 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 21:47:54 --> Final output sent to browser
DEBUG - 2019-04-11 21:47:54 --> Total execution time: 0.3937
DEBUG - 2019-04-11 21:48:03 --> Config Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:48:03 --> URI Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Router Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Output Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Security Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Input Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:48:03 --> Language Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Loader Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Controller Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Session Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:48:03 --> Session routines successfully run
DEBUG - 2019-04-11 21:48:03 --> Model Class Initialized
DEBUG - 2019-04-11 21:48:03 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:48:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:48:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:48:03 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:48:03 --> Final output sent to browser
DEBUG - 2019-04-11 21:48:03 --> Total execution time: 0.1685
DEBUG - 2019-04-11 21:49:26 --> Config Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:49:26 --> URI Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Router Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Output Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Security Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Input Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:49:26 --> Language Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Loader Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Controller Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Session Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:49:26 --> Session routines successfully run
DEBUG - 2019-04-11 21:49:26 --> Model Class Initialized
DEBUG - 2019-04-11 21:49:26 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:49:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:49:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:49:26 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:49:26 --> Final output sent to browser
DEBUG - 2019-04-11 21:49:26 --> Total execution time: 0.4227
DEBUG - 2019-04-11 21:51:14 --> Config Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:51:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:51:14 --> URI Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Router Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Output Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Security Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Input Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:51:14 --> Language Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Loader Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Controller Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Session Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:51:14 --> Session routines successfully run
DEBUG - 2019-04-11 21:51:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:51:14 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:51:14 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 21:52:08 --> Config Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:52:08 --> URI Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Router Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Output Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Security Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Input Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:52:08 --> Language Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Loader Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Controller Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Session Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:52:08 --> Session routines successfully run
DEBUG - 2019-04-11 21:52:08 --> Model Class Initialized
DEBUG - 2019-04-11 21:52:08 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:52:08 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 21:53:20 --> Config Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:53:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:53:20 --> URI Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Router Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Output Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Security Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Input Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:53:20 --> Language Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Loader Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Controller Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Session Class Initialized
DEBUG - 2019-04-11 21:53:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:53:21 --> Session routines successfully run
DEBUG - 2019-04-11 21:53:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:53:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:53:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:53:21 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:53:21 --> Final output sent to browser
DEBUG - 2019-04-11 21:53:21 --> Total execution time: 1.0737
DEBUG - 2019-04-11 21:53:39 --> Config Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:53:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:53:39 --> URI Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Router Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Output Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Security Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Input Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:53:39 --> Language Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Loader Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Controller Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Session Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:53:39 --> Session routines successfully run
DEBUG - 2019-04-11 21:53:39 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:39 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:53:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:53:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:53:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:53:39 --> Final output sent to browser
DEBUG - 2019-04-11 21:53:39 --> Total execution time: 0.3542
DEBUG - 2019-04-11 21:53:45 --> Config Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:53:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:53:45 --> URI Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Router Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Output Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Security Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Input Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:53:45 --> Language Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Loader Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Controller Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Session Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:53:45 --> Session routines successfully run
DEBUG - 2019-04-11 21:53:45 --> Model Class Initialized
DEBUG - 2019-04-11 21:53:45 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:53:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:53:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:53:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:53:45 --> Final output sent to browser
DEBUG - 2019-04-11 21:53:45 --> Total execution time: 0.5721
DEBUG - 2019-04-11 21:55:10 --> Config Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:55:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:55:10 --> URI Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Router Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Output Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Security Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Input Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:55:10 --> Language Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Loader Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Controller Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Session Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:55:10 --> Session routines successfully run
DEBUG - 2019-04-11 21:55:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:55:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:55:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:55:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:55:10 --> Final output sent to browser
DEBUG - 2019-04-11 21:55:10 --> Total execution time: 0.6265
DEBUG - 2019-04-11 21:55:12 --> Config Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:55:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:55:12 --> URI Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Router Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Output Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Security Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Input Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:55:12 --> Language Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Loader Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Controller Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Session Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:55:12 --> Session routines successfully run
DEBUG - 2019-04-11 21:55:12 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:12 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:55:12 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 44
ERROR - 2019-04-11 21:55:12 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 45
DEBUG - 2019-04-11 21:55:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:55:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:55:12 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-11 21:55:12 --> Final output sent to browser
DEBUG - 2019-04-11 21:55:12 --> Total execution time: 0.0897
DEBUG - 2019-04-11 21:55:14 --> Config Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:55:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:55:14 --> URI Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Router Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Output Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Security Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Input Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:55:14 --> Language Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Loader Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Controller Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Session Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:55:14 --> Session routines successfully run
DEBUG - 2019-04-11 21:55:14 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:14 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:55:14 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 44
ERROR - 2019-04-11 21:55:14 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 45
DEBUG - 2019-04-11 21:55:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:55:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:55:14 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-11 21:55:14 --> Final output sent to browser
DEBUG - 2019-04-11 21:55:14 --> Total execution time: 0.1581
DEBUG - 2019-04-11 21:55:21 --> Config Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:55:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:55:21 --> URI Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Router Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Output Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Security Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Input Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:55:21 --> Language Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Loader Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Controller Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Session Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:55:21 --> Session routines successfully run
DEBUG - 2019-04-11 21:55:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:21 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:55:21 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 21:55:25 --> Config Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:55:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:55:25 --> URI Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Router Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Output Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Security Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Input Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:55:25 --> Language Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Loader Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Controller Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Session Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:55:25 --> Session routines successfully run
DEBUG - 2019-04-11 21:55:25 --> Model Class Initialized
DEBUG - 2019-04-11 21:55:25 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:55:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:55:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:55:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:55:25 --> Final output sent to browser
DEBUG - 2019-04-11 21:55:25 --> Total execution time: 0.2721
DEBUG - 2019-04-11 21:57:10 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:10 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:10 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:10 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:10 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:57:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:57:11 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:11 --> Total execution time: 0.2804
DEBUG - 2019-04-11 21:57:15 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:15 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:15 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:15 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:57:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:15 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:57:15 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:15 --> Total execution time: 0.3730
DEBUG - 2019-04-11 21:57:15 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:15 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:15 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:15 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:15 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:57:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:57:16 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:16 --> Total execution time: 0.1861
DEBUG - 2019-04-11 21:57:47 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:47 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:47 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:47 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:47 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:57:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:47 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:57:47 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:47 --> Total execution time: 0.2028
DEBUG - 2019-04-11 21:57:49 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:49 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:50 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:50 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:50 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:50 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:57:50 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 44
ERROR - 2019-04-11 21:57:50 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 45
DEBUG - 2019-04-11 21:57:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:50 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-11 21:57:50 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:50 --> Total execution time: 0.0534
DEBUG - 2019-04-11 21:57:51 --> Config Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:57:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:57:51 --> URI Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Router Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Output Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Security Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Input Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:57:51 --> Language Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Loader Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Controller Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Session Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:57:51 --> Session routines successfully run
DEBUG - 2019-04-11 21:57:51 --> Model Class Initialized
DEBUG - 2019-04-11 21:57:51 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:57:51 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 44
ERROR - 2019-04-11 21:57:51 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 45
DEBUG - 2019-04-11 21:57:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:57:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:57:51 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-11 21:57:51 --> Final output sent to browser
DEBUG - 2019-04-11 21:57:51 --> Total execution time: 0.0411
DEBUG - 2019-04-11 21:58:17 --> Config Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:58:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:58:17 --> URI Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Router Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Output Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Security Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Input Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:58:17 --> Language Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Loader Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Controller Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Session Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:58:17 --> Session routines successfully run
DEBUG - 2019-04-11 21:58:17 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:17 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:58:17 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 44
ERROR - 2019-04-11 21:58:17 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 45
DEBUG - 2019-04-11 21:58:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:58:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:58:17 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-11 21:58:17 --> Final output sent to browser
DEBUG - 2019-04-11 21:58:17 --> Total execution time: 0.0464
DEBUG - 2019-04-11 21:58:21 --> Config Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:58:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:58:21 --> URI Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Router Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Output Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Security Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Input Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:58:21 --> Language Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Loader Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Controller Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Session Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:58:21 --> Session routines successfully run
DEBUG - 2019-04-11 21:58:21 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:21 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:58:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:58:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:58:22 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:58:22 --> Final output sent to browser
DEBUG - 2019-04-11 21:58:22 --> Total execution time: 0.6739
DEBUG - 2019-04-11 21:58:46 --> Config Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:58:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:58:46 --> URI Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Router Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Output Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Security Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Input Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:58:46 --> Language Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Loader Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Controller Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Session Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:58:46 --> Session routines successfully run
DEBUG - 2019-04-11 21:58:46 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:46 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:58:46 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 21:58:50 --> Config Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:58:50 --> URI Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Router Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Output Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Security Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Input Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:58:50 --> Language Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Loader Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Controller Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Session Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:58:50 --> Session routines successfully run
DEBUG - 2019-04-11 21:58:50 --> Model Class Initialized
DEBUG - 2019-04-11 21:58:50 --> Helper loaded: url_helper
ERROR - 2019-04-11 21:58:50 --> 404 Page Not Found --> User/doupdateUserDetails
DEBUG - 2019-04-11 21:59:37 --> Config Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:59:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:59:37 --> URI Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Router Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Output Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Security Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Input Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:59:37 --> Language Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Loader Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Controller Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Session Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:59:37 --> Session routines successfully run
DEBUG - 2019-04-11 21:59:37 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:37 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:59:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:59:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:59:38 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:59:38 --> Final output sent to browser
DEBUG - 2019-04-11 21:59:38 --> Total execution time: 0.7933
DEBUG - 2019-04-11 21:59:40 --> Config Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:59:40 --> URI Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Router Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Output Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Security Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Input Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:59:40 --> Language Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Loader Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Controller Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Session Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:59:40 --> Session routines successfully run
DEBUG - 2019-04-11 21:59:40 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:40 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:59:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:59:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:59:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:59:40 --> Final output sent to browser
DEBUG - 2019-04-11 21:59:40 --> Total execution time: 0.3084
DEBUG - 2019-04-11 21:59:53 --> Config Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Hooks Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Utf8 Class Initialized
DEBUG - 2019-04-11 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 21:59:53 --> URI Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Router Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Output Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Security Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Input Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 21:59:53 --> Language Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Loader Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Controller Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Database Driver Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Session Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Helper loaded: string_helper
DEBUG - 2019-04-11 21:59:53 --> Session routines successfully run
DEBUG - 2019-04-11 21:59:53 --> Model Class Initialized
DEBUG - 2019-04-11 21:59:53 --> Helper loaded: url_helper
DEBUG - 2019-04-11 21:59:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 21:59:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 21:59:53 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 21:59:53 --> Final output sent to browser
DEBUG - 2019-04-11 21:59:53 --> Total execution time: 0.4396
DEBUG - 2019-04-11 22:00:10 --> Config Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:00:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:00:10 --> URI Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Router Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Output Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Security Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Input Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:00:10 --> Language Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Loader Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Controller Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Session Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:00:10 --> Session garbage collection performed.
DEBUG - 2019-04-11 22:00:10 --> Session routines successfully run
DEBUG - 2019-04-11 22:00:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:00:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:00:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:00:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:00:10 --> Final output sent to browser
DEBUG - 2019-04-11 22:00:10 --> Total execution time: 0.2113
DEBUG - 2019-04-11 22:00:47 --> Config Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:00:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:00:47 --> URI Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Router Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Output Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Security Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Input Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:00:47 --> Language Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Loader Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Controller Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Session Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:00:47 --> Session routines successfully run
DEBUG - 2019-04-11 22:00:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:00:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:00:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:00:47 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:00:47 --> Final output sent to browser
DEBUG - 2019-04-11 22:00:47 --> Total execution time: 0.3108
DEBUG - 2019-04-11 22:00:51 --> Config Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:00:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:00:51 --> URI Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Router Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Output Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Security Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Input Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:00:51 --> Language Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Loader Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Controller Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:51 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:00:52 --> Session Class Initialized
DEBUG - 2019-04-11 22:00:52 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:00:52 --> Session routines successfully run
DEBUG - 2019-04-11 22:00:52 --> Model Class Initialized
DEBUG - 2019-04-11 22:00:52 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:00:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:00:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:00:52 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-11 22:00:52 --> Final output sent to browser
DEBUG - 2019-04-11 22:00:52 --> Total execution time: 0.1527
DEBUG - 2019-04-11 22:01:27 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:27 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:27 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:27 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:27 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:27 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:27 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:27 --> A session cookie was not found.
DEBUG - 2019-04-11 22:01:27 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 22:01:27 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:27 --> Total execution time: 0.1507
DEBUG - 2019-04-11 22:01:33 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:33 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:33 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:33 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:33 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 22:01:33 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:33 --> Total execution time: 0.0695
DEBUG - 2019-04-11 22:01:38 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:38 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:38 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:38 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:38 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:38 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:01:39 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:39 --> Total execution time: 0.5800
DEBUG - 2019-04-11 22:01:41 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:41 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:41 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:41 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:41 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:41 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:41 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:41 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:41 --> A session cookie was not found.
DEBUG - 2019-04-11 22:01:42 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:42 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 22:01:42 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:42 --> Total execution time: 1.1297
DEBUG - 2019-04-11 22:01:47 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:47 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:47 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:47 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:47 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:47 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:47 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 22:01:47 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:47 --> Total execution time: 0.0689
DEBUG - 2019-04-11 22:01:55 --> Config Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:01:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:01:55 --> URI Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Router Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Output Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Security Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Input Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:01:55 --> Language Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Loader Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Controller Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Session Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:01:55 --> Session routines successfully run
DEBUG - 2019-04-11 22:01:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:01:55 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:01:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:01:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:01:55 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:01:55 --> Final output sent to browser
DEBUG - 2019-04-11 22:01:55 --> Total execution time: 0.4911
DEBUG - 2019-04-11 22:06:33 --> Config Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:06:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:06:33 --> URI Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Router Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Output Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Security Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Input Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:06:33 --> Language Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Loader Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Controller Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Session Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:06:33 --> Session routines successfully run
DEBUG - 2019-04-11 22:06:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:06:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:06:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:06:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:06:33 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-11 22:06:33 --> Final output sent to browser
DEBUG - 2019-04-11 22:06:33 --> Total execution time: 0.0797
DEBUG - 2019-04-11 22:08:44 --> Config Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:08:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:08:44 --> URI Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Router Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Output Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Security Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Input Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:08:44 --> Language Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Loader Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Controller Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Session Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:08:44 --> Session routines successfully run
DEBUG - 2019-04-11 22:08:44 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:44 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:08:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:08:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:08:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:08:45 --> Final output sent to browser
DEBUG - 2019-04-11 22:08:45 --> Total execution time: 0.9290
DEBUG - 2019-04-11 22:08:46 --> Config Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:08:46 --> URI Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Router Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Output Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Security Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Input Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:08:46 --> Language Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Loader Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Controller Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Session Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:08:46 --> Session routines successfully run
DEBUG - 2019-04-11 22:08:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:08:46 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:08:46 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:08:46 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:08:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:08:46 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:08:46 --> Final output sent to browser
DEBUG - 2019-04-11 22:08:46 --> Total execution time: 0.0610
DEBUG - 2019-04-11 22:10:27 --> Config Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:10:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:10:27 --> URI Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Router Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Output Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Security Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Input Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:10:27 --> Language Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Loader Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Controller Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Session Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:10:27 --> Session routines successfully run
DEBUG - 2019-04-11 22:10:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:10:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:10:27 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:10:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:10:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:10:27 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:10:27 --> Final output sent to browser
DEBUG - 2019-04-11 22:10:27 --> Total execution time: 0.0619
DEBUG - 2019-04-11 22:11:33 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:33 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:33 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:33 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:33 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:33 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:33 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:33 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:33 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:33 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:33 --> Total execution time: 0.0710
DEBUG - 2019-04-11 22:11:41 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:41 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:41 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:41 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:41 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:41 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:41 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:41 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:41 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:41 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:41 --> Total execution time: 0.0604
DEBUG - 2019-04-11 22:11:49 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:49 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:49 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:49 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:49 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:49 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:49 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:49 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:49 --> Total execution time: 0.0779
DEBUG - 2019-04-11 22:11:50 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:50 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:50 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:50 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:50 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:50 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:50 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:50 --> Total execution time: 0.0587
DEBUG - 2019-04-11 22:11:51 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:51 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:51 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:51 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:51 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:51 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:51 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:51 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:51 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:51 --> Total execution time: 0.0522
DEBUG - 2019-04-11 22:11:55 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:55 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:55 --> No URI present. Default controller set.
DEBUG - 2019-04-11 22:11:55 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:55 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:55 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:55 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:11:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 22:11:55 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:55 --> Total execution time: 0.0865
DEBUG - 2019-04-11 22:11:58 --> Config Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:11:58 --> URI Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Router Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Output Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Security Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Input Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:11:58 --> Language Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Loader Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Controller Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Session Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:11:58 --> Session routines successfully run
DEBUG - 2019-04-11 22:11:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:11:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:11:58 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:11:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:11:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:11:58 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:11:58 --> Final output sent to browser
DEBUG - 2019-04-11 22:11:58 --> Total execution time: 0.0512
DEBUG - 2019-04-11 22:12:48 --> Config Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:12:48 --> URI Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Router Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Output Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Security Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Input Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:12:48 --> Language Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Loader Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Controller Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Session Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:12:48 --> Session routines successfully run
DEBUG - 2019-04-11 22:12:48 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:48 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:12:48 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:12:48 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:12:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:12:48 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:12:48 --> Final output sent to browser
DEBUG - 2019-04-11 22:12:48 --> Total execution time: 0.0544
DEBUG - 2019-04-11 22:12:58 --> Config Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:12:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:12:58 --> URI Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Router Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Output Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Security Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Input Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:12:58 --> Language Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Loader Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Controller Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Session Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:12:58 --> Session routines successfully run
DEBUG - 2019-04-11 22:12:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:12:58 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:12:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:12:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:12:58 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:12:58 --> Final output sent to browser
DEBUG - 2019-04-11 22:12:58 --> Total execution time: 0.0711
DEBUG - 2019-04-11 22:12:59 --> Config Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:12:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:12:59 --> URI Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Router Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Output Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Security Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Input Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:12:59 --> Language Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Loader Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Controller Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Session Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:12:59 --> Session routines successfully run
DEBUG - 2019-04-11 22:12:59 --> Model Class Initialized
DEBUG - 2019-04-11 22:12:59 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:12:59 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:12:59 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:12:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:12:59 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:12:59 --> Final output sent to browser
DEBUG - 2019-04-11 22:12:59 --> Total execution time: 0.0725
DEBUG - 2019-04-11 22:13:00 --> Config Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:13:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:13:00 --> URI Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Router Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Output Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Security Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Input Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:13:00 --> Language Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Loader Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Controller Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Session Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:13:00 --> Session routines successfully run
DEBUG - 2019-04-11 22:13:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:00 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:13:00 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:13:00 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:13:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:13:00 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:13:00 --> Final output sent to browser
DEBUG - 2019-04-11 22:13:00 --> Total execution time: 0.0673
DEBUG - 2019-04-11 22:13:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:13:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:13:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:13:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:13:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:13:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:13:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:13:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:13:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:13:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:13:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:13:16 --> Total execution time: 0.0622
DEBUG - 2019-04-11 22:13:30 --> Config Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:13:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:13:30 --> URI Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Router Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Output Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Security Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Input Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:13:30 --> Language Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Loader Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Controller Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:30 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:13:31 --> Session Class Initialized
DEBUG - 2019-04-11 22:13:31 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:13:31 --> Session routines successfully run
DEBUG - 2019-04-11 22:13:31 --> Model Class Initialized
DEBUG - 2019-04-11 22:13:31 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:13:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:13:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:13:31 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-11 22:13:31 --> Final output sent to browser
DEBUG - 2019-04-11 22:13:31 --> Total execution time: 0.0539
DEBUG - 2019-04-11 22:14:13 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:13 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:13 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:13 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:13 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:13 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:13 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:13 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:13 --> Total execution time: 0.5802
DEBUG - 2019-04-11 22:14:42 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:42 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:42 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:42 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:42 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:42 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:42 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:42 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:42 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:42 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:42 --> Total execution time: 0.1713
DEBUG - 2019-04-11 22:14:43 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:43 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:43 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:43 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:43 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:43 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:43 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:43 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:43 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:43 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:43 --> Total execution time: 0.0660
DEBUG - 2019-04-11 22:14:46 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:46 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:46 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:46 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:46 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:46 --> Helper loaded: url_helper
ERROR - 2019-04-11 22:14:46 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-11 22:14:49 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:49 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:49 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:49 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:49 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:49 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:49 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:49 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:49 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:49 --> Total execution time: 0.0500
DEBUG - 2019-04-11 22:14:50 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:50 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:50 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:50 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:50 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:51 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:51 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:51 --> Total execution time: 0.1610
DEBUG - 2019-04-11 22:14:58 --> Config Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:14:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:14:58 --> URI Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Router Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Output Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Security Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Input Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:14:58 --> Language Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Loader Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Controller Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Session Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:14:58 --> Session routines successfully run
DEBUG - 2019-04-11 22:14:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:14:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:14:58 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:14:58 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:14:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:14:58 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:14:58 --> Final output sent to browser
DEBUG - 2019-04-11 22:14:58 --> Total execution time: 0.0546
DEBUG - 2019-04-11 22:15:10 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:10 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:10 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:11 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:11 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:11 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:11 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:11 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:11 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:11 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:11 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:11 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:11 --> Total execution time: 0.0587
DEBUG - 2019-04-11 22:15:12 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:12 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:12 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:12 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:13 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:13 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:13 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:13 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:13 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:13 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:13 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:13 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:13 --> Total execution time: 0.0605
DEBUG - 2019-04-11 22:15:14 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:14 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:14 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:14 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:14 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:14 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:14 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:14 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:14 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:14 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:14 --> Total execution time: 0.0547
DEBUG - 2019-04-11 22:15:15 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:15 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:15 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:15 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:15 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:15 --> Total execution time: 0.0611
DEBUG - 2019-04-11 22:15:15 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:15 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:15 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:15 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:15 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:15 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:15 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:15 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:15 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:15 --> Total execution time: 0.0537
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0563
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0677
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0597
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0459
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0661
DEBUG - 2019-04-11 22:15:16 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:16 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:16 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:16 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:16 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:16 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:16 --> Total execution time: 0.0568
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0601
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0460
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0576
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0597
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0547
DEBUG - 2019-04-11 22:15:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:15:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:15:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:15:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:15:17 --> Session routines successfully run
DEBUG - 2019-04-11 22:15:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:15:17 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:15:17 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:15:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:15:17 --> Final output sent to browser
DEBUG - 2019-04-11 22:15:17 --> Total execution time: 0.0476
DEBUG - 2019-04-11 22:17:10 --> Config Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:17:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:17:10 --> URI Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Router Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Output Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Security Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Input Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:17:10 --> Language Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Loader Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Controller Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Session Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:17:10 --> Session routines successfully run
DEBUG - 2019-04-11 22:17:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:17:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:17:10 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 25
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 27
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 30
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 34
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 37
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 40
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 43
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 47
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 51
ERROR - 2019-04-11 22:17:10 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 55
DEBUG - 2019-04-11 22:17:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:17:10 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:17:10 --> Final output sent to browser
DEBUG - 2019-04-11 22:17:10 --> Total execution time: 0.0733
DEBUG - 2019-04-11 22:18:32 --> Config Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:18:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:18:32 --> URI Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Router Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Output Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Security Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Input Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:18:32 --> Language Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Loader Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Controller Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Model Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Model Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Session Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:18:32 --> Session routines successfully run
DEBUG - 2019-04-11 22:18:32 --> Model Class Initialized
DEBUG - 2019-04-11 22:18:32 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:18:32 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:18:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:18:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:18:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:18:32 --> Final output sent to browser
DEBUG - 2019-04-11 22:18:32 --> Total execution time: 0.0597
DEBUG - 2019-04-11 22:19:18 --> Config Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:19:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:19:18 --> URI Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Router Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Output Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Security Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Input Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:19:18 --> Language Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Loader Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Controller Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Model Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Model Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Session Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:19:18 --> Session routines successfully run
DEBUG - 2019-04-11 22:19:18 --> Model Class Initialized
DEBUG - 2019-04-11 22:19:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:19:18 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:19:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:19:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:19:18 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:19:18 --> Final output sent to browser
DEBUG - 2019-04-11 22:19:18 --> Total execution time: 0.3212
DEBUG - 2019-04-11 22:25:17 --> Config Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:25:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:25:17 --> URI Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Router Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Output Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Security Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Input Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:25:17 --> Language Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Loader Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Controller Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Session Class Initialized
DEBUG - 2019-04-11 22:25:17 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:25:18 --> Session routines successfully run
DEBUG - 2019-04-11 22:25:18 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:18 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:25:18 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:25:18 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:25:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:25:18 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:25:18 --> Final output sent to browser
DEBUG - 2019-04-11 22:25:18 --> Total execution time: 0.9221
DEBUG - 2019-04-11 22:25:20 --> Config Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:25:20 --> URI Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Router Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Output Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Security Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Input Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:25:20 --> Language Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Loader Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Controller Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Session Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:25:20 --> Session routines successfully run
DEBUG - 2019-04-11 22:25:20 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:20 --> Helper loaded: url_helper
ERROR - 2019-04-11 22:25:20 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-11 22:25:22 --> Config Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:25:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:25:22 --> URI Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Router Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Output Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Security Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Input Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:25:22 --> Language Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Loader Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Controller Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Session Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:25:22 --> Session routines successfully run
DEBUG - 2019-04-11 22:25:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:22 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:25:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:25:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:25:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:25:22 --> Final output sent to browser
DEBUG - 2019-04-11 22:25:22 --> Total execution time: 0.0429
DEBUG - 2019-04-11 22:25:49 --> Config Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:25:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:25:49 --> URI Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Router Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Output Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Security Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Input Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:25:49 --> Language Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Loader Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Controller Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Session Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:25:49 --> Session routines successfully run
DEBUG - 2019-04-11 22:25:49 --> Model Class Initialized
DEBUG - 2019-04-11 22:25:49 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:25:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:25:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:25:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:25:50 --> Final output sent to browser
DEBUG - 2019-04-11 22:25:50 --> Total execution time: 0.6273
DEBUG - 2019-04-11 22:26:10 --> Config Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:26:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:26:10 --> URI Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Router Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Output Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Security Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Input Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:26:10 --> Language Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Loader Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Controller Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Session Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:26:10 --> Session routines successfully run
DEBUG - 2019-04-11 22:26:10 --> Model Class Initialized
DEBUG - 2019-04-11 22:26:10 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:26:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:26:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:26:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:26:10 --> Final output sent to browser
DEBUG - 2019-04-11 22:26:10 --> Total execution time: 0.4416
DEBUG - 2019-04-11 22:27:28 --> Config Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:27:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:27:28 --> URI Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Router Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Output Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Security Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Input Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:27:28 --> Language Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Loader Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Controller Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Session Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:27:28 --> Session routines successfully run
DEBUG - 2019-04-11 22:27:28 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:28 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:27:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:27:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:27:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:27:29 --> Final output sent to browser
DEBUG - 2019-04-11 22:27:29 --> Total execution time: 0.3280
DEBUG - 2019-04-11 22:27:58 --> Config Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:27:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:27:58 --> URI Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Router Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Output Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Security Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Input Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:27:58 --> Language Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Loader Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Controller Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Session Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:27:58 --> Session routines successfully run
DEBUG - 2019-04-11 22:27:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:27:58 --> Config Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:27:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:27:58 --> URI Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Router Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Output Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Security Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Input Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:27:58 --> Language Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Loader Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Controller Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Session Class Initialized
DEBUG - 2019-04-11 22:27:58 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:27:58 --> A session cookie was not found.
DEBUG - 2019-04-11 22:27:59 --> Session routines successfully run
DEBUG - 2019-04-11 22:27:59 --> Model Class Initialized
DEBUG - 2019-04-11 22:27:59 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:27:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:27:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:27:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-11 22:27:59 --> Final output sent to browser
DEBUG - 2019-04-11 22:27:59 --> Total execution time: 1.1544
DEBUG - 2019-04-11 22:28:05 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:05 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:05 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:05 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:05 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:05 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:28:05 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:05 --> Total execution time: 0.0424
DEBUG - 2019-04-11 22:28:06 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:06 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:06 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:06 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:06 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:06 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:06 --> File loaded: application/views/producers.php
DEBUG - 2019-04-11 22:28:06 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:06 --> Total execution time: 0.0932
DEBUG - 2019-04-11 22:28:09 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:09 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:09 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:09 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:09 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:09 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:09 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 22:28:09 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:09 --> Total execution time: 0.0613
DEBUG - 2019-04-11 22:28:11 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:11 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:11 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:11 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:11 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:11 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:11 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-11 22:28:11 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:11 --> Total execution time: 0.0426
DEBUG - 2019-04-11 22:28:13 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:13 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:13 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:13 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:13 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:13 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-11 22:28:13 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:13 --> Total execution time: 0.0547
DEBUG - 2019-04-11 22:28:19 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:19 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:19 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:19 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:19 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:19 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:28:20 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:20 --> Total execution time: 0.8196
DEBUG - 2019-04-11 22:28:22 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:22 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:22 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:22 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:22 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:22 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:28:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:28:22 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:22 --> Total execution time: 0.1077
DEBUG - 2019-04-11 22:28:24 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:24 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:24 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:24 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:24 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:24 --> Helper loaded: url_helper
ERROR - 2019-04-11 22:28:24 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-11 22:28:27 --> Config Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:28:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:28:27 --> URI Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Router Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Output Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Security Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Input Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:28:27 --> Language Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Loader Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Controller Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Session Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:28:27 --> Session routines successfully run
DEBUG - 2019-04-11 22:28:27 --> Model Class Initialized
DEBUG - 2019-04-11 22:28:27 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:28:27 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:28:27 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:28:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:28:27 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:28:27 --> Final output sent to browser
DEBUG - 2019-04-11 22:28:27 --> Total execution time: 0.0583
DEBUG - 2019-04-11 22:29:55 --> Config Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:29:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:29:55 --> URI Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Router Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Output Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Security Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Input Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:29:55 --> Language Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Loader Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Controller Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:55 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:29:56 --> Session Class Initialized
DEBUG - 2019-04-11 22:29:56 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:29:56 --> Session routines successfully run
DEBUG - 2019-04-11 22:29:56 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:56 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:29:56 --> File loaded: application/views/header.php
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-11 22:29:56 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-11 22:29:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:29:56 --> File loaded: application/views/profile.php
DEBUG - 2019-04-11 22:29:56 --> Final output sent to browser
DEBUG - 2019-04-11 22:29:56 --> Total execution time: 0.0919
DEBUG - 2019-04-11 22:29:57 --> Config Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:29:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:29:57 --> URI Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Router Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Output Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Security Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Input Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:29:57 --> Language Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Loader Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Controller Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Session Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:29:57 --> Session routines successfully run
DEBUG - 2019-04-11 22:29:57 --> Model Class Initialized
DEBUG - 2019-04-11 22:29:57 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:29:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:29:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:29:58 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:29:58 --> Final output sent to browser
DEBUG - 2019-04-11 22:29:58 --> Total execution time: 0.3137
DEBUG - 2019-04-11 22:32:00 --> Config Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:32:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:32:00 --> URI Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Router Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Output Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Security Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Input Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:32:00 --> Language Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Loader Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Controller Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Session Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:32:00 --> Session routines successfully run
DEBUG - 2019-04-11 22:32:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:32:00 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:32:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:32:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:32:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:32:00 --> Final output sent to browser
DEBUG - 2019-04-11 22:32:00 --> Total execution time: 0.0618
DEBUG - 2019-04-11 22:33:00 --> Config Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:33:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:33:00 --> URI Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Router Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Output Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Security Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Input Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:33:00 --> Language Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Loader Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Controller Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Session Class Initialized
DEBUG - 2019-04-11 22:33:00 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:33:00 --> Session routines successfully run
DEBUG - 2019-04-11 22:33:00 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:33:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:33:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:33:00 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-11 22:33:00 --> Final output sent to browser
DEBUG - 2019-04-11 22:33:00 --> Total execution time: 0.3848
DEBUG - 2019-04-11 22:33:37 --> Config Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:33:37 --> URI Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Router Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Output Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Security Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Input Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:33:37 --> Language Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Loader Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Controller Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Session Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:33:37 --> Session garbage collection performed.
DEBUG - 2019-04-11 22:33:37 --> Session routines successfully run
DEBUG - 2019-04-11 22:33:37 --> Model Class Initialized
DEBUG - 2019-04-11 22:33:37 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:33:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:33:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:33:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:33:37 --> Final output sent to browser
DEBUG - 2019-04-11 22:33:37 --> Total execution time: 0.0443
DEBUG - 2019-04-11 22:36:08 --> Config Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:36:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:36:08 --> URI Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Router Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Output Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Security Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Input Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:36:08 --> Language Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Loader Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Controller Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Session Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:36:08 --> Session routines successfully run
DEBUG - 2019-04-11 22:36:08 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:08 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:36:31 --> Config Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:36:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:36:31 --> URI Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Router Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Output Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Security Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Input Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:36:31 --> Language Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Loader Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Controller Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Session Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:36:31 --> Session routines successfully run
DEBUG - 2019-04-11 22:36:31 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:31 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:36:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:36:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:36:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-11 22:36:32 --> Final output sent to browser
DEBUG - 2019-04-11 22:36:32 --> Total execution time: 0.3578
DEBUG - 2019-04-11 22:36:36 --> Config Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:36:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:36:36 --> URI Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Router Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Output Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Security Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Input Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:36:36 --> Language Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Loader Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Controller Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Session Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:36:36 --> Session routines successfully run
DEBUG - 2019-04-11 22:36:36 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:36 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:36:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:36:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:36:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:36:36 --> Final output sent to browser
DEBUG - 2019-04-11 22:36:36 --> Total execution time: 0.0522
DEBUG - 2019-04-11 22:36:50 --> Config Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Hooks Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Utf8 Class Initialized
DEBUG - 2019-04-11 22:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-11 22:36:50 --> URI Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Router Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Output Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Security Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Input Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-11 22:36:50 --> Language Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Loader Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Controller Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Database Driver Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Session Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Helper loaded: string_helper
DEBUG - 2019-04-11 22:36:50 --> Session routines successfully run
DEBUG - 2019-04-11 22:36:50 --> Model Class Initialized
DEBUG - 2019-04-11 22:36:50 --> Helper loaded: url_helper
DEBUG - 2019-04-11 22:36:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-11 22:36:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-11 22:36:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-11 22:36:50 --> Final output sent to browser
DEBUG - 2019-04-11 22:36:50 --> Total execution time: 0.0715
