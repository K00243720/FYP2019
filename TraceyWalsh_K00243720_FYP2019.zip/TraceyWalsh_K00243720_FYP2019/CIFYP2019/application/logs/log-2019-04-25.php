<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-25 12:23:03 --> Config Class Initialized
DEBUG - 2019-04-25 12:23:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:23:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:23:04 --> URI Class Initialized
DEBUG - 2019-04-25 12:23:04 --> Router Class Initialized
DEBUG - 2019-04-25 12:23:04 --> No URI present. Default controller set.
DEBUG - 2019-04-25 12:23:05 --> Output Class Initialized
DEBUG - 2019-04-25 12:23:05 --> Security Class Initialized
DEBUG - 2019-04-25 12:23:05 --> Input Class Initialized
DEBUG - 2019-04-25 12:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:23:05 --> Language Class Initialized
DEBUG - 2019-04-25 12:23:05 --> Loader Class Initialized
DEBUG - 2019-04-25 12:23:05 --> Controller Class Initialized
DEBUG - 2019-04-25 12:23:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:23:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:23:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:23:06 --> Session Class Initialized
DEBUG - 2019-04-25 12:23:07 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:23:07 --> A session cookie was not found.
DEBUG - 2019-04-25 12:23:07 --> Session routines successfully run
DEBUG - 2019-04-25 12:23:07 --> Model Class Initialized
DEBUG - 2019-04-25 12:23:07 --> Model Class Initialized
DEBUG - 2019-04-25 12:23:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:23:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:23:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:23:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 12:23:09 --> Final output sent to browser
DEBUG - 2019-04-25 12:23:09 --> Total execution time: 6.5664
DEBUG - 2019-04-25 12:24:35 --> Config Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:24:35 --> URI Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Router Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Output Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Security Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Input Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:24:35 --> Language Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Loader Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Controller Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Session Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:24:35 --> Session routines successfully run
DEBUG - 2019-04-25 12:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:24:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:24:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:24:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:24:35 --> File loaded: application/views/producers.php
DEBUG - 2019-04-25 12:24:35 --> Final output sent to browser
DEBUG - 2019-04-25 12:24:35 --> Total execution time: 0.0728
DEBUG - 2019-04-25 12:25:35 --> Config Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:25:35 --> URI Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Router Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Output Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Security Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Input Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:25:35 --> Language Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Loader Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Controller Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Session Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:25:35 --> Session routines successfully run
DEBUG - 2019-04-25 12:25:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:25:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:25:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:25:35 --> File loaded: application/views/producers.php
DEBUG - 2019-04-25 12:25:35 --> Final output sent to browser
DEBUG - 2019-04-25 12:25:35 --> Total execution time: 0.0477
DEBUG - 2019-04-25 12:25:46 --> Config Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:25:46 --> URI Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Router Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Output Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Security Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Input Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:25:46 --> Language Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Loader Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Controller Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Session Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:25:46 --> Session routines successfully run
DEBUG - 2019-04-25 12:25:46 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Model Class Initialized
DEBUG - 2019-04-25 12:25:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:25:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:25:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:25:46 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 12:25:46 --> Final output sent to browser
DEBUG - 2019-04-25 12:25:46 --> Total execution time: 0.0700
DEBUG - 2019-04-25 12:28:06 --> Config Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:28:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:28:06 --> URI Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Router Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Output Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Security Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Input Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:28:06 --> Language Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Loader Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Controller Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Session Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:28:06 --> Session routines successfully run
DEBUG - 2019-04-25 12:28:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Model Class Initialized
DEBUG - 2019-04-25 12:28:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:28:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:28:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:28:06 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 12:28:06 --> DB Transaction Failure
ERROR - 2019-04-25 12:28:06 --> Query error: Unknown column 'userid' in 'where clause'
DEBUG - 2019-04-25 12:28:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-25 12:37:31 --> Config Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:37:31 --> URI Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Router Class Initialized
DEBUG - 2019-04-25 12:37:31 --> No URI present. Default controller set.
DEBUG - 2019-04-25 12:37:31 --> Output Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Security Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Input Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:37:31 --> Language Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Loader Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Controller Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Session Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:37:31 --> A session cookie was not found.
DEBUG - 2019-04-25 12:37:31 --> Session routines successfully run
DEBUG - 2019-04-25 12:37:31 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:31 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:37:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:37:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:37:31 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 12:37:31 --> Final output sent to browser
DEBUG - 2019-04-25 12:37:31 --> Total execution time: 0.1826
DEBUG - 2019-04-25 12:37:34 --> Config Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:37:34 --> URI Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Router Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Output Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Security Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Input Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:37:34 --> Language Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Loader Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Controller Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Session Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:37:34 --> Session routines successfully run
DEBUG - 2019-04-25 12:37:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:37:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:37:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:37:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:37:34 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 12:37:34 --> Final output sent to browser
DEBUG - 2019-04-25 12:37:34 --> Total execution time: 0.0640
DEBUG - 2019-04-25 12:38:13 --> Config Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:38:13 --> URI Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Router Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Output Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Security Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Input Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:38:13 --> Language Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Loader Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Controller Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Session Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:38:13 --> Session routines successfully run
DEBUG - 2019-04-25 12:38:13 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:13 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:38:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:38:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:38:13 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 12:38:13 --> Final output sent to browser
DEBUG - 2019-04-25 12:38:13 --> Total execution time: 0.0438
DEBUG - 2019-04-25 12:38:18 --> Config Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:38:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:38:18 --> URI Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Router Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Output Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Security Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Input Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:38:18 --> Language Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Loader Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Controller Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Session Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:38:18 --> Session routines successfully run
DEBUG - 2019-04-25 12:38:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:38:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:38:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:38:18 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 12:38:18 --> Final output sent to browser
DEBUG - 2019-04-25 12:38:18 --> Total execution time: 0.0528
DEBUG - 2019-04-25 12:38:30 --> Config Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:38:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:38:30 --> URI Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Router Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Output Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Security Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Input Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:38:30 --> Language Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Loader Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Controller Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Session Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:38:30 --> Session routines successfully run
DEBUG - 2019-04-25 12:38:30 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:30 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:38:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:38:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:38:30 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 12:38:30 --> Final output sent to browser
DEBUG - 2019-04-25 12:38:30 --> Total execution time: 0.2351
DEBUG - 2019-04-25 12:38:37 --> Config Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:38:37 --> URI Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Router Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Output Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Security Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Input Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:38:37 --> Language Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Loader Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Controller Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Session Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:38:37 --> Session routines successfully run
DEBUG - 2019-04-25 12:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 12:38:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:38:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:38:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:38:37 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:38:37 --> Final output sent to browser
DEBUG - 2019-04-25 12:38:37 --> Total execution time: 0.0546
DEBUG - 2019-04-25 12:40:18 --> Config Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:40:18 --> URI Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Router Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Output Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Security Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Input Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:40:18 --> Language Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Loader Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Controller Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Session Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:40:18 --> Session routines successfully run
DEBUG - 2019-04-25 12:40:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:40:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:40:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:40:18 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:40:18 --> Final output sent to browser
DEBUG - 2019-04-25 12:40:18 --> Total execution time: 0.0455
DEBUG - 2019-04-25 12:40:35 --> Config Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:40:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:40:35 --> URI Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Router Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Output Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Security Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Input Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:40:35 --> Language Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Loader Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Controller Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Session Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:40:35 --> Session routines successfully run
DEBUG - 2019-04-25 12:40:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:40:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:40:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:40:35 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:40:35 --> Final output sent to browser
DEBUG - 2019-04-25 12:40:35 --> Total execution time: 0.0470
DEBUG - 2019-04-25 12:40:48 --> Config Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:40:48 --> URI Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Router Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Output Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Security Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Input Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:40:48 --> Language Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Loader Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Controller Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Session Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:40:48 --> Session routines successfully run
DEBUG - 2019-04-25 12:40:48 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Model Class Initialized
DEBUG - 2019-04-25 12:40:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:40:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:40:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:40:48 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:40:48 --> Final output sent to browser
DEBUG - 2019-04-25 12:40:48 --> Total execution time: 0.0550
DEBUG - 2019-04-25 12:41:29 --> Config Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:41:29 --> URI Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Router Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Output Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Security Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Input Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:41:29 --> Language Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Loader Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Controller Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Session Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:41:29 --> Session routines successfully run
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:41:29 --> Config Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:41:29 --> URI Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Router Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Output Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Security Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Input Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:41:29 --> Language Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Loader Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Controller Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Session Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:41:29 --> A session cookie was not found.
DEBUG - 2019-04-25 12:41:29 --> Session routines successfully run
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:41:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:41:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:41:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 12:41:30 --> Final output sent to browser
DEBUG - 2019-04-25 12:41:30 --> Total execution time: 0.2552
DEBUG - 2019-04-25 12:41:34 --> Config Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:41:34 --> URI Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Router Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Output Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Security Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Input Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:41:34 --> Language Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Loader Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Controller Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Session Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:41:34 --> Session routines successfully run
DEBUG - 2019-04-25 12:41:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:41:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:41:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:41:34 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 12:41:34 --> Final output sent to browser
DEBUG - 2019-04-25 12:41:34 --> Total execution time: 0.0531
DEBUG - 2019-04-25 12:41:44 --> Config Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:41:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:41:44 --> URI Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Router Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Output Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Security Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Input Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:41:44 --> Language Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Loader Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Controller Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Session Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:41:44 --> Session routines successfully run
DEBUG - 2019-04-25 12:41:44 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:44 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:41:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:41:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:41:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 12:41:44 --> Final output sent to browser
DEBUG - 2019-04-25 12:41:44 --> Total execution time: 0.1493
DEBUG - 2019-04-25 12:41:49 --> Config Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:41:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:41:49 --> URI Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Router Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Output Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Security Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Input Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:41:49 --> Language Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Loader Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Controller Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Session Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:41:49 --> Session routines successfully run
DEBUG - 2019-04-25 12:41:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:41:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:41:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:41:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:41:49 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:41:49 --> Final output sent to browser
DEBUG - 2019-04-25 12:41:49 --> Total execution time: 0.0526
DEBUG - 2019-04-25 12:43:16 --> Config Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:43:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:43:16 --> URI Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Router Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Output Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Security Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Input Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:43:16 --> Language Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Loader Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Controller Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Session Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:43:16 --> Session routines successfully run
DEBUG - 2019-04-25 12:43:16 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:43:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:43:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:43:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:43:16 --> Final output sent to browser
DEBUG - 2019-04-25 12:43:16 --> Total execution time: 0.0527
DEBUG - 2019-04-25 12:43:17 --> Config Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:43:17 --> URI Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Router Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Output Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Security Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Input Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:43:17 --> Language Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Loader Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Controller Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Session Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:43:17 --> Session routines successfully run
DEBUG - 2019-04-25 12:43:17 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:17 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:43:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:43:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:43:17 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:43:17 --> Final output sent to browser
DEBUG - 2019-04-25 12:43:17 --> Total execution time: 0.0501
DEBUG - 2019-04-25 12:43:23 --> Config Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:43:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:43:23 --> URI Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Router Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Output Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Security Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Input Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:43:23 --> Language Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Loader Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Controller Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Session Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:43:23 --> Session routines successfully run
DEBUG - 2019-04-25 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:23 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:43:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:43:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:43:23 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 12:43:23 --> Final output sent to browser
DEBUG - 2019-04-25 12:43:23 --> Total execution time: 0.0520
DEBUG - 2019-04-25 12:43:36 --> Config Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:43:36 --> URI Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Router Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Output Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Security Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Input Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:43:36 --> Language Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Loader Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Controller Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Session Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:43:36 --> Session routines successfully run
DEBUG - 2019-04-25 12:43:36 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Model Class Initialized
DEBUG - 2019-04-25 12:43:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:43:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:43:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:43:36 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-25 12:43:36 --> Final output sent to browser
DEBUG - 2019-04-25 12:43:36 --> Total execution time: 0.0569
DEBUG - 2019-04-25 12:52:49 --> Config Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:52:49 --> URI Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Router Class Initialized
DEBUG - 2019-04-25 12:52:49 --> No URI present. Default controller set.
DEBUG - 2019-04-25 12:52:49 --> Output Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Security Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Input Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:52:49 --> Language Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Loader Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Controller Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Session Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:52:49 --> Session routines successfully run
DEBUG - 2019-04-25 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:52:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:52:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:52:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 12:52:49 --> Final output sent to browser
DEBUG - 2019-04-25 12:52:49 --> Total execution time: 0.1964
DEBUG - 2019-04-25 12:52:58 --> Config Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Hooks Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Utf8 Class Initialized
DEBUG - 2019-04-25 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 12:52:58 --> URI Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Router Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Output Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Security Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Input Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 12:52:58 --> Language Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Loader Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Controller Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Database Driver Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Session Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Helper loaded: string_helper
DEBUG - 2019-04-25 12:52:58 --> Session routines successfully run
DEBUG - 2019-04-25 12:52:58 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Model Class Initialized
DEBUG - 2019-04-25 12:52:58 --> Helper loaded: url_helper
DEBUG - 2019-04-25 12:52:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 12:52:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 12:52:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 12:52:58 --> Final output sent to browser
DEBUG - 2019-04-25 12:52:58 --> Total execution time: 0.0530
DEBUG - 2019-04-25 13:00:14 --> Config Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:00:14 --> URI Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Router Class Initialized
DEBUG - 2019-04-25 13:00:14 --> No URI present. Default controller set.
DEBUG - 2019-04-25 13:00:14 --> Output Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Security Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Input Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:00:14 --> Language Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Loader Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Controller Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Session Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:00:14 --> Session routines successfully run
DEBUG - 2019-04-25 13:00:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:00:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:00:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:00:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 13:00:14 --> Final output sent to browser
DEBUG - 2019-04-25 13:00:14 --> Total execution time: 0.2941
DEBUG - 2019-04-25 13:00:19 --> Config Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:00:19 --> URI Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Router Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Output Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Security Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Input Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:00:19 --> Language Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Loader Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Controller Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Session Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:00:19 --> Session routines successfully run
DEBUG - 2019-04-25 13:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:19 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:00:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:00:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:00:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:00:19 --> Final output sent to browser
DEBUG - 2019-04-25 13:00:19 --> Total execution time: 0.0603
DEBUG - 2019-04-25 13:00:20 --> Config Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:00:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:00:20 --> URI Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Router Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Output Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Security Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Input Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:00:20 --> Language Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Loader Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Controller Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Session Class Initialized
DEBUG - 2019-04-25 13:00:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:00:20 --> Session routines successfully run
DEBUG - 2019-04-25 13:00:20 --> Helper loaded: url_helper
ERROR - 2019-04-25 13:00:20 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE2
DEBUG - 2019-04-25 13:03:19 --> Config Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:03:19 --> URI Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Router Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Output Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Security Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Input Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:03:19 --> Language Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Loader Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Controller Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Session Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:03:19 --> Session routines successfully run
DEBUG - 2019-04-25 13:03:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:03:19 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:03:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:03:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:03:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:03:19 --> Final output sent to browser
DEBUG - 2019-04-25 13:03:19 --> Total execution time: 0.0763
DEBUG - 2019-04-25 13:04:36 --> Config Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:04:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:04:36 --> URI Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Router Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Output Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Security Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Input Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:04:36 --> Language Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Loader Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Controller Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Session Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:04:36 --> Session routines successfully run
DEBUG - 2019-04-25 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:04:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:04:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:04:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:04:36 --> Final output sent to browser
DEBUG - 2019-04-25 13:04:36 --> Total execution time: 0.0626
DEBUG - 2019-04-25 13:04:49 --> Config Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:04:49 --> URI Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Router Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Output Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Security Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Input Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:04:49 --> Language Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Loader Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Controller Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Session Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:04:49 --> Session routines successfully run
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:04:49 --> Final output sent to browser
DEBUG - 2019-04-25 13:04:49 --> Total execution time: 0.0615
DEBUG - 2019-04-25 13:04:49 --> Config Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:04:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:04:49 --> URI Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Router Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Output Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Security Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Input Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:04:49 --> Language Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Loader Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Controller Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Session Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:04:49 --> Session routines successfully run
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Model Class Initialized
DEBUG - 2019-04-25 13:04:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:04:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:04:49 --> Final output sent to browser
DEBUG - 2019-04-25 13:04:49 --> Total execution time: 0.0639
DEBUG - 2019-04-25 13:05:26 --> Config Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:05:26 --> URI Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Router Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Output Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Security Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Input Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:05:26 --> Language Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Loader Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Controller Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Session Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:05:26 --> Session routines successfully run
DEBUG - 2019-04-25 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:05:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:05:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:05:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:05:26 --> Final output sent to browser
DEBUG - 2019-04-25 13:05:26 --> Total execution time: 0.1442
DEBUG - 2019-04-25 13:05:27 --> Config Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:05:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:05:27 --> URI Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Router Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Output Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Security Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Input Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:05:27 --> Language Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Loader Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Controller Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:27 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:05:28 --> Session Class Initialized
DEBUG - 2019-04-25 13:05:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:05:28 --> Session routines successfully run
DEBUG - 2019-04-25 13:05:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:05:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:05:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:05:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:05:28 --> Final output sent to browser
DEBUG - 2019-04-25 13:05:28 --> Total execution time: 0.0563
DEBUG - 2019-04-25 13:05:36 --> Config Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:05:36 --> URI Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Router Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Output Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Security Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Input Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:05:36 --> Language Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Loader Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Controller Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Session Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:05:36 --> Session routines successfully run
DEBUG - 2019-04-25 13:05:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:05:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:05:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:05:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:05:36 --> Final output sent to browser
DEBUG - 2019-04-25 13:05:36 --> Total execution time: 0.0508
DEBUG - 2019-04-25 13:05:48 --> Config Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:05:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:05:48 --> URI Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Router Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Output Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Security Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Input Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:05:48 --> Language Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Loader Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Controller Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Session Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:05:48 --> Session routines successfully run
DEBUG - 2019-04-25 13:05:48 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Model Class Initialized
DEBUG - 2019-04-25 13:05:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:05:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:05:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:05:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:05:48 --> Final output sent to browser
DEBUG - 2019-04-25 13:05:48 --> Total execution time: 0.0736
DEBUG - 2019-04-25 13:07:17 --> Config Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:07:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:07:17 --> URI Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Router Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Output Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Security Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Input Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:07:17 --> Language Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Loader Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Controller Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Session Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:07:17 --> Session routines successfully run
DEBUG - 2019-04-25 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:17 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:07:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:07:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:07:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:07:17 --> Final output sent to browser
DEBUG - 2019-04-25 13:07:17 --> Total execution time: 0.0527
DEBUG - 2019-04-25 13:07:35 --> Config Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:07:35 --> URI Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Router Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Output Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Security Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Input Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:07:35 --> Language Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Loader Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Controller Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Session Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:07:35 --> Session routines successfully run
DEBUG - 2019-04-25 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:07:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:07:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:07:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:07:35 --> Final output sent to browser
DEBUG - 2019-04-25 13:07:35 --> Total execution time: 0.0664
DEBUG - 2019-04-25 13:07:53 --> Config Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:07:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:07:53 --> URI Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Router Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Output Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Security Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Input Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:07:53 --> Language Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Loader Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Controller Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Session Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:07:53 --> Session routines successfully run
DEBUG - 2019-04-25 13:07:53 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:53 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:07:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:07:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:07:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:07:53 --> Final output sent to browser
DEBUG - 2019-04-25 13:07:53 --> Total execution time: 0.0663
DEBUG - 2019-04-25 13:07:54 --> Config Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:07:54 --> URI Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Router Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Output Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Security Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Input Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:07:54 --> Language Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Loader Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Controller Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Session Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:07:54 --> Session routines successfully run
DEBUG - 2019-04-25 13:07:54 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:54 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:07:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:07:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:07:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:07:54 --> Final output sent to browser
DEBUG - 2019-04-25 13:07:54 --> Total execution time: 0.0532
DEBUG - 2019-04-25 13:07:56 --> Config Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:07:56 --> URI Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Router Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Output Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Security Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Input Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:07:56 --> Language Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Loader Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Controller Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Session Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:07:56 --> Session routines successfully run
DEBUG - 2019-04-25 13:07:56 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Model Class Initialized
DEBUG - 2019-04-25 13:07:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:07:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:07:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:07:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:07:56 --> Final output sent to browser
DEBUG - 2019-04-25 13:07:56 --> Total execution time: 0.0588
DEBUG - 2019-04-25 13:08:06 --> Config Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:08:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:08:06 --> URI Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Router Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Output Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Security Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Input Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:08:06 --> Language Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Loader Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Controller Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Session Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:08:06 --> Session routines successfully run
DEBUG - 2019-04-25 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:08:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:08:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:08:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:08:06 --> Final output sent to browser
DEBUG - 2019-04-25 13:08:06 --> Total execution time: 0.0543
DEBUG - 2019-04-25 13:08:20 --> Config Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:08:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:08:20 --> URI Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Router Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Output Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Security Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Input Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:08:20 --> Language Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Loader Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Controller Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Session Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:08:20 --> Session routines successfully run
DEBUG - 2019-04-25 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:08:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:08:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:08:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:08:20 --> Final output sent to browser
DEBUG - 2019-04-25 13:08:20 --> Total execution time: 0.0613
DEBUG - 2019-04-25 13:08:21 --> Config Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:08:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:08:21 --> URI Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Router Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Output Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Security Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Input Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:08:21 --> Language Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Loader Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Controller Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Session Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:08:21 --> Session routines successfully run
DEBUG - 2019-04-25 13:08:21 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:21 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:08:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:08:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:08:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:08:21 --> Final output sent to browser
DEBUG - 2019-04-25 13:08:21 --> Total execution time: 0.0403
DEBUG - 2019-04-25 13:08:23 --> Config Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:08:23 --> URI Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Router Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Output Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Security Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Input Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:08:23 --> Language Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Loader Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Controller Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Session Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:08:23 --> Session routines successfully run
DEBUG - 2019-04-25 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:08:23 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:08:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:08:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:08:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:08:23 --> Final output sent to browser
DEBUG - 2019-04-25 13:08:23 --> Total execution time: 0.0623
DEBUG - 2019-04-25 13:10:11 --> Config Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:10:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:10:11 --> URI Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Router Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Output Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Security Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Input Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:10:11 --> Language Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Loader Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Controller Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Session Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:10:11 --> Session routines successfully run
DEBUG - 2019-04-25 13:10:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:10:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:10:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:10:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:10:11 --> Final output sent to browser
DEBUG - 2019-04-25 13:10:11 --> Total execution time: 0.0664
DEBUG - 2019-04-25 13:10:46 --> Config Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:10:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:10:46 --> URI Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Router Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Output Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Security Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Input Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:10:46 --> Language Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Loader Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Controller Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Session Class Initialized
DEBUG - 2019-04-25 13:10:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:10:47 --> Session routines successfully run
DEBUG - 2019-04-25 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:10:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:10:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:10:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:10:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:10:47 --> Final output sent to browser
DEBUG - 2019-04-25 13:10:47 --> Total execution time: 0.1309
DEBUG - 2019-04-25 13:11:16 --> Config Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:11:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:11:16 --> URI Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Router Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Output Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Security Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Input Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:11:16 --> Language Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Loader Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Controller Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Session Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:11:16 --> Session routines successfully run
DEBUG - 2019-04-25 13:11:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:11:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:11:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:11:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:11:16 --> Final output sent to browser
DEBUG - 2019-04-25 13:11:16 --> Total execution time: 0.0621
DEBUG - 2019-04-25 13:11:37 --> Config Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:11:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:11:37 --> URI Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Router Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Output Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Security Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Input Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:11:37 --> Language Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Loader Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Controller Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Session Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:11:37 --> Session routines successfully run
DEBUG - 2019-04-25 13:11:37 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Model Class Initialized
DEBUG - 2019-04-25 13:11:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:11:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:11:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:11:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:11:37 --> Final output sent to browser
DEBUG - 2019-04-25 13:11:37 --> Total execution time: 0.0754
DEBUG - 2019-04-25 13:12:16 --> Config Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:12:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:12:16 --> URI Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Router Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Output Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Security Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Input Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:12:16 --> Language Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Loader Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Controller Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Session Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:12:16 --> Session routines successfully run
DEBUG - 2019-04-25 13:12:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:12:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:12:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:12:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:12:16 --> Final output sent to browser
DEBUG - 2019-04-25 13:12:16 --> Total execution time: 0.0541
DEBUG - 2019-04-25 13:12:19 --> Config Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:12:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:12:19 --> URI Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Router Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Output Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Security Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Input Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:12:19 --> Language Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Loader Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Controller Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Session Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:12:19 --> Session routines successfully run
DEBUG - 2019-04-25 13:12:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:19 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:12:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:12:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:12:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:12:19 --> Final output sent to browser
DEBUG - 2019-04-25 13:12:19 --> Total execution time: 0.0616
DEBUG - 2019-04-25 13:12:57 --> Config Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:12:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:12:57 --> URI Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Router Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Output Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Security Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Input Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:12:57 --> Language Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Loader Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Controller Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Session Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:12:57 --> Session routines successfully run
DEBUG - 2019-04-25 13:12:57 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:57 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:12:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:12:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:12:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:12:57 --> Final output sent to browser
DEBUG - 2019-04-25 13:12:57 --> Total execution time: 0.0569
DEBUG - 2019-04-25 13:12:59 --> Config Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:12:59 --> URI Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Router Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Output Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Security Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Input Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:12:59 --> Language Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Loader Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Controller Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Session Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:12:59 --> Session routines successfully run
DEBUG - 2019-04-25 13:12:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:12:59 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:12:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:12:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:12:59 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:12:59 --> Final output sent to browser
DEBUG - 2019-04-25 13:12:59 --> Total execution time: 0.0412
DEBUG - 2019-04-25 13:13:05 --> Config Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:13:05 --> URI Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Router Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Output Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Security Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Input Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:13:05 --> Language Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Loader Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Controller Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Session Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:13:05 --> Session routines successfully run
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:13:05 --> Config Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:13:05 --> URI Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Router Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Output Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Security Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Input Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:13:05 --> Language Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Loader Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Controller Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Session Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:13:05 --> Session routines successfully run
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:13:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:13:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:13:05 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 13:13:05 --> Final output sent to browser
DEBUG - 2019-04-25 13:13:05 --> Total execution time: 0.1279
DEBUG - 2019-04-25 13:13:14 --> Config Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:13:14 --> URI Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Router Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Output Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Security Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Input Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:13:14 --> Language Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Loader Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Controller Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Session Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:13:14 --> Session routines successfully run
DEBUG - 2019-04-25 13:13:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:13:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:13:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:13:14 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 13:13:14 --> Final output sent to browser
DEBUG - 2019-04-25 13:13:14 --> Total execution time: 0.0945
DEBUG - 2019-04-25 13:13:46 --> Config Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:13:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:13:46 --> URI Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Router Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Output Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Security Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Input Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:13:46 --> Language Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Loader Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Controller Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Session Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:13:46 --> Session routines successfully run
DEBUG - 2019-04-25 13:13:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:13:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:13:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:13:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:13:46 --> Final output sent to browser
DEBUG - 2019-04-25 13:13:46 --> Total execution time: 0.0716
DEBUG - 2019-04-25 13:13:47 --> Config Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:13:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:13:47 --> URI Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Router Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Output Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Security Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Input Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:13:47 --> Language Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Loader Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Controller Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Session Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:13:47 --> Session routines successfully run
DEBUG - 2019-04-25 13:13:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Model Class Initialized
DEBUG - 2019-04-25 13:13:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:13:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:13:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:13:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:13:47 --> Final output sent to browser
DEBUG - 2019-04-25 13:13:47 --> Total execution time: 0.0416
DEBUG - 2019-04-25 13:14:01 --> Config Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:14:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:14:01 --> URI Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Router Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Output Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Security Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Input Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:14:01 --> Language Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Loader Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Controller Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Session Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:14:01 --> Session routines successfully run
DEBUG - 2019-04-25 13:14:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:01 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:14:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:14:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:14:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:14:01 --> Final output sent to browser
DEBUG - 2019-04-25 13:14:01 --> Total execution time: 0.0656
DEBUG - 2019-04-25 13:14:02 --> Config Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:14:02 --> URI Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Router Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Output Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Security Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Input Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:14:02 --> Language Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Loader Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Controller Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Session Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:14:02 --> Session routines successfully run
DEBUG - 2019-04-25 13:14:02 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:02 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:14:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:14:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:14:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:14:02 --> Final output sent to browser
DEBUG - 2019-04-25 13:14:02 --> Total execution time: 0.0519
DEBUG - 2019-04-25 13:14:03 --> Config Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:14:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:14:03 --> URI Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Router Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Output Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Security Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Input Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:14:03 --> Language Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Loader Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Controller Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Session Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:14:03 --> Session routines successfully run
DEBUG - 2019-04-25 13:14:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:14:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:14:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:14:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:14:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:14:03 --> Final output sent to browser
DEBUG - 2019-04-25 13:14:03 --> Total execution time: 0.0511
DEBUG - 2019-04-25 13:15:59 --> Config Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:15:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:15:59 --> URI Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Router Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Output Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Security Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Input Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:15:59 --> Language Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Loader Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Controller Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Session Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:15:59 --> Session routines successfully run
DEBUG - 2019-04-25 13:15:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Model Class Initialized
DEBUG - 2019-04-25 13:15:59 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:15:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:15:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:15:59 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:15:59 --> Final output sent to browser
DEBUG - 2019-04-25 13:15:59 --> Total execution time: 0.1074
DEBUG - 2019-04-25 13:16:01 --> Config Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:16:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:16:01 --> URI Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Router Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Output Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Security Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Input Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:16:01 --> Language Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Loader Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Controller Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Session Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:16:01 --> Session routines successfully run
DEBUG - 2019-04-25 13:16:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Model Class Initialized
DEBUG - 2019-04-25 13:16:01 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:16:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:16:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:16:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:16:01 --> Final output sent to browser
DEBUG - 2019-04-25 13:16:01 --> Total execution time: 0.0526
DEBUG - 2019-04-25 13:17:33 --> Config Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:17:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:17:33 --> URI Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Router Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Output Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Security Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Input Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:17:33 --> Language Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Loader Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Controller Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Session Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:17:33 --> Session garbage collection performed.
DEBUG - 2019-04-25 13:17:33 --> Session routines successfully run
DEBUG - 2019-04-25 13:17:33 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:33 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:17:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:17:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:17:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:17:33 --> Final output sent to browser
DEBUG - 2019-04-25 13:17:33 --> Total execution time: 0.1839
DEBUG - 2019-04-25 13:17:35 --> Config Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:17:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:17:35 --> URI Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Router Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Output Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Security Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Input Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:17:35 --> Language Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Loader Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Controller Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Session Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:17:35 --> Session routines successfully run
DEBUG - 2019-04-25 13:17:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Model Class Initialized
DEBUG - 2019-04-25 13:17:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:17:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:17:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:17:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:17:35 --> Final output sent to browser
DEBUG - 2019-04-25 13:17:35 --> Total execution time: 0.0589
DEBUG - 2019-04-25 13:27:32 --> Config Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:27:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:27:32 --> URI Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Router Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Output Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Security Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Input Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:27:32 --> Language Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Loader Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Controller Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Session Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:27:32 --> Session routines successfully run
DEBUG - 2019-04-25 13:27:32 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:27:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:27:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:27:32 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-25 13:27:32 --> Final output sent to browser
DEBUG - 2019-04-25 13:27:32 --> Total execution time: 0.1142
DEBUG - 2019-04-25 13:27:39 --> Config Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:27:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:27:39 --> URI Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Router Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Output Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Security Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Input Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:27:39 --> Language Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Loader Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Controller Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:27:40 --> Session Class Initialized
DEBUG - 2019-04-25 13:27:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:27:40 --> Session routines successfully run
DEBUG - 2019-04-25 13:27:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:27:40 --> Helper loaded: url_helper
ERROR - 2019-04-25 13:27:40 --> Severity: Notice  --> Undefined index: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 182
DEBUG - 2019-04-25 13:27:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:27:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:27:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 13:27:40 --> Final output sent to browser
DEBUG - 2019-04-25 13:27:40 --> Total execution time: 0.1242
DEBUG - 2019-04-25 13:33:11 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:11 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:11 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:11 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 13:33:11 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:11 --> Total execution time: 0.1692
DEBUG - 2019-04-25 13:33:24 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:24 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:24 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:24 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:24 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:24 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 13:33:24 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:24 --> Total execution time: 0.1089
DEBUG - 2019-04-25 13:33:28 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:28 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:28 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:28 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:28 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:28 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:28 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:28 --> A session cookie was not found.
DEBUG - 2019-04-25 13:33:28 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 13:33:28 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:28 --> Total execution time: 0.1313
DEBUG - 2019-04-25 13:33:30 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:30 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:30 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:30 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:30 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:30 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:30 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 13:33:30 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:30 --> Total execution time: 0.0617
DEBUG - 2019-04-25 13:33:40 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:40 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:40 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:40 --> Session garbage collection performed.
DEBUG - 2019-04-25 13:33:40 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 13:33:40 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:40 --> Total execution time: 0.3331
DEBUG - 2019-04-25 13:33:52 --> Config Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:33:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:33:52 --> URI Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Router Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Output Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Security Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Input Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:33:52 --> Language Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Loader Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Controller Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Model Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Session Class Initialized
DEBUG - 2019-04-25 13:33:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:33:52 --> Session routines successfully run
DEBUG - 2019-04-25 13:33:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:33:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:33:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:33:52 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-25 13:33:52 --> Final output sent to browser
DEBUG - 2019-04-25 13:33:52 --> Total execution time: 0.0505
DEBUG - 2019-04-25 13:34:08 --> Config Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:34:08 --> URI Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Router Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Output Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Security Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Input Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:34:08 --> Language Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Loader Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Controller Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Session Class Initialized
DEBUG - 2019-04-25 13:34:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:34:08 --> Session routines successfully run
DEBUG - 2019-04-25 13:34:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:34:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:34:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:34:08 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-25 13:34:08 --> Final output sent to browser
DEBUG - 2019-04-25 13:34:08 --> Total execution time: 0.0580
DEBUG - 2019-04-25 13:34:38 --> Config Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:34:38 --> URI Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Router Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Output Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Security Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Input Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:34:38 --> Language Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Loader Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Controller Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Session Class Initialized
DEBUG - 2019-04-25 13:34:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:34:38 --> Session routines successfully run
DEBUG - 2019-04-25 13:34:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:34:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:34:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:34:38 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-25 13:34:38 --> Final output sent to browser
DEBUG - 2019-04-25 13:34:38 --> Total execution time: 0.0564
DEBUG - 2019-04-25 13:34:41 --> Config Class Initialized
DEBUG - 2019-04-25 13:34:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:34:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:34:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:34:41 --> URI Class Initialized
DEBUG - 2019-04-25 13:34:41 --> Router Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Output Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Security Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Input Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:34:42 --> Language Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Loader Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Controller Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Model Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Session Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:34:42 --> Session routines successfully run
DEBUG - 2019-04-25 13:34:42 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:34:42 --> Upload Class Initialized
DEBUG - 2019-04-25 13:34:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:34:42 --> The upload path does not appear to be valid.
DEBUG - 2019-04-25 13:34:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:34:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:34:42 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:35:03 --> Config Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:35:03 --> URI Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Router Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Output Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Security Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Input Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:35:03 --> Language Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Loader Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Controller Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Session Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:35:03 --> Session routines successfully run
DEBUG - 2019-04-25 13:35:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:35:03 --> Upload Class Initialized
DEBUG - 2019-04-25 13:35:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:35:03 --> The upload path does not appear to be valid.
DEBUG - 2019-04-25 13:35:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:35:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:35:03 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:35:18 --> Config Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:35:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:35:18 --> URI Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Router Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Output Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Security Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Input Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:35:18 --> Language Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Loader Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Controller Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Session Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:35:18 --> Session routines successfully run
DEBUG - 2019-04-25 13:35:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:35:18 --> Upload Class Initialized
DEBUG - 2019-04-25 13:35:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:35:18 --> The upload path does not appear to be valid.
DEBUG - 2019-04-25 13:35:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:35:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:35:18 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:35:23 --> Config Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:35:23 --> URI Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Router Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Output Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Security Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Input Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:35:23 --> Language Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Loader Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Controller Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Model Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Session Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:35:23 --> Session routines successfully run
DEBUG - 2019-04-25 13:35:23 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:35:23 --> Upload Class Initialized
DEBUG - 2019-04-25 13:35:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:35:23 --> The upload path does not appear to be valid.
DEBUG - 2019-04-25 13:35:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:35:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:35:23 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:36:40 --> Config Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:36:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:36:40 --> URI Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Router Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Output Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Security Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Input Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:36:40 --> Language Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Loader Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Controller Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Session Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:36:40 --> Session routines successfully run
DEBUG - 2019-04-25 13:36:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:36:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:36:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:36:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 13:36:40 --> Final output sent to browser
DEBUG - 2019-04-25 13:36:40 --> Total execution time: 0.1369
DEBUG - 2019-04-25 13:36:45 --> Config Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:36:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:36:45 --> URI Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Router Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Output Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Security Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Input Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:36:45 --> Language Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Loader Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Controller Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Model Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Session Class Initialized
DEBUG - 2019-04-25 13:36:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:36:45 --> Session routines successfully run
DEBUG - 2019-04-25 13:36:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:36:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:36:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:36:45 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-25 13:36:45 --> Final output sent to browser
DEBUG - 2019-04-25 13:36:45 --> Total execution time: 0.0515
DEBUG - 2019-04-25 13:37:00 --> Config Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:37:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:37:00 --> URI Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Router Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Output Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Security Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Input Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:37:00 --> Language Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Loader Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Controller Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Session Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:37:00 --> Session routines successfully run
DEBUG - 2019-04-25 13:37:00 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:37:00 --> Upload Class Initialized
DEBUG - 2019-04-25 13:37:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:37:00 --> You did not select a file to upload.
DEBUG - 2019-04-25 13:37:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:37:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:37:00 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:40:10 --> Config Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:40:10 --> URI Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Router Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Output Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Security Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Input Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:40:10 --> Language Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Loader Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Controller Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Session Class Initialized
DEBUG - 2019-04-25 13:40:10 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:40:10 --> Session routines successfully run
DEBUG - 2019-04-25 13:40:10 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:40:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:40:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:40:10 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-25 13:40:10 --> Final output sent to browser
DEBUG - 2019-04-25 13:40:10 --> Total execution time: 0.1276
DEBUG - 2019-04-25 13:40:25 --> Config Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:40:25 --> URI Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Router Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Output Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Security Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Input Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:40:25 --> Language Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Loader Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Controller Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Model Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Session Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:40:25 --> Session routines successfully run
DEBUG - 2019-04-25 13:40:25 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:40:25 --> Upload Class Initialized
DEBUG - 2019-04-25 13:40:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:40:25 --> You did not select a file to upload.
DEBUG - 2019-04-25 13:40:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:40:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:40:25 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:42:34 --> Config Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:42:34 --> URI Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Router Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Output Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Security Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Input Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:42:34 --> Language Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Loader Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Controller Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Session Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:42:34 --> Session routines successfully run
DEBUG - 2019-04-25 13:42:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:42:34 --> Upload Class Initialized
DEBUG - 2019-04-25 13:42:34 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:42:34 --> You did not select a file to upload.
DEBUG - 2019-04-25 13:42:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:42:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:42:34 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:45:34 --> Config Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:45:34 --> URI Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Router Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Output Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Security Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Input Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:45:34 --> Language Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Loader Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Controller Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Session Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:45:34 --> Session routines successfully run
DEBUG - 2019-04-25 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:45:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:45:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:45:34 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 13:45:34 --> Final output sent to browser
DEBUG - 2019-04-25 13:45:34 --> Total execution time: 0.1684
DEBUG - 2019-04-25 13:45:36 --> Config Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:45:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:45:36 --> URI Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Router Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Output Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Security Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Input Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:45:36 --> Language Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Loader Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Controller Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Session Class Initialized
DEBUG - 2019-04-25 13:45:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:45:36 --> Session routines successfully run
DEBUG - 2019-04-25 13:45:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:45:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:45:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:45:36 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-25 13:45:36 --> Final output sent to browser
DEBUG - 2019-04-25 13:45:36 --> Total execution time: 0.0521
DEBUG - 2019-04-25 13:45:50 --> Config Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:45:50 --> URI Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Router Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Output Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Security Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Input Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:45:50 --> Language Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Loader Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Controller Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Session Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:45:50 --> Session routines successfully run
DEBUG - 2019-04-25 13:45:50 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:45:50 --> Upload Class Initialized
DEBUG - 2019-04-25 13:45:50 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:45:50 --> You did not select a file to upload.
DEBUG - 2019-04-25 13:45:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:45:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:45:50 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 13:50:03 --> Config Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 13:50:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 13:50:03 --> URI Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Router Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Output Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Security Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Input Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 13:50:03 --> Language Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Loader Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Controller Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Model Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Session Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 13:50:03 --> Session routines successfully run
DEBUG - 2019-04-25 13:50:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 13:50:03 --> Upload Class Initialized
DEBUG - 2019-04-25 13:50:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-25 13:50:03 --> You did not select a file to upload.
DEBUG - 2019-04-25 13:50:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 13:50:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 13:50:03 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 14:22:35 --> Config Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:22:35 --> URI Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Router Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Output Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Security Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Input Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:22:35 --> Language Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Loader Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Controller Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Session Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:22:35 --> Session routines successfully run
DEBUG - 2019-04-25 14:22:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:22:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:22:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:22:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:22:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:22:35 --> Final output sent to browser
DEBUG - 2019-04-25 14:22:35 --> Total execution time: 0.1282
DEBUG - 2019-04-25 14:23:46 --> Config Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:23:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:23:46 --> URI Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Router Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Output Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Security Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Input Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:23:46 --> Language Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Loader Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Controller Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Session Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:23:46 --> Session routines successfully run
DEBUG - 2019-04-25 14:23:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:23:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:23:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:23:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:23:46 --> Final output sent to browser
DEBUG - 2019-04-25 14:23:46 --> Total execution time: 0.0558
DEBUG - 2019-04-25 14:23:49 --> Config Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:23:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:23:49 --> URI Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Router Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Output Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Security Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Input Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:23:49 --> Language Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Loader Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Controller Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Session Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:23:49 --> Session routines successfully run
DEBUG - 2019-04-25 14:23:49 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:23:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:23:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:23:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:23:49 --> Final output sent to browser
DEBUG - 2019-04-25 14:23:49 --> Total execution time: 0.0708
DEBUG - 2019-04-25 14:23:56 --> Config Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:23:56 --> URI Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Router Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Output Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Security Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Input Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:23:56 --> Language Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Loader Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Controller Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Session Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:23:56 --> Session routines successfully run
DEBUG - 2019-04-25 14:23:56 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Model Class Initialized
DEBUG - 2019-04-25 14:23:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:23:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:23:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:23:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 14:23:56 --> Final output sent to browser
DEBUG - 2019-04-25 14:23:56 --> Total execution time: 0.1098
DEBUG - 2019-04-25 14:24:21 --> Config Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:24:21 --> URI Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Router Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Output Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Security Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Input Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:24:21 --> Language Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Loader Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Controller Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Session Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:24:21 --> Session routines successfully run
DEBUG - 2019-04-25 14:24:21 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:21 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:24:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:24:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:24:21 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 14:24:21 --> Final output sent to browser
DEBUG - 2019-04-25 14:24:21 --> Total execution time: 0.1043
DEBUG - 2019-04-25 14:24:28 --> Config Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:24:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:24:28 --> URI Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Router Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Output Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Security Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Input Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:24:28 --> Language Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Loader Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Controller Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Session Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:24:28 --> Session routines successfully run
DEBUG - 2019-04-25 14:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:24:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:24:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:24:28 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:24:28 --> Final output sent to browser
DEBUG - 2019-04-25 14:24:28 --> Total execution time: 0.1064
DEBUG - 2019-04-25 14:24:29 --> Config Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:24:29 --> URI Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Router Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Output Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Security Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Input Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:24:29 --> Language Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Loader Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Controller Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Session Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:24:29 --> Session routines successfully run
DEBUG - 2019-04-25 14:24:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:24:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:24:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:24:29 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 14:24:29 --> Final output sent to browser
DEBUG - 2019-04-25 14:24:29 --> Total execution time: 0.1935
DEBUG - 2019-04-25 14:24:32 --> Config Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:24:32 --> URI Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Router Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Output Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Security Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Input Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:24:32 --> Language Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Loader Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Controller Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Session Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:24:32 --> Session routines successfully run
DEBUG - 2019-04-25 14:24:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:24:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:24:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:24:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-25 14:24:32 --> Final output sent to browser
DEBUG - 2019-04-25 14:24:32 --> Total execution time: 0.0710
DEBUG - 2019-04-25 14:24:34 --> Config Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:24:34 --> URI Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Router Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Output Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Security Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Input Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:24:34 --> Language Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Loader Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Controller Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Session Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:24:34 --> Session routines successfully run
DEBUG - 2019-04-25 14:24:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:24:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:24:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:24:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:24:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:24:34 --> Final output sent to browser
DEBUG - 2019-04-25 14:24:34 --> Total execution time: 0.0476
DEBUG - 2019-04-25 14:27:37 --> Config Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:27:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:27:37 --> URI Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Router Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Output Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Security Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Input Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:27:37 --> Language Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Loader Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Controller Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Session Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:27:37 --> Session routines successfully run
DEBUG - 2019-04-25 14:27:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:27:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:27:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:27:37 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 14:27:37 --> Final output sent to browser
DEBUG - 2019-04-25 14:27:37 --> Total execution time: 0.1617
DEBUG - 2019-04-25 14:27:39 --> Config Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:27:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:27:39 --> URI Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Router Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Output Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Security Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Input Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:27:39 --> Language Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Loader Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Controller Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Session Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:27:39 --> Session routines successfully run
DEBUG - 2019-04-25 14:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Model Class Initialized
DEBUG - 2019-04-25 14:27:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:27:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:27:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:27:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:27:39 --> Final output sent to browser
DEBUG - 2019-04-25 14:27:39 --> Total execution time: 0.0552
DEBUG - 2019-04-25 14:28:16 --> Config Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:28:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:28:16 --> URI Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Router Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Output Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Security Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Input Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:28:16 --> Language Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Loader Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Controller Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Model Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Model Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Session Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:28:16 --> Session routines successfully run
DEBUG - 2019-04-25 14:28:16 --> Model Class Initialized
DEBUG - 2019-04-25 14:28:16 --> Model Class Initialized
DEBUG - 2019-04-25 14:28:17 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:28:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:28:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:28:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:28:17 --> Final output sent to browser
DEBUG - 2019-04-25 14:28:17 --> Total execution time: 0.0552
DEBUG - 2019-04-25 14:29:20 --> Config Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:29:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:29:20 --> URI Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Router Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Output Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Security Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Input Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:29:20 --> Language Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Loader Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Controller Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Session Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:29:20 --> Session routines successfully run
DEBUG - 2019-04-25 14:29:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:29:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:29:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:29:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:29:20 --> Final output sent to browser
DEBUG - 2019-04-25 14:29:20 --> Total execution time: 0.0663
DEBUG - 2019-04-25 14:29:36 --> Config Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:29:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:29:36 --> URI Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Router Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Output Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Security Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Input Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:29:36 --> Language Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Loader Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Controller Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Session Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:29:36 --> Session routines successfully run
DEBUG - 2019-04-25 14:29:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:29:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:29:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:29:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:29:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:29:36 --> Final output sent to browser
DEBUG - 2019-04-25 14:29:36 --> Total execution time: 0.0687
DEBUG - 2019-04-25 14:31:11 --> Config Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:31:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:31:11 --> URI Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Router Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Output Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Security Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Input Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:31:11 --> Language Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Loader Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Controller Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Session Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:31:11 --> Session routines successfully run
DEBUG - 2019-04-25 14:31:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:31:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:31:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:31:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:31:11 --> Final output sent to browser
DEBUG - 2019-04-25 14:31:11 --> Total execution time: 0.0699
DEBUG - 2019-04-25 14:31:54 --> Config Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:31:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:31:54 --> URI Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Router Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Output Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Security Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Input Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:31:54 --> Language Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Loader Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Controller Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Session Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:31:54 --> Session routines successfully run
DEBUG - 2019-04-25 14:31:54 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Model Class Initialized
DEBUG - 2019-04-25 14:31:54 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:31:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:31:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:31:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:31:54 --> Final output sent to browser
DEBUG - 2019-04-25 14:31:54 --> Total execution time: 0.0648
DEBUG - 2019-04-25 14:32:09 --> Config Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:32:09 --> URI Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Router Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Output Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Security Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Input Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:32:09 --> Language Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Loader Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Controller Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Session Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:32:09 --> Session routines successfully run
DEBUG - 2019-04-25 14:32:09 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:09 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:32:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:32:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:32:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:32:09 --> Final output sent to browser
DEBUG - 2019-04-25 14:32:09 --> Total execution time: 0.0705
DEBUG - 2019-04-25 14:32:20 --> Config Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:32:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:32:20 --> URI Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Router Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Output Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Security Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Input Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:32:20 --> Language Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Loader Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Controller Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Session Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:32:20 --> Session routines successfully run
DEBUG - 2019-04-25 14:32:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:32:29 --> Config Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:32:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:32:29 --> URI Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Router Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Output Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Security Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Input Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:32:29 --> Language Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Loader Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Controller Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Session Class Initialized
DEBUG - 2019-04-25 14:32:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:32:29 --> Session routines successfully run
DEBUG - 2019-04-25 14:32:29 --> Helper loaded: url_helper
ERROR - 2019-04-25 14:32:29 --> 404 Page Not Found --> Notice/WRITE%20TO%20ORDERS%20PAGE3
DEBUG - 2019-04-25 14:33:44 --> Config Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:33:44 --> URI Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Router Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Output Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Security Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Input Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:33:44 --> Language Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Loader Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Controller Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Session Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:33:44 --> Session routines successfully run
DEBUG - 2019-04-25 14:33:44 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:44 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:33:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:33:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:33:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:33:44 --> Final output sent to browser
DEBUG - 2019-04-25 14:33:44 --> Total execution time: 0.1247
DEBUG - 2019-04-25 14:33:45 --> Config Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:33:45 --> URI Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Router Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Output Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Security Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Input Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:33:45 --> Language Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Loader Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Controller Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:33:46 --> Session Class Initialized
DEBUG - 2019-04-25 14:33:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:33:46 --> Session routines successfully run
DEBUG - 2019-04-25 14:33:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:46 --> Model Class Initialized
DEBUG - 2019-04-25 14:33:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:33:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:33:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:33:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:33:46 --> Final output sent to browser
DEBUG - 2019-04-25 14:33:46 --> Total execution time: 0.0643
DEBUG - 2019-04-25 14:34:31 --> Config Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:34:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:34:31 --> URI Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Router Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Output Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Security Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Input Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:34:31 --> Language Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Loader Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Controller Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Session Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:34:31 --> Session routines successfully run
DEBUG - 2019-04-25 14:34:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:34:31 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:34:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:34:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:34:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:34:31 --> Final output sent to browser
DEBUG - 2019-04-25 14:34:31 --> Total execution time: 0.0612
DEBUG - 2019-04-25 14:35:32 --> Config Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:35:32 --> URI Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Router Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Output Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Security Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Input Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:35:32 --> Language Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Loader Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Controller Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Session Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:35:32 --> Session routines successfully run
DEBUG - 2019-04-25 14:35:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:35:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:35:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:35:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:35:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:35:32 --> Final output sent to browser
DEBUG - 2019-04-25 14:35:32 --> Total execution time: 0.0704
DEBUG - 2019-04-25 14:38:35 --> Config Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:38:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:38:35 --> URI Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Router Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Output Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Security Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Input Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:38:35 --> Language Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Loader Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Controller Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Session Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:38:35 --> Session routines successfully run
DEBUG - 2019-04-25 14:38:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:38:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:38:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:38:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:38:35 --> Final output sent to browser
DEBUG - 2019-04-25 14:38:35 --> Total execution time: 0.0597
DEBUG - 2019-04-25 14:38:37 --> Config Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:38:37 --> URI Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Router Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Output Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Security Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Input Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:38:37 --> Language Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Loader Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Controller Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:38:38 --> Session Class Initialized
DEBUG - 2019-04-25 14:38:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:38:38 --> Session routines successfully run
DEBUG - 2019-04-25 14:38:38 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:38 --> Model Class Initialized
DEBUG - 2019-04-25 14:38:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:38:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:38:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:38:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:38:38 --> Final output sent to browser
DEBUG - 2019-04-25 14:38:38 --> Total execution time: 0.0661
DEBUG - 2019-04-25 14:48:10 --> Config Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:48:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:48:10 --> URI Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Router Class Initialized
DEBUG - 2019-04-25 14:48:10 --> No URI present. Default controller set.
DEBUG - 2019-04-25 14:48:10 --> Output Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Security Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Input Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:48:10 --> Language Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Loader Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Controller Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Session Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:48:10 --> Session routines successfully run
DEBUG - 2019-04-25 14:48:10 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:10 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:48:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:48:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:48:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 14:48:10 --> Final output sent to browser
DEBUG - 2019-04-25 14:48:10 --> Total execution time: 0.2758
DEBUG - 2019-04-25 14:48:12 --> Config Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:48:12 --> URI Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Router Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Output Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Security Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Input Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:48:12 --> Language Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Loader Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Controller Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Session Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:48:12 --> Session routines successfully run
DEBUG - 2019-04-25 14:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:48:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:48:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:48:12 --> File loaded: application/views/producers.php
DEBUG - 2019-04-25 14:48:12 --> Final output sent to browser
DEBUG - 2019-04-25 14:48:12 --> Total execution time: 0.0588
DEBUG - 2019-04-25 14:48:13 --> Config Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:48:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:48:13 --> URI Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Router Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Output Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Security Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Input Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:48:13 --> Language Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Loader Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Controller Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Session Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:48:13 --> Session routines successfully run
DEBUG - 2019-04-25 14:48:13 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:13 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:48:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:48:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:48:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 14:48:13 --> Final output sent to browser
DEBUG - 2019-04-25 14:48:13 --> Total execution time: 0.0529
DEBUG - 2019-04-25 14:48:15 --> Config Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:48:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:48:15 --> URI Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Router Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Output Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Security Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Input Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:48:15 --> Language Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Loader Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Controller Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Session Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:48:15 --> Session routines successfully run
DEBUG - 2019-04-25 14:48:15 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Model Class Initialized
DEBUG - 2019-04-25 14:48:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:48:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:48:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:48:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 14:48:15 --> Final output sent to browser
DEBUG - 2019-04-25 14:48:15 --> Total execution time: 0.1137
DEBUG - 2019-04-25 14:49:51 --> Config Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:49:51 --> URI Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Router Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Output Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Security Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Input Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:49:51 --> Language Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Loader Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Controller Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Model Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Model Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Session Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:49:51 --> Session routines successfully run
DEBUG - 2019-04-25 14:49:51 --> Model Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Model Class Initialized
DEBUG - 2019-04-25 14:49:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:49:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:49:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:49:51 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 14:49:51 --> Final output sent to browser
DEBUG - 2019-04-25 14:49:51 --> Total execution time: 0.0709
DEBUG - 2019-04-25 14:54:43 --> Config Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:54:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:54:43 --> URI Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Router Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Output Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Security Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Input Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:54:43 --> Language Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Loader Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Controller Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Session Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:54:43 --> Session routines successfully run
DEBUG - 2019-04-25 14:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:43 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:54:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:54:43 --> Final output sent to browser
DEBUG - 2019-04-25 14:54:43 --> Total execution time: 0.3297
DEBUG - 2019-04-25 14:54:53 --> Config Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:54:53 --> URI Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Router Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Output Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Security Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Input Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:54:53 --> Language Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Loader Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Controller Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Session Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:54:53 --> Session routines successfully run
DEBUG - 2019-04-25 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-25 14:54:53 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:54:53 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:54:53 --> Final output sent to browser
DEBUG - 2019-04-25 14:54:53 --> Total execution time: 0.2590
DEBUG - 2019-04-25 14:58:29 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:29 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:29 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:29 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:58:29 --> Final output sent to browser
DEBUG - 2019-04-25 14:58:29 --> Total execution time: 0.2748
DEBUG - 2019-04-25 14:58:31 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:31 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:31 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:31 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:31 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:31 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 14:58:31 --> Final output sent to browser
DEBUG - 2019-04-25 14:58:31 --> Total execution time: 0.1191
DEBUG - 2019-04-25 14:58:32 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:32 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:32 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:32 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:32 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:32 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:32 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:32 --> A session cookie was not found.
DEBUG - 2019-04-25 14:58:32 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:32 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 14:58:32 --> Final output sent to browser
DEBUG - 2019-04-25 14:58:32 --> Total execution time: 0.1491
DEBUG - 2019-04-25 14:58:34 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:34 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:34 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:34 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:34 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 14:58:34 --> Final output sent to browser
DEBUG - 2019-04-25 14:58:34 --> Total execution time: 0.0604
DEBUG - 2019-04-25 14:58:36 --> Config Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:58:36 --> URI Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Router Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Output Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Security Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Input Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:58:36 --> Language Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Loader Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Controller Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Session Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:58:36 --> Session routines successfully run
DEBUG - 2019-04-25 14:58:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Model Class Initialized
DEBUG - 2019-04-25 14:58:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:58:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:58:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:58:36 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 14:58:36 --> Final output sent to browser
DEBUG - 2019-04-25 14:58:36 --> Total execution time: 0.0525
DEBUG - 2019-04-25 14:59:11 --> Config Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 14:59:11 --> URI Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Router Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Output Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Security Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Input Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 14:59:11 --> Language Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Loader Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Controller Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Session Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 14:59:11 --> Session routines successfully run
DEBUG - 2019-04-25 14:59:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Model Class Initialized
DEBUG - 2019-04-25 14:59:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 14:59:12 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 14:59:12 --> Final output sent to browser
DEBUG - 2019-04-25 14:59:12 --> Total execution time: 0.3448
DEBUG - 2019-04-25 15:01:35 --> Config Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:01:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:01:35 --> URI Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Router Class Initialized
DEBUG - 2019-04-25 15:01:35 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:01:35 --> Output Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Security Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Input Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:01:35 --> Language Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Loader Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Controller Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Session Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:01:35 --> Session routines successfully run
DEBUG - 2019-04-25 15:01:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:01:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:01:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:01:35 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:01:35 --> Final output sent to browser
DEBUG - 2019-04-25 15:01:35 --> Total execution time: 0.2100
DEBUG - 2019-04-25 15:01:42 --> Config Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:01:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:01:42 --> URI Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Router Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Output Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Security Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Input Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:01:42 --> Language Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Loader Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Controller Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Session Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:01:42 --> Session routines successfully run
DEBUG - 2019-04-25 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:01:42 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:01:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:01:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:01:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:01:42 --> Final output sent to browser
DEBUG - 2019-04-25 15:01:42 --> Total execution time: 0.1269
DEBUG - 2019-04-25 15:02:42 --> Config Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:02:42 --> URI Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Router Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Output Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Security Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Input Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:02:42 --> Language Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Loader Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Controller Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Session Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:02:42 --> Session routines successfully run
DEBUG - 2019-04-25 15:02:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:42 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:02:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:02:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:02:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:02:42 --> Final output sent to browser
DEBUG - 2019-04-25 15:02:42 --> Total execution time: 0.1136
DEBUG - 2019-04-25 15:02:43 --> Config Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:02:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:02:43 --> URI Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Router Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Output Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Security Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Input Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:02:43 --> Language Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Loader Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Controller Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Session Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:02:43 --> Session routines successfully run
DEBUG - 2019-04-25 15:02:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:02:43 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:02:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:02:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:02:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:02:43 --> Final output sent to browser
DEBUG - 2019-04-25 15:02:43 --> Total execution time: 0.0799
DEBUG - 2019-04-25 15:03:06 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:06 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:06 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:06 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:06 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:06 --> Total execution time: 0.0706
DEBUG - 2019-04-25 15:03:07 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:07 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:07 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:07 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:07 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:07 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:07 --> Total execution time: 0.1329
DEBUG - 2019-04-25 15:03:08 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:08 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:08 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:08 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:08 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:08 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:08 --> Total execution time: 0.1148
DEBUG - 2019-04-25 15:03:15 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:15 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:15 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:15 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:15 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:15 --> Total execution time: 0.1821
DEBUG - 2019-04-25 15:03:15 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:15 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:15 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:16 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:16 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:16 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:16 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:16 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:16 --> Total execution time: 0.1399
DEBUG - 2019-04-25 15:03:54 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:54 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:54 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:54 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:54 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:54 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:55 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:55 --> Total execution time: 0.1097
DEBUG - 2019-04-25 15:03:55 --> Config Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:03:55 --> URI Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Router Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Output Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Security Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Input Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:03:55 --> Language Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Loader Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Controller Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Session Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:03:55 --> Session routines successfully run
DEBUG - 2019-04-25 15:03:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:03:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:03:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:03:55 --> Final output sent to browser
DEBUG - 2019-04-25 15:03:55 --> Total execution time: 0.1070
DEBUG - 2019-04-25 15:04:39 --> Config Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:04:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:04:39 --> URI Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Router Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Output Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Security Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Input Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:04:39 --> Language Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Loader Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Controller Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Session Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:04:39 --> Session routines successfully run
DEBUG - 2019-04-25 15:04:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:04:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:04:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:04:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:04:39 --> Final output sent to browser
DEBUG - 2019-04-25 15:04:39 --> Total execution time: 0.0999
DEBUG - 2019-04-25 15:04:40 --> Config Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:04:40 --> URI Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Router Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Output Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Security Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Input Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:04:40 --> Language Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Loader Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Controller Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Session Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:04:40 --> Session routines successfully run
DEBUG - 2019-04-25 15:04:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:04:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:04:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:04:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:04:40 --> Final output sent to browser
DEBUG - 2019-04-25 15:04:40 --> Total execution time: 0.1224
DEBUG - 2019-04-25 15:04:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:04:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:04:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:04:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:04:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:04:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:04:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:04:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:04:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:04:41 --> Final output sent to browser
DEBUG - 2019-04-25 15:04:41 --> Total execution time: 0.0828
DEBUG - 2019-04-25 15:05:33 --> Config Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:05:33 --> URI Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Router Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Output Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Security Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Input Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:05:33 --> Language Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Loader Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Controller Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Session Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:05:33 --> Session routines successfully run
DEBUG - 2019-04-25 15:05:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:33 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:05:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:05:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:05:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:05:33 --> Final output sent to browser
DEBUG - 2019-04-25 15:05:33 --> Total execution time: 0.1112
DEBUG - 2019-04-25 15:05:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:05:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:05:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:05:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:05:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:05:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:05:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:05:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:05:34 --> Final output sent to browser
DEBUG - 2019-04-25 15:05:34 --> Total execution time: 0.0839
DEBUG - 2019-04-25 15:05:51 --> Config Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:05:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:05:51 --> URI Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Router Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Output Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Security Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Input Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:05:51 --> Language Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Loader Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Controller Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Session Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:05:51 --> Session routines successfully run
DEBUG - 2019-04-25 15:05:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:05:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:05:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:05:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:05:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:05:51 --> Final output sent to browser
DEBUG - 2019-04-25 15:05:51 --> Total execution time: 0.0877
DEBUG - 2019-04-25 15:06:06 --> Config Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:06:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:06:06 --> URI Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Router Class Initialized
DEBUG - 2019-04-25 15:06:06 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:06:06 --> Output Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Security Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Input Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:06:06 --> Language Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Loader Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Controller Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Session Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:06:06 --> Session routines successfully run
DEBUG - 2019-04-25 15:06:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:06:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:06:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:06:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:06:06 --> Final output sent to browser
DEBUG - 2019-04-25 15:06:06 --> Total execution time: 0.0983
DEBUG - 2019-04-25 15:06:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:06:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:06:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:06:24 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:06:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:06:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:06:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:06:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:06:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:06:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:06:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:06:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:06:24 --> Final output sent to browser
DEBUG - 2019-04-25 15:06:24 --> Total execution time: 0.1135
DEBUG - 2019-04-25 15:07:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:07:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:07:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:07:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:07:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:07:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:07:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:07:24 --> A session cookie was not found.
DEBUG - 2019-04-25 15:07:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:07:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:07:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:07:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:07:24 --> Final output sent to browser
DEBUG - 2019-04-25 15:07:24 --> Total execution time: 0.1490
DEBUG - 2019-04-25 15:07:26 --> Config Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:07:26 --> URI Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Router Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Output Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Security Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Input Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:07:26 --> Language Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Loader Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Controller Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Session Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:07:26 --> Session routines successfully run
DEBUG - 2019-04-25 15:07:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:07:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:07:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:07:26 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:07:26 --> Final output sent to browser
DEBUG - 2019-04-25 15:07:26 --> Total execution time: 0.0408
DEBUG - 2019-04-25 15:07:33 --> Config Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:07:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:07:33 --> URI Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Router Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Output Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Security Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Input Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:07:33 --> Language Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Loader Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Controller Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Session Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:07:33 --> Session routines successfully run
DEBUG - 2019-04-25 15:07:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Model Class Initialized
DEBUG - 2019-04-25 15:07:33 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:07:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:07:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:07:33 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:07:33 --> Final output sent to browser
DEBUG - 2019-04-25 15:07:33 --> Total execution time: 0.2569
DEBUG - 2019-04-25 15:08:08 --> Config Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:08:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:08:08 --> URI Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Router Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Output Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Security Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Input Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:08:08 --> Language Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Loader Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Controller Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Session Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:08:08 --> Session routines successfully run
DEBUG - 2019-04-25 15:08:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:08:08 --> Config Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:08:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:08:08 --> URI Class Initialized
DEBUG - 2019-04-25 15:08:08 --> Router Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Output Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Security Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Input Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:08:09 --> Language Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Loader Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Controller Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Session Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:08:09 --> A session cookie was not found.
DEBUG - 2019-04-25 15:08:09 --> Session routines successfully run
DEBUG - 2019-04-25 15:08:09 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:09 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:08:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:08:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:08:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:08:09 --> Final output sent to browser
DEBUG - 2019-04-25 15:08:09 --> Total execution time: 0.1507
DEBUG - 2019-04-25 15:08:12 --> Config Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:08:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:08:12 --> URI Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Router Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Output Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Security Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Input Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:08:12 --> Language Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Loader Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Controller Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Session Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:08:12 --> Session garbage collection performed.
DEBUG - 2019-04-25 15:08:12 --> Session routines successfully run
DEBUG - 2019-04-25 15:08:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:08:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:08:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:08:12 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 15:08:12 --> Final output sent to browser
DEBUG - 2019-04-25 15:08:12 --> Total execution time: 0.0753
DEBUG - 2019-04-25 15:08:58 --> Config Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:08:58 --> URI Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Router Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Output Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Security Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Input Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:08:58 --> Language Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Loader Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Controller Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Session Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:08:58 --> Session routines successfully run
DEBUG - 2019-04-25 15:08:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:08:58 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:08:58 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:08:58 --> Final output sent to browser
DEBUG - 2019-04-25 15:08:58 --> Total execution time: 0.2422
DEBUG - 2019-04-25 15:11:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:11:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:11:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:11:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:11:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:11:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:11:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:11:41 --> A session cookie was not found.
DEBUG - 2019-04-25 15:11:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:11:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:11:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:11:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:11:42 --> Final output sent to browser
DEBUG - 2019-04-25 15:11:42 --> Total execution time: 0.1514
DEBUG - 2019-04-25 15:11:45 --> Config Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:11:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:11:45 --> URI Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Router Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Output Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Security Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Input Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:11:45 --> Language Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Loader Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Controller Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Session Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:11:45 --> Session routines successfully run
DEBUG - 2019-04-25 15:11:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:11:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:11:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:11:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:11:45 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 15:11:45 --> Final output sent to browser
DEBUG - 2019-04-25 15:11:45 --> Total execution time: 0.0630
DEBUG - 2019-04-25 15:12:27 --> Config Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:12:27 --> URI Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Router Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Output Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Security Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Input Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:12:27 --> Language Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Loader Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Controller Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Session Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:12:27 --> Session routines successfully run
DEBUG - 2019-04-25 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:27 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:12:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:12:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:12:27 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:12:27 --> Final output sent to browser
DEBUG - 2019-04-25 15:12:27 --> Total execution time: 0.1811
DEBUG - 2019-04-25 15:12:52 --> Config Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:12:52 --> URI Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Router Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Output Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Security Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Input Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:12:52 --> Language Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Loader Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Controller Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:12:53 --> Session Class Initialized
DEBUG - 2019-04-25 15:12:53 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:12:53 --> Session routines successfully run
DEBUG - 2019-04-25 15:12:53 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:53 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:53 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:12:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:12:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:12:53 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:12:53 --> Final output sent to browser
DEBUG - 2019-04-25 15:12:53 --> Total execution time: 0.0781
DEBUG - 2019-04-25 15:12:55 --> Config Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:12:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:12:55 --> URI Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Router Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Output Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Security Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Input Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:12:55 --> Language Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Loader Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Controller Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Session Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:12:55 --> Session routines successfully run
DEBUG - 2019-04-25 15:12:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:12:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:12:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:12:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:12:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:12:55 --> Final output sent to browser
DEBUG - 2019-04-25 15:12:55 --> Total execution time: 0.0456
DEBUG - 2019-04-25 15:14:52 --> Config Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:14:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:14:52 --> URI Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Router Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Output Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Security Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Input Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:14:52 --> Language Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Loader Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Controller Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Session Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:14:52 --> Session routines successfully run
DEBUG - 2019-04-25 15:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 15:14:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:14:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:14:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:14:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:14:52 --> Final output sent to browser
DEBUG - 2019-04-25 15:14:52 --> Total execution time: 0.0564
DEBUG - 2019-04-25 15:19:06 --> Config Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:19:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:19:06 --> URI Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Router Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Output Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Security Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Input Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:19:06 --> Language Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Loader Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Controller Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Session Class Initialized
DEBUG - 2019-04-25 15:19:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:19:07 --> Session routines successfully run
DEBUG - 2019-04-25 15:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:07 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:19:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:19:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:19:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:19:07 --> Final output sent to browser
DEBUG - 2019-04-25 15:19:07 --> Total execution time: 0.1034
DEBUG - 2019-04-25 15:19:26 --> Config Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:19:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:19:26 --> URI Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Router Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Output Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Security Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Input Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:19:26 --> Language Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Loader Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Controller Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Session Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:19:26 --> Session routines successfully run
DEBUG - 2019-04-25 15:19:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:19:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:19:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:19:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:19:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:19:26 --> Final output sent to browser
DEBUG - 2019-04-25 15:19:26 --> Total execution time: 0.0559
DEBUG - 2019-04-25 15:20:19 --> Config Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:20:19 --> URI Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Router Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Output Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Security Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Input Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:20:19 --> Language Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Loader Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Controller Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Session Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:20:19 --> Session routines successfully run
DEBUG - 2019-04-25 15:20:19 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:19 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:20:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:20:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:20:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:20:19 --> Final output sent to browser
DEBUG - 2019-04-25 15:20:19 --> Total execution time: 0.0588
DEBUG - 2019-04-25 15:20:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:20:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:20:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:20:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:20:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:20:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:20:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:20:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:20:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:20:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:20:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:20:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:20:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:20:34 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 15:20:34 --> Final output sent to browser
DEBUG - 2019-04-25 15:20:34 --> Total execution time: 0.1048
DEBUG - 2019-04-25 15:21:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:24 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:21:24 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:24 --> Total execution time: 0.0806
DEBUG - 2019-04-25 15:21:28 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:28 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:28 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:28 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:28 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:21:28 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:28 --> Total execution time: 0.0878
DEBUG - 2019-04-25 15:21:32 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:32 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:32 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:32 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:32 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:32 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:21:32 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:32 --> Total execution time: 0.0962
DEBUG - 2019-04-25 15:21:40 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:40 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:40 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:40 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:40 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:40 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:40 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:40 --> A session cookie was not found.
DEBUG - 2019-04-25 15:21:40 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:21:40 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:40 --> Total execution time: 0.1316
DEBUG - 2019-04-25 15:21:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:41 --> Session garbage collection performed.
DEBUG - 2019-04-25 15:21:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:41 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:21:41 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:41 --> Total execution time: 0.0523
DEBUG - 2019-04-25 15:21:51 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:51 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:51 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:51 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:21:51 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:51 --> Total execution time: 0.1758
DEBUG - 2019-04-25 15:21:58 --> Config Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:21:58 --> URI Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Router Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Output Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Security Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Input Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:21:58 --> Language Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Loader Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Controller Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Session Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:21:58 --> Session routines successfully run
DEBUG - 2019-04-25 15:21:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Model Class Initialized
DEBUG - 2019-04-25 15:21:58 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:21:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:21:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:21:58 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:21:58 --> Final output sent to browser
DEBUG - 2019-04-25 15:21:58 --> Total execution time: 0.0852
DEBUG - 2019-04-25 15:22:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:22:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:22:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:22:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:22:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:22:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:22:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:22:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:22:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:22:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 15:22:41 --> Final output sent to browser
DEBUG - 2019-04-25 15:22:41 --> Total execution time: 0.0624
DEBUG - 2019-04-25 15:28:05 --> Config Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:28:05 --> URI Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Router Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Output Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Security Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Input Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:28:05 --> Language Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Loader Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Controller Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Session Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:28:05 --> Session routines successfully run
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:28:05 --> Config Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:28:05 --> URI Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Router Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Output Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Security Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Input Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:28:05 --> Language Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Loader Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Controller Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Session Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:28:05 --> A session cookie was not found.
DEBUG - 2019-04-25 15:28:05 --> Session routines successfully run
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:28:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:28:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:28:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:28:06 --> Final output sent to browser
DEBUG - 2019-04-25 15:28:06 --> Total execution time: 0.1293
DEBUG - 2019-04-25 15:28:07 --> Config Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:28:07 --> URI Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Router Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Output Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Security Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Input Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:28:07 --> Language Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Loader Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Controller Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Session Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:28:07 --> Session routines successfully run
DEBUG - 2019-04-25 15:28:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:07 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:28:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:28:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:28:07 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:28:07 --> Final output sent to browser
DEBUG - 2019-04-25 15:28:07 --> Total execution time: 0.0645
DEBUG - 2019-04-25 15:28:12 --> Config Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:28:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:28:12 --> URI Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Router Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Output Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Security Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Input Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:28:12 --> Language Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Loader Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Controller Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Session Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:28:12 --> Session routines successfully run
DEBUG - 2019-04-25 15:28:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:28:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:28:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:28:12 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:28:12 --> Final output sent to browser
DEBUG - 2019-04-25 15:28:12 --> Total execution time: 0.1715
DEBUG - 2019-04-25 15:28:18 --> Config Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:28:18 --> URI Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Router Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Output Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Security Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Input Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:28:18 --> Language Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Loader Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Controller Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Session Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:28:18 --> Session routines successfully run
DEBUG - 2019-04-25 15:28:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:28:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:28:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:28:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:28:18 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 15:28:18 --> Final output sent to browser
DEBUG - 2019-04-25 15:28:18 --> Total execution time: 0.0996
DEBUG - 2019-04-25 15:36:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:36:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:36:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:36:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:36:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:36:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:36:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Session Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:36:24 --> A session cookie was not found.
DEBUG - 2019-04-25 15:36:24 --> Session routines successfully run
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:36:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:36:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:36:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:36:24 --> Final output sent to browser
DEBUG - 2019-04-25 15:36:24 --> Total execution time: 0.1492
DEBUG - 2019-04-25 15:36:27 --> Config Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:36:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:36:27 --> URI Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Router Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Output Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Security Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Input Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:36:27 --> Language Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Loader Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Controller Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Session Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:36:27 --> Session routines successfully run
DEBUG - 2019-04-25 15:36:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:27 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:36:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:36:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:36:27 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:36:27 --> Final output sent to browser
DEBUG - 2019-04-25 15:36:27 --> Total execution time: 0.0586
DEBUG - 2019-04-25 15:36:31 --> Config Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:36:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:36:31 --> URI Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Router Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Output Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Security Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Input Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:36:31 --> Language Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Loader Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Controller Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Session Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:36:31 --> Session garbage collection performed.
DEBUG - 2019-04-25 15:36:31 --> Session routines successfully run
DEBUG - 2019-04-25 15:36:31 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:31 --> Helper loaded: url_helper
ERROR - 2019-04-25 15:36:31 --> Severity: Warning  --> Use of undefined constant type - assumed 'type' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:36:31 --> Severity: Notice  --> Undefined index: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:36:31 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 107
DEBUG - 2019-04-25 15:36:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:36:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:36:31 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:36:31 --> Final output sent to browser
DEBUG - 2019-04-25 15:36:31 --> Total execution time: 0.1732
DEBUG - 2019-04-25 15:36:50 --> Config Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:36:50 --> URI Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Router Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Output Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Security Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Input Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:36:50 --> Language Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Loader Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Controller Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Session Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:36:50 --> Session routines successfully run
DEBUG - 2019-04-25 15:36:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:36:50 --> Helper loaded: url_helper
ERROR - 2019-04-25 15:36:50 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:36:50 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:36:50 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 107
DEBUG - 2019-04-25 15:36:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:36:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:36:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:36:50 --> Final output sent to browser
DEBUG - 2019-04-25 15:36:50 --> Total execution time: 0.2044
DEBUG - 2019-04-25 15:37:23 --> Config Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:37:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:37:23 --> URI Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Router Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Output Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Security Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Input Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:37:23 --> Language Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Loader Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Controller Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Session Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:37:23 --> Session routines successfully run
DEBUG - 2019-04-25 15:37:23 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:23 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:37:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:37:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:37:23 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:37:23 --> Final output sent to browser
DEBUG - 2019-04-25 15:37:23 --> Total execution time: 0.0581
DEBUG - 2019-04-25 15:37:27 --> Config Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:37:27 --> URI Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Router Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Output Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Security Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Input Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:37:27 --> Language Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Loader Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Controller Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Session Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:37:27 --> Session routines successfully run
DEBUG - 2019-04-25 15:37:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:37:27 --> Helper loaded: url_helper
ERROR - 2019-04-25 15:37:27 --> Severity: Notice  --> Undefined index: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:37:27 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 107
DEBUG - 2019-04-25 15:37:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:37:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:37:27 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:37:27 --> Final output sent to browser
DEBUG - 2019-04-25 15:37:27 --> Total execution time: 0.1655
DEBUG - 2019-04-25 15:39:36 --> Config Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:39:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:39:36 --> URI Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Router Class Initialized
DEBUG - 2019-04-25 15:39:36 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:39:36 --> Output Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Security Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Input Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:39:36 --> Language Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Loader Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Controller Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Session Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:39:36 --> A session cookie was not found.
DEBUG - 2019-04-25 15:39:36 --> Session routines successfully run
DEBUG - 2019-04-25 15:39:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:39:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:39:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:39:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:39:36 --> Final output sent to browser
DEBUG - 2019-04-25 15:39:36 --> Total execution time: 0.1571
DEBUG - 2019-04-25 15:39:39 --> Config Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:39:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:39:39 --> URI Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Router Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Output Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Security Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Input Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:39:39 --> Language Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Loader Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Controller Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Session Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:39:39 --> Session routines successfully run
DEBUG - 2019-04-25 15:39:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:39:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:39:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:39:39 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:39:39 --> Final output sent to browser
DEBUG - 2019-04-25 15:39:39 --> Total execution time: 0.0585
DEBUG - 2019-04-25 15:39:43 --> Config Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:39:43 --> URI Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Router Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Output Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Security Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Input Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:39:43 --> Language Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Loader Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Controller Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Session Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:39:43 --> Session routines successfully run
DEBUG - 2019-04-25 15:39:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Model Class Initialized
DEBUG - 2019-04-25 15:39:43 --> Helper loaded: url_helper
ERROR - 2019-04-25 15:39:43 --> Severity: Notice  --> Undefined index: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 89
ERROR - 2019-04-25 15:39:43 --> Severity: Notice  --> Undefined variable: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 107
DEBUG - 2019-04-25 15:39:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:39:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:39:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:39:43 --> Final output sent to browser
DEBUG - 2019-04-25 15:39:43 --> Total execution time: 0.1654
DEBUG - 2019-04-25 15:43:41 --> Config Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:43:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:43:41 --> URI Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Router Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Output Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Security Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Input Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:43:41 --> Language Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Loader Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Controller Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Session Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:43:41 --> Session routines successfully run
DEBUG - 2019-04-25 15:43:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:43:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:43:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:43:41 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:43:41 --> Final output sent to browser
DEBUG - 2019-04-25 15:43:41 --> Total execution time: 0.0534
DEBUG - 2019-04-25 15:43:44 --> Config Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:43:44 --> URI Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Router Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Output Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Security Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Input Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:43:44 --> Language Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Loader Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Controller Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Session Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:43:44 --> Session routines successfully run
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:43:44 --> Config Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:43:44 --> URI Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Router Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Output Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Security Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Input Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:43:44 --> Language Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Loader Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Controller Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Session Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:43:44 --> A session cookie was not found.
DEBUG - 2019-04-25 15:43:44 --> Session routines successfully run
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:43:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:43:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:43:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:43:45 --> Final output sent to browser
DEBUG - 2019-04-25 15:43:45 --> Total execution time: 0.1318
DEBUG - 2019-04-25 15:43:46 --> Config Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:43:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:43:46 --> URI Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Router Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Output Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Security Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Input Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:43:46 --> Language Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Loader Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Controller Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Session Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:43:46 --> Session routines successfully run
DEBUG - 2019-04-25 15:43:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:43:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:43:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:43:46 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:43:46 --> Final output sent to browser
DEBUG - 2019-04-25 15:43:46 --> Total execution time: 0.0559
DEBUG - 2019-04-25 15:43:50 --> Config Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:43:50 --> URI Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Router Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Output Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Security Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Input Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:43:50 --> Language Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Loader Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Controller Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Session Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:43:50 --> Session routines successfully run
DEBUG - 2019-04-25 15:43:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:43:50 --> Helper loaded: url_helper
ERROR - 2019-04-25 15:43:50 --> Severity: Notice  --> Undefined index: type==2 C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 101
DEBUG - 2019-04-25 15:43:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:43:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:43:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:43:50 --> Final output sent to browser
DEBUG - 2019-04-25 15:43:50 --> Total execution time: 0.1673
DEBUG - 2019-04-25 15:44:11 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:11 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:11 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:11 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:11 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:44:11 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:11 --> Total execution time: 0.0493
DEBUG - 2019-04-25 15:44:12 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:12 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:12 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:12 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:12 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:12 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:12 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:12 --> A session cookie was not found.
DEBUG - 2019-04-25 15:44:12 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:44:12 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:12 --> Total execution time: 0.2307
DEBUG - 2019-04-25 15:44:13 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:13 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:13 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:13 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:13 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:13 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:44:13 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:13 --> Total execution time: 0.0612
DEBUG - 2019-04-25 15:44:18 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:18 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:18 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:18 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:18 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:44:18 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:18 --> Total execution time: 0.2052
DEBUG - 2019-04-25 15:44:55 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:55 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:55 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:55 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:55 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:55 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:55 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:55 --> A session cookie was not found.
DEBUG - 2019-04-25 15:44:55 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:44:55 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:55 --> Total execution time: 0.2231
DEBUG - 2019-04-25 15:44:57 --> Config Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:44:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:44:57 --> URI Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Router Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Output Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Security Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Input Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:44:57 --> Language Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Loader Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Controller Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Session Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:44:57 --> Session routines successfully run
DEBUG - 2019-04-25 15:44:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:44:57 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:44:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:44:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:44:57 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:44:57 --> Final output sent to browser
DEBUG - 2019-04-25 15:44:57 --> Total execution time: 0.0550
DEBUG - 2019-04-25 15:45:00 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:00 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:00 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:00 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:00 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:00 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:45:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:45:00 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:45:00 --> Final output sent to browser
DEBUG - 2019-04-25 15:45:00 --> Total execution time: 0.1609
DEBUG - 2019-04-25 15:45:05 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:05 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:05 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:05 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:45:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:45:05 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 15:45:05 --> Final output sent to browser
DEBUG - 2019-04-25 15:45:05 --> Total execution time: 0.0819
DEBUG - 2019-04-25 15:45:38 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:38 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:38 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:38 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:38 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:38 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:38 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:38 --> A session cookie was not found.
DEBUG - 2019-04-25 15:45:38 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:45:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:45:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:45:38 --> Final output sent to browser
DEBUG - 2019-04-25 15:45:38 --> Total execution time: 0.1575
DEBUG - 2019-04-25 15:45:39 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:39 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:39 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:39 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:45:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:45:39 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:45:39 --> Final output sent to browser
DEBUG - 2019-04-25 15:45:39 --> Total execution time: 0.0514
DEBUG - 2019-04-25 15:45:45 --> Config Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:45:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:45:45 --> URI Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Router Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Output Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Security Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Input Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:45:45 --> Language Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Loader Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Controller Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Session Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:45:45 --> Session routines successfully run
DEBUG - 2019-04-25 15:45:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:45:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:45:45 --> Final output sent to browser
DEBUG - 2019-04-25 15:45:45 --> Total execution time: 0.1613
DEBUG - 2019-04-25 15:46:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:34 --> A session cookie was not found.
DEBUG - 2019-04-25 15:46:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:46:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:46:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:46:34 --> Final output sent to browser
DEBUG - 2019-04-25 15:46:34 --> Total execution time: 0.1383
DEBUG - 2019-04-25 15:46:35 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:35 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:35 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:36 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:36 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:46:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:46:36 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:46:36 --> Final output sent to browser
DEBUG - 2019-04-25 15:46:36 --> Total execution time: 0.0506
DEBUG - 2019-04-25 15:46:39 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:39 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:39 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:39 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:46:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:46:39 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-25 15:46:39 --> Final output sent to browser
DEBUG - 2019-04-25 15:46:39 --> Total execution time: 0.0796
DEBUG - 2019-04-25 15:46:46 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:46 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:46 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:46 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:46:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:46:46 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:46:46 --> Final output sent to browser
DEBUG - 2019-04-25 15:46:46 --> Total execution time: 0.0667
DEBUG - 2019-04-25 15:46:56 --> Config Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:46:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:46:56 --> URI Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Router Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Output Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Security Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Input Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:46:56 --> Language Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Loader Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Controller Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Session Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:46:56 --> Session routines successfully run
DEBUG - 2019-04-25 15:46:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:46:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:46:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:46:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:46:56 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:46:56 --> Final output sent to browser
DEBUG - 2019-04-25 15:46:56 --> Total execution time: 0.3744
DEBUG - 2019-04-25 15:49:45 --> Config Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:49:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:49:45 --> URI Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Router Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Output Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Security Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Input Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:49:45 --> Language Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Loader Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Controller Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Session Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:49:45 --> Session routines successfully run
DEBUG - 2019-04-25 15:49:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Model Class Initialized
DEBUG - 2019-04-25 15:49:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:49:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:49:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:49:45 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 15:49:45 --> Final output sent to browser
DEBUG - 2019-04-25 15:49:45 --> Total execution time: 0.0958
DEBUG - 2019-04-25 15:50:24 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:24 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:24 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:24 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:25 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:25 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:25 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:25 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:25 --> A session cookie was not found.
DEBUG - 2019-04-25 15:50:25 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:25 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:50:25 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:25 --> Total execution time: 0.2415
DEBUG - 2019-04-25 15:50:26 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:26 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:26 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:26 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:26 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:50:26 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:26 --> Total execution time: 0.0620
DEBUG - 2019-04-25 15:50:30 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:30 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:30 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:30 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:30 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:30 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:30 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:50:30 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:30 --> Total execution time: 0.1634
DEBUG - 2019-04-25 15:50:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:34 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:34 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:34 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:34 --> A session cookie was not found.
DEBUG - 2019-04-25 15:50:34 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:50:34 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:34 --> Total execution time: 0.1689
DEBUG - 2019-04-25 15:50:36 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:36 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:36 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:36 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:36 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:50:36 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:36 --> Total execution time: 0.0501
DEBUG - 2019-04-25 15:50:40 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:40 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:40 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:40 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:50:40 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:40 --> Total execution time: 0.1427
DEBUG - 2019-04-25 15:50:50 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:50 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:50 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:50 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:50 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:50 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:50:50 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:50 --> Total execution time: 0.1025
DEBUG - 2019-04-25 15:50:56 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:56 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:56 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:56 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:56 --> Config Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:50:56 --> URI Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Router Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Output Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Security Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Input Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:50:56 --> Language Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Loader Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Controller Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Session Class Initialized
DEBUG - 2019-04-25 15:50:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:50:56 --> A session cookie was not found.
DEBUG - 2019-04-25 15:50:57 --> Session routines successfully run
DEBUG - 2019-04-25 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-25 15:50:57 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:50:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:50:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:50:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:50:57 --> Final output sent to browser
DEBUG - 2019-04-25 15:50:57 --> Total execution time: 0.1794
DEBUG - 2019-04-25 15:53:36 --> Config Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:53:36 --> URI Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Router Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Output Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Security Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Input Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:53:36 --> Language Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Loader Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Controller Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Session Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:53:36 --> Session routines successfully run
DEBUG - 2019-04-25 15:53:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:53:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:53:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:53:36 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:53:36 --> Final output sent to browser
DEBUG - 2019-04-25 15:53:36 --> Total execution time: 0.0740
DEBUG - 2019-04-25 15:53:44 --> Config Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:53:44 --> URI Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Router Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Output Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Security Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Input Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:53:44 --> Language Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Loader Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Controller Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Session Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:53:44 --> Session routines successfully run
DEBUG - 2019-04-25 15:53:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:44 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:53:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:53:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:53:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:53:44 --> Final output sent to browser
DEBUG - 2019-04-25 15:53:44 --> Total execution time: 0.1908
DEBUG - 2019-04-25 15:53:47 --> Config Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:53:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:53:47 --> URI Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Router Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Output Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Security Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Input Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:53:47 --> Language Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Loader Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Controller Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Session Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:53:47 --> Session routines successfully run
DEBUG - 2019-04-25 15:53:47 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Model Class Initialized
DEBUG - 2019-04-25 15:53:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:53:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:53:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:53:47 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:53:47 --> Final output sent to browser
DEBUG - 2019-04-25 15:53:47 --> Total execution time: 0.1004
DEBUG - 2019-04-25 15:56:04 --> Config Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:56:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:56:04 --> URI Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Router Class Initialized
DEBUG - 2019-04-25 15:56:04 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:56:04 --> Output Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Security Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Input Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:56:04 --> Language Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Loader Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Controller Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Model Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Model Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Session Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:56:04 --> Session routines successfully run
DEBUG - 2019-04-25 15:56:04 --> Model Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Model Class Initialized
DEBUG - 2019-04-25 15:56:04 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:56:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:56:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:56:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:56:04 --> Final output sent to browser
DEBUG - 2019-04-25 15:56:04 --> Total execution time: 0.1728
DEBUG - 2019-04-25 15:57:02 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:02 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:02 --> No URI present. Default controller set.
DEBUG - 2019-04-25 15:57:02 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:02 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:02 --> A session cookie was not found.
DEBUG - 2019-04-25 15:57:02 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:02 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:02 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:02 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:57:02 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:02 --> Total execution time: 0.1682
DEBUG - 2019-04-25 15:57:06 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:06 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:06 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:06 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:06 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:57:06 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:06 --> Total execution time: 0.0517
DEBUG - 2019-04-25 15:57:11 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:11 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:11 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:11 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:57:11 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:11 --> Total execution time: 0.1474
DEBUG - 2019-04-25 15:57:14 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:14 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:14 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:14 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:14 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:14 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 15:57:14 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:14 --> Total execution time: 0.1065
DEBUG - 2019-04-25 15:57:20 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:20 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:20 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:20 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:20 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:20 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:20 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:20 --> A session cookie was not found.
DEBUG - 2019-04-25 15:57:20 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:57:20 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:20 --> Total execution time: 0.2467
DEBUG - 2019-04-25 15:57:22 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:22 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:22 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:22 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:22 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:22 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 15:57:22 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:22 --> Total execution time: 0.0557
DEBUG - 2019-04-25 15:57:25 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:25 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:25 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:25 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:26 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:26 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 15:57:26 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:26 --> Total execution time: 0.2348
DEBUG - 2019-04-25 15:57:27 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:27 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:27 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:27 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:27 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:27 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-25 15:57:27 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:27 --> Total execution time: 0.0941
DEBUG - 2019-04-25 15:57:36 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:36 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:36 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:36 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:36 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:37 --> Config Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 15:57:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 15:57:37 --> URI Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Router Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Output Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Security Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Input Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 15:57:37 --> Language Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Loader Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Controller Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Session Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 15:57:37 --> A session cookie was not found.
DEBUG - 2019-04-25 15:57:37 --> Session routines successfully run
DEBUG - 2019-04-25 15:57:37 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Model Class Initialized
DEBUG - 2019-04-25 15:57:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 15:57:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 15:57:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 15:57:37 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 15:57:37 --> Final output sent to browser
DEBUG - 2019-04-25 15:57:37 --> Total execution time: 0.1380
DEBUG - 2019-04-25 16:00:06 --> Config Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:00:06 --> URI Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Router Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Output Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Security Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Input Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:00:06 --> Language Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Loader Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Controller Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Session Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:00:06 --> Session routines successfully run
DEBUG - 2019-04-25 16:00:06 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:00:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:00:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:00:06 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 16:00:06 --> Final output sent to browser
DEBUG - 2019-04-25 16:00:06 --> Total execution time: 0.0539
DEBUG - 2019-04-25 16:00:12 --> Config Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:00:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:00:12 --> URI Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Router Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Output Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Security Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Input Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:00:12 --> Language Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Loader Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Controller Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Session Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:00:12 --> Session routines successfully run
DEBUG - 2019-04-25 16:00:12 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:00:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:00:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:00:12 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:00:12 --> Final output sent to browser
DEBUG - 2019-04-25 16:00:12 --> Total execution time: 0.1359
DEBUG - 2019-04-25 16:00:15 --> Config Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:00:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:00:15 --> URI Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Router Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Output Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Security Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Input Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:00:15 --> Language Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Loader Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Controller Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Session Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:00:15 --> Session routines successfully run
DEBUG - 2019-04-25 16:00:15 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Model Class Initialized
DEBUG - 2019-04-25 16:00:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:00:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:00:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:00:15 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:00:15 --> Final output sent to browser
DEBUG - 2019-04-25 16:00:15 --> Total execution time: 0.0936
DEBUG - 2019-04-25 16:01:28 --> Config Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:01:28 --> URI Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Router Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Output Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Security Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Input Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:01:28 --> Language Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Loader Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Controller Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Session Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:01:28 --> Session routines successfully run
DEBUG - 2019-04-25 16:01:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:01:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:01:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:01:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:01:28 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:01:28 --> Final output sent to browser
DEBUG - 2019-04-25 16:01:28 --> Total execution time: 0.0869
DEBUG - 2019-04-25 16:02:29 --> Config Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:02:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:02:29 --> URI Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Router Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Output Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Security Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Input Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:02:29 --> Language Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Loader Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Controller Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Session Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:02:29 --> Session routines successfully run
DEBUG - 2019-04-25 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:02:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:02:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:02:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:02:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:02:29 --> Final output sent to browser
DEBUG - 2019-04-25 16:02:29 --> Total execution time: 0.1085
DEBUG - 2019-04-25 16:03:00 --> Config Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:03:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:03:00 --> URI Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Router Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Output Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Security Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Input Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:03:00 --> Language Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Loader Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Controller Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Session Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:03:00 --> Session routines successfully run
DEBUG - 2019-04-25 16:03:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:00 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:03:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:03:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:03:00 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:03:00 --> Final output sent to browser
DEBUG - 2019-04-25 16:03:00 --> Total execution time: 0.2700
DEBUG - 2019-04-25 16:03:20 --> Config Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:03:20 --> URI Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Router Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Output Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Security Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Input Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:03:20 --> Language Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Loader Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Controller Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Session Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:03:20 --> Session routines successfully run
DEBUG - 2019-04-25 16:03:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:03:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:03:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:03:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:03:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:03:20 --> Final output sent to browser
DEBUG - 2019-04-25 16:03:20 --> Total execution time: 0.1168
DEBUG - 2019-04-25 16:05:09 --> Config Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:05:09 --> URI Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Router Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Output Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Security Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Input Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:05:09 --> Language Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Loader Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Controller Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Session Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:05:09 --> Session routines successfully run
DEBUG - 2019-04-25 16:05:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:05:09 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:05:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:05:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:05:09 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:05:09 --> Final output sent to browser
DEBUG - 2019-04-25 16:05:09 --> Total execution time: 0.1073
DEBUG - 2019-04-25 16:06:05 --> Config Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:06:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:06:05 --> URI Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Router Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Output Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Security Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Input Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:06:05 --> Language Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Loader Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Controller Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Session Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:06:05 --> Session routines successfully run
DEBUG - 2019-04-25 16:06:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:06:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:06:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:06:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:06:05 --> Final output sent to browser
DEBUG - 2019-04-25 16:06:05 --> Total execution time: 0.0629
DEBUG - 2019-04-25 16:06:37 --> Config Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:06:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:06:37 --> URI Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Router Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Output Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Security Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Input Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:06:37 --> Language Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Loader Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Controller Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Session Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:06:37 --> Session routines successfully run
DEBUG - 2019-04-25 16:06:37 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Model Class Initialized
DEBUG - 2019-04-25 16:06:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:06:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:06:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:06:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:06:37 --> Final output sent to browser
DEBUG - 2019-04-25 16:06:37 --> Total execution time: 0.0579
DEBUG - 2019-04-25 16:07:47 --> Config Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:07:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:07:47 --> URI Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Router Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Output Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Security Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Input Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:07:47 --> Language Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Loader Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Controller Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Session Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:07:47 --> Session routines successfully run
DEBUG - 2019-04-25 16:07:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:07:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:07:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:07:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:07:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:07:47 --> Final output sent to browser
DEBUG - 2019-04-25 16:07:47 --> Total execution time: 0.0629
DEBUG - 2019-04-25 16:09:09 --> Config Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:09:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:09:09 --> URI Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Router Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Output Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Security Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Input Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:09:09 --> Language Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Loader Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Controller Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Session Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:09:09 --> Session routines successfully run
DEBUG - 2019-04-25 16:09:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:09 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:09:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:09:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:09:09 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-25 16:09:09 --> Final output sent to browser
DEBUG - 2019-04-25 16:09:09 --> Total execution time: 0.1748
DEBUG - 2019-04-25 16:09:16 --> Config Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:09:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:09:16 --> URI Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Router Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Output Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Security Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Input Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:09:16 --> Language Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Loader Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Controller Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Session Class Initialized
DEBUG - 2019-04-25 16:09:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:09:16 --> Session routines successfully run
DEBUG - 2019-04-25 16:09:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:09:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:09:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:09:16 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-25 16:09:16 --> Final output sent to browser
DEBUG - 2019-04-25 16:09:16 --> Total execution time: 0.0637
DEBUG - 2019-04-25 16:09:21 --> Config Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:09:21 --> URI Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Router Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Output Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Security Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Input Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:09:21 --> Language Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Loader Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Controller Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Session Class Initialized
DEBUG - 2019-04-25 16:09:21 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:09:21 --> Session routines successfully run
DEBUG - 2019-04-25 16:09:21 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:09:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:09:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:09:21 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-25 16:09:21 --> Final output sent to browser
DEBUG - 2019-04-25 16:09:21 --> Total execution time: 0.0646
DEBUG - 2019-04-25 16:09:29 --> Config Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:09:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:09:29 --> URI Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Router Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Output Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Security Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Input Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:09:29 --> Language Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Loader Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Controller Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Session Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:09:29 --> Session routines successfully run
DEBUG - 2019-04-25 16:09:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Model Class Initialized
DEBUG - 2019-04-25 16:09:29 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:09:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:09:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:09:29 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:09:29 --> Final output sent to browser
DEBUG - 2019-04-25 16:09:29 --> Total execution time: 0.0548
DEBUG - 2019-04-25 16:10:05 --> Config Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:10:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:10:05 --> URI Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Router Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Output Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Security Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Input Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:10:05 --> Language Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Loader Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Controller Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Session Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:10:05 --> Session routines successfully run
DEBUG - 2019-04-25 16:10:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Model Class Initialized
DEBUG - 2019-04-25 16:10:05 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:10:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:10:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:10:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:10:05 --> Final output sent to browser
DEBUG - 2019-04-25 16:10:05 --> Total execution time: 0.0562
DEBUG - 2019-04-25 16:11:03 --> Config Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:11:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:11:03 --> URI Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Router Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Output Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Security Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Input Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:11:03 --> Language Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Loader Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Controller Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Session Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:11:03 --> Session routines successfully run
DEBUG - 2019-04-25 16:11:03 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:11:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:11:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:11:04 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:11:04 --> Final output sent to browser
DEBUG - 2019-04-25 16:11:04 --> Total execution time: 0.1128
DEBUG - 2019-04-25 16:11:39 --> Config Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:11:39 --> URI Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Router Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Output Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Security Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Input Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:11:39 --> Language Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Loader Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Controller Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Session Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:11:39 --> Session garbage collection performed.
DEBUG - 2019-04-25 16:11:39 --> Session routines successfully run
DEBUG - 2019-04-25 16:11:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:11:54 --> Config Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:11:54 --> URI Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Router Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Output Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Security Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Input Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:11:54 --> Language Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Loader Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Controller Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Session Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:11:54 --> Session routines successfully run
DEBUG - 2019-04-25 16:11:54 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Model Class Initialized
DEBUG - 2019-04-25 16:11:54 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:11:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:11:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:11:54 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:11:54 --> Final output sent to browser
DEBUG - 2019-04-25 16:11:54 --> Total execution time: 0.0845
DEBUG - 2019-04-25 16:12:20 --> Config Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:12:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:12:20 --> URI Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Router Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Output Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Security Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Input Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:12:20 --> Language Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Loader Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Controller Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Session Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:12:20 --> Session routines successfully run
DEBUG - 2019-04-25 16:12:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Model Class Initialized
DEBUG - 2019-04-25 16:12:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:14:52 --> Config Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:14:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:14:52 --> URI Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Router Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Output Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Security Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Input Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:14:52 --> Language Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Loader Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Controller Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Session Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:14:52 --> Session routines successfully run
DEBUG - 2019-04-25 16:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:14:53 --> Config Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:14:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:14:53 --> URI Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Router Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Output Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Security Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Input Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:14:53 --> Language Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Loader Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Controller Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Session Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:14:53 --> Session routines successfully run
DEBUG - 2019-04-25 16:14:53 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Model Class Initialized
DEBUG - 2019-04-25 16:14:53 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:15:16 --> Config Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:15:16 --> URI Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Router Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Output Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Security Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Input Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:15:16 --> Language Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Loader Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Controller Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Session Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:15:16 --> Session routines successfully run
DEBUG - 2019-04-25 16:15:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:15:16 --> File loaded: application/views/header.php
ERROR - 2019-04-25 16:15:16 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
ERROR - 2019-04-25 16:15:16 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
DEBUG - 2019-04-25 16:15:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:15:16 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:15:16 --> Final output sent to browser
DEBUG - 2019-04-25 16:15:16 --> Total execution time: 0.0748
DEBUG - 2019-04-25 16:15:39 --> Config Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:15:39 --> URI Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Router Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Output Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Security Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Input Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:15:39 --> Language Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Loader Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Controller Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Session Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:15:39 --> Session routines successfully run
DEBUG - 2019-04-25 16:15:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Model Class Initialized
DEBUG - 2019-04-25 16:15:39 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:16:36 --> Config Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:16:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:16:36 --> URI Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Router Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Output Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Security Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Input Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:16:36 --> Language Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Loader Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Controller Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Model Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Model Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Session Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:16:36 --> Session routines successfully run
DEBUG - 2019-04-25 16:16:36 --> Model Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Model Class Initialized
DEBUG - 2019-04-25 16:16:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:16:36 --> File loaded: application/views/header.php
ERROR - 2019-04-25 16:16:36 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
ERROR - 2019-04-25 16:16:36 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 26
ERROR - 2019-04-25 16:16:36 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
ERROR - 2019-04-25 16:16:36 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 26
DEBUG - 2019-04-25 16:16:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:16:36 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:16:36 --> Final output sent to browser
DEBUG - 2019-04-25 16:16:36 --> Total execution time: 0.0708
DEBUG - 2019-04-25 16:17:38 --> Config Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:17:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:17:38 --> URI Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Router Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Output Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Security Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Input Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:17:38 --> Language Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Loader Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Controller Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Session Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:17:38 --> Session garbage collection performed.
DEBUG - 2019-04-25 16:17:38 --> Session routines successfully run
DEBUG - 2019-04-25 16:17:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:17:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:18:00 --> Config Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:18:00 --> URI Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Router Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Output Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Security Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Input Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:18:00 --> Language Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Loader Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Controller Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Session Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:18:00 --> Session routines successfully run
DEBUG - 2019-04-25 16:18:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:00 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:18:28 --> Config Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:18:28 --> URI Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Router Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Output Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Security Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Input Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:18:28 --> Language Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Loader Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Controller Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Session Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:18:28 --> Session routines successfully run
DEBUG - 2019-04-25 16:18:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Model Class Initialized
DEBUG - 2019-04-25 16:18:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:19:07 --> Config Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:19:07 --> URI Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Router Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Output Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Security Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Input Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:19:07 --> Language Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Loader Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Controller Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Session Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:19:07 --> Session routines successfully run
DEBUG - 2019-04-25 16:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Model Class Initialized
DEBUG - 2019-04-25 16:19:07 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:19:07 --> File loaded: application/views/header.php
ERROR - 2019-04-25 16:19:07 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-25 16:19:07 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-25 16:19:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:19:07 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-25 16:19:07 --> Final output sent to browser
DEBUG - 2019-04-25 16:19:07 --> Total execution time: 0.1243
DEBUG - 2019-04-25 16:22:34 --> Config Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:22:34 --> URI Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Router Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Output Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Security Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Input Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:22:34 --> Language Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Loader Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Controller Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Session Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:22:34 --> Session routines successfully run
DEBUG - 2019-04-25 16:22:34 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:22:51 --> Config Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:22:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:22:51 --> URI Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Router Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Output Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Security Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Input Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:22:51 --> Language Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Loader Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Controller Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Session Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:22:51 --> Session routines successfully run
DEBUG - 2019-04-25 16:22:51 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Model Class Initialized
DEBUG - 2019-04-25 16:22:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:25:18 --> Config Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:25:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:25:18 --> URI Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Router Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Output Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Security Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Input Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:25:18 --> Language Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Loader Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Controller Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Session Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:25:18 --> Session routines successfully run
DEBUG - 2019-04-25 16:25:18 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:18 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:25:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:25:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:25:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 16:25:18 --> Final output sent to browser
DEBUG - 2019-04-25 16:25:18 --> Total execution time: 0.0689
DEBUG - 2019-04-25 16:25:26 --> Config Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:25:26 --> URI Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Router Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Output Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Security Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Input Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:25:26 --> Language Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Loader Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Controller Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Session Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:25:26 --> Session routines successfully run
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:25:26 --> Config Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:25:26 --> URI Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Router Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Output Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Security Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Input Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:25:26 --> Language Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Loader Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Controller Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Session Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:25:26 --> Session routines successfully run
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Model Class Initialized
DEBUG - 2019-04-25 16:25:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:28:52 --> Config Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:28:52 --> URI Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Router Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Output Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Security Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Input Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:28:52 --> Language Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Loader Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Controller Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Session Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:28:52 --> Session routines successfully run
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:28:52 --> Config Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:28:52 --> URI Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Router Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Output Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Security Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Input Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:28:52 --> Language Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Loader Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Controller Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Session Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:28:52 --> A session cookie was not found.
DEBUG - 2019-04-25 16:28:52 --> Session routines successfully run
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:28:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:28:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:28:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 16:28:52 --> Final output sent to browser
DEBUG - 2019-04-25 16:28:52 --> Total execution time: 0.1120
DEBUG - 2019-04-25 16:28:55 --> Config Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:28:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:28:55 --> URI Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Router Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Output Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Security Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Input Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:28:55 --> Language Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Loader Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Controller Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Session Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:28:55 --> Session routines successfully run
DEBUG - 2019-04-25 16:28:55 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Model Class Initialized
DEBUG - 2019-04-25 16:28:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:28:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:28:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:28:55 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 16:28:55 --> Final output sent to browser
DEBUG - 2019-04-25 16:28:55 --> Total execution time: 0.0532
DEBUG - 2019-04-25 16:29:38 --> Config Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:29:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:29:38 --> URI Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Router Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Output Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Security Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Input Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:29:38 --> Language Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Loader Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Controller Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Session Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:29:38 --> Session routines successfully run
DEBUG - 2019-04-25 16:29:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 16:29:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 16:29:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 16:29:38 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 16:29:38 --> Final output sent to browser
DEBUG - 2019-04-25 16:29:38 --> Total execution time: 0.0670
DEBUG - 2019-04-25 16:29:47 --> Config Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Hooks Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Utf8 Class Initialized
DEBUG - 2019-04-25 16:29:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 16:29:47 --> URI Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Router Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Output Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Security Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Input Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 16:29:47 --> Language Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Loader Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Controller Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Database Driver Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Session Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Helper loaded: string_helper
DEBUG - 2019-04-25 16:29:47 --> Session routines successfully run
DEBUG - 2019-04-25 16:29:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Model Class Initialized
DEBUG - 2019-04-25 16:29:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:08:31 --> Config Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:08:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:08:31 --> URI Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Router Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Output Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Security Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Input Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:08:31 --> Language Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Loader Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Controller Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Session Class Initialized
DEBUG - 2019-04-25 17:08:31 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:08:32 --> Session garbage collection performed.
DEBUG - 2019-04-25 17:08:32 --> Session routines successfully run
DEBUG - 2019-04-25 17:08:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:08:32 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:08:32 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:08:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:08:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:08:32 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 17:08:32 --> Final output sent to browser
DEBUG - 2019-04-25 17:08:32 --> Total execution time: 0.1017
DEBUG - 2019-04-25 17:08:42 --> Config Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:08:42 --> URI Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Router Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Output Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Security Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Input Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:08:42 --> Language Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Loader Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Controller Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Session Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:08:42 --> Session routines successfully run
DEBUG - 2019-04-25 17:08:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:08:42 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:08:42 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:08:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2019-04-25 17:08:42 --> Severity: Notice  --> Undefined variable: anAuthor C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 152
DEBUG - 2019-04-25 17:19:08 --> Config Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:19:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:19:08 --> URI Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Router Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Output Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Security Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Input Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:19:08 --> Language Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Loader Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Controller Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Session Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:19:08 --> Session routines successfully run
DEBUG - 2019-04-25 17:19:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:19:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:19:08 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:19:08 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:19:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:19:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:19:08 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 17:19:08 --> Final output sent to browser
DEBUG - 2019-04-25 17:19:08 --> Total execution time: 0.1112
DEBUG - 2019-04-25 17:20:15 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:15 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:15 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:15 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:15 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:15 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:15 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:15 --> A session cookie was not found.
DEBUG - 2019-04-25 17:20:15 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:15 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:15 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:20:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:20:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:20:15 --> Final output sent to browser
DEBUG - 2019-04-25 17:20:15 --> Total execution time: 0.1884
DEBUG - 2019-04-25 17:20:16 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:16 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:16 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:16 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:16 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:16 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:20:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:20:16 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 17:20:16 --> Final output sent to browser
DEBUG - 2019-04-25 17:20:16 --> Total execution time: 0.0657
DEBUG - 2019-04-25 17:20:37 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:37 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:37 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:37 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:37 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:37 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:20:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:20:37 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:20:37 --> Final output sent to browser
DEBUG - 2019-04-25 17:20:37 --> Total execution time: 0.0715
DEBUG - 2019-04-25 17:20:48 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:48 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:48 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:48 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:48 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:48 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:20:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:20:48 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 17:20:48 --> Final output sent to browser
DEBUG - 2019-04-25 17:20:48 --> Total execution time: 0.0678
DEBUG - 2019-04-25 17:20:52 --> Config Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:20:52 --> URI Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Router Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Output Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Security Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Input Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:20:52 --> Language Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Loader Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Controller Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Session Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:20:52 --> Session routines successfully run
DEBUG - 2019-04-25 17:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:20:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:20:52 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:20:52 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:20:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:20:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:20:52 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:20:52 --> Final output sent to browser
DEBUG - 2019-04-25 17:20:52 --> Total execution time: 0.0538
DEBUG - 2019-04-25 17:24:24 --> Config Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:24:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:24:24 --> URI Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Router Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Output Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Security Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Input Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:24:24 --> Language Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Loader Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Controller Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Session Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:24:24 --> Session routines successfully run
DEBUG - 2019-04-25 17:24:24 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:24 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:24:24 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:24:24 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:24:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:24:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:24:24 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:24:24 --> Final output sent to browser
DEBUG - 2019-04-25 17:24:24 --> Total execution time: 0.0605
DEBUG - 2019-04-25 17:24:26 --> Config Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:24:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:24:26 --> URI Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Router Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Output Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Security Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Input Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:24:26 --> Language Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Loader Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Controller Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Session Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:24:26 --> Session routines successfully run
DEBUG - 2019-04-25 17:24:26 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:26 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:24:26 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:24:26 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:24:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:24:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:24:26 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:24:26 --> Final output sent to browser
DEBUG - 2019-04-25 17:24:26 --> Total execution time: 0.0559
DEBUG - 2019-04-25 17:24:28 --> Config Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:24:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:24:28 --> URI Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Router Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Output Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Security Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Input Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:24:28 --> Language Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Loader Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Controller Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Session Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:24:28 --> Session routines successfully run
DEBUG - 2019-04-25 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:24:28 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:24:28 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:24:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:24:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:24:28 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:24:28 --> Final output sent to browser
DEBUG - 2019-04-25 17:24:28 --> Total execution time: 0.0608
DEBUG - 2019-04-25 17:24:35 --> Config Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:24:35 --> URI Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Router Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Output Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Security Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Input Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:24:35 --> Language Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Loader Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Controller Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Session Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:24:35 --> Session routines successfully run
DEBUG - 2019-04-25 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:24:35 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:24:35 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:24:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:24:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:24:35 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:24:35 --> Final output sent to browser
DEBUG - 2019-04-25 17:24:35 --> Total execution time: 0.0609
DEBUG - 2019-04-25 17:24:36 --> Config Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:24:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:24:36 --> URI Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Router Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Output Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Security Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Input Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:24:36 --> Language Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Loader Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Controller Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Session Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:24:36 --> Session garbage collection performed.
DEBUG - 2019-04-25 17:24:36 --> Session routines successfully run
DEBUG - 2019-04-25 17:24:36 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Model Class Initialized
DEBUG - 2019-04-25 17:24:36 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:24:36 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:24:36 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:24:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:24:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:24:36 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-25 17:24:36 --> Final output sent to browser
DEBUG - 2019-04-25 17:24:36 --> Total execution time: 0.0559
DEBUG - 2019-04-25 17:33:45 --> Config Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:33:45 --> URI Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Router Class Initialized
DEBUG - 2019-04-25 17:33:45 --> No URI present. Default controller set.
DEBUG - 2019-04-25 17:33:45 --> Output Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Security Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Input Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:33:45 --> Language Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Loader Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Controller Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Session Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:33:45 --> Session routines successfully run
DEBUG - 2019-04-25 17:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:33:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:33:45 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:33:45 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:33:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:33:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:33:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:33:45 --> Final output sent to browser
DEBUG - 2019-04-25 17:33:45 --> Total execution time: 0.1475
DEBUG - 2019-04-25 17:37:10 --> Config Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:37:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:37:10 --> URI Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Router Class Initialized
DEBUG - 2019-04-25 17:37:10 --> No URI present. Default controller set.
DEBUG - 2019-04-25 17:37:10 --> Output Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Security Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Input Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:37:10 --> Language Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Loader Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Controller Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Session Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:37:10 --> Session routines successfully run
DEBUG - 2019-04-25 17:37:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:10 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:37:10 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:37:10 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:37:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:37:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:37:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:37:10 --> Final output sent to browser
DEBUG - 2019-04-25 17:37:10 --> Total execution time: 0.1291
DEBUG - 2019-04-25 17:37:46 --> Config Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:37:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:37:46 --> URI Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Router Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Output Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Security Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Input Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:37:46 --> Language Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Loader Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Controller Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Session Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:37:46 --> Session routines successfully run
DEBUG - 2019-04-25 17:37:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:37:46 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:37:46 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:37:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:37:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:37:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:37:46 --> Final output sent to browser
DEBUG - 2019-04-25 17:37:46 --> Total execution time: 0.0580
DEBUG - 2019-04-25 17:37:52 --> Config Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:37:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:37:52 --> URI Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Router Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Output Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Security Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Input Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:37:52 --> Language Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Loader Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Controller Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Session Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:37:52 --> Session routines successfully run
DEBUG - 2019-04-25 17:37:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:37:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:37:52 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:37:52 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:37:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:37:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:37:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:37:52 --> Final output sent to browser
DEBUG - 2019-04-25 17:37:52 --> Total execution time: 0.0623
DEBUG - 2019-04-25 17:38:22 --> Config Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:38:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:38:22 --> URI Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Router Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Output Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Security Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Input Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:38:22 --> Language Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Loader Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Controller Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Model Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Model Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Session Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:38:22 --> Session routines successfully run
DEBUG - 2019-04-25 17:38:22 --> Model Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Model Class Initialized
DEBUG - 2019-04-25 17:38:22 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:38:22 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:38:22 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Config Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:39:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:39:47 --> URI Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Router Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Output Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Security Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Input Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:39:47 --> Language Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Loader Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Controller Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Model Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Model Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Session Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:39:47 --> Session routines successfully run
DEBUG - 2019-04-25 17:39:47 --> Model Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Model Class Initialized
DEBUG - 2019-04-25 17:39:47 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:39:47 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:39:47 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:39:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:39:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:39:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:39:47 --> Final output sent to browser
DEBUG - 2019-04-25 17:39:47 --> Total execution time: 0.1094
DEBUG - 2019-04-25 17:43:59 --> Config Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:43:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:43:59 --> URI Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Router Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Output Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Security Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Input Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:43:59 --> Language Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Loader Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Controller Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Model Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Model Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Session Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:43:59 --> Session routines successfully run
DEBUG - 2019-04-25 17:43:59 --> Model Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Model Class Initialized
DEBUG - 2019-04-25 17:43:59 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:43:59 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:43:59 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:43:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:43:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:43:59 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:43:59 --> Final output sent to browser
DEBUG - 2019-04-25 17:43:59 --> Total execution time: 0.0493
DEBUG - 2019-04-25 17:44:01 --> Config Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:44:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:44:01 --> URI Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Router Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Output Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Security Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Input Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:44:01 --> Language Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Loader Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Controller Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Session Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:44:01 --> Session routines successfully run
DEBUG - 2019-04-25 17:44:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:44:01 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:44:01 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:44:01 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:01 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:01 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:01 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:01 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:01 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:01 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:01 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:01 --> Total execution time: 0.1238
DEBUG - 2019-04-25 17:45:02 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:02 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:02 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:02 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:02 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:02 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:02 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:02 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:02 --> Total execution time: 0.0623
DEBUG - 2019-04-25 17:45:33 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:33 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:33 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:33 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:33 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:33 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:33 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:33 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:33 --> Total execution time: 0.0545
DEBUG - 2019-04-25 17:45:34 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:34 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:34 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:34 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:34 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:34 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:34 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:34 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:34 --> Total execution time: 0.0502
DEBUG - 2019-04-25 17:45:35 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:35 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:35 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:35 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:35 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:35 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:35 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:35 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:35 --> Total execution time: 0.0473
DEBUG - 2019-04-25 17:45:37 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:37 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:37 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:37 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:37 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:37 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:37 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:45:37 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:37 --> Total execution time: 0.0806
DEBUG - 2019-04-25 17:45:38 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:38 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:38 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:38 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:38 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:38 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:38 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:38 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:38 --> Total execution time: 0.0531
DEBUG - 2019-04-25 17:45:50 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:50 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:50 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:50 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:50 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:50 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:50 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:50 --> Total execution time: 0.0580
DEBUG - 2019-04-25 17:45:50 --> Config Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:45:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:45:50 --> URI Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Router Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Output Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Security Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Input Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:45:50 --> Language Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Loader Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Controller Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Session Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:45:50 --> Session routines successfully run
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:45:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:45:51 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:45:51 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:45:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:45:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:45:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:45:51 --> Final output sent to browser
DEBUG - 2019-04-25 17:45:51 --> Total execution time: 0.0545
DEBUG - 2019-04-25 17:47:14 --> Config Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:47:14 --> URI Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Router Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Output Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Security Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Input Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:47:14 --> Language Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Loader Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Controller Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Session Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:47:14 --> Session routines successfully run
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:47:14 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:47:14 --> Final output sent to browser
DEBUG - 2019-04-25 17:47:14 --> Total execution time: 0.0714
DEBUG - 2019-04-25 17:47:14 --> Config Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:47:14 --> URI Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Router Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Output Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Security Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Input Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:47:14 --> Language Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Loader Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Controller Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Session Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:47:14 --> Session routines successfully run
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:47:14 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:47:14 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:47:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:47:14 --> Final output sent to browser
DEBUG - 2019-04-25 17:47:14 --> Total execution time: 0.0659
DEBUG - 2019-04-25 17:47:16 --> Config Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:47:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:47:16 --> URI Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Router Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Output Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Security Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Input Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:47:16 --> Language Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Loader Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Controller Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Session Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:47:16 --> Session routines successfully run
DEBUG - 2019-04-25 17:47:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:16 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:47:16 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:47:16 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:47:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:47:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:47:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:47:16 --> Final output sent to browser
DEBUG - 2019-04-25 17:47:16 --> Total execution time: 0.0666
DEBUG - 2019-04-25 17:47:52 --> Config Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:47:52 --> URI Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Router Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Output Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Security Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Input Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:47:52 --> Language Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Loader Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Controller Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Session Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:47:52 --> Session routines successfully run
DEBUG - 2019-04-25 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-25 17:47:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:47:52 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:47:52 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:47:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:47:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:47:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:47:52 --> Final output sent to browser
DEBUG - 2019-04-25 17:47:52 --> Total execution time: 0.0702
DEBUG - 2019-04-25 17:48:02 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:02 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:02 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:02 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:02 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:02 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:02 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:02 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:02 --> Total execution time: 0.0681
DEBUG - 2019-04-25 17:48:03 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:03 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:03 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:03 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:03 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:48:03 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:03 --> Total execution time: 0.0841
DEBUG - 2019-04-25 17:48:03 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:03 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:03 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:03 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:03 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:03 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:03 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:03 --> Total execution time: 0.0608
DEBUG - 2019-04-25 17:48:12 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:12 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:12 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:12 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:12 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:12 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:12 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:12 --> Total execution time: 0.0688
DEBUG - 2019-04-25 17:48:14 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:14 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:14 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:14 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:14 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:14 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:14 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:14 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:14 --> Total execution time: 0.0589
DEBUG - 2019-04-25 17:48:32 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:32 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:32 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:32 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:32 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:32 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:32 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:32 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:32 --> Total execution time: 0.0631
DEBUG - 2019-04-25 17:48:33 --> Config Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:48:33 --> URI Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Router Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Output Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Security Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Input Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:48:33 --> Language Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Loader Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Controller Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Session Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:48:33 --> Session routines successfully run
DEBUG - 2019-04-25 17:48:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Model Class Initialized
DEBUG - 2019-04-25 17:48:33 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:48:33 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:48:33 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:48:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:48:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:48:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:48:33 --> Final output sent to browser
DEBUG - 2019-04-25 17:48:33 --> Total execution time: 0.0589
DEBUG - 2019-04-25 17:50:48 --> Config Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:50:48 --> URI Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Router Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Output Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Security Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Input Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:50:48 --> Language Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Loader Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Controller Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Session Class Initialized
DEBUG - 2019-04-25 17:50:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:50:49 --> Session routines successfully run
DEBUG - 2019-04-25 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:50:49 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:50:49 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:50:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:50:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:50:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:50:49 --> Final output sent to browser
DEBUG - 2019-04-25 17:50:49 --> Total execution time: 0.1170
DEBUG - 2019-04-25 17:50:50 --> Config Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:50:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:50:50 --> URI Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Router Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Output Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Security Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Input Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:50:50 --> Language Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Loader Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Controller Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Session Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:50:50 --> Session routines successfully run
DEBUG - 2019-04-25 17:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:50 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:50:50 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:50:50 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:50:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:50:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:50:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:50:50 --> Final output sent to browser
DEBUG - 2019-04-25 17:50:50 --> Total execution time: 0.0790
DEBUG - 2019-04-25 17:50:51 --> Config Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:50:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:50:51 --> URI Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Router Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Output Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Security Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Input Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:50:51 --> Language Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Loader Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Controller Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Session Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:50:51 --> Session routines successfully run
DEBUG - 2019-04-25 17:50:51 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Model Class Initialized
DEBUG - 2019-04-25 17:50:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:50:51 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:50:51 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:50:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:50:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:50:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:50:51 --> Final output sent to browser
DEBUG - 2019-04-25 17:50:51 --> Total execution time: 0.0598
DEBUG - 2019-04-25 17:51:48 --> Config Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:51:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:51:48 --> URI Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Router Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Output Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Security Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Input Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:51:48 --> Language Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Loader Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Controller Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Session Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:51:48 --> Session routines successfully run
DEBUG - 2019-04-25 17:51:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:51:48 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:51:48 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:51:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:51:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:51:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:51:48 --> Final output sent to browser
DEBUG - 2019-04-25 17:51:48 --> Total execution time: 0.0590
DEBUG - 2019-04-25 17:51:49 --> Config Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:51:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:51:49 --> URI Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Router Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Output Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Security Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Input Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:51:49 --> Language Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Loader Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Controller Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Session Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:51:49 --> Session routines successfully run
DEBUG - 2019-04-25 17:51:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Model Class Initialized
DEBUG - 2019-04-25 17:51:49 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:51:49 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:51:49 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:51:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:51:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:51:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:51:49 --> Final output sent to browser
DEBUG - 2019-04-25 17:51:49 --> Total execution time: 0.0580
DEBUG - 2019-04-25 17:52:06 --> Config Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:52:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:52:06 --> URI Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Router Class Initialized
DEBUG - 2019-04-25 17:52:06 --> No URI present. Default controller set.
DEBUG - 2019-04-25 17:52:06 --> Output Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Security Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Input Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:52:06 --> Language Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Loader Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Controller Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Session Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:52:06 --> Session routines successfully run
DEBUG - 2019-04-25 17:52:06 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:06 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:52:06 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:52:06 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:52:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:52:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:52:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:52:06 --> Final output sent to browser
DEBUG - 2019-04-25 17:52:06 --> Total execution time: 0.1017
DEBUG - 2019-04-25 17:52:08 --> Config Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:52:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:52:08 --> URI Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Router Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Output Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Security Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Input Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:52:08 --> Language Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Loader Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Controller Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Session Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:52:08 --> Session routines successfully run
DEBUG - 2019-04-25 17:52:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:52:08 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:52:08 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:52:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:52:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:52:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:52:08 --> Final output sent to browser
DEBUG - 2019-04-25 17:52:08 --> Total execution time: 0.0666
DEBUG - 2019-04-25 17:52:37 --> Config Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:52:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:52:37 --> URI Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Router Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Output Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Security Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Input Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:52:37 --> Language Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Loader Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Controller Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Session Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:52:37 --> Session routines successfully run
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:52:37 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:52:37 --> Final output sent to browser
DEBUG - 2019-04-25 17:52:37 --> Total execution time: 0.0576
DEBUG - 2019-04-25 17:52:37 --> Config Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:52:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:52:37 --> URI Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Router Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Output Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Security Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Input Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:52:37 --> Language Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Loader Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Controller Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Session Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:52:37 --> Session routines successfully run
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Model Class Initialized
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:52:37 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:52:37 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:52:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:52:37 --> Final output sent to browser
DEBUG - 2019-04-25 17:52:37 --> Total execution time: 0.0513
DEBUG - 2019-04-25 17:53:10 --> Config Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:53:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:53:10 --> URI Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Router Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Output Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Security Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Input Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:53:10 --> Language Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Loader Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Controller Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Session Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:53:10 --> Session routines successfully run
DEBUG - 2019-04-25 17:53:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:10 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:53:10 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:53:10 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:53:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:53:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:53:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:53:10 --> Final output sent to browser
DEBUG - 2019-04-25 17:53:10 --> Total execution time: 0.0675
DEBUG - 2019-04-25 17:53:58 --> Config Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:53:58 --> URI Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Router Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Output Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Security Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Input Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:53:58 --> Language Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Loader Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Controller Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Session Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:53:58 --> Session routines successfully run
DEBUG - 2019-04-25 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-25 17:53:58 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:53:58 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:53:58 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:53:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:53:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:53:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:53:58 --> Final output sent to browser
DEBUG - 2019-04-25 17:53:58 --> Total execution time: 0.0758
DEBUG - 2019-04-25 17:54:43 --> Config Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:54:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:54:43 --> URI Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Router Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Output Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Security Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Input Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:54:43 --> Language Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Loader Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Controller Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Session Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:54:43 --> Session routines successfully run
DEBUG - 2019-04-25 17:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:43 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:54:43 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:54:43 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:54:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:54:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:54:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:54:43 --> Final output sent to browser
DEBUG - 2019-04-25 17:54:43 --> Total execution time: 0.0494
DEBUG - 2019-04-25 17:54:56 --> Config Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:54:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:54:56 --> URI Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Router Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Output Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Security Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Input Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:54:56 --> Language Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Loader Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Controller Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Session Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:54:56 --> Session routines successfully run
DEBUG - 2019-04-25 17:54:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:54:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:54:56 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:54:56 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:08 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:08 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:08 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:08 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:08 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:08 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:55:08 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:08 --> Total execution time: 0.0883
DEBUG - 2019-04-25 17:55:23 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:23 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:23 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:23 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:23 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:23 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:23 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:23 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:55:23 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:23 --> Total execution time: 0.0541
DEBUG - 2019-04-25 17:55:40 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:40 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:40 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:40 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:40 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:40 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:40 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:40 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:55:40 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:40 --> Total execution time: 0.0565
DEBUG - 2019-04-25 17:55:43 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:43 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:43 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:43 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:43 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:43 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:43 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:55:43 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:43 --> Total execution time: 0.0682
DEBUG - 2019-04-25 17:55:45 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:45 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:45 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:45 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:45 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:45 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:45 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 17:55:46 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:46 --> Total execution time: 0.1097
DEBUG - 2019-04-25 17:55:46 --> Config Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:55:46 --> URI Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Router Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Output Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Security Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Input Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:55:46 --> Language Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Loader Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Controller Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Session Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:55:46 --> Session routines successfully run
DEBUG - 2019-04-25 17:55:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Model Class Initialized
DEBUG - 2019-04-25 17:55:46 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:55:46 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:55:46 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:55:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:55:46 --> Final output sent to browser
DEBUG - 2019-04-25 17:55:46 --> Total execution time: 0.0631
DEBUG - 2019-04-25 17:56:28 --> Config Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:56:28 --> URI Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Router Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Output Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Security Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Input Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:56:28 --> Language Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Loader Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Controller Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Session Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:56:28 --> Session routines successfully run
DEBUG - 2019-04-25 17:56:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:56:28 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:56:28 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:56:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 17:56:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 17:56:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 17:56:28 --> Final output sent to browser
DEBUG - 2019-04-25 17:56:28 --> Total execution time: 0.1135
DEBUG - 2019-04-25 17:56:56 --> Config Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:56:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:56:56 --> URI Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Router Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Output Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Security Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Input Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:56:56 --> Language Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Loader Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Controller Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Model Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Session Class Initialized
DEBUG - 2019-04-25 17:56:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:56:56 --> Session garbage collection performed.
DEBUG - 2019-04-25 17:56:56 --> Session routines successfully run
DEBUG - 2019-04-25 17:56:56 --> Helper loaded: url_helper
ERROR - 2019-04-25 17:56:56 --> 404 Page Not Found --> Order/saveOrderDetails3
DEBUG - 2019-04-25 17:57:42 --> Config Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:57:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:57:42 --> URI Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Router Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Output Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Security Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Input Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:57:42 --> Language Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Loader Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Controller Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Session Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:57:42 --> Session routines successfully run
DEBUG - 2019-04-25 17:57:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Model Class Initialized
DEBUG - 2019-04-25 17:57:42 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:57:42 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:57:42 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Config Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:58:48 --> URI Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Router Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Output Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Security Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Input Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:58:48 --> Language Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Loader Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Controller Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Session Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:58:48 --> Session routines successfully run
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:58:48 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Config Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:58:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:58:48 --> URI Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Router Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Output Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Security Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Input Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:58:48 --> Language Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Loader Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Controller Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Session Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:58:48 --> Session routines successfully run
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Model Class Initialized
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:58:48 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:58:48 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Config Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:59:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:59:15 --> URI Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Router Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Output Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Security Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Input Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:59:15 --> Language Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Loader Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Controller Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Session Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:59:15 --> Session routines successfully run
DEBUG - 2019-04-25 17:59:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:15 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:59:15 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:59:15 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Config Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:59:21 --> URI Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Router Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Output Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Security Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Input Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:59:21 --> Language Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Loader Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Controller Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Session Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:59:21 --> Session routines successfully run
DEBUG - 2019-04-25 17:59:21 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:21 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:59:21 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:59:21 --> Form Validation Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Config Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Hooks Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Utf8 Class Initialized
DEBUG - 2019-04-25 17:59:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 17:59:54 --> URI Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Router Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Output Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Security Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Input Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 17:59:54 --> Language Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Loader Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Controller Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Database Driver Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Session Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Helper loaded: string_helper
DEBUG - 2019-04-25 17:59:54 --> Session routines successfully run
DEBUG - 2019-04-25 17:59:54 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Model Class Initialized
DEBUG - 2019-04-25 17:59:54 --> Helper loaded: url_helper
DEBUG - 2019-04-25 17:59:54 --> Helper loaded: form_helper
DEBUG - 2019-04-25 17:59:54 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Config Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:00:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:00:19 --> URI Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Router Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Output Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Security Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Input Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:00:19 --> Language Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Loader Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Controller Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Session Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:00:19 --> Session routines successfully run
DEBUG - 2019-04-25 18:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:00:19 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:00:19 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:00:19 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:00:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 18:00:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 18:00:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 18:00:19 --> Final output sent to browser
DEBUG - 2019-04-25 18:00:19 --> Total execution time: 0.0646
DEBUG - 2019-04-25 18:04:19 --> Config Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:04:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:04:19 --> URI Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Router Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Output Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Security Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Input Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:04:19 --> Language Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Loader Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Controller Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Model Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Session Class Initialized
DEBUG - 2019-04-25 18:04:19 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:04:20 --> Session routines successfully run
DEBUG - 2019-04-25 18:04:20 --> Model Class Initialized
DEBUG - 2019-04-25 18:04:20 --> Model Class Initialized
DEBUG - 2019-04-25 18:04:20 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:04:20 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:04:20 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Config Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:19:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:19:55 --> URI Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Router Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Output Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Security Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Input Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:19:55 --> Language Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Loader Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Controller Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Model Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Model Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Session Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:19:55 --> Session routines successfully run
DEBUG - 2019-04-25 18:19:55 --> Model Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Model Class Initialized
DEBUG - 2019-04-25 18:19:55 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:19:55 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:19:55 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Config Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:20:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:20:52 --> URI Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Router Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Output Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Security Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Input Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:20:52 --> Language Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Loader Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Controller Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Session Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:20:52 --> Session routines successfully run
DEBUG - 2019-04-25 18:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:52 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:20:52 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:20:52 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:20:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 18:20:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 18:20:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-25 18:20:52 --> Final output sent to browser
DEBUG - 2019-04-25 18:20:52 --> Total execution time: 0.1161
DEBUG - 2019-04-25 18:20:53 --> Config Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:20:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:20:53 --> URI Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Router Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Output Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Security Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Input Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:20:53 --> Language Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Loader Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Controller Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Session Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:20:53 --> Session routines successfully run
DEBUG - 2019-04-25 18:20:53 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Model Class Initialized
DEBUG - 2019-04-25 18:20:53 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:20:53 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:20:53 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Config Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:21:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:21:51 --> URI Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Router Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Output Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Security Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Input Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:21:51 --> Language Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Loader Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Controller Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Session Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:21:51 --> Session routines successfully run
DEBUG - 2019-04-25 18:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Model Class Initialized
DEBUG - 2019-04-25 18:21:51 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:21:51 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:21:51 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Config Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:38:41 --> URI Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Router Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Output Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Security Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Input Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:38:41 --> Language Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Loader Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Controller Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Model Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Model Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Session Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:38:41 --> Session routines successfully run
DEBUG - 2019-04-25 18:38:41 --> Model Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Model Class Initialized
DEBUG - 2019-04-25 18:38:41 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:38:41 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:38:41 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:38:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 18:38:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 18:38:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 18:38:41 --> Final output sent to browser
DEBUG - 2019-04-25 18:38:41 --> Total execution time: 0.1720
DEBUG - 2019-04-25 18:42:28 --> Config Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Hooks Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Utf8 Class Initialized
DEBUG - 2019-04-25 18:42:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 18:42:28 --> URI Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Router Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Output Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Security Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Input Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 18:42:28 --> Language Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Loader Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Controller Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Model Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Model Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Database Driver Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Session Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Helper loaded: string_helper
DEBUG - 2019-04-25 18:42:28 --> Session routines successfully run
DEBUG - 2019-04-25 18:42:28 --> Model Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Model Class Initialized
DEBUG - 2019-04-25 18:42:28 --> Helper loaded: url_helper
DEBUG - 2019-04-25 18:42:28 --> Helper loaded: form_helper
DEBUG - 2019-04-25 18:42:28 --> Form Validation Class Initialized
DEBUG - 2019-04-25 18:42:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 18:42:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 18:42:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 18:42:28 --> Final output sent to browser
DEBUG - 2019-04-25 18:42:28 --> Total execution time: 0.0695
DEBUG - 2019-04-25 19:01:12 --> Config Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:01:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:01:12 --> URI Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Router Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Output Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Security Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Input Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:01:12 --> Language Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Loader Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Controller Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Session Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:01:12 --> Session routines successfully run
DEBUG - 2019-04-25 19:01:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:01:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:01:12 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:01:12 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:01:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:01:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:01:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 19:01:12 --> Final output sent to browser
DEBUG - 2019-04-25 19:01:12 --> Total execution time: 0.1216
DEBUG - 2019-04-25 19:02:09 --> Config Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:02:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:02:09 --> URI Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Router Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Output Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Security Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Input Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:02:09 --> Language Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Loader Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Controller Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Session Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:02:09 --> Session routines successfully run
DEBUG - 2019-04-25 19:02:09 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:09 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:02:09 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:02:09 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:02:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:02:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:02:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 19:02:09 --> Final output sent to browser
DEBUG - 2019-04-25 19:02:09 --> Total execution time: 0.0606
DEBUG - 2019-04-25 19:02:11 --> Config Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:02:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:02:11 --> URI Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Router Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Output Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Security Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Input Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:02:11 --> Language Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Loader Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Controller Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Session Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:02:11 --> Session routines successfully run
DEBUG - 2019-04-25 19:02:11 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Model Class Initialized
DEBUG - 2019-04-25 19:02:11 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:02:11 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:02:11 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:02:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:02:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:02:11 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-25 19:02:11 --> Final output sent to browser
DEBUG - 2019-04-25 19:02:11 --> Total execution time: 0.0607
DEBUG - 2019-04-25 19:24:56 --> Config Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:24:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:24:56 --> URI Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Router Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Output Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Security Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Input Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:24:56 --> Language Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Loader Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Controller Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Model Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Model Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Session Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:24:56 --> Session routines successfully run
DEBUG - 2019-04-25 19:24:56 --> Model Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Model Class Initialized
DEBUG - 2019-04-25 19:24:56 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:24:57 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:24:57 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:24:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:24:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:24:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 19:24:57 --> Final output sent to browser
DEBUG - 2019-04-25 19:24:57 --> Total execution time: 0.1365
DEBUG - 2019-04-25 19:25:10 --> Config Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:25:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:25:10 --> URI Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Router Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Output Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Security Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Input Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:25:10 --> Language Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Loader Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Controller Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Session Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:25:10 --> Session routines successfully run
DEBUG - 2019-04-25 19:25:10 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:10 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:25:10 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:25:10 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:25:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:25:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:25:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 19:25:10 --> Final output sent to browser
DEBUG - 2019-04-25 19:25:10 --> Total execution time: 0.0608
DEBUG - 2019-04-25 19:25:12 --> Config Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Hooks Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Utf8 Class Initialized
DEBUG - 2019-04-25 19:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-25 19:25:12 --> URI Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Router Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Output Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Security Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Input Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-25 19:25:12 --> Language Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Loader Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Controller Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Database Driver Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Session Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Helper loaded: string_helper
DEBUG - 2019-04-25 19:25:12 --> Session routines successfully run
DEBUG - 2019-04-25 19:25:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Model Class Initialized
DEBUG - 2019-04-25 19:25:12 --> Helper loaded: url_helper
DEBUG - 2019-04-25 19:25:12 --> Helper loaded: form_helper
DEBUG - 2019-04-25 19:25:12 --> Form Validation Class Initialized
DEBUG - 2019-04-25 19:25:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-25 19:25:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-25 19:25:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-25 19:25:12 --> Final output sent to browser
DEBUG - 2019-04-25 19:25:12 --> Total execution time: 0.0689
