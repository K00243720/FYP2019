<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-16 12:37:40 --> Config Class Initialized
DEBUG - 2019-04-16 12:37:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Utf8 Class Initialized
DEBUG - 2019-04-16 12:37:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 12:37:41 --> URI Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Router Class Initialized
DEBUG - 2019-04-16 12:37:41 --> No URI present. Default controller set.
DEBUG - 2019-04-16 12:37:41 --> Output Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Security Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Input Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 12:37:41 --> Language Class Initialized
DEBUG - 2019-04-16 12:37:41 --> Loader Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Controller Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Model Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Model Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Session Class Initialized
DEBUG - 2019-04-16 12:37:42 --> Helper loaded: string_helper
DEBUG - 2019-04-16 12:37:42 --> A session cookie was not found.
DEBUG - 2019-04-16 12:37:43 --> Session routines successfully run
DEBUG - 2019-04-16 12:37:43 --> Model Class Initialized
DEBUG - 2019-04-16 12:37:43 --> Helper loaded: url_helper
ERROR - 2019-04-16 12:37:53 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 12:37:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 12:37:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 12:37:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 12:37:53 --> Final output sent to browser
DEBUG - 2019-04-16 12:37:53 --> Total execution time: 12.8455
DEBUG - 2019-04-16 13:02:04 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:04 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Output Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Security Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Input Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:02:04 --> Language Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Loader Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Controller Class Initialized
DEBUG - 2019-04-16 13:02:04 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Session Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:02:05 --> Session routines successfully run
DEBUG - 2019-04-16 13:02:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:02:05 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:02:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:02:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:02:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:02:05 --> Final output sent to browser
DEBUG - 2019-04-16 13:02:05 --> Total execution time: 0.4332
DEBUG - 2019-04-16 13:02:05 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:05 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:05 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:16 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Output Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Security Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Input Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:02:16 --> Language Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Loader Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Controller Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Session Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:02:16 --> Session routines successfully run
DEBUG - 2019-04-16 13:02:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:02:16 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:02:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:02:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:02:16 --> File loaded: application/views/producers.php
DEBUG - 2019-04-16 13:02:16 --> Final output sent to browser
DEBUG - 2019-04-16 13:02:16 --> Total execution time: 0.0849
DEBUG - 2019-04-16 13:02:16 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:16 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:16 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:23 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Output Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Security Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Input Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:02:23 --> Language Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Loader Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Controller Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Session Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:02:23 --> Session routines successfully run
DEBUG - 2019-04-16 13:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:02:23 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:02:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:02:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:02:23 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 13:02:23 --> Final output sent to browser
DEBUG - 2019-04-16 13:02:23 --> Total execution time: 0.1179
DEBUG - 2019-04-16 13:02:23 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:23 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:23 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:26 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Output Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Security Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Input Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:02:26 --> Language Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Loader Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Controller Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Session Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:02:26 --> Session routines successfully run
DEBUG - 2019-04-16 13:02:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:02:26 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:02:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:02:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:02:26 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 13:02:26 --> Final output sent to browser
DEBUG - 2019-04-16 13:02:26 --> Total execution time: 0.1127
DEBUG - 2019-04-16 13:02:26 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:26 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:26 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:29 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Router Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Output Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Security Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Input Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:02:29 --> Language Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Loader Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Controller Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Session Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:02:29 --> Session routines successfully run
DEBUG - 2019-04-16 13:02:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:02:29 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:02:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:02:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:02:29 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:02:29 --> Final output sent to browser
DEBUG - 2019-04-16 13:02:29 --> Total execution time: 0.0576
DEBUG - 2019-04-16 13:02:29 --> Config Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:02:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:02:29 --> URI Class Initialized
DEBUG - 2019-04-16 13:02:29 --> Router Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Config Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:03:05 --> URI Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Router Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Output Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Security Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Input Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:03:05 --> Language Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Loader Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Controller Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Session Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:03:05 --> Session routines successfully run
DEBUG - 2019-04-16 13:03:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:03:05 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-16 13:03:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:03:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:03:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:03:05 --> Final output sent to browser
DEBUG - 2019-04-16 13:03:05 --> Total execution time: 0.2650
DEBUG - 2019-04-16 13:03:05 --> Config Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:03:05 --> URI Class Initialized
DEBUG - 2019-04-16 13:03:05 --> Router Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Config Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:03:26 --> URI Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Router Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Output Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Security Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Input Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:03:26 --> Language Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Loader Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Controller Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Session Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:03:26 --> Session routines successfully run
DEBUG - 2019-04-16 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:03:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:03:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:03:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:03:27 --> Final output sent to browser
DEBUG - 2019-04-16 13:03:27 --> Total execution time: 0.3561
DEBUG - 2019-04-16 13:03:46 --> Config Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:03:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:03:46 --> URI Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Router Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Output Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Security Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Input Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:03:46 --> Language Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Loader Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Controller Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Session Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:03:46 --> Session routines successfully run
DEBUG - 2019-04-16 13:03:46 --> Model Class Initialized
DEBUG - 2019-04-16 13:03:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:03:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:03:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:03:47 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:03:47 --> Final output sent to browser
DEBUG - 2019-04-16 13:03:47 --> Total execution time: 0.3366
DEBUG - 2019-04-16 13:05:18 --> Config Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:05:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:05:18 --> URI Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Router Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Output Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Security Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Input Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:05:18 --> Language Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Loader Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Controller Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Session Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:05:18 --> Session routines successfully run
DEBUG - 2019-04-16 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:18 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:05:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:05:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:05:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:05:18 --> Final output sent to browser
DEBUG - 2019-04-16 13:05:18 --> Total execution time: 0.2359
DEBUG - 2019-04-16 13:05:19 --> Config Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:05:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:05:19 --> URI Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Router Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Output Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Security Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Input Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:05:19 --> Language Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Loader Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Controller Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:05:19 --> Session Class Initialized
DEBUG - 2019-04-16 13:05:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:05:20 --> Session routines successfully run
DEBUG - 2019-04-16 13:05:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:20 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:05:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:05:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:05:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:05:20 --> Final output sent to browser
DEBUG - 2019-04-16 13:05:20 --> Total execution time: 0.0569
DEBUG - 2019-04-16 13:05:22 --> Config Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:05:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:05:22 --> URI Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Router Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Output Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Security Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Input Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:05:22 --> Language Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Loader Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Controller Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Session Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:05:22 --> Session routines successfully run
DEBUG - 2019-04-16 13:05:22 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:22 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:05:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:05:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:05:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:05:22 --> Final output sent to browser
DEBUG - 2019-04-16 13:05:22 --> Total execution time: 0.0408
DEBUG - 2019-04-16 13:05:30 --> Config Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:05:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:05:30 --> URI Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Router Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Output Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Security Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Input Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:05:30 --> Language Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Loader Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Controller Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Session Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:05:30 --> Session routines successfully run
DEBUG - 2019-04-16 13:05:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:05:30 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:05:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:05:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:05:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:05:30 --> Final output sent to browser
DEBUG - 2019-04-16 13:05:30 --> Total execution time: 0.0570
DEBUG - 2019-04-16 13:16:54 --> Config Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:16:54 --> URI Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Router Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Output Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Security Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Input Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:16:54 --> Language Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Loader Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Controller Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Model Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Model Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Session Class Initialized
DEBUG - 2019-04-16 13:16:54 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:16:55 --> Session routines successfully run
DEBUG - 2019-04-16 13:16:55 --> Model Class Initialized
DEBUG - 2019-04-16 13:16:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:16:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:16:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:16:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:16:55 --> Final output sent to browser
DEBUG - 2019-04-16 13:16:55 --> Total execution time: 0.5114
DEBUG - 2019-04-16 13:17:09 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:09 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:09 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:09 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:09 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:09 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:17:09 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:09 --> Total execution time: 0.0617
DEBUG - 2019-04-16 13:17:11 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:11 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:11 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:11 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:11 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:17:11 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:11 --> Total execution time: 0.0656
DEBUG - 2019-04-16 13:17:25 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:25 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:25 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:25 --> A session cookie was not found.
DEBUG - 2019-04-16 13:17:26 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:26 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:17:26 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:26 --> Total execution time: 0.4219
DEBUG - 2019-04-16 13:17:31 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:31 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:31 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:31 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:31 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:17:31 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:31 --> Total execution time: 0.0649
DEBUG - 2019-04-16 13:17:40 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:40 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:40 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:40 --> Session garbage collection performed.
DEBUG - 2019-04-16 13:17:40 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:17:41 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:41 --> Total execution time: 0.7257
DEBUG - 2019-04-16 13:17:43 --> Config Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:17:43 --> URI Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Router Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Output Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Security Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Input Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:17:43 --> Language Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Loader Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Controller Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Session Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:17:43 --> Session routines successfully run
DEBUG - 2019-04-16 13:17:43 --> Model Class Initialized
DEBUG - 2019-04-16 13:17:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:17:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:17:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:17:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:17:43 --> Final output sent to browser
DEBUG - 2019-04-16 13:17:43 --> Total execution time: 0.0587
DEBUG - 2019-04-16 13:18:27 --> Config Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:18:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:18:27 --> URI Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Router Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Output Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Security Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Input Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:18:27 --> Language Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Loader Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Controller Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Session Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:18:27 --> Session routines successfully run
DEBUG - 2019-04-16 13:18:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:27 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:18:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:18:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:18:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:18:27 --> Final output sent to browser
DEBUG - 2019-04-16 13:18:27 --> Total execution time: 0.0582
DEBUG - 2019-04-16 13:18:29 --> Config Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:18:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:18:29 --> URI Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Router Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Output Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Security Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Input Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:18:29 --> Language Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Loader Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Controller Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Session Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:18:29 --> Session routines successfully run
DEBUG - 2019-04-16 13:18:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:29 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:18:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:18:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:18:29 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 13:18:29 --> Final output sent to browser
DEBUG - 2019-04-16 13:18:29 --> Total execution time: 0.0471
DEBUG - 2019-04-16 13:18:39 --> Config Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:18:39 --> URI Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Router Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Output Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Security Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Input Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:18:39 --> Language Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Loader Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Controller Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Session Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:18:39 --> Session routines successfully run
DEBUG - 2019-04-16 13:18:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:18:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:18:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:18:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:18:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:18:39 --> Final output sent to browser
DEBUG - 2019-04-16 13:18:39 --> Total execution time: 0.3233
DEBUG - 2019-04-16 13:22:16 --> Config Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:22:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:22:16 --> URI Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Router Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Output Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Security Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Input Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:22:16 --> Language Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Loader Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Controller Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Session Class Initialized
DEBUG - 2019-04-16 13:22:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:22:17 --> Session routines successfully run
DEBUG - 2019-04-16 13:22:17 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:22:17 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE1
DEBUG - 2019-04-16 13:24:44 --> Config Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:24:44 --> URI Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Router Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Output Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Security Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Input Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:24:44 --> Language Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Loader Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Controller Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Model Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Model Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Session Class Initialized
DEBUG - 2019-04-16 13:24:44 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:24:45 --> Session routines successfully run
DEBUG - 2019-04-16 13:24:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:24:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:24:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:24:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:24:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:24:45 --> Final output sent to browser
DEBUG - 2019-04-16 13:24:45 --> Total execution time: 0.4992
DEBUG - 2019-04-16 13:25:51 --> Config Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:25:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:25:51 --> URI Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Router Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Output Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Security Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Input Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:25:51 --> Language Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Loader Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Controller Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Session Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:25:51 --> Session routines successfully run
DEBUG - 2019-04-16 13:25:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:25:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:25:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:25:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:25:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:25:51 --> Final output sent to browser
DEBUG - 2019-04-16 13:25:51 --> Total execution time: 0.1783
DEBUG - 2019-04-16 13:26:10 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:10 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:10 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:10 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:10 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:10 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:26:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:26:10 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:10 --> Total execution time: 0.1590
DEBUG - 2019-04-16 13:26:13 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:13 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:13 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:13 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:13 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:26:13 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 48
ERROR - 2019-04-16 13:26:13 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 49
DEBUG - 2019-04-16 13:26:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:13 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-16 13:26:13 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:13 --> Total execution time: 0.0807
DEBUG - 2019-04-16 13:26:24 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:24 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:24 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:24 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:25 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:25 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:25 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:25 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:26:25 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 48
ERROR - 2019-04-16 13:26:25 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 49
DEBUG - 2019-04-16 13:26:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:25 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-16 13:26:25 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:25 --> Total execution time: 0.0469
DEBUG - 2019-04-16 13:26:29 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:29 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:29 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:29 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:29 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:26:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:26:29 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:29 --> Total execution time: 0.1114
DEBUG - 2019-04-16 13:26:48 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:48 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:48 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:48 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:48 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:26:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:48 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:26:48 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:48 --> Total execution time: 0.0877
DEBUG - 2019-04-16 13:26:50 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:50 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:50 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:50 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:50 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:26:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:26:50 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:50 --> Total execution time: 0.0582
DEBUG - 2019-04-16 13:26:51 --> Config Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:26:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:26:51 --> URI Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Router Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Output Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Security Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Input Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:26:51 --> Language Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Loader Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Controller Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Session Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:26:51 --> Session routines successfully run
DEBUG - 2019-04-16 13:26:51 --> Model Class Initialized
DEBUG - 2019-04-16 13:26:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:26:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:26:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:26:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:26:51 --> Final output sent to browser
DEBUG - 2019-04-16 13:26:51 --> Total execution time: 0.1135
DEBUG - 2019-04-16 13:27:31 --> Config Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:27:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:27:31 --> URI Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Router Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Output Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Security Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Input Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:27:31 --> Language Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Loader Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Controller Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Session Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:27:31 --> Session routines successfully run
DEBUG - 2019-04-16 13:27:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:31 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:27:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:27:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:27:31 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:27:31 --> Final output sent to browser
DEBUG - 2019-04-16 13:27:31 --> Total execution time: 0.1140
DEBUG - 2019-04-16 13:27:33 --> Config Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:27:33 --> URI Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Router Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Output Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Security Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Input Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:27:33 --> Language Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Loader Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Controller Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Session Class Initialized
DEBUG - 2019-04-16 13:27:33 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:27:33 --> Session routines successfully run
DEBUG - 2019-04-16 13:27:33 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:27:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:27:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:27:33 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-16 13:27:33 --> Final output sent to browser
DEBUG - 2019-04-16 13:27:33 --> Total execution time: 0.1131
DEBUG - 2019-04-16 13:27:36 --> Config Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:27:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:27:36 --> URI Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Router Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Output Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Security Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Input Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:27:36 --> Language Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Loader Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Controller Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Session Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:27:36 --> Session routines successfully run
DEBUG - 2019-04-16 13:27:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:27:36 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:27:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:27:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:27:36 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:27:36 --> Final output sent to browser
DEBUG - 2019-04-16 13:27:36 --> Total execution time: 0.1349
DEBUG - 2019-04-16 13:28:03 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:03 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:03 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:03 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:03 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-16 13:28:03 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:03 --> Total execution time: 0.1019
DEBUG - 2019-04-16 13:28:07 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:07 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:07 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:07 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:07 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:07 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:08 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:08 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:08 --> Total execution time: 0.1361
DEBUG - 2019-04-16 13:28:19 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:19 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:19 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:19 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:19 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:19 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:19 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-16 13:28:19 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:19 --> Total execution time: 0.0568
DEBUG - 2019-04-16 13:28:39 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:39 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:39 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:39 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:39 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:39 --> Total execution time: 0.1181
DEBUG - 2019-04-16 13:28:40 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:40 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:40 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:40 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:40 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:40 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:40 --> Total execution time: 0.1112
DEBUG - 2019-04-16 13:28:42 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:42 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:42 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:42 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:42 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:42 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:42 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:42 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:42 --> Total execution time: 0.1216
DEBUG - 2019-04-16 13:28:45 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:45 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:45 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:45 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:45 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 13:28:45 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:45 --> Total execution time: 0.0617
DEBUG - 2019-04-16 13:28:48 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:48 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:48 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:48 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:48 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:48 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:48 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:48 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:48 --> Total execution time: 0.1334
DEBUG - 2019-04-16 13:28:56 --> Config Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:28:56 --> URI Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Router Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Output Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Security Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Input Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:28:56 --> Language Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Loader Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Controller Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Session Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:28:56 --> Session routines successfully run
DEBUG - 2019-04-16 13:28:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:28:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:28:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:28:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:28:56 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:28:56 --> Final output sent to browser
DEBUG - 2019-04-16 13:28:56 --> Total execution time: 0.0918
DEBUG - 2019-04-16 13:29:50 --> Config Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:29:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:29:50 --> URI Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Router Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Output Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Security Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Input Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:29:50 --> Language Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Loader Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Controller Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Session Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:29:50 --> Session routines successfully run
DEBUG - 2019-04-16 13:29:50 --> Model Class Initialized
DEBUG - 2019-04-16 13:29:50 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:29:51 --> File loaded: application/views/header.php
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-16 13:29:51 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-16 13:29:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:29:51 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:29:51 --> Final output sent to browser
DEBUG - 2019-04-16 13:29:51 --> Total execution time: 0.1777
DEBUG - 2019-04-16 13:30:52 --> Config Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:30:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:30:52 --> URI Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Router Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Output Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Security Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Input Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:30:52 --> Language Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Loader Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Controller Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Session Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:30:52 --> Session routines successfully run
DEBUG - 2019-04-16 13:30:52 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:52 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:30:52 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-16 13:30:56 --> Config Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:30:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:30:56 --> URI Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Router Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Output Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Security Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Input Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:30:56 --> Language Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Loader Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Controller Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Session Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:30:56 --> Session routines successfully run
DEBUG - 2019-04-16 13:30:56 --> Model Class Initialized
DEBUG - 2019-04-16 13:30:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:30:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:30:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:30:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:30:56 --> Final output sent to browser
DEBUG - 2019-04-16 13:30:56 --> Total execution time: 0.0698
DEBUG - 2019-04-16 13:31:30 --> Config Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:31:30 --> URI Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Router Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Output Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Security Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Input Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:31:30 --> Language Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Loader Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Controller Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Model Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Session Class Initialized
DEBUG - 2019-04-16 13:31:30 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:31:30 --> Session routines successfully run
DEBUG - 2019-04-16 13:31:30 --> Helper loaded: url_helper
ERROR - 2019-04-16 13:31:30 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE2
DEBUG - 2019-04-16 13:34:20 --> Config Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:34:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:34:20 --> URI Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Router Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Output Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Security Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Input Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:34:20 --> Language Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Loader Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Controller Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Session Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:34:20 --> Session routines successfully run
DEBUG - 2019-04-16 13:34:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:20 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:34:44 --> Config Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:34:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:34:44 --> URI Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Router Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Output Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Security Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Input Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:34:44 --> Language Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Loader Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Controller Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Session Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:34:44 --> Session routines successfully run
DEBUG - 2019-04-16 13:34:44 --> Model Class Initialized
DEBUG - 2019-04-16 13:34:44 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:34:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:34:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:34:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:34:44 --> Final output sent to browser
DEBUG - 2019-04-16 13:34:44 --> Total execution time: 0.0498
DEBUG - 2019-04-16 13:35:55 --> Config Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:35:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:35:55 --> URI Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Router Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Output Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Security Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Input Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:35:55 --> Language Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Loader Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Controller Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Model Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Model Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Session Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:35:55 --> Session routines successfully run
DEBUG - 2019-04-16 13:35:55 --> Model Class Initialized
DEBUG - 2019-04-16 13:35:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:35:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:35:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:35:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:35:55 --> Final output sent to browser
DEBUG - 2019-04-16 13:35:55 --> Total execution time: 0.1734
DEBUG - 2019-04-16 13:37:00 --> Config Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:37:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:37:00 --> URI Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Router Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Output Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Security Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Input Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:37:00 --> Language Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Loader Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Controller Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Session Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:37:00 --> Session routines successfully run
DEBUG - 2019-04-16 13:37:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:37:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:37:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:37:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:37:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:37:00 --> Final output sent to browser
DEBUG - 2019-04-16 13:37:00 --> Total execution time: 0.0720
DEBUG - 2019-04-16 13:41:00 --> Config Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:41:00 --> URI Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Router Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Output Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Security Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Input Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:41:00 --> Language Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Loader Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Controller Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Session Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:41:00 --> Session routines successfully run
DEBUG - 2019-04-16 13:41:00 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:41:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:41:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:41:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:41:00 --> Final output sent to browser
DEBUG - 2019-04-16 13:41:00 --> Total execution time: 0.1355
DEBUG - 2019-04-16 13:41:28 --> Config Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:41:28 --> URI Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Router Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Output Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Security Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Input Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:41:28 --> Language Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Loader Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Controller Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Session Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:41:28 --> Session routines successfully run
DEBUG - 2019-04-16 13:41:28 --> Model Class Initialized
DEBUG - 2019-04-16 13:41:28 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:41:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:41:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:41:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:41:28 --> Final output sent to browser
DEBUG - 2019-04-16 13:41:28 --> Total execution time: 0.0540
DEBUG - 2019-04-16 13:44:45 --> Config Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:44:45 --> URI Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Router Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Output Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Security Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Input Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:44:45 --> Language Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Loader Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Controller Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Session Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:44:45 --> Session garbage collection performed.
DEBUG - 2019-04-16 13:44:45 --> Session routines successfully run
DEBUG - 2019-04-16 13:44:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:44:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:44:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:44:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:44:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:44:45 --> Final output sent to browser
DEBUG - 2019-04-16 13:44:45 --> Total execution time: 0.0465
DEBUG - 2019-04-16 13:47:05 --> Config Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:47:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:47:05 --> URI Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Router Class Initialized
DEBUG - 2019-04-16 13:47:05 --> No URI present. Default controller set.
DEBUG - 2019-04-16 13:47:05 --> Output Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Security Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Input Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:47:05 --> Language Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Loader Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Controller Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Session Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:47:05 --> A session cookie was not found.
DEBUG - 2019-04-16 13:47:05 --> Session routines successfully run
DEBUG - 2019-04-16 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:05 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:47:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:47:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:47:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 13:47:05 --> Final output sent to browser
DEBUG - 2019-04-16 13:47:05 --> Total execution time: 0.1668
DEBUG - 2019-04-16 13:47:11 --> Config Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:47:11 --> URI Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Router Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Output Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Security Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Input Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:47:11 --> Language Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Loader Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Controller Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Session Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:47:11 --> Session routines successfully run
DEBUG - 2019-04-16 13:47:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:11 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:47:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:47:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:47:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:47:11 --> Final output sent to browser
DEBUG - 2019-04-16 13:47:11 --> Total execution time: 0.0518
DEBUG - 2019-04-16 13:47:37 --> Config Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:47:37 --> URI Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Router Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Output Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Security Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Input Class Initialized
DEBUG - 2019-04-16 13:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:47:38 --> Language Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Loader Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Controller Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Session Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:47:38 --> Session routines successfully run
DEBUG - 2019-04-16 13:47:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:38 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:47:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:47:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:47:38 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 13:47:38 --> Final output sent to browser
DEBUG - 2019-04-16 13:47:38 --> Total execution time: 0.0546
DEBUG - 2019-04-16 13:47:45 --> Config Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:47:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:47:45 --> URI Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Router Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Output Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Security Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Input Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:47:45 --> Language Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Loader Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Controller Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Session Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:47:45 --> Session routines successfully run
DEBUG - 2019-04-16 13:47:45 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:47:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:47:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:47:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:47:45 --> Final output sent to browser
DEBUG - 2019-04-16 13:47:45 --> Total execution time: 0.1847
DEBUG - 2019-04-16 13:47:53 --> Config Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:47:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:47:53 --> URI Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Router Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Output Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Security Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Input Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:47:53 --> Language Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Loader Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Controller Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Session Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:47:53 --> Session routines successfully run
DEBUG - 2019-04-16 13:47:53 --> Model Class Initialized
DEBUG - 2019-04-16 13:47:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:47:53 --> File loaded: application/views/header.php
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-16 13:47:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-16 13:47:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:47:53 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:47:53 --> Final output sent to browser
DEBUG - 2019-04-16 13:47:53 --> Total execution time: 0.0648
DEBUG - 2019-04-16 13:49:38 --> Config Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:49:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:49:38 --> URI Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Router Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Output Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Security Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Input Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:49:38 --> Language Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Loader Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Controller Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Session Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:49:38 --> Session routines successfully run
DEBUG - 2019-04-16 13:49:38 --> Model Class Initialized
DEBUG - 2019-04-16 13:49:38 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:51:54 --> Config Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:51:54 --> URI Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Router Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Output Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Security Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Input Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:51:54 --> Language Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Loader Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Controller Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Model Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Model Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Session Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:51:54 --> Session routines successfully run
DEBUG - 2019-04-16 13:51:54 --> Model Class Initialized
DEBUG - 2019-04-16 13:51:54 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:52:13 --> Config Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:52:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:52:13 --> URI Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Router Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Output Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Security Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Input Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:52:13 --> Language Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Loader Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Controller Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Session Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:52:13 --> Session routines successfully run
DEBUG - 2019-04-16 13:52:13 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:13 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:52:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:52:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:52:13 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:52:13 --> Final output sent to browser
DEBUG - 2019-04-16 13:52:13 --> Total execution time: 0.3731
DEBUG - 2019-04-16 13:52:32 --> Config Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:52:32 --> URI Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Router Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Output Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Security Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Input Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:52:32 --> Language Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Loader Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Controller Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Session Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:52:32 --> Session routines successfully run
DEBUG - 2019-04-16 13:52:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:32 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:52:32 --> File loaded: application/views/header.php
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-16 13:52:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-16 13:52:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:52:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:52:32 --> Final output sent to browser
DEBUG - 2019-04-16 13:52:32 --> Total execution time: 0.0848
DEBUG - 2019-04-16 13:52:36 --> Config Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:52:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:52:36 --> URI Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Router Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Output Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Security Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Input Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:52:36 --> Language Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Loader Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Controller Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Session Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:52:36 --> Session routines successfully run
DEBUG - 2019-04-16 13:52:36 --> Model Class Initialized
DEBUG - 2019-04-16 13:52:36 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:52:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:52:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:52:36 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-16 13:52:36 --> Final output sent to browser
DEBUG - 2019-04-16 13:52:36 --> Total execution time: 0.1002
DEBUG - 2019-04-16 13:53:11 --> Config Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:53:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:53:11 --> URI Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Router Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Output Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Security Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Input Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:53:11 --> Language Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Loader Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Controller Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Session Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:53:11 --> Session routines successfully run
DEBUG - 2019-04-16 13:53:11 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:11 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:53:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:53:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:53:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:53:11 --> Final output sent to browser
DEBUG - 2019-04-16 13:53:11 --> Total execution time: 0.1145
DEBUG - 2019-04-16 13:53:16 --> Config Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:53:16 --> URI Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Router Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Output Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Security Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Input Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:53:16 --> Language Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Loader Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Controller Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Session Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:53:16 --> Session routines successfully run
DEBUG - 2019-04-16 13:53:16 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:16 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:53:16 --> File loaded: application/views/header.php
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-16 13:53:16 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-16 13:53:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:53:16 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:53:16 --> Final output sent to browser
DEBUG - 2019-04-16 13:53:16 --> Total execution time: 0.0789
DEBUG - 2019-04-16 13:53:29 --> Config Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:53:29 --> URI Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Router Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Output Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Security Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Input Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:53:29 --> Language Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Loader Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Controller Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Session Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:53:29 --> Session routines successfully run
DEBUG - 2019-04-16 13:53:29 --> Model Class Initialized
DEBUG - 2019-04-16 13:53:29 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:53:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:53:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:53:29 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-16 13:53:29 --> Final output sent to browser
DEBUG - 2019-04-16 13:53:29 --> Total execution time: 0.0679
DEBUG - 2019-04-16 13:54:32 --> Config Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:54:32 --> URI Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Router Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Output Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Security Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Input Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:54:32 --> Language Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Loader Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Controller Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Session Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:54:32 --> Session routines successfully run
DEBUG - 2019-04-16 13:54:32 --> Model Class Initialized
DEBUG - 2019-04-16 13:54:32 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:54:32 --> File loaded: application/views/header.php
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-16 13:54:32 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-16 13:54:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:54:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:54:32 --> Final output sent to browser
DEBUG - 2019-04-16 13:54:32 --> Total execution time: 0.0788
DEBUG - 2019-04-16 13:56:20 --> Config Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:56:20 --> URI Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Router Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Output Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Security Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Input Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:56:20 --> Language Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Loader Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Controller Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Session Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:56:20 --> Session routines successfully run
DEBUG - 2019-04-16 13:56:20 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:20 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:56:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:56:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:56:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 13:56:20 --> Final output sent to browser
DEBUG - 2019-04-16 13:56:20 --> Total execution time: 0.1134
DEBUG - 2019-04-16 13:56:21 --> Config Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:56:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:56:21 --> URI Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Router Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Output Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Security Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Input Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:56:21 --> Language Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Loader Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Controller Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Session Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:56:21 --> Session routines successfully run
DEBUG - 2019-04-16 13:56:21 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:21 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:56:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:56:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:56:21 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:56:21 --> Final output sent to browser
DEBUG - 2019-04-16 13:56:21 --> Total execution time: 0.0500
DEBUG - 2019-04-16 13:56:27 --> Config Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:56:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:56:27 --> URI Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Router Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Output Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Security Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Input Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:56:27 --> Language Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Loader Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Controller Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Session Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:56:27 --> Session routines successfully run
DEBUG - 2019-04-16 13:56:27 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:27 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:56:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:56:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:56:27 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-16 13:56:27 --> Final output sent to browser
DEBUG - 2019-04-16 13:56:27 --> Total execution time: 0.0623
DEBUG - 2019-04-16 13:56:31 --> Config Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:56:31 --> URI Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Router Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Output Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Security Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Input Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:56:31 --> Language Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Loader Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Controller Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Session Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:56:31 --> Session routines successfully run
DEBUG - 2019-04-16 13:56:31 --> Model Class Initialized
DEBUG - 2019-04-16 13:56:31 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:56:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:56:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:56:31 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 13:56:31 --> Final output sent to browser
DEBUG - 2019-04-16 13:56:31 --> Total execution time: 0.0552
DEBUG - 2019-04-16 13:57:34 --> Config Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Hooks Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Utf8 Class Initialized
DEBUG - 2019-04-16 13:57:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 13:57:34 --> URI Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Router Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Output Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Security Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Input Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 13:57:34 --> Language Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Loader Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Controller Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Model Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Model Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Database Driver Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Session Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Helper loaded: string_helper
DEBUG - 2019-04-16 13:57:34 --> Session routines successfully run
DEBUG - 2019-04-16 13:57:34 --> Model Class Initialized
DEBUG - 2019-04-16 13:57:34 --> Helper loaded: url_helper
DEBUG - 2019-04-16 13:57:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 13:57:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 13:57:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 13:57:34 --> Final output sent to browser
DEBUG - 2019-04-16 13:57:34 --> Total execution time: 0.1206
DEBUG - 2019-04-16 14:04:27 --> Config Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:04:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:04:27 --> URI Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Router Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Output Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Security Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Input Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:04:27 --> Language Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Loader Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Controller Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Model Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Model Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Session Class Initialized
DEBUG - 2019-04-16 14:04:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:04:28 --> Session routines successfully run
DEBUG - 2019-04-16 14:04:28 --> Model Class Initialized
DEBUG - 2019-04-16 14:04:28 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:04:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:04:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:04:28 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:04:28 --> Final output sent to browser
DEBUG - 2019-04-16 14:04:28 --> Total execution time: 0.1753
DEBUG - 2019-04-16 14:08:29 --> Config Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:08:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:08:29 --> URI Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Router Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Output Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Security Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Input Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:08:29 --> Language Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Loader Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Controller Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Session Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:08:29 --> Session routines successfully run
DEBUG - 2019-04-16 14:08:29 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:29 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:08:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:08:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:08:29 --> File loaded: application/views/profile.php
DEBUG - 2019-04-16 14:08:29 --> Final output sent to browser
DEBUG - 2019-04-16 14:08:29 --> Total execution time: 0.0562
DEBUG - 2019-04-16 14:08:35 --> Config Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:08:35 --> URI Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Router Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Output Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Security Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Input Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:08:35 --> Language Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Loader Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Controller Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Session Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:08:35 --> Session routines successfully run
DEBUG - 2019-04-16 14:08:35 --> Model Class Initialized
DEBUG - 2019-04-16 14:08:35 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:08:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:08:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:08:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 14:08:35 --> Final output sent to browser
DEBUG - 2019-04-16 14:08:35 --> Total execution time: 0.0650
DEBUG - 2019-04-16 14:12:46 --> Config Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:12:46 --> URI Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Router Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Output Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Security Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Input Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:12:46 --> Language Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Loader Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Controller Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Session Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:12:46 --> Session routines successfully run
DEBUG - 2019-04-16 14:12:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:12:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:12:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:12:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:12:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:12:46 --> Final output sent to browser
DEBUG - 2019-04-16 14:12:46 --> Total execution time: 0.2194
DEBUG - 2019-04-16 14:17:53 --> Config Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:17:53 --> URI Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Router Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Output Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Security Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Input Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:17:53 --> Language Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Loader Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Controller Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Session Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:17:53 --> Session routines successfully run
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:17:53 --> Config Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:17:53 --> URI Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Router Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Output Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Security Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Input Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:17:53 --> Language Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Loader Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Controller Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Session Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:17:53 --> A session cookie was not found.
DEBUG - 2019-04-16 14:17:53 --> Session routines successfully run
DEBUG - 2019-04-16 14:17:53 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:17:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:17:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:17:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:17:53 --> Final output sent to browser
DEBUG - 2019-04-16 14:17:53 --> Total execution time: 0.1651
DEBUG - 2019-04-16 14:17:55 --> Config Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:17:55 --> URI Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Router Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Output Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Security Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Input Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:17:55 --> Language Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Loader Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Controller Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Session Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:17:55 --> Session routines successfully run
DEBUG - 2019-04-16 14:17:55 --> Model Class Initialized
DEBUG - 2019-04-16 14:17:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:17:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:17:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:17:55 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 14:17:55 --> Final output sent to browser
DEBUG - 2019-04-16 14:17:55 --> Total execution time: 0.0565
DEBUG - 2019-04-16 14:18:02 --> Config Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:18:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:18:02 --> URI Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Router Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Output Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Security Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Input Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:18:02 --> Language Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Loader Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Controller Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Model Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Model Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Session Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:18:02 --> Session routines successfully run
DEBUG - 2019-04-16 14:18:02 --> Model Class Initialized
DEBUG - 2019-04-16 14:18:02 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:18:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:18:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:18:02 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:18:02 --> Final output sent to browser
DEBUG - 2019-04-16 14:18:02 --> Total execution time: 0.1808
DEBUG - 2019-04-16 14:19:51 --> Config Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:19:51 --> URI Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Router Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Output Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Security Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Input Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:19:51 --> Language Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Loader Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Controller Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Session Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:19:51 --> Session routines successfully run
DEBUG - 2019-04-16 14:19:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:19:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:19:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:19:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:19:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:19:51 --> Final output sent to browser
DEBUG - 2019-04-16 14:19:51 --> Total execution time: 0.1680
DEBUG - 2019-04-16 14:22:59 --> Config Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:22:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:22:59 --> URI Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Router Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Output Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Security Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Input Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:22:59 --> Language Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Loader Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Controller Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Session Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:22:59 --> Session routines successfully run
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:22:59 --> Config Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:22:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:22:59 --> URI Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Router Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Output Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Security Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Input Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:22:59 --> Language Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Loader Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Controller Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Session Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:22:59 --> A session cookie was not found.
DEBUG - 2019-04-16 14:22:59 --> Session routines successfully run
DEBUG - 2019-04-16 14:22:59 --> Model Class Initialized
DEBUG - 2019-04-16 14:22:59 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:22:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:22:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:22:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:22:59 --> Final output sent to browser
DEBUG - 2019-04-16 14:22:59 --> Total execution time: 0.1300
DEBUG - 2019-04-16 14:25:28 --> Config Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:25:28 --> URI Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Router Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Output Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Security Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Input Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:25:28 --> Language Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Loader Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Controller Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Model Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Model Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Session Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:25:28 --> Session routines successfully run
DEBUG - 2019-04-16 14:25:28 --> Model Class Initialized
DEBUG - 2019-04-16 14:25:28 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:25:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:25:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:25:28 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 14:25:28 --> Final output sent to browser
DEBUG - 2019-04-16 14:25:28 --> Total execution time: 0.0562
DEBUG - 2019-04-16 14:31:51 --> Config Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:31:51 --> URI Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Router Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Output Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Security Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Input Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:31:51 --> Language Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Loader Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Controller Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Session Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:31:51 --> Session routines successfully run
DEBUG - 2019-04-16 14:31:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:31:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:31:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:31:51 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 14:31:51 --> Final output sent to browser
DEBUG - 2019-04-16 14:31:51 --> Total execution time: 0.2702
DEBUG - 2019-04-16 14:31:56 --> Config Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:31:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:31:56 --> URI Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Router Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Output Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Security Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Input Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:31:56 --> Language Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Loader Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Controller Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Session Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:31:56 --> Session routines successfully run
DEBUG - 2019-04-16 14:31:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:31:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:31:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:31:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:31:56 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 14:31:56 --> Final output sent to browser
DEBUG - 2019-04-16 14:31:56 --> Total execution time: 0.0578
DEBUG - 2019-04-16 14:33:10 --> Config Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:33:10 --> URI Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Router Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Output Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Security Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Input Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:33:10 --> Language Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Loader Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Controller Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Model Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Model Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Session Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:33:10 --> Session routines successfully run
DEBUG - 2019-04-16 14:33:10 --> Model Class Initialized
DEBUG - 2019-04-16 14:33:10 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:33:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:33:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:33:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:33:10 --> Final output sent to browser
DEBUG - 2019-04-16 14:33:10 --> Total execution time: 0.1919
DEBUG - 2019-04-16 14:41:24 --> Config Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:41:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:41:24 --> URI Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Router Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Output Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Security Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Input Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:41:24 --> Language Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Loader Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Controller Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Session Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:41:24 --> Session routines successfully run
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:41:24 --> Config Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:41:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:41:24 --> URI Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Router Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Output Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Security Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Input Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:41:24 --> Language Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Loader Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Controller Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Session Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:41:24 --> A session cookie was not found.
DEBUG - 2019-04-16 14:41:24 --> Session routines successfully run
DEBUG - 2019-04-16 14:41:24 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:24 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:41:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:41:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:41:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:41:24 --> Final output sent to browser
DEBUG - 2019-04-16 14:41:24 --> Total execution time: 0.1315
DEBUG - 2019-04-16 14:41:26 --> Config Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:41:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:41:26 --> URI Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Router Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Output Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Security Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Input Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:41:26 --> Language Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Loader Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Controller Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Session Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:41:26 --> Session routines successfully run
DEBUG - 2019-04-16 14:41:26 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:41:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:41:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:41:26 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 14:41:26 --> Final output sent to browser
DEBUG - 2019-04-16 14:41:26 --> Total execution time: 0.1376
DEBUG - 2019-04-16 14:41:34 --> Config Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:41:34 --> URI Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Router Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Output Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Security Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Input Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:41:34 --> Language Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Loader Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Controller Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Session Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:41:34 --> Session routines successfully run
DEBUG - 2019-04-16 14:41:34 --> Model Class Initialized
DEBUG - 2019-04-16 14:41:34 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:41:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:41:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:41:34 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:41:34 --> Final output sent to browser
DEBUG - 2019-04-16 14:41:34 --> Total execution time: 0.2188
DEBUG - 2019-04-16 14:42:03 --> Config Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:42:03 --> URI Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Router Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Output Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Security Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Input Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:42:03 --> Language Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Loader Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Controller Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Session Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:42:03 --> Session routines successfully run
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:42:03 --> Config Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:42:03 --> URI Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Router Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Output Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Security Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Input Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:42:03 --> Language Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Loader Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Controller Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Session Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:42:03 --> A session cookie was not found.
DEBUG - 2019-04-16 14:42:03 --> Session routines successfully run
DEBUG - 2019-04-16 14:42:03 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:42:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:42:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:42:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:42:03 --> Final output sent to browser
DEBUG - 2019-04-16 14:42:03 --> Total execution time: 0.2360
DEBUG - 2019-04-16 14:42:06 --> Config Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:42:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:42:06 --> URI Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Router Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Output Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Security Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Input Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:42:06 --> Language Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Loader Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Controller Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Session Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:42:06 --> Session routines successfully run
DEBUG - 2019-04-16 14:42:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:42:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:42:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:42:06 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 14:42:06 --> Final output sent to browser
DEBUG - 2019-04-16 14:42:06 --> Total execution time: 0.0473
DEBUG - 2019-04-16 14:42:13 --> Config Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:42:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:42:13 --> URI Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Router Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Output Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Security Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Input Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:42:13 --> Language Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Loader Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Controller Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Session Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:42:13 --> Session routines successfully run
DEBUG - 2019-04-16 14:42:13 --> Model Class Initialized
DEBUG - 2019-04-16 14:42:13 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:42:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:42:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:42:13 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:42:13 --> Final output sent to browser
DEBUG - 2019-04-16 14:42:13 --> Total execution time: 0.1902
DEBUG - 2019-04-16 14:43:39 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:39 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:39 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:40 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:40 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:40 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:40 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:40 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:40 --> A session cookie was not found.
DEBUG - 2019-04-16 14:43:40 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:40 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:43:40 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:40 --> Total execution time: 0.1552
DEBUG - 2019-04-16 14:43:41 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:41 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:41 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:41 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:41 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:41 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:41 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 14:43:41 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:41 --> Total execution time: 0.0526
DEBUG - 2019-04-16 14:43:46 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:46 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:46 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:46 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:43:46 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:46 --> Total execution time: 0.1516
DEBUG - 2019-04-16 14:43:51 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:51 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:51 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:51 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:51 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:51 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:51 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:51 --> A session cookie was not found.
DEBUG - 2019-04-16 14:43:51 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:51 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:51 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:43:51 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:51 --> Total execution time: 0.2565
DEBUG - 2019-04-16 14:43:52 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:52 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:52 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:52 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:52 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:52 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:52 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 14:43:52 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:52 --> Total execution time: 0.0682
DEBUG - 2019-04-16 14:43:56 --> Config Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:43:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:43:56 --> URI Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Router Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Output Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Security Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Input Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:43:56 --> Language Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Loader Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Controller Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Session Class Initialized
DEBUG - 2019-04-16 14:43:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:43:56 --> Session routines successfully run
DEBUG - 2019-04-16 14:43:57 --> Model Class Initialized
DEBUG - 2019-04-16 14:43:57 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:43:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:43:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:43:57 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:43:57 --> Final output sent to browser
DEBUG - 2019-04-16 14:43:57 --> Total execution time: 0.1199
DEBUG - 2019-04-16 14:44:04 --> Config Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:44:04 --> URI Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Router Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Output Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Security Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Input Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:44:04 --> Language Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Loader Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Controller Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Session Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:44:04 --> Session routines successfully run
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:44:04 --> Config Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:44:04 --> URI Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Router Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Output Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Security Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Input Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:44:04 --> Language Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Loader Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Controller Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Session Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:44:04 --> A session cookie was not found.
DEBUG - 2019-04-16 14:44:04 --> Session routines successfully run
DEBUG - 2019-04-16 14:44:04 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:44:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:44:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:44:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 14:44:04 --> Final output sent to browser
DEBUG - 2019-04-16 14:44:04 --> Total execution time: 0.1261
DEBUG - 2019-04-16 14:44:06 --> Config Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:44:06 --> URI Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Router Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Output Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Security Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Input Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:44:06 --> Language Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Loader Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Controller Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Session Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:44:06 --> Session routines successfully run
DEBUG - 2019-04-16 14:44:06 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:44:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:44:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:44:06 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-16 14:44:06 --> Final output sent to browser
DEBUG - 2019-04-16 14:44:06 --> Total execution time: 0.0545
DEBUG - 2019-04-16 14:44:46 --> Config Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:44:46 --> URI Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Router Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Output Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Security Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Input Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:44:46 --> Language Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Loader Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Controller Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Session Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:44:46 --> Session routines successfully run
DEBUG - 2019-04-16 14:44:46 --> Model Class Initialized
DEBUG - 2019-04-16 14:44:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:44:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:44:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:44:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 14:44:46 --> Final output sent to browser
DEBUG - 2019-04-16 14:44:46 --> Total execution time: 0.3336
DEBUG - 2019-04-16 14:45:16 --> Config Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:45:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:45:16 --> URI Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Router Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Output Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Security Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Input Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:45:16 --> Language Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Loader Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Controller Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Model Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Model Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Session Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:45:16 --> Session routines successfully run
DEBUG - 2019-04-16 14:45:16 --> Model Class Initialized
DEBUG - 2019-04-16 14:45:16 --> Helper loaded: url_helper
ERROR - 2019-04-16 14:45:16 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-16 14:47:56 --> Config Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 14:47:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 14:47:56 --> URI Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Router Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Output Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Security Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Input Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 14:47:56 --> Language Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Loader Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Controller Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Session Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 14:47:56 --> Session routines successfully run
DEBUG - 2019-04-16 14:47:56 --> Model Class Initialized
DEBUG - 2019-04-16 14:47:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 14:47:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 14:47:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 14:47:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 14:47:56 --> Final output sent to browser
DEBUG - 2019-04-16 14:47:56 --> Total execution time: 0.0621
DEBUG - 2019-04-16 15:06:16 --> Config Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 15:06:16 --> URI Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Router Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Output Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Security Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Input Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 15:06:16 --> Language Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Loader Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Controller Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Model Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Model Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Session Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 15:06:16 --> Session routines successfully run
DEBUG - 2019-04-16 15:06:16 --> Model Class Initialized
DEBUG - 2019-04-16 15:06:16 --> Helper loaded: url_helper
DEBUG - 2019-04-16 15:06:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 15:06:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 15:06:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 15:06:16 --> Final output sent to browser
DEBUG - 2019-04-16 15:06:16 --> Total execution time: 0.1583
DEBUG - 2019-04-16 15:07:20 --> Config Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Hooks Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Utf8 Class Initialized
DEBUG - 2019-04-16 15:07:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 15:07:20 --> URI Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Router Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Output Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Security Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Input Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 15:07:20 --> Language Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Loader Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Controller Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Model Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Model Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Database Driver Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Session Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 15:07:20 --> Session routines successfully run
DEBUG - 2019-04-16 15:07:20 --> Model Class Initialized
DEBUG - 2019-04-16 15:07:20 --> Helper loaded: url_helper
DEBUG - 2019-04-16 15:07:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 15:07:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 15:07:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 15:07:20 --> Final output sent to browser
DEBUG - 2019-04-16 15:07:20 --> Total execution time: 0.0627
DEBUG - 2019-04-16 16:01:44 --> Config Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:01:44 --> URI Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Router Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Output Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Security Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Input Class Initialized
DEBUG - 2019-04-16 16:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:01:44 --> Language Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Config Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:01:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:01:59 --> URI Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Router Class Initialized
DEBUG - 2019-04-16 16:01:59 --> No URI present. Default controller set.
DEBUG - 2019-04-16 16:01:59 --> Output Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Security Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Input Class Initialized
DEBUG - 2019-04-16 16:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:01:59 --> Language Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Config Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:02:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:02:51 --> URI Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Router Class Initialized
DEBUG - 2019-04-16 16:02:51 --> No URI present. Default controller set.
DEBUG - 2019-04-16 16:02:51 --> Output Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Security Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Input Class Initialized
DEBUG - 2019-04-16 16:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:02:51 --> Language Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Config Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:03:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:03:32 --> URI Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Router Class Initialized
DEBUG - 2019-04-16 16:03:32 --> No URI present. Default controller set.
DEBUG - 2019-04-16 16:03:32 --> Output Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Security Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Input Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:03:32 --> Language Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Loader Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Controller Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Session Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:03:32 --> Session routines successfully run
DEBUG - 2019-04-16 16:03:32 --> Model Class Initialized
DEBUG - 2019-04-16 16:03:32 --> Helper loaded: url_helper
ERROR - 2019-04-16 16:03:32 --> Severity: Notice  --> Undefined property: User::$Order_Model C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 18
DEBUG - 2019-04-16 16:06:26 --> Config Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:06:26 --> URI Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Router Class Initialized
DEBUG - 2019-04-16 16:06:26 --> No URI present. Default controller set.
DEBUG - 2019-04-16 16:06:26 --> Output Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Security Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Input Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:06:26 --> Language Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Loader Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Controller Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Model Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Model Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Session Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:06:26 --> Session routines successfully run
DEBUG - 2019-04-16 16:06:26 --> Model Class Initialized
DEBUG - 2019-04-16 16:06:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:06:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:06:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:06:26 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:06:26 --> Final output sent to browser
DEBUG - 2019-04-16 16:06:26 --> Total execution time: 0.0967
DEBUG - 2019-04-16 16:14:57 --> Config Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:14:57 --> URI Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Router Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Output Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Security Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Input Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:14:57 --> Language Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Loader Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Controller Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Session Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:14:57 --> Session routines successfully run
DEBUG - 2019-04-16 16:14:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:14:57 --> Config Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:14:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:14:57 --> URI Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Router Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Output Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Security Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Input Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:14:57 --> Language Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Loader Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Controller Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Session Class Initialized
DEBUG - 2019-04-16 16:14:57 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:14:57 --> A session cookie was not found.
DEBUG - 2019-04-16 16:14:58 --> Session routines successfully run
DEBUG - 2019-04-16 16:14:58 --> Model Class Initialized
DEBUG - 2019-04-16 16:14:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:14:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:14:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:14:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:14:58 --> Final output sent to browser
DEBUG - 2019-04-16 16:14:58 --> Total execution time: 0.2698
DEBUG - 2019-04-16 16:15:00 --> Config Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:15:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:15:00 --> URI Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Router Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Output Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Security Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Input Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:15:00 --> Language Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Loader Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Controller Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Session Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:15:00 --> Session routines successfully run
DEBUG - 2019-04-16 16:15:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:15:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:15:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:15:00 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:15:00 --> Final output sent to browser
DEBUG - 2019-04-16 16:15:00 --> Total execution time: 0.0520
DEBUG - 2019-04-16 16:15:10 --> Config Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:15:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:15:10 --> URI Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Router Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Output Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Security Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Input Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:15:10 --> Language Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Loader Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Controller Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Session Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:15:10 --> Session routines successfully run
DEBUG - 2019-04-16 16:15:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:15:10 --> Helper loaded: url_helper
ERROR - 2019-04-16 16:15:10 --> Severity: Notice  --> Undefined property: User::$Order_Model C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 82
DEBUG - 2019-04-16 16:16:19 --> Config Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:16:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:16:19 --> URI Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Router Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Output Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Security Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Input Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:16:19 --> Language Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Loader Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Controller Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Model Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Model Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Session Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:16:19 --> Session routines successfully run
DEBUG - 2019-04-16 16:16:19 --> Model Class Initialized
DEBUG - 2019-04-16 16:16:19 --> Helper loaded: url_helper
ERROR - 2019-04-16 16:16:19 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 42
DEBUG - 2019-04-16 16:16:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:16:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:16:19 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:16:19 --> Final output sent to browser
DEBUG - 2019-04-16 16:16:19 --> Total execution time: 0.0707
DEBUG - 2019-04-16 16:19:53 --> Config Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:19:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:19:53 --> URI Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Router Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Output Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Security Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Input Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:19:53 --> Language Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Loader Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Controller Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Session Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:19:53 --> Session routines successfully run
DEBUG - 2019-04-16 16:19:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:19:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:19:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:19:53 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:19:53 --> Final output sent to browser
DEBUG - 2019-04-16 16:19:53 --> Total execution time: 0.0569
DEBUG - 2019-04-16 16:19:56 --> Config Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:19:56 --> URI Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Router Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Output Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Security Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Input Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:19:56 --> Language Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Loader Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Controller Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Session Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:19:56 --> Session routines successfully run
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:19:56 --> Config Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:19:56 --> URI Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Router Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Output Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Security Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Input Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:19:56 --> Language Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Loader Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Controller Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Session Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:19:56 --> A session cookie was not found.
DEBUG - 2019-04-16 16:19:56 --> Session routines successfully run
DEBUG - 2019-04-16 16:19:56 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:56 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:19:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:19:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:19:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:19:56 --> Final output sent to browser
DEBUG - 2019-04-16 16:19:56 --> Total execution time: 0.1415
DEBUG - 2019-04-16 16:19:58 --> Config Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:19:58 --> URI Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Router Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Output Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Security Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Input Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:19:58 --> Language Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Loader Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Controller Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Session Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:19:58 --> Session routines successfully run
DEBUG - 2019-04-16 16:19:58 --> Model Class Initialized
DEBUG - 2019-04-16 16:19:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:19:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:19:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:19:58 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:19:58 --> Final output sent to browser
DEBUG - 2019-04-16 16:19:58 --> Total execution time: 0.0651
DEBUG - 2019-04-16 16:20:07 --> Config Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:20:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:20:07 --> URI Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Router Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Output Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Security Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Input Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:20:07 --> Language Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Loader Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Controller Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Model Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Model Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Session Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:20:07 --> Session routines successfully run
DEBUG - 2019-04-16 16:20:07 --> Model Class Initialized
DEBUG - 2019-04-16 16:20:07 --> Helper loaded: url_helper
ERROR - 2019-04-16 16:20:07 --> Severity: Notice  --> Undefined property: User::$Order_Model C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 82
DEBUG - 2019-04-16 16:21:40 --> Config Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:21:40 --> URI Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Router Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Output Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Security Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Input Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:21:40 --> Language Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Loader Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Controller Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Session Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:21:40 --> Session routines successfully run
DEBUG - 2019-04-16 16:21:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:21:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:21:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:21:40 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:21:40 --> Final output sent to browser
DEBUG - 2019-04-16 16:21:40 --> Total execution time: 0.0681
DEBUG - 2019-04-16 16:21:45 --> Config Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:21:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:21:45 --> URI Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Router Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Output Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Security Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Input Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:21:45 --> Language Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Loader Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Controller Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Session Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:21:45 --> Session routines successfully run
DEBUG - 2019-04-16 16:21:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:21:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:21:45 --> DB Transaction Failure
ERROR - 2019-04-16 16:21:45 --> Query error: Table 'cifyp2019.order' doesn't exist
DEBUG - 2019-04-16 16:21:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-16 16:22:43 --> Config Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:22:43 --> URI Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Router Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Output Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Security Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Input Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:22:43 --> Language Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Loader Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Controller Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Session Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:22:43 --> Session routines successfully run
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:22:43 --> Config Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:22:43 --> URI Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Router Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Output Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Security Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Input Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:22:43 --> Language Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Loader Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Controller Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Session Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:22:43 --> A session cookie was not found.
DEBUG - 2019-04-16 16:22:43 --> Session routines successfully run
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:22:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:22:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:22:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:22:43 --> Final output sent to browser
DEBUG - 2019-04-16 16:22:43 --> Total execution time: 0.1077
DEBUG - 2019-04-16 16:22:45 --> Config Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:22:45 --> URI Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Router Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Output Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Security Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Input Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:22:45 --> Language Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Loader Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Controller Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Session Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:22:45 --> Session routines successfully run
DEBUG - 2019-04-16 16:22:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:22:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:22:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:22:45 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:22:45 --> Final output sent to browser
DEBUG - 2019-04-16 16:22:45 --> Total execution time: 0.0540
DEBUG - 2019-04-16 16:22:49 --> Config Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:22:49 --> URI Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Router Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Output Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Security Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Input Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:22:49 --> Language Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Loader Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Controller Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Session Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:22:49 --> Session routines successfully run
DEBUG - 2019-04-16 16:22:49 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:49 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:22:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:22:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:22:49 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:22:49 --> Final output sent to browser
DEBUG - 2019-04-16 16:22:49 --> Total execution time: 0.1683
DEBUG - 2019-04-16 16:22:53 --> Config Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:22:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:22:53 --> URI Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Router Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Output Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Security Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Input Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:22:53 --> Language Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Loader Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Controller Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Session Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:22:53 --> Session routines successfully run
DEBUG - 2019-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:22:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:22:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:22:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:22:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:22:53 --> Final output sent to browser
DEBUG - 2019-04-16 16:22:53 --> Total execution time: 0.0818
DEBUG - 2019-04-16 16:23:24 --> Config Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:23:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:23:24 --> URI Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Router Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Output Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Security Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Input Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:23:24 --> Language Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Loader Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Controller Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Session Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:23:24 --> Session routines successfully run
DEBUG - 2019-04-16 16:23:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:24 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:23:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:23:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:23:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:23:24 --> Final output sent to browser
DEBUG - 2019-04-16 16:23:24 --> Total execution time: 0.1285
DEBUG - 2019-04-16 16:23:25 --> Config Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:23:25 --> URI Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Router Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Output Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Security Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Input Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:23:25 --> Language Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Loader Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Controller Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Session Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:23:25 --> Session routines successfully run
DEBUG - 2019-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:23:25 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:23:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:23:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:23:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:23:25 --> Final output sent to browser
DEBUG - 2019-04-16 16:23:25 --> Total execution time: 0.1033
DEBUG - 2019-04-16 16:24:04 --> Config Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:24:04 --> URI Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Router Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Output Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Security Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Input Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:24:04 --> Language Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Loader Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Controller Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Session Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:24:04 --> Session routines successfully run
DEBUG - 2019-04-16 16:24:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:24:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:24:04 --> File loaded: application/views/header.php
ERROR - 2019-04-16 16:24:04 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 7
ERROR - 2019-04-16 16:24:04 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 8
ERROR - 2019-04-16 16:24:04 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 9
ERROR - 2019-04-16 16:24:04 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 10
ERROR - 2019-04-16 16:24:04 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 11
DEBUG - 2019-04-16 16:24:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:24:04 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:24:04 --> Final output sent to browser
DEBUG - 2019-04-16 16:24:04 --> Total execution time: 0.0906
DEBUG - 2019-04-16 16:33:30 --> Config Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:33:30 --> URI Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Router Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Output Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Security Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Input Class Initialized
DEBUG - 2019-04-16 16:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:33:30 --> Language Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Loader Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Controller Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Session Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:33:31 --> Session routines successfully run
DEBUG - 2019-04-16 16:33:31 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:31 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:33:54 --> Config Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:33:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:33:54 --> URI Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Router Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Output Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Security Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Input Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:33:54 --> Language Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Loader Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Controller Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Session Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:33:54 --> Session routines successfully run
DEBUG - 2019-04-16 16:33:54 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Model Class Initialized
DEBUG - 2019-04-16 16:33:54 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:33:54 --> File loaded: application/views/header.php
ERROR - 2019-04-16 16:33:54 --> Severity: Notice  --> Undefined index: details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-16 16:33:54 --> Severity: Notice  --> Undefined index: details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-16 16:33:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:33:54 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:33:54 --> Final output sent to browser
DEBUG - 2019-04-16 16:33:54 --> Total execution time: 0.1209
DEBUG - 2019-04-16 16:34:12 --> Config Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:34:12 --> URI Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Router Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Output Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Security Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Input Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:34:12 --> Language Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Loader Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Controller Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Session Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:34:12 --> Session routines successfully run
DEBUG - 2019-04-16 16:34:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:12 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:34:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:34:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:34:12 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:34:12 --> Final output sent to browser
DEBUG - 2019-04-16 16:34:12 --> Total execution time: 0.1118
DEBUG - 2019-04-16 16:34:30 --> Config Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:34:30 --> URI Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Router Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Output Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Security Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Input Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:34:30 --> Language Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Loader Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Controller Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Session Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:34:30 --> Session routines successfully run
DEBUG - 2019-04-16 16:34:30 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Model Class Initialized
DEBUG - 2019-04-16 16:34:30 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:34:30 --> DB Transaction Failure
ERROR - 2019-04-16 16:34:30 --> Query error: Unknown column 'userid' in 'where clause'
DEBUG - 2019-04-16 16:34:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-16 16:35:25 --> Config Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:35:25 --> URI Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Router Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Output Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Security Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Input Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:35:25 --> Language Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Loader Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Controller Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Session Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:35:25 --> Session routines successfully run
DEBUG - 2019-04-16 16:35:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:25 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:35:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:35:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:35:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:35:25 --> Final output sent to browser
DEBUG - 2019-04-16 16:35:25 --> Total execution time: 0.1260
DEBUG - 2019-04-16 16:35:29 --> Config Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:35:29 --> URI Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Router Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Output Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Security Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Input Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:35:29 --> Language Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Loader Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Controller Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Session Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:35:29 --> Session routines successfully run
DEBUG - 2019-04-16 16:35:29 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:29 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:35:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:35:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:35:29 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 16:35:29 --> Final output sent to browser
DEBUG - 2019-04-16 16:35:29 --> Total execution time: 0.0577
DEBUG - 2019-04-16 16:35:52 --> Config Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:35:52 --> URI Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Router Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Output Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Security Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Input Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:35:52 --> Language Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Loader Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Controller Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Session Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:35:52 --> Session routines successfully run
DEBUG - 2019-04-16 16:35:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:35:52 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:35:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:35:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:35:52 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:35:52 --> Final output sent to browser
DEBUG - 2019-04-16 16:35:52 --> Total execution time: 0.0872
DEBUG - 2019-04-16 16:39:22 --> Config Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:39:22 --> URI Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Router Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Output Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Security Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Input Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:39:22 --> Language Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Loader Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Controller Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Session Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:39:22 --> Session routines successfully run
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:39:22 --> Config Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:39:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:39:22 --> URI Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Router Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Output Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Security Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Input Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:39:22 --> Language Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Loader Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Controller Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Session Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:39:22 --> A session cookie was not found.
DEBUG - 2019-04-16 16:39:22 --> Session routines successfully run
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:22 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:39:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:39:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:39:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:39:22 --> Final output sent to browser
DEBUG - 2019-04-16 16:39:22 --> Total execution time: 0.1423
DEBUG - 2019-04-16 16:39:24 --> Config Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:39:24 --> URI Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Router Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Output Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Security Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Input Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:39:24 --> Language Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Loader Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Controller Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Session Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:39:24 --> Session routines successfully run
DEBUG - 2019-04-16 16:39:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:24 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:39:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:39:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:39:24 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:39:24 --> Final output sent to browser
DEBUG - 2019-04-16 16:39:24 --> Total execution time: 0.0523
DEBUG - 2019-04-16 16:39:43 --> Config Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:39:43 --> URI Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Router Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Output Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Security Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Input Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:39:43 --> Language Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Loader Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Controller Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Session Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:39:43 --> Session routines successfully run
DEBUG - 2019-04-16 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:39:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:39:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:39:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:39:43 --> Final output sent to browser
DEBUG - 2019-04-16 16:39:43 --> Total execution time: 0.1196
DEBUG - 2019-04-16 16:39:46 --> Config Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:39:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:39:46 --> URI Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Router Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Output Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Security Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Input Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:39:46 --> Language Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Loader Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Controller Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Session Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:39:46 --> Session routines successfully run
DEBUG - 2019-04-16 16:39:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:39:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:39:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:39:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:39:46 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:39:46 --> Final output sent to browser
DEBUG - 2019-04-16 16:39:46 --> Total execution time: 0.0892
DEBUG - 2019-04-16 16:41:04 --> Config Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:41:04 --> URI Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Router Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Output Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Security Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Input Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:41:04 --> Language Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Loader Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Controller Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Session Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:41:04 --> Session routines successfully run
DEBUG - 2019-04-16 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:41:04 --> Final output sent to browser
DEBUG - 2019-04-16 16:41:04 --> Total execution time: 0.1110
DEBUG - 2019-04-16 16:41:40 --> Config Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:41:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:41:40 --> URI Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Router Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Output Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Security Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Input Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:41:40 --> Language Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Loader Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Controller Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Session Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:41:40 --> Session routines successfully run
DEBUG - 2019-04-16 16:41:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:41:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:41:40 --> Final output sent to browser
DEBUG - 2019-04-16 16:41:40 --> Total execution time: 0.0811
DEBUG - 2019-04-16 16:43:35 --> Config Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:43:35 --> URI Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Router Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Output Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Security Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Input Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:43:35 --> Language Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Loader Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Controller Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Session Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:43:35 --> Session routines successfully run
DEBUG - 2019-04-16 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-16 16:43:35 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:43:35 --> Final output sent to browser
DEBUG - 2019-04-16 16:43:35 --> Total execution time: 0.1248
DEBUG - 2019-04-16 16:44:33 --> Config Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:44:33 --> URI Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Router Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Output Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Security Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Input Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:44:33 --> Language Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Loader Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Controller Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Session Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:44:33 --> Session routines successfully run
DEBUG - 2019-04-16 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:33 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:44:33 --> Final output sent to browser
DEBUG - 2019-04-16 16:44:33 --> Total execution time: 0.1514
DEBUG - 2019-04-16 16:44:37 --> Config Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:44:37 --> URI Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Router Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Output Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Security Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Input Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:44:37 --> Language Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Loader Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Controller Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Session Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:44:37 --> Session routines successfully run
DEBUG - 2019-04-16 16:44:37 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:37 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:44:37 --> Final output sent to browser
DEBUG - 2019-04-16 16:44:37 --> Total execution time: 0.1378
DEBUG - 2019-04-16 16:44:53 --> Config Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:44:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:44:53 --> URI Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Router Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Output Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Security Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Input Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:44:53 --> Language Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Loader Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Controller Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Session Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:44:53 --> Session routines successfully run
DEBUG - 2019-04-16 16:44:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:53 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:44:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:44:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:44:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 16:44:53 --> Final output sent to browser
DEBUG - 2019-04-16 16:44:53 --> Total execution time: 0.0663
DEBUG - 2019-04-16 16:44:55 --> Config Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:44:55 --> URI Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Router Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Output Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Security Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Input Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:44:55 --> Language Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Loader Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Controller Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Session Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:44:55 --> Session routines successfully run
DEBUG - 2019-04-16 16:44:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:44:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:44:55 --> Final output sent to browser
DEBUG - 2019-04-16 16:44:55 --> Total execution time: 0.0999
DEBUG - 2019-04-16 16:45:57 --> Config Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:45:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:45:57 --> URI Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Router Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Output Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Security Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Input Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:45:57 --> Language Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Loader Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Controller Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Session Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:45:57 --> Session routines successfully run
DEBUG - 2019-04-16 16:45:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Model Class Initialized
DEBUG - 2019-04-16 16:45:57 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:45:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:45:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:45:57 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:45:57 --> Final output sent to browser
DEBUG - 2019-04-16 16:45:57 --> Total execution time: 0.1151
DEBUG - 2019-04-16 16:46:52 --> Config Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:46:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:46:52 --> URI Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Router Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Output Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Security Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Input Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:46:52 --> Language Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Loader Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Controller Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Session Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:46:52 --> Session routines successfully run
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:46:52 --> Config Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:46:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:46:52 --> URI Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Router Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Output Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Security Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Input Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:46:52 --> Language Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Loader Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Controller Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Session Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:46:52 --> A session cookie was not found.
DEBUG - 2019-04-16 16:46:52 --> Session routines successfully run
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:52 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:46:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:46:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:46:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:46:52 --> Final output sent to browser
DEBUG - 2019-04-16 16:46:52 --> Total execution time: 0.1368
DEBUG - 2019-04-16 16:46:55 --> Config Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:46:55 --> URI Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Router Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Output Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Security Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Input Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:46:55 --> Language Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Loader Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Controller Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Session Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:46:55 --> Session routines successfully run
DEBUG - 2019-04-16 16:46:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:46:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:46:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:46:55 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:46:55 --> Final output sent to browser
DEBUG - 2019-04-16 16:46:55 --> Total execution time: 0.0608
DEBUG - 2019-04-16 16:46:59 --> Config Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:46:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:46:59 --> URI Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Router Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Output Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Security Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Input Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:46:59 --> Language Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Loader Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Controller Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Session Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:46:59 --> Session routines successfully run
DEBUG - 2019-04-16 16:46:59 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Model Class Initialized
DEBUG - 2019-04-16 16:46:59 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:46:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:46:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:46:59 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:46:59 --> Final output sent to browser
DEBUG - 2019-04-16 16:46:59 --> Total execution time: 0.1468
DEBUG - 2019-04-16 16:47:02 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:02 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:02 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:02 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:02 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:02 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:47:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:47:02 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:47:02 --> Final output sent to browser
DEBUG - 2019-04-16 16:47:02 --> Total execution time: 0.4019
DEBUG - 2019-04-16 16:47:04 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:04 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:04 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:04 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:04 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:04 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:04 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:04 --> A session cookie was not found.
DEBUG - 2019-04-16 16:47:04 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:47:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:47:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:47:04 --> Final output sent to browser
DEBUG - 2019-04-16 16:47:04 --> Total execution time: 0.1339
DEBUG - 2019-04-16 16:47:06 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:06 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:06 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:06 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:06 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:47:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:47:06 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:47:06 --> Final output sent to browser
DEBUG - 2019-04-16 16:47:06 --> Total execution time: 0.0526
DEBUG - 2019-04-16 16:47:10 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:10 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:10 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:10 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:10 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:47:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:47:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:47:10 --> Final output sent to browser
DEBUG - 2019-04-16 16:47:10 --> Total execution time: 0.1489
DEBUG - 2019-04-16 16:47:12 --> Config Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:47:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:47:12 --> URI Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Router Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Output Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Security Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Input Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:47:12 --> Language Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Loader Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Controller Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Session Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:47:12 --> Session routines successfully run
DEBUG - 2019-04-16 16:47:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Model Class Initialized
DEBUG - 2019-04-16 16:47:12 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:47:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:47:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:47:13 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-16 16:47:13 --> Final output sent to browser
DEBUG - 2019-04-16 16:47:13 --> Total execution time: 0.1180
DEBUG - 2019-04-16 16:49:42 --> Config Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:49:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:49:42 --> URI Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Router Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Output Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Security Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Input Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:49:42 --> Language Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Loader Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Controller Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Session Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:49:43 --> Session routines successfully run
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:49:43 --> Config Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:49:43 --> URI Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Router Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Output Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Security Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Input Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:49:43 --> Language Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Loader Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Controller Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Session Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:49:43 --> A session cookie was not found.
DEBUG - 2019-04-16 16:49:43 --> Session routines successfully run
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:49:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:49:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:49:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:49:43 --> Final output sent to browser
DEBUG - 2019-04-16 16:49:43 --> Total execution time: 0.1450
DEBUG - 2019-04-16 16:49:46 --> Config Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:49:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:49:46 --> URI Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Router Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Output Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Security Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Input Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:49:46 --> Language Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Loader Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Controller Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Session Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:49:46 --> Session routines successfully run
DEBUG - 2019-04-16 16:49:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:49:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:49:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:49:46 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:49:46 --> Final output sent to browser
DEBUG - 2019-04-16 16:49:46 --> Total execution time: 0.0432
DEBUG - 2019-04-16 16:49:55 --> Config Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:49:55 --> URI Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Router Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Output Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Security Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Input Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:49:55 --> Language Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Loader Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Controller Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Session Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:49:55 --> Session routines successfully run
DEBUG - 2019-04-16 16:49:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Model Class Initialized
DEBUG - 2019-04-16 16:49:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:49:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:49:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:49:55 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:49:55 --> Final output sent to browser
DEBUG - 2019-04-16 16:49:55 --> Total execution time: 0.1405
DEBUG - 2019-04-16 16:50:00 --> Config Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:50:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:50:00 --> URI Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Router Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Output Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Security Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Input Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:50:00 --> Language Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Loader Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Controller Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Session Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:50:00 --> Session routines successfully run
DEBUG - 2019-04-16 16:50:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Model Class Initialized
DEBUG - 2019-04-16 16:50:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:50:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:50:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:50:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 16:50:00 --> Final output sent to browser
DEBUG - 2019-04-16 16:50:00 --> Total execution time: 0.0877
DEBUG - 2019-04-16 16:58:38 --> Config Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:58:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:58:38 --> URI Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Router Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Output Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Security Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Input Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:58:38 --> Language Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Loader Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Controller Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Session Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:58:38 --> Session routines successfully run
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:58:38 --> Config Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:58:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:58:38 --> URI Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Router Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Output Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Security Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Input Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:58:38 --> Language Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Loader Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Controller Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Session Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:58:38 --> A session cookie was not found.
DEBUG - 2019-04-16 16:58:38 --> Session routines successfully run
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:38 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:58:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:58:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:58:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 16:58:38 --> Final output sent to browser
DEBUG - 2019-04-16 16:58:38 --> Total execution time: 0.1471
DEBUG - 2019-04-16 16:58:40 --> Config Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:58:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:58:40 --> URI Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Router Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Output Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Security Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Input Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:58:40 --> Language Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Loader Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Controller Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Session Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:58:40 --> Session routines successfully run
DEBUG - 2019-04-16 16:58:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:58:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:58:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:58:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:58:40 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:58:40 --> Final output sent to browser
DEBUG - 2019-04-16 16:58:40 --> Total execution time: 0.0502
DEBUG - 2019-04-16 16:59:40 --> Config Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:59:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:59:40 --> URI Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Router Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Output Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Security Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Input Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:59:40 --> Language Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Loader Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Controller Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Session Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:59:40 --> Session routines successfully run
DEBUG - 2019-04-16 16:59:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:59:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:59:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:59:40 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 16:59:40 --> Final output sent to browser
DEBUG - 2019-04-16 16:59:40 --> Total execution time: 0.0600
DEBUG - 2019-04-16 16:59:45 --> Config Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:59:45 --> URI Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Router Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Output Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Security Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Input Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:59:45 --> Language Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Loader Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Controller Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Session Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:59:45 --> Session routines successfully run
DEBUG - 2019-04-16 16:59:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:59:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:59:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:59:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 16:59:45 --> Final output sent to browser
DEBUG - 2019-04-16 16:59:45 --> Total execution time: 0.1514
DEBUG - 2019-04-16 16:59:47 --> Config Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Hooks Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Utf8 Class Initialized
DEBUG - 2019-04-16 16:59:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 16:59:47 --> URI Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Router Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Output Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Security Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Input Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 16:59:47 --> Language Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Loader Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Controller Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Database Driver Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Session Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Helper loaded: string_helper
DEBUG - 2019-04-16 16:59:47 --> Session routines successfully run
DEBUG - 2019-04-16 16:59:47 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Model Class Initialized
DEBUG - 2019-04-16 16:59:47 --> Helper loaded: url_helper
DEBUG - 2019-04-16 16:59:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 16:59:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 16:59:47 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 16:59:47 --> Final output sent to browser
DEBUG - 2019-04-16 16:59:47 --> Total execution time: 0.1266
DEBUG - 2019-04-16 17:01:56 --> Config Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:01:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:01:56 --> URI Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Router Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Output Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Security Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Input Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:01:56 --> Language Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Loader Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Controller Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Session Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:01:56 --> Session routines successfully run
DEBUG - 2019-04-16 17:01:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:01:56 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:01:56 --> Severity: Notice  --> Undefined variable: z C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
ERROR - 2019-04-16 17:01:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
DEBUG - 2019-04-16 17:01:56 --> Final output sent to browser
DEBUG - 2019-04-16 17:01:56 --> Total execution time: 0.0930
DEBUG - 2019-04-16 17:02:20 --> Config Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:02:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:02:20 --> URI Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Router Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Output Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Security Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Input Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:02:20 --> Language Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Loader Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Controller Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Session Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:02:20 --> Session routines successfully run
DEBUG - 2019-04-16 17:02:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:20 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:02:20 --> Severity: Notice  --> Undefined variable: AllCustOrders C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
ERROR - 2019-04-16 17:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
DEBUG - 2019-04-16 17:02:20 --> Final output sent to browser
DEBUG - 2019-04-16 17:02:20 --> Total execution time: 0.0982
DEBUG - 2019-04-16 17:02:23 --> Config Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:02:23 --> URI Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Router Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Output Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Security Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Input Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:02:23 --> Language Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Loader Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Controller Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Session Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:02:23 --> Session garbage collection performed.
DEBUG - 2019-04-16 17:02:23 --> Session routines successfully run
DEBUG - 2019-04-16 17:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Model Class Initialized
DEBUG - 2019-04-16 17:02:23 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:02:23 --> Severity: Notice  --> Undefined variable: AllCustOrders C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
ERROR - 2019-04-16 17:02:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 34
DEBUG - 2019-04-16 17:02:23 --> Final output sent to browser
DEBUG - 2019-04-16 17:02:23 --> Total execution time: 0.1780
DEBUG - 2019-04-16 17:03:01 --> Config Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:03:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:03:01 --> URI Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Router Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Output Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Security Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Input Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:03:01 --> Language Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Loader Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Controller Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Session Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:03:01 --> Session routines successfully run
DEBUG - 2019-04-16 17:03:01 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:01 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:03:01 --> Severity: Notice  --> Undefined variable: orderCustOrders C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 36
ERROR - 2019-04-16 17:03:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 36
DEBUG - 2019-04-16 17:03:01 --> Final output sent to browser
DEBUG - 2019-04-16 17:03:01 --> Total execution time: 0.1268
DEBUG - 2019-04-16 17:03:21 --> Config Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:03:21 --> URI Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Router Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Output Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Security Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Input Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:03:21 --> Language Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Loader Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Controller Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Session Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:03:21 --> Session routines successfully run
DEBUG - 2019-04-16 17:03:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:03:21 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:03:21 --> Final output sent to browser
DEBUG - 2019-04-16 17:03:21 --> Total execution time: 0.1214
DEBUG - 2019-04-16 17:04:22 --> Config Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:04:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:04:22 --> URI Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Router Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Output Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Security Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Input Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:04:22 --> Language Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Loader Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Controller Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Session Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:04:22 --> Session routines successfully run
DEBUG - 2019-04-16 17:04:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:04:22 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:04:22 --> Severity: Warning  --> Use of undefined constant AllCustOrders - assumed 'AllCustOrders' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 36
DEBUG - 2019-04-16 17:04:22 --> Final output sent to browser
DEBUG - 2019-04-16 17:04:22 --> Total execution time: 0.1946
DEBUG - 2019-04-16 17:06:18 --> Config Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:06:18 --> URI Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Router Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Output Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Security Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Input Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:06:18 --> Language Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Loader Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Controller Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Session Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:06:18 --> Session routines successfully run
DEBUG - 2019-04-16 17:06:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:18 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:06:18 --> Final output sent to browser
DEBUG - 2019-04-16 17:06:18 --> Total execution time: 0.1149
DEBUG - 2019-04-16 17:06:25 --> Config Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:06:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:06:25 --> URI Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Router Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Output Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Security Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Input Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:06:25 --> Language Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Loader Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Controller Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Session Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:06:25 --> Session routines successfully run
DEBUG - 2019-04-16 17:06:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:25 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:06:25 --> Final output sent to browser
DEBUG - 2019-04-16 17:06:25 --> Total execution time: 0.1192
DEBUG - 2019-04-16 17:06:43 --> Config Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:06:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:06:43 --> URI Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Router Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Output Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Security Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Input Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:06:43 --> Language Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Loader Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Controller Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Session Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:06:43 --> Session routines successfully run
DEBUG - 2019-04-16 17:06:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:06:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:06:43 --> File loaded: application/views/header.php
ERROR - 2019-04-16 17:06:43 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 21
DEBUG - 2019-04-16 17:06:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:06:43 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:06:43 --> Final output sent to browser
DEBUG - 2019-04-16 17:06:43 --> Total execution time: 0.1231
DEBUG - 2019-04-16 17:08:05 --> Config Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:08:05 --> URI Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Router Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Output Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Security Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Input Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:08:05 --> Language Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Loader Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Controller Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Session Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:08:05 --> Session routines successfully run
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:08:05 --> Config Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:08:05 --> URI Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Router Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Output Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Security Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Input Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:08:05 --> Language Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Loader Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Controller Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Session Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:08:05 --> A session cookie was not found.
DEBUG - 2019-04-16 17:08:05 --> Session routines successfully run
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:05 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:08:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:08:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:08:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 17:08:05 --> Final output sent to browser
DEBUG - 2019-04-16 17:08:05 --> Total execution time: 0.0954
DEBUG - 2019-04-16 17:08:07 --> Config Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:08:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:08:07 --> URI Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Router Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Output Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Security Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Input Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:08:07 --> Language Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Loader Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Controller Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Session Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:08:07 --> Session garbage collection performed.
DEBUG - 2019-04-16 17:08:07 --> Session routines successfully run
DEBUG - 2019-04-16 17:08:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:07 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:08:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:08:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:08:07 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 17:08:07 --> Final output sent to browser
DEBUG - 2019-04-16 17:08:07 --> Total execution time: 0.0749
DEBUG - 2019-04-16 17:08:14 --> Config Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:08:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:08:14 --> URI Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Router Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Output Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Security Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Input Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:08:14 --> Language Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Loader Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Controller Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Session Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:08:14 --> Session routines successfully run
DEBUG - 2019-04-16 17:08:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:14 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:08:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:08:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:08:14 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 17:08:14 --> Final output sent to browser
DEBUG - 2019-04-16 17:08:14 --> Total execution time: 0.1692
DEBUG - 2019-04-16 17:08:17 --> Config Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:08:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:08:17 --> URI Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Router Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Output Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Security Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Input Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:08:17 --> Language Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Loader Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Controller Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Session Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:08:17 --> Session routines successfully run
DEBUG - 2019-04-16 17:08:17 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Model Class Initialized
DEBUG - 2019-04-16 17:08:17 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:08:17 --> File loaded: application/views/header.php
ERROR - 2019-04-16 17:08:17 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 21
DEBUG - 2019-04-16 17:08:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:08:17 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:08:17 --> Final output sent to browser
DEBUG - 2019-04-16 17:08:17 --> Total execution time: 0.0925
DEBUG - 2019-04-16 17:14:12 --> Config Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:14:12 --> URI Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Router Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Output Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Security Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Input Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:14:12 --> Language Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Loader Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Controller Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Session Class Initialized
DEBUG - 2019-04-16 17:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:14:13 --> Session routines successfully run
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:14:13 --> Config Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:14:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:14:13 --> URI Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Router Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Output Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Security Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Input Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:14:13 --> Language Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Loader Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Controller Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Session Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:14:13 --> A session cookie was not found.
DEBUG - 2019-04-16 17:14:13 --> Session routines successfully run
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:13 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:14:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:14:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:14:13 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 17:14:13 --> Final output sent to browser
DEBUG - 2019-04-16 17:14:13 --> Total execution time: 0.1498
DEBUG - 2019-04-16 17:14:15 --> Config Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:14:15 --> URI Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Router Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Output Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Security Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Input Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:14:15 --> Language Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Loader Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Controller Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Session Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:14:15 --> Session routines successfully run
DEBUG - 2019-04-16 17:14:15 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:15 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:14:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:14:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:14:15 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 17:14:15 --> Final output sent to browser
DEBUG - 2019-04-16 17:14:15 --> Total execution time: 0.0543
DEBUG - 2019-04-16 17:14:18 --> Config Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:14:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:14:18 --> URI Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Router Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Output Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Security Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Input Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:14:18 --> Language Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Loader Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Controller Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Session Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:14:18 --> Session routines successfully run
DEBUG - 2019-04-16 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:18 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:14:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:14:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:14:19 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 17:14:19 --> Final output sent to browser
DEBUG - 2019-04-16 17:14:19 --> Total execution time: 0.3023
DEBUG - 2019-04-16 17:14:20 --> Config Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:14:20 --> URI Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Router Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Output Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Security Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Input Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:14:20 --> Language Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Loader Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Controller Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Session Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:14:20 --> Session routines successfully run
DEBUG - 2019-04-16 17:14:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Model Class Initialized
DEBUG - 2019-04-16 17:14:20 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:14:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:14:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:14:21 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:14:21 --> Final output sent to browser
DEBUG - 2019-04-16 17:14:21 --> Total execution time: 0.0965
DEBUG - 2019-04-16 17:15:58 --> Config Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:15:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:15:58 --> URI Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Router Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Output Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Security Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Input Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:15:58 --> Language Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Loader Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Controller Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Session Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:15:58 --> Session routines successfully run
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:15:58 --> Config Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:15:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:15:58 --> URI Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Router Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Output Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Security Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Input Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:15:58 --> Language Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Loader Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Controller Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Session Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:15:58 --> A session cookie was not found.
DEBUG - 2019-04-16 17:15:58 --> Session routines successfully run
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:15:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:15:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:15:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 17:15:58 --> Final output sent to browser
DEBUG - 2019-04-16 17:15:58 --> Total execution time: 0.1647
DEBUG - 2019-04-16 17:15:59 --> Config Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:15:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:15:59 --> URI Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Router Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Output Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Security Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Input Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:15:59 --> Language Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Loader Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Controller Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Session Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:15:59 --> Session routines successfully run
DEBUG - 2019-04-16 17:15:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:15:59 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:15:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:15:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:15:59 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 17:15:59 --> Final output sent to browser
DEBUG - 2019-04-16 17:15:59 --> Total execution time: 0.0433
DEBUG - 2019-04-16 17:16:04 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:04 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:04 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:04 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:04 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:04 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:04 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 17:16:04 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:04 --> Total execution time: 0.1401
DEBUG - 2019-04-16 17:16:06 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:06 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:06 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:06 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:06 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:16:06 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:06 --> Total execution time: 0.0738
DEBUG - 2019-04-16 17:16:39 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:39 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:39 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:39 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:39 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:39 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:39 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:39 --> A session cookie was not found.
DEBUG - 2019-04-16 17:16:39 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-16 17:16:39 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:39 --> Total execution time: 0.2071
DEBUG - 2019-04-16 17:16:40 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:40 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:40 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:40 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:40 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-16 17:16:40 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:40 --> Total execution time: 0.0630
DEBUG - 2019-04-16 17:16:46 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:46 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:46 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:46 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:46 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:46 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 17:16:46 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:46 --> Total execution time: 0.1436
DEBUG - 2019-04-16 17:16:48 --> Config Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:16:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:16:48 --> URI Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Router Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Output Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Security Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Input Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:16:48 --> Language Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Loader Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Controller Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Session Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:16:48 --> Session routines successfully run
DEBUG - 2019-04-16 17:16:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:16:48 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:16:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:16:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:16:48 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:16:48 --> Final output sent to browser
DEBUG - 2019-04-16 17:16:48 --> Total execution time: 0.1196
DEBUG - 2019-04-16 17:17:27 --> Config Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:17:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:17:27 --> URI Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Router Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Output Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Security Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Input Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:17:27 --> Language Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Loader Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Controller Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Session Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:17:27 --> Session routines successfully run
DEBUG - 2019-04-16 17:17:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:17:27 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:17:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:17:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:17:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:17:27 --> Final output sent to browser
DEBUG - 2019-04-16 17:17:27 --> Total execution time: 0.0516
DEBUG - 2019-04-16 17:19:21 --> Config Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:19:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:19:21 --> URI Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Router Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Output Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Security Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Input Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:19:21 --> Language Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Loader Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Controller Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Session Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:19:21 --> Session routines successfully run
DEBUG - 2019-04-16 17:19:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:19:21 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:20:45 --> Config Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:20:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:20:45 --> URI Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Router Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Output Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Security Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Input Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:20:45 --> Language Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Loader Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Controller Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Session Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:20:45 --> Session routines successfully run
DEBUG - 2019-04-16 17:20:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:20:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:21:03 --> Config Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:21:03 --> URI Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Router Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Output Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Security Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Input Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:21:03 --> Language Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Loader Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Controller Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Session Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:21:03 --> Session routines successfully run
DEBUG - 2019-04-16 17:21:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:21:41 --> Config Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:21:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:21:41 --> URI Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Router Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Output Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Security Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Input Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:21:41 --> Language Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Loader Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Controller Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Session Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:21:41 --> Session routines successfully run
DEBUG - 2019-04-16 17:21:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:21:41 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:24:28 --> Config Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:24:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:24:28 --> URI Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Router Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Output Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Security Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Input Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:24:28 --> Language Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Loader Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Controller Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Session Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:24:28 --> Session routines successfully run
DEBUG - 2019-04-16 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:28 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:24:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:24:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:24:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:24:28 --> Final output sent to browser
DEBUG - 2019-04-16 17:24:28 --> Total execution time: 0.0685
DEBUG - 2019-04-16 17:24:52 --> Config Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:24:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:24:52 --> URI Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Router Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Output Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Security Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Input Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:24:52 --> Language Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Loader Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Controller Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Session Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:24:52 --> Session routines successfully run
DEBUG - 2019-04-16 17:24:52 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:52 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:24:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:24:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:24:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:24:52 --> Final output sent to browser
DEBUG - 2019-04-16 17:24:52 --> Total execution time: 0.0490
DEBUG - 2019-04-16 17:24:56 --> Config Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:24:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:24:56 --> URI Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Router Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Output Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Security Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Input Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:24:56 --> Language Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Loader Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Controller Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Model Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Session Class Initialized
DEBUG - 2019-04-16 17:24:56 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:24:56 --> Session routines successfully run
DEBUG - 2019-04-16 17:24:56 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:24:56 --> 404 Page Not Found --> Order/doOrder
DEBUG - 2019-04-16 17:26:15 --> Config Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:26:15 --> URI Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Router Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Output Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Security Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Input Class Initialized
DEBUG - 2019-04-16 17:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:26:15 --> Language Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Loader Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Controller Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Session Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:26:16 --> Session routines successfully run
DEBUG - 2019-04-16 17:26:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:16 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:26:33 --> Config Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:26:33 --> URI Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Router Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Output Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Security Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Input Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:26:33 --> Language Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Loader Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Controller Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Session Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:26:33 --> Session routines successfully run
DEBUG - 2019-04-16 17:26:33 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:33 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:26:35 --> Config Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:26:35 --> URI Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Router Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Output Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Security Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Input Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:26:35 --> Language Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Loader Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Controller Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Session Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:26:35 --> Session garbage collection performed.
DEBUG - 2019-04-16 17:26:35 --> Session routines successfully run
DEBUG - 2019-04-16 17:26:35 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:35 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:26:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:26:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:26:36 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:26:36 --> Final output sent to browser
DEBUG - 2019-04-16 17:26:36 --> Total execution time: 0.1350
DEBUG - 2019-04-16 17:26:37 --> Config Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:26:37 --> URI Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Router Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Output Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Security Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Input Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:26:37 --> Language Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Loader Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Controller Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Session Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:26:37 --> Session routines successfully run
DEBUG - 2019-04-16 17:26:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:26:37 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:27:00 --> Config Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:27:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:27:00 --> URI Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Router Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Output Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Security Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Input Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:27:00 --> Language Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Loader Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Controller Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Session Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:27:00 --> Session routines successfully run
DEBUG - 2019-04-16 17:27:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:27:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:28:03 --> Config Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:28:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:28:03 --> URI Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Router Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Output Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Security Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Input Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:28:03 --> Language Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Loader Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Controller Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Session Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:28:03 --> Session routines successfully run
DEBUG - 2019-04-16 17:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:28:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:28:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:28:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:28:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:28:03 --> Final output sent to browser
DEBUG - 2019-04-16 17:28:03 --> Total execution time: 0.0537
DEBUG - 2019-04-16 17:32:03 --> Config Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:32:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:32:03 --> URI Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Router Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Output Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Security Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Input Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:32:03 --> Language Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Loader Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Controller Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Session Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:32:03 --> Session routines successfully run
DEBUG - 2019-04-16 17:32:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:32:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:32:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:32:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:32:03 --> Final output sent to browser
DEBUG - 2019-04-16 17:32:03 --> Total execution time: 0.1205
DEBUG - 2019-04-16 17:32:18 --> Config Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:32:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:32:18 --> URI Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Router Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Output Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Security Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Input Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:32:18 --> Language Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Loader Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Controller Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Session Class Initialized
DEBUG - 2019-04-16 17:32:18 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:32:18 --> Session routines successfully run
DEBUG - 2019-04-16 17:32:18 --> Helper loaded: url_helper
ERROR - 2019-04-16 17:32:18 --> 404 Page Not Found --> Order/doOrder
DEBUG - 2019-04-16 17:32:47 --> Config Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:32:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:32:47 --> URI Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Router Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Output Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Security Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Input Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:32:47 --> Language Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Loader Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Controller Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Session Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:32:47 --> Session routines successfully run
DEBUG - 2019-04-16 17:32:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:47 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:32:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:32:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:32:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:32:47 --> Final output sent to browser
DEBUG - 2019-04-16 17:32:47 --> Total execution time: 0.0652
DEBUG - 2019-04-16 17:32:50 --> Config Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:32:50 --> URI Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Router Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Output Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Security Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Input Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:32:50 --> Language Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Loader Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Controller Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Session Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:32:50 --> Session routines successfully run
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:32:50 --> Config Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:32:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:32:50 --> URI Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Router Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Output Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Security Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Input Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:32:50 --> Language Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Loader Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Controller Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Session Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:32:50 --> Session routines successfully run
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Model Class Initialized
DEBUG - 2019-04-16 17:32:50 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:38:42 --> Config Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:38:42 --> URI Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Router Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Output Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Security Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Input Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:38:42 --> Language Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Loader Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Controller Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Session Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:38:42 --> Session routines successfully run
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:38:42 --> Config Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:38:42 --> URI Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Router Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Output Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Security Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Input Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:38:42 --> Language Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Loader Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Controller Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Session Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:38:42 --> Session routines successfully run
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:38:42 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:39:25 --> Config Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:39:25 --> URI Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Router Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Output Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Security Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Input Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:39:25 --> Language Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Loader Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Controller Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Session Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:39:25 --> Session routines successfully run
DEBUG - 2019-04-16 17:39:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:25 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:39:55 --> Config Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:39:55 --> URI Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Router Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Output Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Security Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Input Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:39:55 --> Language Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Loader Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Controller Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Session Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:39:55 --> Session routines successfully run
DEBUG - 2019-04-16 17:39:55 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:55 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:39:58 --> Config Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:39:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:39:58 --> URI Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Router Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Output Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Security Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Input Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:39:58 --> Language Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Loader Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Controller Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Session Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:39:58 --> Session routines successfully run
DEBUG - 2019-04-16 17:39:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:39:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:40:26 --> Config Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:40:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:40:26 --> URI Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Router Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Output Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Security Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Input Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:40:26 --> Language Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Loader Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Controller Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Session Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:40:26 --> Session routines successfully run
DEBUG - 2019-04-16 17:40:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:40:26 --> File loaded: application/views/header.php
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
ERROR - 2019-04-16 17:40:26 --> Severity: Notice  --> Undefined index: UserId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 36
DEBUG - 2019-04-16 17:40:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:40:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:40:26 --> Final output sent to browser
DEBUG - 2019-04-16 17:40:26 --> Total execution time: 0.0630
DEBUG - 2019-04-16 17:40:48 --> Config Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:40:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:40:48 --> URI Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Router Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Output Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Security Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Input Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:40:48 --> Language Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Loader Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Controller Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Session Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:40:48 --> Session routines successfully run
DEBUG - 2019-04-16 17:40:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Model Class Initialized
DEBUG - 2019-04-16 17:40:48 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:40:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:40:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:40:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:40:48 --> Final output sent to browser
DEBUG - 2019-04-16 17:40:48 --> Total execution time: 0.0612
DEBUG - 2019-04-16 17:40:53 --> Config Class Initialized
DEBUG - 2019-04-16 17:40:53 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:40:53 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:40:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:40:53 --> URI Class Initialized
DEBUG - 2019-04-16 17:40:53 --> Router Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Config Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:46:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:46:19 --> URI Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Router Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Output Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Security Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Input Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:46:19 --> Language Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Loader Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Controller Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Session Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:46:19 --> Session routines successfully run
DEBUG - 2019-04-16 17:46:19 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:19 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:46:40 --> Config Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:46:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:46:40 --> URI Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Router Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Output Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Security Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Input Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:46:40 --> Language Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Loader Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Controller Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Session Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:46:40 --> Session routines successfully run
DEBUG - 2019-04-16 17:46:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:46:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:46:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:46:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:46:40 --> Final output sent to browser
DEBUG - 2019-04-16 17:46:40 --> Total execution time: 0.0659
DEBUG - 2019-04-16 17:46:42 --> Config Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:46:42 --> URI Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Router Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Output Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Security Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Input Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:46:42 --> Language Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Loader Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Controller Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Session Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:46:42 --> Session routines successfully run
DEBUG - 2019-04-16 17:46:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Model Class Initialized
DEBUG - 2019-04-16 17:46:42 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:21 --> Config Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:47:21 --> URI Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Router Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Output Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Security Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Input Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:47:21 --> Language Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Loader Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Controller Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Session Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:47:21 --> Session garbage collection performed.
DEBUG - 2019-04-16 17:47:21 --> Session routines successfully run
DEBUG - 2019-04-16 17:47:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:21 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:26 --> Config Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:47:26 --> URI Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Router Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Output Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Security Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Input Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:47:26 --> Language Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Loader Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Controller Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Session Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:47:26 --> Session routines successfully run
DEBUG - 2019-04-16 17:47:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:26 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:47:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:47:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:47:26 --> Final output sent to browser
DEBUG - 2019-04-16 17:47:26 --> Total execution time: 0.0506
DEBUG - 2019-04-16 17:47:27 --> Config Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:47:27 --> URI Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Router Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Output Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Security Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Input Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:47:27 --> Language Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Loader Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Controller Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Session Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:47:27 --> Session routines successfully run
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:27 --> Config Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:47:27 --> URI Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Router Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Output Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Security Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Input Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:47:27 --> Language Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Loader Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Controller Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Session Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:47:27 --> Session routines successfully run
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:27 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:54 --> Config Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:47:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:47:54 --> URI Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Router Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Output Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Security Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Input Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:47:54 --> Language Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Loader Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Controller Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Session Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:47:54 --> Session routines successfully run
DEBUG - 2019-04-16 17:47:54 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Model Class Initialized
DEBUG - 2019-04-16 17:47:54 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:47:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:47:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:47:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:47:54 --> Final output sent to browser
DEBUG - 2019-04-16 17:47:54 --> Total execution time: 0.0547
DEBUG - 2019-04-16 17:48:08 --> Config Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:48:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:48:08 --> URI Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Router Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Output Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Security Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Input Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:48:08 --> Language Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Loader Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Controller Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Session Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:48:08 --> Session routines successfully run
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:48:08 --> Config Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:48:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:48:08 --> URI Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Router Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Output Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Security Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Input Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:48:08 --> Language Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Loader Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Controller Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Session Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:48:08 --> Session routines successfully run
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:08 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:48:43 --> Config Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:48:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:48:43 --> URI Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Router Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Output Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Security Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Input Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:48:43 --> Language Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Loader Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Controller Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Session Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:48:43 --> Session routines successfully run
DEBUG - 2019-04-16 17:48:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:43 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:48:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:48:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:48:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:48:43 --> Final output sent to browser
DEBUG - 2019-04-16 17:48:43 --> Total execution time: 0.0621
DEBUG - 2019-04-16 17:48:44 --> Config Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:48:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:48:44 --> URI Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Router Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Output Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Security Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Input Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:48:44 --> Language Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Loader Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Controller Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Session Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:48:44 --> Session routines successfully run
DEBUG - 2019-04-16 17:48:44 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Model Class Initialized
DEBUG - 2019-04-16 17:48:44 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:48:44 --> Final output sent to browser
DEBUG - 2019-04-16 17:48:44 --> Total execution time: 0.0672
DEBUG - 2019-04-16 17:49:08 --> Config Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:49:08 --> URI Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Router Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Output Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Security Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Input Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:49:08 --> Language Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Loader Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Controller Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Session Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:49:08 --> Session routines successfully run
DEBUG - 2019-04-16 17:49:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:08 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:49:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:49:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:49:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:49:08 --> Final output sent to browser
DEBUG - 2019-04-16 17:49:08 --> Total execution time: 0.0646
DEBUG - 2019-04-16 17:49:09 --> Config Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:49:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:49:09 --> URI Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Router Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Output Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Security Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Input Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:49:09 --> Language Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Loader Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Controller Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Session Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:49:09 --> Session routines successfully run
DEBUG - 2019-04-16 17:49:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:09 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:49:09 --> Final output sent to browser
DEBUG - 2019-04-16 17:49:09 --> Total execution time: 0.0515
DEBUG - 2019-04-16 17:49:40 --> Config Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:49:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:49:40 --> URI Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Router Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Output Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Security Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Input Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:49:40 --> Language Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Loader Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Controller Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Session Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:49:40 --> Session routines successfully run
DEBUG - 2019-04-16 17:49:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:40 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:49:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:49:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:49:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:49:40 --> Final output sent to browser
DEBUG - 2019-04-16 17:49:40 --> Total execution time: 0.0778
DEBUG - 2019-04-16 17:49:41 --> Config Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:49:41 --> URI Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Router Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Output Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Security Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Input Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:49:41 --> Language Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Loader Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Controller Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Session Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:49:41 --> Session routines successfully run
DEBUG - 2019-04-16 17:49:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Model Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:49:41 --> Config Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:49:41 --> URI Class Initialized
DEBUG - 2019-04-16 17:49:41 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:08 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Output Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Security Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Input Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:50:08 --> Language Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Loader Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Controller Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Session Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:50:08 --> Session routines successfully run
DEBUG - 2019-04-16 17:50:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:08 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:50:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:50:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:50:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:50:08 --> Final output sent to browser
DEBUG - 2019-04-16 17:50:08 --> Total execution time: 0.0591
DEBUG - 2019-04-16 17:50:09 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:09 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Output Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Security Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Input Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:50:09 --> Language Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Loader Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Controller Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Session Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:50:09 --> Session routines successfully run
DEBUG - 2019-04-16 17:50:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:50:09 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:09 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:09 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:47 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Output Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Security Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Input Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:50:47 --> Language Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Loader Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Controller Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Session Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:50:47 --> Session routines successfully run
DEBUG - 2019-04-16 17:50:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:47 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:50:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:50:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:50:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:50:47 --> Final output sent to browser
DEBUG - 2019-04-16 17:50:47 --> Total execution time: 0.0642
DEBUG - 2019-04-16 17:50:49 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:49 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Router Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Output Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Security Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Input Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:50:49 --> Language Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Loader Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Controller Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Session Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:50:49 --> Session routines successfully run
DEBUG - 2019-04-16 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Model Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:50:49 --> Config Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:50:49 --> URI Class Initialized
DEBUG - 2019-04-16 17:50:49 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:05 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:05 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:05 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:05 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:51:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:51:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:51:05 --> Final output sent to browser
DEBUG - 2019-04-16 17:51:05 --> Total execution time: 0.0686
DEBUG - 2019-04-16 17:51:06 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:06 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:06 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:06 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:06 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:06 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:06 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:06 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:06 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:51:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:51:06 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:51:06 --> Final output sent to browser
DEBUG - 2019-04-16 17:51:06 --> Total execution time: 0.1194
DEBUG - 2019-04-16 17:51:37 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:37 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:37 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:37 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:37 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:51:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:51:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:51:37 --> Final output sent to browser
DEBUG - 2019-04-16 17:51:37 --> Total execution time: 0.1299
DEBUG - 2019-04-16 17:51:39 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:39 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:39 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:39 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:39 --> Config Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:51:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:51:39 --> URI Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Router Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Output Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Security Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Input Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:51:39 --> Language Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Loader Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Controller Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Session Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:51:39 --> Session routines successfully run
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Model Class Initialized
DEBUG - 2019-04-16 17:51:39 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:51:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:51:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:51:39 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:51:39 --> Final output sent to browser
DEBUG - 2019-04-16 17:51:39 --> Total execution time: 0.1237
DEBUG - 2019-04-16 17:52:59 --> Config Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:52:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:52:59 --> URI Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Router Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Output Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Security Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Input Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:52:59 --> Language Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Loader Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Controller Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Session Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:52:59 --> Session routines successfully run
DEBUG - 2019-04-16 17:52:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Model Class Initialized
DEBUG - 2019-04-16 17:52:59 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:53:07 --> Config Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:53:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:53:07 --> URI Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Router Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Output Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Security Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Input Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:53:07 --> Language Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Loader Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Controller Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Session Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:53:07 --> Session routines successfully run
DEBUG - 2019-04-16 17:53:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:07 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:53:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:53:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:53:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:53:07 --> Final output sent to browser
DEBUG - 2019-04-16 17:53:07 --> Total execution time: 0.0767
DEBUG - 2019-04-16 17:53:58 --> Config Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:53:58 --> URI Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Router Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Output Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Security Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Input Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:53:58 --> Language Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Loader Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Controller Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Session Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:53:58 --> Session routines successfully run
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:53:58 --> Config Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:53:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:53:58 --> URI Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Router Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Output Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Security Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Input Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:53:58 --> Language Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Loader Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Controller Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Session Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:53:58 --> Session routines successfully run
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Model Class Initialized
DEBUG - 2019-04-16 17:53:58 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:53:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:53:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:53:58 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:53:58 --> Final output sent to browser
DEBUG - 2019-04-16 17:53:58 --> Total execution time: 0.0892
DEBUG - 2019-04-16 17:54:00 --> Config Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:54:00 --> URI Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Router Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Output Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Security Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Input Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:54:00 --> Language Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Loader Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Controller Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Session Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:54:00 --> Session routines successfully run
DEBUG - 2019-04-16 17:54:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:00 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:54:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:54:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:54:00 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-16 17:54:00 --> Final output sent to browser
DEBUG - 2019-04-16 17:54:00 --> Total execution time: 0.0984
DEBUG - 2019-04-16 17:54:03 --> Config Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:54:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:54:03 --> URI Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Router Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Output Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Security Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Input Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:54:03 --> Language Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Loader Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Controller Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Session Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:54:03 --> Session routines successfully run
DEBUG - 2019-04-16 17:54:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:03 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:54:03 --> File loaded: application/views/header.php
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
ERROR - 2019-04-16 17:54:03 --> Severity: Notice  --> Undefined index: area C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 37
DEBUG - 2019-04-16 17:54:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:54:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:54:03 --> Final output sent to browser
DEBUG - 2019-04-16 17:54:03 --> Total execution time: 0.0623
DEBUG - 2019-04-16 17:54:22 --> Config Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:54:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:54:22 --> URI Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Router Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Output Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Security Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Input Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:54:22 --> Language Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Loader Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Controller Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Session Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:54:22 --> Session routines successfully run
DEBUG - 2019-04-16 17:54:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Model Class Initialized
DEBUG - 2019-04-16 17:54:22 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:54:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:54:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:54:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:54:22 --> Final output sent to browser
DEBUG - 2019-04-16 17:54:22 --> Total execution time: 0.0569
DEBUG - 2019-04-16 17:56:45 --> Config Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:56:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:56:45 --> URI Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Router Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Output Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Security Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Input Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:56:45 --> Language Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Loader Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Controller Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Session Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:56:45 --> Session routines successfully run
DEBUG - 2019-04-16 17:56:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Model Class Initialized
DEBUG - 2019-04-16 17:56:45 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:57:07 --> Config Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:57:07 --> URI Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Router Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Output Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Security Class Initialized
DEBUG - 2019-04-16 17:57:07 --> Input Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:57:08 --> Language Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Loader Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Controller Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Session Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:57:08 --> Session routines successfully run
DEBUG - 2019-04-16 17:57:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:08 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:57:08 --> File loaded: application/views/header.php
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
ERROR - 2019-04-16 17:57:08 --> Severity: Notice  --> Undefined index: userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 38
DEBUG - 2019-04-16 17:57:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:57:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:57:08 --> Final output sent to browser
DEBUG - 2019-04-16 17:57:08 --> Total execution time: 0.0699
DEBUG - 2019-04-16 17:57:16 --> Config Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:57:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:57:16 --> URI Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Router Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Output Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Security Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Input Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:57:16 --> Language Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Loader Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Controller Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Session Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:57:16 --> Session routines successfully run
DEBUG - 2019-04-16 17:57:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Model Class Initialized
DEBUG - 2019-04-16 17:57:16 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:57:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:57:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:57:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:57:16 --> Final output sent to browser
DEBUG - 2019-04-16 17:57:16 --> Total execution time: 0.0635
DEBUG - 2019-04-16 17:59:12 --> Config Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:59:12 --> URI Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Router Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Output Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Security Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Input Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:59:12 --> Language Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Loader Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Controller Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Session Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:59:12 --> Session routines successfully run
DEBUG - 2019-04-16 17:59:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:12 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:59:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:59:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:59:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-16 17:59:12 --> Final output sent to browser
DEBUG - 2019-04-16 17:59:12 --> Total execution time: 0.0623
DEBUG - 2019-04-16 17:59:14 --> Config Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:59:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:59:14 --> URI Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Router Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Output Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Security Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Input Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:59:14 --> Language Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Loader Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Controller Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Session Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:59:14 --> Session routines successfully run
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:59:14 --> Config Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Hooks Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Utf8 Class Initialized
DEBUG - 2019-04-16 17:59:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-16 17:59:14 --> URI Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Router Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Output Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Security Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Input Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-16 17:59:14 --> Language Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Loader Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Controller Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Database Driver Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Session Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Helper loaded: string_helper
DEBUG - 2019-04-16 17:59:14 --> Session routines successfully run
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-16 17:59:14 --> Helper loaded: url_helper
DEBUG - 2019-04-16 17:59:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-16 17:59:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-16 17:59:14 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-16 17:59:14 --> Final output sent to browser
DEBUG - 2019-04-16 17:59:14 --> Total execution time: 0.0858
