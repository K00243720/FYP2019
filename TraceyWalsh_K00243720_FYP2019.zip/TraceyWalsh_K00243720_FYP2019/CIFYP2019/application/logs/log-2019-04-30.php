<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-30 14:44:38 --> Config Class Initialized
DEBUG - 2019-04-30 14:44:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:44:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:44:38 --> URI Class Initialized
DEBUG - 2019-04-30 14:44:38 --> Router Class Initialized
DEBUG - 2019-04-30 14:44:38 --> No URI present. Default controller set.
DEBUG - 2019-04-30 14:44:38 --> Output Class Initialized
DEBUG - 2019-04-30 14:44:38 --> Security Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Input Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:44:39 --> Language Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Loader Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Controller Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:39 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:44:40 --> Session Class Initialized
DEBUG - 2019-04-30 14:44:40 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:44:40 --> A session cookie was not found.
DEBUG - 2019-04-30 14:44:40 --> Session routines successfully run
DEBUG - 2019-04-30 14:44:40 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:40 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:40 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:44:40 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:44:40 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:44:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:44:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:44:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 14:44:41 --> Final output sent to browser
DEBUG - 2019-04-30 14:44:41 --> Total execution time: 3.6488
DEBUG - 2019-04-30 14:44:50 --> Config Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:44:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:44:50 --> URI Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Router Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Output Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Security Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Input Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:44:50 --> Language Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Loader Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Controller Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Session Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:44:50 --> Session routines successfully run
DEBUG - 2019-04-30 14:44:50 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Model Class Initialized
DEBUG - 2019-04-30 14:44:50 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:44:50 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:44:50 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:44:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:44:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:44:51 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 14:44:51 --> Final output sent to browser
DEBUG - 2019-04-30 14:44:51 --> Total execution time: 0.2665
DEBUG - 2019-04-30 14:45:06 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:06 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:06 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:06 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:06 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:06 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:08 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:08 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:08 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:08 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:08 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:08 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:08 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 14:45:08 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:08 --> Total execution time: 2.1202
DEBUG - 2019-04-30 14:45:11 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:11 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:11 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:11 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:11 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:11 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:11 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:11 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:11 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 14:45:11 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:11 --> Total execution time: 0.1314
DEBUG - 2019-04-30 14:45:12 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:12 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:12 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:12 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:12 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:12 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:12 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:12 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:12 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-30 14:45:12 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:12 --> Total execution time: 0.0912
DEBUG - 2019-04-30 14:45:13 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:13 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:13 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:13 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:13 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:13 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:13 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:13 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 14:45:13 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:13 --> Total execution time: 0.0678
DEBUG - 2019-04-30 14:45:23 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:23 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:23 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:23 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:23 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:23 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:23 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:23 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 14:45:23 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:23 --> Total execution time: 0.6147
DEBUG - 2019-04-30 14:45:28 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:28 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:28 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:28 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:28 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:28 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:28 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:28 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:28 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:28 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:29 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:29 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:29 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:29 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:29 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:29 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 14:45:29 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:29 --> Total execution time: 0.2831
DEBUG - 2019-04-30 14:45:33 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:33 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:33 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:33 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:33 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:33 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:33 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:33 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:33 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 14:45:33 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:33 --> Total execution time: 0.3153
DEBUG - 2019-04-30 14:45:34 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:34 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:34 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:34 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:34 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:34 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:34 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:34 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:34 --> File loaded: application/views/profile.php
DEBUG - 2019-04-30 14:45:34 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:34 --> Total execution time: 0.0989
DEBUG - 2019-04-30 14:45:36 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:36 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:36 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:36 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:36 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:36 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:36 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:36 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:36 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-30 14:45:36 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:36 --> Total execution time: 0.0825
DEBUG - 2019-04-30 14:45:37 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:37 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:37 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:37 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:37 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:37 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Config Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:45:37 --> URI Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Router Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Output Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Security Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Input Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:45:37 --> Language Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Loader Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Controller Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:37 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:45:38 --> Session Class Initialized
DEBUG - 2019-04-30 14:45:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:45:38 --> A session cookie was not found.
DEBUG - 2019-04-30 14:45:38 --> Session routines successfully run
DEBUG - 2019-04-30 14:45:38 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:38 --> Model Class Initialized
DEBUG - 2019-04-30 14:45:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:45:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:45:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:45:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:45:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:45:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 14:45:38 --> Final output sent to browser
DEBUG - 2019-04-30 14:45:38 --> Total execution time: 0.2301
DEBUG - 2019-04-30 14:46:41 --> Config Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Hooks Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Utf8 Class Initialized
DEBUG - 2019-04-30 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 14:46:41 --> URI Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Router Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Output Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Security Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Input Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 14:46:41 --> Language Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Loader Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Controller Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Model Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Model Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Database Driver Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Session Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Helper loaded: string_helper
DEBUG - 2019-04-30 14:46:41 --> Session routines successfully run
DEBUG - 2019-04-30 14:46:41 --> Model Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Model Class Initialized
DEBUG - 2019-04-30 14:46:41 --> Helper loaded: url_helper
DEBUG - 2019-04-30 14:46:41 --> Helper loaded: form_helper
DEBUG - 2019-04-30 14:46:41 --> Form Validation Class Initialized
DEBUG - 2019-04-30 14:46:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 14:46:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 14:46:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 14:46:41 --> Final output sent to browser
DEBUG - 2019-04-30 14:46:41 --> Total execution time: 0.1538
DEBUG - 2019-04-30 15:01:27 --> Config Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:01:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:01:27 --> URI Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Router Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Output Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Security Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Input Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:01:27 --> Language Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Loader Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Controller Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Session Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:01:27 --> Session routines successfully run
DEBUG - 2019-04-30 15:01:27 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:27 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:01:27 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:01:27 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:01:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:01:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:01:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:01:27 --> Final output sent to browser
DEBUG - 2019-04-30 15:01:27 --> Total execution time: 0.3448
DEBUG - 2019-04-30 15:01:37 --> Config Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:01:37 --> URI Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Router Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Output Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Security Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Input Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:01:37 --> Language Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Loader Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Controller Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Session Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:01:37 --> Session routines successfully run
DEBUG - 2019-04-30 15:01:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:37 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:01:37 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:01:37 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:01:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:01:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:01:37 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 15:01:37 --> Final output sent to browser
DEBUG - 2019-04-30 15:01:37 --> Total execution time: 0.0543
DEBUG - 2019-04-30 15:01:46 --> Config Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:01:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:01:46 --> URI Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Router Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Output Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Security Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Input Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:01:46 --> Language Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Loader Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Controller Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Session Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:01:46 --> Session routines successfully run
DEBUG - 2019-04-30 15:01:46 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:46 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:01:46 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:01:46 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:01:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:01:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:01:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-30 15:01:46 --> Final output sent to browser
DEBUG - 2019-04-30 15:01:46 --> Total execution time: 0.2213
DEBUG - 2019-04-30 15:01:50 --> Config Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:01:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:01:50 --> URI Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Router Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Output Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Security Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Input Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:01:50 --> Language Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Loader Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Controller Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Model Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Session Class Initialized
DEBUG - 2019-04-30 15:01:50 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:01:50 --> Session routines successfully run
DEBUG - 2019-04-30 15:01:51 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:01:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:01:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:01:51 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-30 15:01:51 --> Final output sent to browser
DEBUG - 2019-04-30 15:01:51 --> Total execution time: 0.1018
DEBUG - 2019-04-30 15:02:10 --> Config Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:02:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:02:10 --> URI Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Router Class Initialized
DEBUG - 2019-04-30 15:02:10 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:02:10 --> Output Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Security Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Input Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:02:10 --> Language Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Loader Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Controller Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Session Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:02:10 --> Session routines successfully run
DEBUG - 2019-04-30 15:02:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:02:10 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:02:10 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:02:10 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:02:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:02:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:02:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:02:10 --> Final output sent to browser
DEBUG - 2019-04-30 15:02:10 --> Total execution time: 0.1993
DEBUG - 2019-04-30 15:07:37 --> Config Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:07:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:07:37 --> URI Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Router Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Output Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Security Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Input Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:07:37 --> Language Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Loader Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Controller Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Session Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:07:37 --> Session routines successfully run
DEBUG - 2019-04-30 15:07:37 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:07:37 --> Upload Class Initialized
DEBUG - 2019-04-30 15:07:37 --> Image Lib Class Initialized
DEBUG - 2019-04-30 15:07:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:07:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:07:37 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-30 15:07:37 --> Final output sent to browser
DEBUG - 2019-04-30 15:07:37 --> Total execution time: 0.5054
DEBUG - 2019-04-30 15:07:40 --> Config Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:07:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:07:40 --> URI Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Router Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Output Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Security Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Input Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:07:40 --> Language Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Loader Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Controller Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Session Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:07:40 --> Session routines successfully run
DEBUG - 2019-04-30 15:07:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:40 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:07:40 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:07:40 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:07:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:07:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:07:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:07:40 --> Final output sent to browser
DEBUG - 2019-04-30 15:07:40 --> Total execution time: 0.0784
DEBUG - 2019-04-30 15:07:50 --> Config Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:07:50 --> URI Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Router Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Output Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Security Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Input Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:07:50 --> Language Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Loader Class Initialized
DEBUG - 2019-04-30 15:07:50 --> Controller Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Session Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:07:51 --> Session routines successfully run
DEBUG - 2019-04-30 15:07:51 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:51 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:07:51 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:07:51 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:07:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:07:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:07:51 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-30 15:07:51 --> Final output sent to browser
DEBUG - 2019-04-30 15:07:51 --> Total execution time: 0.1957
DEBUG - 2019-04-30 15:07:57 --> Config Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:07:57 --> URI Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Router Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Output Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Security Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Input Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:07:57 --> Language Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Loader Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Controller Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Session Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:07:57 --> Session routines successfully run
DEBUG - 2019-04-30 15:07:57 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Model Class Initialized
DEBUG - 2019-04-30 15:07:57 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:07:57 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:07:57 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:07:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:07:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:07:57 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-30 15:07:57 --> Final output sent to browser
DEBUG - 2019-04-30 15:07:57 --> Total execution time: 0.1384
DEBUG - 2019-04-30 15:08:28 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:28 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:28 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:28 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:28 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:28 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:08:28 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:08:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:08:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:08:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:08:28 --> Final output sent to browser
DEBUG - 2019-04-30 15:08:28 --> Total execution time: 0.0604
DEBUG - 2019-04-30 15:08:35 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:35 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:35 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:35 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:35 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:35 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:08:35 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:08:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:08:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:08:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:08:35 --> Final output sent to browser
DEBUG - 2019-04-30 15:08:35 --> Total execution time: 0.0668
DEBUG - 2019-04-30 15:08:38 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:38 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:38 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:38 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:08:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:38 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:38 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:38 --> A session cookie was not found.
DEBUG - 2019-04-30 15:08:39 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:39 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:39 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:08:39 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:08:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:08:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:08:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:08:39 --> Final output sent to browser
DEBUG - 2019-04-30 15:08:39 --> Total execution time: 0.9221
DEBUG - 2019-04-30 15:08:49 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:49 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:49 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:49 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:49 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:49 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:49 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:08:49 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:08:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:08:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:08:50 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:08:50 --> Final output sent to browser
DEBUG - 2019-04-30 15:08:50 --> Total execution time: 0.1386
DEBUG - 2019-04-30 15:08:55 --> Config Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:08:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:08:55 --> URI Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Router Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Output Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Security Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Input Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:08:55 --> Language Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Loader Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Controller Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Model Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Session Class Initialized
DEBUG - 2019-04-30 15:08:55 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:08:55 --> Session routines successfully run
DEBUG - 2019-04-30 15:08:55 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:08:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:08:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:08:55 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:08:55 --> Final output sent to browser
DEBUG - 2019-04-30 15:08:55 --> Total execution time: 0.0699
DEBUG - 2019-04-30 15:09:02 --> Config Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:09:02 --> URI Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Router Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Output Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Security Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Input Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:09:02 --> Language Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Loader Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Controller Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Session Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:09:02 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:09:02 --> Session routines successfully run
DEBUG - 2019-04-30 15:09:02 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:02 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:09:02 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:09:02 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:09:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:09:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:09:02 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 15:09:02 --> Final output sent to browser
DEBUG - 2019-04-30 15:09:02 --> Total execution time: 0.2699
DEBUG - 2019-04-30 15:09:04 --> Config Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:09:04 --> URI Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Router Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Output Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Security Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Input Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:09:04 --> Language Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Loader Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Controller Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Session Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:09:04 --> Session routines successfully run
DEBUG - 2019-04-30 15:09:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:09:04 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:09:04 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:09:04 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:09:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:09:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:09:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:09:04 --> Final output sent to browser
DEBUG - 2019-04-30 15:09:04 --> Total execution time: 0.2281
DEBUG - 2019-04-30 15:10:10 --> Config Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:10:10 --> URI Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Router Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Output Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Security Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Input Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:10:10 --> Language Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Loader Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Controller Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Session Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:10:10 --> Session routines successfully run
DEBUG - 2019-04-30 15:10:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:10 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:10:10 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:10:10 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:10:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:10:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:10:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:10:10 --> Final output sent to browser
DEBUG - 2019-04-30 15:10:10 --> Total execution time: 0.1881
DEBUG - 2019-04-30 15:10:12 --> Config Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:10:12 --> URI Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Router Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Output Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Security Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Input Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:10:12 --> Language Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Loader Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Controller Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Session Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:10:12 --> Session routines successfully run
DEBUG - 2019-04-30 15:10:12 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:12 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:10:12 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:10:12 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:10:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:10:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:10:12 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:10:12 --> Final output sent to browser
DEBUG - 2019-04-30 15:10:12 --> Total execution time: 0.0572
DEBUG - 2019-04-30 15:10:13 --> Config Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:10:13 --> URI Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Router Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Output Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Security Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Input Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:10:13 --> Language Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Loader Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Controller Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Session Class Initialized
DEBUG - 2019-04-30 15:10:13 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:10:13 --> Session routines successfully run
DEBUG - 2019-04-30 15:10:13 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:10:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:10:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:10:13 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:10:13 --> Final output sent to browser
DEBUG - 2019-04-30 15:10:13 --> Total execution time: 0.0643
DEBUG - 2019-04-30 15:10:20 --> Config Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:10:20 --> URI Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Router Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Output Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Security Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Input Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:10:20 --> Language Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Loader Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Controller Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Model Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Session Class Initialized
DEBUG - 2019-04-30 15:10:20 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:10:20 --> Session routines successfully run
DEBUG - 2019-04-30 15:10:20 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:10:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:10:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:10:20 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:10:20 --> Final output sent to browser
DEBUG - 2019-04-30 15:10:20 --> Total execution time: 0.0422
DEBUG - 2019-04-30 15:11:01 --> Config Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:11:01 --> URI Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Router Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Output Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Security Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Input Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:11:01 --> Language Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Loader Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Controller Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Model Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Model Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Model Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Session Class Initialized
DEBUG - 2019-04-30 15:11:01 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:11:01 --> Session routines successfully run
DEBUG - 2019-04-30 15:11:01 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:11:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:11:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:11:01 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:11:01 --> Final output sent to browser
DEBUG - 2019-04-30 15:11:01 --> Total execution time: 0.0668
DEBUG - 2019-04-30 15:12:06 --> Config Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:12:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:12:06 --> URI Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Router Class Initialized
DEBUG - 2019-04-30 15:12:06 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:12:06 --> Output Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Security Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Input Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:12:06 --> Language Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Loader Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Controller Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Session Class Initialized
DEBUG - 2019-04-30 15:12:06 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:12:06 --> A session cookie was not found.
DEBUG - 2019-04-30 15:12:07 --> Session routines successfully run
DEBUG - 2019-04-30 15:12:07 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:07 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:07 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:12:07 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:12:07 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:12:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:12:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:12:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:12:07 --> Final output sent to browser
DEBUG - 2019-04-30 15:12:07 --> Total execution time: 1.6274
DEBUG - 2019-04-30 15:12:52 --> Config Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:12:52 --> URI Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Router Class Initialized
DEBUG - 2019-04-30 15:12:52 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:12:52 --> Output Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Security Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Input Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:12:52 --> Language Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Loader Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Controller Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Session Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:12:52 --> Session routines successfully run
DEBUG - 2019-04-30 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:12:52 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:12:52 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:12:52 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:12:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:12:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:12:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:12:52 --> Final output sent to browser
DEBUG - 2019-04-30 15:12:52 --> Total execution time: 0.2595
DEBUG - 2019-04-30 15:13:52 --> Config Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:13:52 --> URI Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Router Class Initialized
DEBUG - 2019-04-30 15:13:52 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:13:52 --> Output Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Security Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Input Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:13:52 --> Language Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Loader Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Controller Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Session Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:13:52 --> Session routines successfully run
DEBUG - 2019-04-30 15:13:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Model Class Initialized
DEBUG - 2019-04-30 15:13:52 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:13:52 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:13:52 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:13:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:13:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:13:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:13:53 --> Final output sent to browser
DEBUG - 2019-04-30 15:13:53 --> Total execution time: 0.1406
DEBUG - 2019-04-30 15:14:03 --> Config Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:14:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:14:03 --> URI Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Router Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Output Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Security Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Input Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:14:03 --> Language Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Loader Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Controller Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Session Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:14:03 --> Session routines successfully run
DEBUG - 2019-04-30 15:14:03 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:03 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:14:03 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:14:03 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:14:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:14:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:14:03 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:14:03 --> Final output sent to browser
DEBUG - 2019-04-30 15:14:03 --> Total execution time: 0.0588
DEBUG - 2019-04-30 15:14:08 --> Config Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:14:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:14:08 --> URI Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Router Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Output Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Security Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Input Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:14:08 --> Language Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Loader Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Controller Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Session Class Initialized
DEBUG - 2019-04-30 15:14:08 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:14:08 --> Session routines successfully run
DEBUG - 2019-04-30 15:14:08 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:14:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:14:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:14:08 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:14:08 --> Final output sent to browser
DEBUG - 2019-04-30 15:14:08 --> Total execution time: 0.0949
DEBUG - 2019-04-30 15:14:11 --> Config Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:14:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:14:11 --> URI Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Router Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Output Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Security Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Input Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:14:11 --> Language Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Loader Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Controller Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Session Class Initialized
DEBUG - 2019-04-30 15:14:11 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:14:11 --> Session routines successfully run
DEBUG - 2019-04-30 15:14:11 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:14:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:14:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:14:11 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:14:11 --> Final output sent to browser
DEBUG - 2019-04-30 15:14:11 --> Total execution time: 0.0491
DEBUG - 2019-04-30 15:14:16 --> Config Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:14:16 --> URI Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Router Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Output Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Security Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Input Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:14:16 --> Language Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Loader Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Controller Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Session Class Initialized
DEBUG - 2019-04-30 15:14:16 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:14:16 --> Session routines successfully run
DEBUG - 2019-04-30 15:14:16 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:14:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:14:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:14:16 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:14:16 --> Final output sent to browser
DEBUG - 2019-04-30 15:14:16 --> Total execution time: 0.0565
DEBUG - 2019-04-30 15:14:19 --> Config Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:14:19 --> URI Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Router Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Output Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Security Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Input Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:14:19 --> Language Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Loader Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Controller Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Session Class Initialized
DEBUG - 2019-04-30 15:14:19 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:14:19 --> Session routines successfully run
DEBUG - 2019-04-30 15:14:19 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:14:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:14:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:14:19 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:14:19 --> Final output sent to browser
DEBUG - 2019-04-30 15:14:19 --> Total execution time: 0.0612
DEBUG - 2019-04-30 15:16:16 --> Config Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:16:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:16:16 --> URI Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Router Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Output Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Security Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Input Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:16:16 --> Language Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Loader Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Controller Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Session Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:16:16 --> Session routines successfully run
DEBUG - 2019-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:16 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:16:16 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:16:16 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:16:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:16:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:16:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:16:16 --> Final output sent to browser
DEBUG - 2019-04-30 15:16:16 --> Total execution time: 0.2151
DEBUG - 2019-04-30 15:16:19 --> Config Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:16:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:16:19 --> URI Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Router Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Output Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Security Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Input Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:16:19 --> Language Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Loader Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Controller Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Session Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:16:19 --> Session routines successfully run
DEBUG - 2019-04-30 15:16:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:19 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:16:19 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:16:19 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:16:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:16:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:16:19 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 15:16:19 --> Final output sent to browser
DEBUG - 2019-04-30 15:16:19 --> Total execution time: 0.0605
DEBUG - 2019-04-30 15:16:21 --> Config Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:16:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:16:21 --> URI Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Router Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Output Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Security Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Input Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:16:21 --> Language Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Loader Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Controller Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Session Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:16:21 --> Session routines successfully run
DEBUG - 2019-04-30 15:16:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:21 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:16:21 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:16:21 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:16:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:16:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:16:21 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:16:21 --> Final output sent to browser
DEBUG - 2019-04-30 15:16:21 --> Total execution time: 0.2050
DEBUG - 2019-04-30 15:16:24 --> Config Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:16:24 --> URI Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Router Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Output Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Security Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Input Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:16:24 --> Language Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Loader Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Controller Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Session Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:16:24 --> Session routines successfully run
DEBUG - 2019-04-30 15:16:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:24 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:16:24 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:16:24 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:16:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:16:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:16:24 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:16:24 --> Final output sent to browser
DEBUG - 2019-04-30 15:16:24 --> Total execution time: 0.0525
DEBUG - 2019-04-30 15:16:54 --> Config Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:16:54 --> URI Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Router Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Output Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Security Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Input Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:16:54 --> Language Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Loader Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Controller Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Session Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:16:54 --> Session routines successfully run
DEBUG - 2019-04-30 15:16:54 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Model Class Initialized
DEBUG - 2019-04-30 15:16:54 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:16:54 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:16:54 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:16:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:16:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:16:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:16:54 --> Final output sent to browser
DEBUG - 2019-04-30 15:16:54 --> Total execution time: 0.1491
DEBUG - 2019-04-30 15:17:24 --> Config Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:17:24 --> URI Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Router Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Output Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Security Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Input Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:17:24 --> Language Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Loader Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Controller Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Session Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:17:24 --> Session routines successfully run
DEBUG - 2019-04-30 15:17:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Model Class Initialized
DEBUG - 2019-04-30 15:17:24 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:17:24 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:17:24 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:17:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:17:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:17:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:17:25 --> Final output sent to browser
DEBUG - 2019-04-30 15:17:25 --> Total execution time: 1.0141
DEBUG - 2019-04-30 15:21:28 --> Config Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:21:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:21:28 --> URI Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Router Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Output Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Security Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Input Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:21:28 --> Language Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Loader Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Controller Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Session Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:21:28 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:21:28 --> Session routines successfully run
DEBUG - 2019-04-30 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:28 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:21:28 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:21:28 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:21:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:21:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:21:28 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:21:28 --> Final output sent to browser
DEBUG - 2019-04-30 15:21:28 --> Total execution time: 0.0570
DEBUG - 2019-04-30 15:21:48 --> Config Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:21:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:21:48 --> URI Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Router Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Output Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Security Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Input Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:21:48 --> Language Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Loader Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Controller Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Session Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:21:48 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:21:48 --> Session routines successfully run
DEBUG - 2019-04-30 15:21:48 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Model Class Initialized
DEBUG - 2019-04-30 15:21:48 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:21:48 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:21:48 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:21:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:21:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:21:48 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:21:48 --> Final output sent to browser
DEBUG - 2019-04-30 15:21:48 --> Total execution time: 0.0632
DEBUG - 2019-04-30 15:22:05 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:05 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:05 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:05 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:22:05 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:05 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:05 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:05 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:05 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:05 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:22:05 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:05 --> Total execution time: 0.0660
DEBUG - 2019-04-30 15:22:16 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:16 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:16 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:16 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:16 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:16 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:16 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:16 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:22:16 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:16 --> Total execution time: 0.0875
DEBUG - 2019-04-30 15:22:18 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:18 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:18 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:18 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:18 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:18 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:18 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-30 15:22:18 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:18 --> Total execution time: 0.0601
DEBUG - 2019-04-30 15:22:30 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:30 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:30 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:22:30 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:30 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:30 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:30 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:30 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:30 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:30 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:22:30 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:30 --> Total execution time: 0.2857
DEBUG - 2019-04-30 15:22:32 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:32 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:32 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:32 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:32 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:32 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:32 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:32 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:32 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:22:32 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:32 --> Total execution time: 0.0582
DEBUG - 2019-04-30 15:22:37 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:37 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:37 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:38 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:38 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 15:22:38 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:38 --> Total execution time: 0.0948
DEBUG - 2019-04-30 15:22:44 --> Config Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:22:45 --> URI Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Router Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Output Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Security Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Input Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:22:45 --> Language Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Loader Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Controller Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Session Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:22:45 --> Session routines successfully run
DEBUG - 2019-04-30 15:22:45 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Model Class Initialized
DEBUG - 2019-04-30 15:22:45 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:22:45 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:22:45 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:22:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:22:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:22:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:22:45 --> Final output sent to browser
DEBUG - 2019-04-30 15:22:45 --> Total execution time: 0.1784
DEBUG - 2019-04-30 15:23:25 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:25 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:25 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:25 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:25 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:25 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:25 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:23:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:23:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:23:25 --> Final output sent to browser
DEBUG - 2019-04-30 15:23:25 --> Total execution time: 0.0626
DEBUG - 2019-04-30 15:23:26 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:26 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:26 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:26 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:26 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:26 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:26 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:26 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:23:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:23:26 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 15:23:26 --> Final output sent to browser
DEBUG - 2019-04-30 15:23:26 --> Total execution time: 0.1892
DEBUG - 2019-04-30 15:23:33 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:33 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:33 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:33 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:33 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:33 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:33 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:23:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:23:33 --> File loaded: application/views/profile.php
DEBUG - 2019-04-30 15:23:33 --> Final output sent to browser
DEBUG - 2019-04-30 15:23:33 --> Total execution time: 0.0955
DEBUG - 2019-04-30 15:23:38 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:38 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:38 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:38 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:23:38 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:38 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:38 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:38 --> A session cookie was not found.
DEBUG - 2019-04-30 15:23:38 --> Session garbage collection performed.
DEBUG - 2019-04-30 15:23:38 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:23:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:23:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:23:38 --> Final output sent to browser
DEBUG - 2019-04-30 15:23:38 --> Total execution time: 0.2147
DEBUG - 2019-04-30 15:23:39 --> Config Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:23:39 --> URI Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Router Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Output Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Security Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Input Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:23:39 --> Language Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Loader Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Controller Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Session Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:23:39 --> Session routines successfully run
DEBUG - 2019-04-30 15:23:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Model Class Initialized
DEBUG - 2019-04-30 15:23:39 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:23:39 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:23:39 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:23:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:23:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:23:39 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:23:39 --> Final output sent to browser
DEBUG - 2019-04-30 15:23:39 --> Total execution time: 0.0474
DEBUG - 2019-04-30 15:24:06 --> Config Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:24:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:24:06 --> URI Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Router Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Output Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Security Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Input Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:24:06 --> Language Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Loader Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Controller Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Session Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:24:06 --> Session routines successfully run
DEBUG - 2019-04-30 15:24:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Model Class Initialized
DEBUG - 2019-04-30 15:24:06 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:24:06 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:24:06 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:24:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:24:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:24:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:24:07 --> Final output sent to browser
DEBUG - 2019-04-30 15:24:07 --> Total execution time: 0.1804
DEBUG - 2019-04-30 15:30:04 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:04 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:04 --> No URI present. Default controller set.
DEBUG - 2019-04-30 15:30:04 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:04 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:04 --> A session cookie was not found.
DEBUG - 2019-04-30 15:30:04 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:04 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:04 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:04 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:30:04 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:04 --> Total execution time: 0.1673
DEBUG - 2019-04-30 15:30:15 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:15 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:15 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:15 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:15 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:15 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:15 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:15 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:15 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 15:30:15 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:15 --> Total execution time: 0.0726
DEBUG - 2019-04-30 15:30:18 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:18 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:18 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:18 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:18 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:18 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:18 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:18 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 15:30:18 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:18 --> Total execution time: 0.0525
DEBUG - 2019-04-30 15:30:19 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:19 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:19 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:19 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:19 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:19 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:19 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:19 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 15:30:19 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:19 --> Total execution time: 0.0658
DEBUG - 2019-04-30 15:30:21 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:21 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:21 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:21 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:21 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:21 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:21 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:21 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-30 15:30:21 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:21 --> Total execution time: 0.0803
DEBUG - 2019-04-30 15:30:25 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:25 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:25 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:25 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:25 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:25 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:25 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:25 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 15:30:25 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:25 --> Total execution time: 0.0534
DEBUG - 2019-04-30 15:30:33 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:33 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:33 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:33 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:33 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:33 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:33 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:30:33 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:33 --> Total execution time: 0.1699
DEBUG - 2019-04-30 15:30:35 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:35 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:35 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:35 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:35 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:35 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:35 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 15:30:35 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:35 --> Total execution time: 0.0534
DEBUG - 2019-04-30 15:30:36 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:36 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:36 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:36 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:36 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:36 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:36 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:36 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:36 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 15:30:36 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:36 --> Total execution time: 0.1444
DEBUG - 2019-04-30 15:30:38 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:38 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:38 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:38 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:38 --> File loaded: application/views/profile.php
DEBUG - 2019-04-30 15:30:38 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:38 --> Total execution time: 0.0572
DEBUG - 2019-04-30 15:30:40 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:40 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:40 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:40 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:40 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Config Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Hooks Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Utf8 Class Initialized
DEBUG - 2019-04-30 15:30:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 15:30:40 --> URI Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Router Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Output Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Security Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Input Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 15:30:40 --> Language Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Loader Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Controller Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Database Driver Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Session Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: string_helper
DEBUG - 2019-04-30 15:30:40 --> A session cookie was not found.
DEBUG - 2019-04-30 15:30:40 --> Session routines successfully run
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Model Class Initialized
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: url_helper
DEBUG - 2019-04-30 15:30:40 --> Helper loaded: form_helper
DEBUG - 2019-04-30 15:30:40 --> Form Validation Class Initialized
DEBUG - 2019-04-30 15:30:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 15:30:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 15:30:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 15:30:40 --> Final output sent to browser
DEBUG - 2019-04-30 15:30:40 --> Total execution time: 0.1632
DEBUG - 2019-04-30 16:01:40 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:40 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:40 --> No URI present. Default controller set.
DEBUG - 2019-04-30 16:01:40 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:40 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:40 --> A session cookie was not found.
DEBUG - 2019-04-30 16:01:40 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:40 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:40 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:40 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:40 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 16:01:40 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:40 --> Total execution time: 0.1304
DEBUG - 2019-04-30 16:01:44 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:44 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:44 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:44 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:44 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:44 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:44 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:44 --> File loaded: application/views/marketBasic.php
DEBUG - 2019-04-30 16:01:44 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:44 --> Total execution time: 0.0606
DEBUG - 2019-04-30 16:01:48 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:48 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:48 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:48 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:48 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:49 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:49 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:49 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 16:01:49 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:49 --> Total execution time: 0.0689
DEBUG - 2019-04-30 16:01:52 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:52 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:52 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:52 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:52 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:52 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:52 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:52 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:52 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-30 16:01:52 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:52 --> Total execution time: 0.0656
DEBUG - 2019-04-30 16:01:57 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:57 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:57 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:57 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:57 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:57 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:57 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:57 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 16:01:57 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:57 --> Total execution time: 0.0572
DEBUG - 2019-04-30 16:01:59 --> Config Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:01:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:01:59 --> URI Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Router Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Output Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Security Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Input Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:01:59 --> Language Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Loader Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Controller Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Session Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:01:59 --> Session routines successfully run
DEBUG - 2019-04-30 16:01:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:01:59 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:01:59 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:01:59 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:01:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:01:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:01:59 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-30 16:01:59 --> Final output sent to browser
DEBUG - 2019-04-30 16:01:59 --> Total execution time: 0.0581
DEBUG - 2019-04-30 16:02:01 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:01 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:01 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:01 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:01 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:01 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:01 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:01 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:01 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 16:02:01 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:01 --> Total execution time: 0.0749
DEBUG - 2019-04-30 16:02:08 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:08 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:08 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:08 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:08 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:08 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:08 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:08 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 16:02:08 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:08 --> Total execution time: 0.1080
DEBUG - 2019-04-30 16:02:11 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:11 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:11 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:11 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:11 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:11 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:11 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:11 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:02:11 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:11 --> Total execution time: 0.0902
DEBUG - 2019-04-30 16:02:18 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:18 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:18 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:18 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:18 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:18 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:18 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:18 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:18 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:02:18 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:18 --> Total execution time: 0.1031
DEBUG - 2019-04-30 16:02:23 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:23 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:23 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:23 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:23 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:23 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:23 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:23 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:23 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:23 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:23 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:23 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:23 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:02:23 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:23 --> Total execution time: 0.1036
DEBUG - 2019-04-30 16:02:25 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:25 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:25 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:25 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:25 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:25 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:25 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:25 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:26 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:02:26 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:26 --> Total execution time: 0.0995
DEBUG - 2019-04-30 16:02:27 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:27 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:27 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:27 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:27 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:27 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:27 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:27 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 16:02:27 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:27 --> Total execution time: 0.0570
DEBUG - 2019-04-30 16:02:29 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:29 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:29 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:29 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:29 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Config Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:02:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:02:29 --> URI Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Router Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Output Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Security Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Input Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:02:29 --> Language Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Loader Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Controller Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Session Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:02:29 --> Session routines successfully run
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Model Class Initialized
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:02:29 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:02:29 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:02:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:02:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:02:29 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:02:29 --> Final output sent to browser
DEBUG - 2019-04-30 16:02:29 --> Total execution time: 0.0916
DEBUG - 2019-04-30 16:04:11 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:11 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:11 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:11 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:11 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:11 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:11 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:11 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:11 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:11 --> Total execution time: 0.0956
DEBUG - 2019-04-30 16:04:17 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:17 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:17 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:17 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:17 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:17 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:17 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:17 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:17 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:17 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:17 --> Total execution time: 0.1031
DEBUG - 2019-04-30 16:04:19 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:19 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:19 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:19 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:19 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:19 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:19 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:19 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:19 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:20 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:20 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:20 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:20 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:20 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:20 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:20 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:20 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:20 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:20 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:20 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:20 --> Total execution time: 0.1159
DEBUG - 2019-04-30 16:04:35 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:35 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:35 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:35 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:35 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:35 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:35 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:35 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 16:04:35 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:35 --> Total execution time: 0.0727
DEBUG - 2019-04-30 16:04:37 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:37 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:37 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:37 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:37 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:37 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:37 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:37 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:37 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:37 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:37 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:37 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:37 --> Total execution time: 0.0982
DEBUG - 2019-04-30 16:04:46 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:46 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:46 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:46 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:46 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:46 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:46 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:46 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:46 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:46 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:46 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:46 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:47 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:47 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:47 --> Total execution time: 0.1204
DEBUG - 2019-04-30 16:04:48 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:48 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:48 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:48 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:48 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:48 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:48 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 16:04:48 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:48 --> Total execution time: 0.0622
DEBUG - 2019-04-30 16:04:50 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:50 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:50 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:50 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:50 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:50 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:50 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:50 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:50 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:50 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:50 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:50 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:50 --> Total execution time: 0.0773
DEBUG - 2019-04-30 16:04:57 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:57 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:57 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:57 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:57 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:57 --> Config Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:04:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:04:57 --> URI Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Router Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Output Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Security Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Input Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:04:57 --> Language Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Loader Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Controller Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:57 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:04:58 --> Session Class Initialized
DEBUG - 2019-04-30 16:04:58 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:04:58 --> Session routines successfully run
DEBUG - 2019-04-30 16:04:58 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:58 --> Model Class Initialized
DEBUG - 2019-04-30 16:04:58 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:04:58 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:04:58 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:04:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:04:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:04:58 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:04:58 --> Final output sent to browser
DEBUG - 2019-04-30 16:04:58 --> Total execution time: 0.0806
DEBUG - 2019-04-30 16:07:44 --> Config Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:07:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:07:44 --> URI Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Router Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Output Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Security Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Input Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:07:44 --> Language Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Loader Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Controller Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Session Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:07:44 --> Session routines successfully run
DEBUG - 2019-04-30 16:07:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Model Class Initialized
DEBUG - 2019-04-30 16:07:44 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:07:44 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:07:44 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:07:44 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:07:44 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:07:44 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 8
DEBUG - 2019-04-30 16:07:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:07:44 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:07:44 --> Final output sent to browser
DEBUG - 2019-04-30 16:07:44 --> Total execution time: 0.2814
DEBUG - 2019-04-30 16:08:59 --> Config Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:08:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:08:59 --> URI Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Router Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Output Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Security Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Input Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:08:59 --> Language Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Loader Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Controller Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Session Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:08:59 --> Session routines successfully run
DEBUG - 2019-04-30 16:08:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:08:59 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:08:59 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:08:59 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:08:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:08:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:08:59 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:08:59 --> Final output sent to browser
DEBUG - 2019-04-30 16:08:59 --> Total execution time: 0.1215
DEBUG - 2019-04-30 16:10:25 --> Config Class Initialized
DEBUG - 2019-04-30 16:10:25 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:10:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:10:26 --> URI Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Router Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Output Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Security Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Input Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:10:26 --> Language Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Loader Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Controller Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Model Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Model Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Session Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:10:26 --> Session routines successfully run
DEBUG - 2019-04-30 16:10:26 --> Model Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Model Class Initialized
DEBUG - 2019-04-30 16:10:26 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:10:26 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:10:26 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:10:26 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:10:26 --> Severity: Notice  --> Undefined variable: Detail C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
ERROR - 2019-04-30 16:10:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 25
DEBUG - 2019-04-30 16:10:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:10:26 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:10:26 --> Final output sent to browser
DEBUG - 2019-04-30 16:10:26 --> Total execution time: 0.1231
DEBUG - 2019-04-30 16:11:59 --> Config Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:11:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:11:59 --> URI Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Router Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Output Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Security Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Input Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:11:59 --> Language Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Loader Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Controller Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Session Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:11:59 --> Session routines successfully run
DEBUG - 2019-04-30 16:11:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Model Class Initialized
DEBUG - 2019-04-30 16:11:59 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:11:59 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:11:59 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:12:00 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:12:00 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
DEBUG - 2019-04-30 16:12:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:12:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:12:00 --> Final output sent to browser
DEBUG - 2019-04-30 16:12:00 --> Total execution time: 0.1633
DEBUG - 2019-04-30 16:12:02 --> Config Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:12:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:12:02 --> URI Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Router Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Output Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Security Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Input Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:12:02 --> Language Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Loader Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Controller Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Model Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Model Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Session Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:12:02 --> Session routines successfully run
DEBUG - 2019-04-30 16:12:02 --> Model Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Model Class Initialized
DEBUG - 2019-04-30 16:12:02 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:12:02 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:12:02 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:12:02 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:12:02 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:12:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
DEBUG - 2019-04-30 16:12:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:12:02 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:12:02 --> Final output sent to browser
DEBUG - 2019-04-30 16:12:02 --> Total execution time: 0.0896
DEBUG - 2019-04-30 16:18:36 --> Config Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:18:36 --> URI Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Router Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Output Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Security Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Input Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:18:36 --> Language Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Loader Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Controller Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Session Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:18:36 --> Session garbage collection performed.
DEBUG - 2019-04-30 16:18:36 --> Session routines successfully run
DEBUG - 2019-04-30 16:18:36 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:36 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:18:36 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:18:36 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:18:36 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:18:36 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:36 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
DEBUG - 2019-04-30 16:18:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:18:36 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:18:36 --> Final output sent to browser
DEBUG - 2019-04-30 16:18:36 --> Total execution time: 0.2041
DEBUG - 2019-04-30 16:18:54 --> Config Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:18:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:18:54 --> URI Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Router Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Output Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Security Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Input Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:18:54 --> Language Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Loader Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Controller Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Session Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:18:54 --> Session routines successfully run
DEBUG - 2019-04-30 16:18:54 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Model Class Initialized
DEBUG - 2019-04-30 16:18:54 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:18:54 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:18:54 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:18:54 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
DEBUG - 2019-04-30 16:18:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:18:54 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:18:54 --> Final output sent to browser
DEBUG - 2019-04-30 16:18:54 --> Total execution time: 0.1151
DEBUG - 2019-04-30 16:20:12 --> Config Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:20:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:20:12 --> URI Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Router Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Output Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Security Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Input Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:20:12 --> Language Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Loader Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Controller Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Model Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Model Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Session Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:20:12 --> Session routines successfully run
DEBUG - 2019-04-30 16:20:12 --> Model Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Model Class Initialized
DEBUG - 2019-04-30 16:20:12 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:20:12 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:20:12 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:20:12 --> File loaded: application/views/header.php
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 7
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Notice  --> Undefined variable: Details C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
ERROR - 2019-04-30 16:20:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 26
DEBUG - 2019-04-30 16:20:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:20:12 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:20:12 --> Final output sent to browser
DEBUG - 2019-04-30 16:20:12 --> Total execution time: 0.1184
DEBUG - 2019-04-30 16:24:48 --> Config Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:24:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:24:48 --> URI Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Router Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Output Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Security Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Input Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:24:48 --> Language Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Loader Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Controller Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Session Class Initialized
DEBUG - 2019-04-30 16:24:48 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:24:49 --> Session routines successfully run
DEBUG - 2019-04-30 16:24:49 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:49 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:49 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:24:49 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:24:49 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:24:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:24:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:24:49 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 16:24:49 --> Final output sent to browser
DEBUG - 2019-04-30 16:24:49 --> Total execution time: 1.1703
DEBUG - 2019-04-30 16:24:55 --> Config Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:24:55 --> URI Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Router Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Output Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Security Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Input Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:24:55 --> Language Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Loader Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Controller Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Session Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:24:55 --> Session routines successfully run
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:24:55 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Config Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Hooks Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Utf8 Class Initialized
DEBUG - 2019-04-30 16:24:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 16:24:55 --> URI Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Router Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Output Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Security Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Input Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 16:24:55 --> Language Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Loader Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Controller Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Database Driver Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Session Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: string_helper
DEBUG - 2019-04-30 16:24:55 --> A session cookie was not found.
DEBUG - 2019-04-30 16:24:55 --> Session routines successfully run
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Model Class Initialized
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: url_helper
DEBUG - 2019-04-30 16:24:55 --> Helper loaded: form_helper
DEBUG - 2019-04-30 16:24:55 --> Form Validation Class Initialized
DEBUG - 2019-04-30 16:24:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 16:24:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 16:24:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 16:24:56 --> Final output sent to browser
DEBUG - 2019-04-30 16:24:56 --> Total execution time: 0.1780
DEBUG - 2019-04-30 17:16:37 --> Config Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:16:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:16:37 --> URI Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Router Class Initialized
DEBUG - 2019-04-30 17:16:37 --> No URI present. Default controller set.
DEBUG - 2019-04-30 17:16:37 --> Output Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Security Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Input Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:16:37 --> Language Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Loader Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Controller Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Session Class Initialized
DEBUG - 2019-04-30 17:16:37 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:16:38 --> Session garbage collection performed.
DEBUG - 2019-04-30 17:16:38 --> Session routines successfully run
DEBUG - 2019-04-30 17:16:38 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:38 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:38 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:16:38 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:16:38 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:16:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:16:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:16:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-30 17:16:38 --> Final output sent to browser
DEBUG - 2019-04-30 17:16:38 --> Total execution time: 0.2338
DEBUG - 2019-04-30 17:16:45 --> Config Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:16:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:16:45 --> URI Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Router Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Output Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Security Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Input Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:16:45 --> Language Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Loader Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Controller Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Session Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:16:45 --> Session routines successfully run
DEBUG - 2019-04-30 17:16:45 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Model Class Initialized
DEBUG - 2019-04-30 17:16:45 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:16:45 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:16:45 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:16:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:16:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:16:45 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 17:16:45 --> Final output sent to browser
DEBUG - 2019-04-30 17:16:45 --> Total execution time: 0.0405
DEBUG - 2019-04-30 17:24:33 --> Config Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:24:33 --> URI Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Router Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Output Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Security Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Input Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:24:33 --> Language Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Loader Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Controller Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Session Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:24:33 --> Session garbage collection performed.
DEBUG - 2019-04-30 17:24:33 --> Session routines successfully run
DEBUG - 2019-04-30 17:24:33 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:33 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:24:33 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:24:33 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:24:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:24:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:24:33 --> File loaded: application/views/producers.php
DEBUG - 2019-04-30 17:24:33 --> Final output sent to browser
DEBUG - 2019-04-30 17:24:33 --> Total execution time: 0.2254
DEBUG - 2019-04-30 17:24:35 --> Config Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:24:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:24:35 --> URI Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Router Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Output Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Security Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Input Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:24:35 --> Language Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Loader Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Controller Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Session Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:24:35 --> Session routines successfully run
DEBUG - 2019-04-30 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:35 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:24:35 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:24:35 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:24:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:24:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:24:35 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-30 17:24:35 --> Final output sent to browser
DEBUG - 2019-04-30 17:24:35 --> Total execution time: 0.0548
DEBUG - 2019-04-30 17:24:41 --> Config Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:24:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:24:41 --> URI Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Router Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Output Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Security Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Input Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:24:41 --> Language Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Loader Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Controller Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Session Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:24:41 --> Session routines successfully run
DEBUG - 2019-04-30 17:24:41 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:41 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:24:41 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:24:41 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:24:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:24:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:24:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-30 17:24:41 --> Final output sent to browser
DEBUG - 2019-04-30 17:24:41 --> Total execution time: 0.1438
DEBUG - 2019-04-30 17:24:43 --> Config Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:24:43 --> URI Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Router Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Output Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Security Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Input Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:24:43 --> Language Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Loader Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Controller Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Session Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:24:43 --> Session routines successfully run
DEBUG - 2019-04-30 17:24:43 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Model Class Initialized
DEBUG - 2019-04-30 17:24:43 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:24:43 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:24:43 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:24:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:24:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:24:43 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-30 17:24:43 --> Final output sent to browser
DEBUG - 2019-04-30 17:24:43 --> Total execution time: 0.0836
DEBUG - 2019-04-30 17:37:27 --> Config Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Hooks Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Utf8 Class Initialized
DEBUG - 2019-04-30 17:37:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-30 17:37:27 --> URI Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Router Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Output Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Security Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Input Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-30 17:37:27 --> Language Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Loader Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Controller Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Model Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Model Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Database Driver Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Session Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Helper loaded: string_helper
DEBUG - 2019-04-30 17:37:27 --> Session routines successfully run
DEBUG - 2019-04-30 17:37:27 --> Model Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Model Class Initialized
DEBUG - 2019-04-30 17:37:27 --> Helper loaded: url_helper
DEBUG - 2019-04-30 17:37:27 --> Helper loaded: form_helper
DEBUG - 2019-04-30 17:37:27 --> Form Validation Class Initialized
DEBUG - 2019-04-30 17:37:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-30 17:37:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-30 17:37:27 --> File loaded: application/views/profile.php
DEBUG - 2019-04-30 17:37:27 --> Final output sent to browser
DEBUG - 2019-04-30 17:37:27 --> Total execution time: 0.1498
