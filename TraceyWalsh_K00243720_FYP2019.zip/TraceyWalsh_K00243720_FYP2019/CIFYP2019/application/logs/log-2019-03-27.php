<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-27 18:17:36 --> Config Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Hooks Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Utf8 Class Initialized
DEBUG - 2019-03-27 18:17:36 --> UTF-8 Support Enabled
DEBUG - 2019-03-27 18:17:36 --> URI Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Router Class Initialized
DEBUG - 2019-03-27 18:17:36 --> No URI present. Default controller set.
DEBUG - 2019-03-27 18:17:36 --> Output Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Security Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Input Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-27 18:17:36 --> Language Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Loader Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Controller Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Model Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Model Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Database Driver Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Session Class Initialized
DEBUG - 2019-03-27 18:17:36 --> Helper loaded: string_helper
DEBUG - 2019-03-27 18:17:37 --> Session garbage collection performed.
DEBUG - 2019-03-27 18:17:37 --> Session routines successfully run
DEBUG - 2019-03-27 18:17:37 --> Model Class Initialized
DEBUG - 2019-03-27 18:17:37 --> Helper loaded: url_helper
DEBUG - 2019-03-27 18:17:37 --> File loaded: application/views/header.php
DEBUG - 2019-03-27 18:17:37 --> File loaded: application/views/footer.php
DEBUG - 2019-03-27 18:17:37 --> File loaded: application/views/homePage.php
DEBUG - 2019-03-27 18:17:37 --> Final output sent to browser
DEBUG - 2019-03-27 18:17:37 --> Total execution time: 0.8602
DEBUG - 2019-03-27 18:24:49 --> Config Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Hooks Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Utf8 Class Initialized
DEBUG - 2019-03-27 18:24:49 --> UTF-8 Support Enabled
DEBUG - 2019-03-27 18:24:49 --> URI Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Router Class Initialized
DEBUG - 2019-03-27 18:24:49 --> No URI present. Default controller set.
DEBUG - 2019-03-27 18:24:49 --> Output Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Security Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Input Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-27 18:24:49 --> Language Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Loader Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Controller Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Model Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Model Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Database Driver Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Session Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Helper loaded: string_helper
DEBUG - 2019-03-27 18:24:49 --> Session garbage collection performed.
DEBUG - 2019-03-27 18:24:49 --> Session routines successfully run
DEBUG - 2019-03-27 18:24:49 --> Model Class Initialized
DEBUG - 2019-03-27 18:24:49 --> Helper loaded: url_helper
DEBUG - 2019-03-27 18:24:49 --> File loaded: application/views/header.php
DEBUG - 2019-03-27 18:24:49 --> File loaded: application/views/footer.php
DEBUG - 2019-03-27 18:24:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-03-27 18:24:49 --> Final output sent to browser
DEBUG - 2019-03-27 18:24:49 --> Total execution time: 0.1367
