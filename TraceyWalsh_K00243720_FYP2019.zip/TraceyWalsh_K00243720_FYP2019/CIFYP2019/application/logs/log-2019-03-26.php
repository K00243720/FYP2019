<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-03-26 12:30:18 --> Config Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:30:18 --> URI Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Router Class Initialized
DEBUG - 2019-03-26 12:30:18 --> No URI present. Default controller set.
DEBUG - 2019-03-26 12:30:18 --> Output Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Security Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Input Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:30:18 --> Language Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Loader Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Controller Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Session Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:30:18 --> A session cookie was not found.
DEBUG - 2019-03-26 12:30:18 --> Session routines successfully run
DEBUG - 2019-03-26 12:30:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:30:18 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:30:19 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:30:19 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:30:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-03-26 12:30:19 --> Final output sent to browser
DEBUG - 2019-03-26 12:30:19 --> Total execution time: 0.4032
DEBUG - 2019-03-26 12:42:55 --> Config Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:42:55 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:42:55 --> URI Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Router Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Output Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Security Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Input Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:42:55 --> Language Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Loader Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Controller Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Model Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Model Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Session Class Initialized
DEBUG - 2019-03-26 12:42:55 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:42:56 --> Session routines successfully run
DEBUG - 2019-03-26 12:42:56 --> Model Class Initialized
DEBUG - 2019-03-26 12:42:56 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:42:56 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:42:56 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:42:56 --> File loaded: application/views/logonUser.php
DEBUG - 2019-03-26 12:42:56 --> Final output sent to browser
DEBUG - 2019-03-26 12:42:56 --> Total execution time: 0.3331
DEBUG - 2019-03-26 12:43:10 --> Config Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:43:10 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:43:10 --> URI Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Router Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Output Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Security Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Input Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:43:10 --> Language Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Loader Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Controller Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Model Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Model Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Session Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:43:10 --> Session routines successfully run
DEBUG - 2019-03-26 12:43:10 --> Model Class Initialized
DEBUG - 2019-03-26 12:43:10 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:43:10 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:43:10 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:43:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-03-26 12:43:10 --> Final output sent to browser
DEBUG - 2019-03-26 12:43:10 --> Total execution time: 0.4615
DEBUG - 2019-03-26 12:52:07 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:07 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:07 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:07 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:07 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:07 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:07 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:07 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:07 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:07 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-03-26 12:52:07 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:07 --> Total execution time: 0.2688
DEBUG - 2019-03-26 12:52:16 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:16 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:16 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:16 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:16 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:16 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:16 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:16 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-03-26 12:52:16 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:16 --> Total execution time: 0.4079
DEBUG - 2019-03-26 12:52:18 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:18 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:18 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:18 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:18 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:18 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:18 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:18 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:18 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:18 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-03-26 12:52:18 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:18 --> Total execution time: 0.0830
DEBUG - 2019-03-26 12:52:24 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:24 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:24 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:24 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:24 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:24 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:24 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:24 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:24 --> File loaded: application/views/homePage.php
DEBUG - 2019-03-26 12:52:24 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:24 --> Total execution time: 0.1338
DEBUG - 2019-03-26 12:52:29 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:29 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:29 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:29 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:29 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:29 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:29 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:29 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-03-26 12:52:29 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:29 --> Total execution time: 0.1254
DEBUG - 2019-03-26 12:52:33 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:33 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:33 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:33 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:33 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:33 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:33 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:33 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:33 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:33 --> File loaded: application/views/editNotice.php
DEBUG - 2019-03-26 12:52:33 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:33 --> Total execution time: 0.0948
DEBUG - 2019-03-26 12:52:43 --> Config Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Hooks Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Utf8 Class Initialized
DEBUG - 2019-03-26 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2019-03-26 12:52:43 --> URI Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Router Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Output Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Security Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Input Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-03-26 12:52:43 --> Language Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Loader Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Controller Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Database Driver Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Session Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Helper loaded: string_helper
DEBUG - 2019-03-26 12:52:43 --> Session routines successfully run
DEBUG - 2019-03-26 12:52:43 --> Model Class Initialized
DEBUG - 2019-03-26 12:52:43 --> Helper loaded: url_helper
DEBUG - 2019-03-26 12:52:44 --> File loaded: application/views/header.php
DEBUG - 2019-03-26 12:52:44 --> File loaded: application/views/footer.php
DEBUG - 2019-03-26 12:52:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-03-26 12:52:44 --> Final output sent to browser
DEBUG - 2019-03-26 12:52:44 --> Total execution time: 0.1501
