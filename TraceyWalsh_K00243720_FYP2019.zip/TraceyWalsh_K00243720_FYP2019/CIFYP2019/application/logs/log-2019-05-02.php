<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-05-02 17:11:25 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:25 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:25 --> No URI present. Default controller set.
DEBUG - 2019-05-02 17:11:25 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:25 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:25 --> A session cookie was not found.
DEBUG - 2019-05-02 17:11:25 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:25 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:25 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:25 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:25 --> Form Validation Class Initialized
DEBUG - 2019-05-02 17:11:25 --> File loaded: application/views/header.php
DEBUG - 2019-05-02 17:11:25 --> File loaded: application/views/footer.php
DEBUG - 2019-05-02 17:11:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-05-02 17:11:25 --> Final output sent to browser
DEBUG - 2019-05-02 17:11:25 --> Total execution time: 0.3503
DEBUG - 2019-05-02 17:11:28 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:28 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:28 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:28 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:28 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:28 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:28 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:28 --> Form Validation Class Initialized
DEBUG - 2019-05-02 17:11:28 --> File loaded: application/views/header.php
DEBUG - 2019-05-02 17:11:28 --> File loaded: application/views/footer.php
DEBUG - 2019-05-02 17:11:28 --> File loaded: application/views/logonUser.php
DEBUG - 2019-05-02 17:11:28 --> Final output sent to browser
DEBUG - 2019-05-02 17:11:28 --> Total execution time: 0.0667
DEBUG - 2019-05-02 17:11:38 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:38 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:38 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:38 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:38 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:38 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:38 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:38 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:38 --> Form Validation Class Initialized
DEBUG - 2019-05-02 17:11:38 --> File loaded: application/views/header.php
DEBUG - 2019-05-02 17:11:38 --> File loaded: application/views/footer.php
DEBUG - 2019-05-02 17:11:38 --> File loaded: application/views/market.php
DEBUG - 2019-05-02 17:11:38 --> Final output sent to browser
DEBUG - 2019-05-02 17:11:38 --> Total execution time: 0.1968
DEBUG - 2019-05-02 17:11:40 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:40 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:40 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:40 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:40 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:40 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:40 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:40 --> Form Validation Class Initialized
DEBUG - 2019-05-02 17:11:40 --> File loaded: application/views/header.php
DEBUG - 2019-05-02 17:11:40 --> File loaded: application/views/footer.php
DEBUG - 2019-05-02 17:11:40 --> File loaded: application/views/profile.php
DEBUG - 2019-05-02 17:11:40 --> Final output sent to browser
DEBUG - 2019-05-02 17:11:40 --> Total execution time: 0.0691
DEBUG - 2019-05-02 17:11:45 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:45 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:45 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:45 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:45 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:45 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:45 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:45 --> Form Validation Class Initialized
DEBUG - 2019-05-02 17:11:45 --> File loaded: application/views/header.php
DEBUG - 2019-05-02 17:11:45 --> File loaded: application/views/footer.php
DEBUG - 2019-05-02 17:11:45 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-05-02 17:11:45 --> Final output sent to browser
DEBUG - 2019-05-02 17:11:45 --> Total execution time: 0.0563
DEBUG - 2019-05-02 17:11:48 --> Config Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Hooks Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Utf8 Class Initialized
DEBUG - 2019-05-02 17:11:48 --> UTF-8 Support Enabled
DEBUG - 2019-05-02 17:11:48 --> URI Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Router Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Output Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Security Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Input Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-05-02 17:11:48 --> Language Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Loader Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Controller Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Database Driver Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Session Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Helper loaded: string_helper
DEBUG - 2019-05-02 17:11:48 --> Session routines successfully run
DEBUG - 2019-05-02 17:11:48 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Model Class Initialized
DEBUG - 2019-05-02 17:11:48 --> Helper loaded: url_helper
DEBUG - 2019-05-02 17:11:48 --> Helper loaded: form_helper
DEBUG - 2019-05-02 17:11:48 --> Form Validation Class Initialized
