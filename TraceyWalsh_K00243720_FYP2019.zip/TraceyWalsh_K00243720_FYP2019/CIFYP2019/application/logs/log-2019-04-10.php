<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-10 17:47:52 --> Config Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Hooks Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Utf8 Class Initialized
DEBUG - 2019-04-10 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-10 17:47:52 --> URI Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Router Class Initialized
DEBUG - 2019-04-10 17:47:52 --> No URI present. Default controller set.
DEBUG - 2019-04-10 17:47:52 --> Output Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Security Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Input Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-10 17:47:52 --> Language Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Loader Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Controller Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Database Driver Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Session Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Helper loaded: string_helper
DEBUG - 2019-04-10 17:47:52 --> A session cookie was not found.
DEBUG - 2019-04-10 17:47:52 --> Session routines successfully run
DEBUG - 2019-04-10 17:47:52 --> Model Class Initialized
DEBUG - 2019-04-10 17:47:52 --> Helper loaded: url_helper
DEBUG - 2019-04-10 17:47:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-10 17:47:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-10 17:47:52 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-10 17:47:52 --> Final output sent to browser
DEBUG - 2019-04-10 17:47:52 --> Total execution time: 0.9790
DEBUG - 2019-04-10 17:59:14 --> Config Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Hooks Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Utf8 Class Initialized
DEBUG - 2019-04-10 17:59:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-10 17:59:14 --> URI Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Router Class Initialized
DEBUG - 2019-04-10 17:59:14 --> No URI present. Default controller set.
DEBUG - 2019-04-10 17:59:14 --> Output Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Security Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Input Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-10 17:59:14 --> Language Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Loader Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Controller Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Database Driver Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Session Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Helper loaded: string_helper
DEBUG - 2019-04-10 17:59:14 --> Session routines successfully run
DEBUG - 2019-04-10 17:59:14 --> Model Class Initialized
DEBUG - 2019-04-10 17:59:14 --> Helper loaded: url_helper
DEBUG - 2019-04-10 17:59:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-10 17:59:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-10 17:59:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-10 17:59:14 --> Final output sent to browser
DEBUG - 2019-04-10 17:59:14 --> Total execution time: 0.2316
DEBUG - 2019-04-10 18:00:00 --> Config Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Hooks Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Utf8 Class Initialized
DEBUG - 2019-04-10 18:00:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-10 18:00:00 --> URI Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Router Class Initialized
DEBUG - 2019-04-10 18:00:00 --> No URI present. Default controller set.
DEBUG - 2019-04-10 18:00:00 --> Output Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Security Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Input Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-10 18:00:00 --> Language Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Loader Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Controller Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Database Driver Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Session Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Helper loaded: string_helper
DEBUG - 2019-04-10 18:00:00 --> Session routines successfully run
DEBUG - 2019-04-10 18:00:00 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:00 --> Helper loaded: url_helper
DEBUG - 2019-04-10 18:00:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-10 18:00:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-10 18:00:00 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-10 18:00:00 --> Final output sent to browser
DEBUG - 2019-04-10 18:00:00 --> Total execution time: 0.2376
DEBUG - 2019-04-10 18:00:03 --> Config Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Hooks Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Utf8 Class Initialized
DEBUG - 2019-04-10 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-10 18:00:03 --> URI Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Router Class Initialized
DEBUG - 2019-04-10 18:00:03 --> No URI present. Default controller set.
DEBUG - 2019-04-10 18:00:03 --> Output Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Security Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Input Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-10 18:00:03 --> Language Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Loader Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Controller Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Database Driver Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Session Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Helper loaded: string_helper
DEBUG - 2019-04-10 18:00:03 --> Session routines successfully run
DEBUG - 2019-04-10 18:00:03 --> Model Class Initialized
DEBUG - 2019-04-10 18:00:03 --> Helper loaded: url_helper
DEBUG - 2019-04-10 18:00:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-10 18:00:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-10 18:00:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-10 18:00:03 --> Final output sent to browser
DEBUG - 2019-04-10 18:00:03 --> Total execution time: 0.1052
