<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-12 10:05:18 --> Config Class Initialized
DEBUG - 2019-04-12 10:05:18 --> Hooks Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 10:05:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 10:05:19 --> URI Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Router Class Initialized
DEBUG - 2019-04-12 10:05:19 --> No URI present. Default controller set.
DEBUG - 2019-04-12 10:05:19 --> Output Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Security Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Input Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 10:05:19 --> Language Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Loader Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Controller Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Model Class Initialized
DEBUG - 2019-04-12 10:05:19 --> Model Class Initialized
DEBUG - 2019-04-12 10:05:20 --> Database Driver Class Initialized
DEBUG - 2019-04-12 10:05:20 --> Session Class Initialized
DEBUG - 2019-04-12 10:05:20 --> Helper loaded: string_helper
DEBUG - 2019-04-12 10:05:20 --> A session cookie was not found.
DEBUG - 2019-04-12 10:05:21 --> Session routines successfully run
DEBUG - 2019-04-12 10:05:21 --> Model Class Initialized
DEBUG - 2019-04-12 10:05:21 --> Helper loaded: url_helper
DEBUG - 2019-04-12 10:05:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 10:05:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 10:05:23 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 10:05:23 --> Final output sent to browser
DEBUG - 2019-04-12 10:05:23 --> Total execution time: 4.9210
DEBUG - 2019-04-12 11:12:10 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:10 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:10 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:10 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:12:10 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:10 --> Total execution time: 0.1181
DEBUG - 2019-04-12 11:12:10 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:10 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:10 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:10 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:10 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:10 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:12:10 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:12:23 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:23 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:23 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:23 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:23 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 11:12:23 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:23 --> Total execution time: 0.0738
DEBUG - 2019-04-12 11:12:23 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:23 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:23 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:23 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:23 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:12:23 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:12:36 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:36 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:36 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:36 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:36 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-12 11:12:36 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:36 --> Total execution time: 0.0569
DEBUG - 2019-04-12 11:12:36 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:36 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:36 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:36 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:36 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:36 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:12:36 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:12:40 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:40 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:40 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:40 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:40 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 11:12:40 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:40 --> Total execution time: 0.0517
DEBUG - 2019-04-12 11:12:40 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:40 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:40 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:40 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:40 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:12:40 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:12:47 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:47 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:47 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:47 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:47 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:12:47 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:47 --> Total execution time: 0.2378
DEBUG - 2019-04-12 11:12:47 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:47 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:47 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:47 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:47 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:12:47 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:12:56 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:56 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:56 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:56 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:56 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 11:12:56 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:56 --> Total execution time: 0.0871
DEBUG - 2019-04-12 11:12:56 --> Config Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:12:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:12:56 --> URI Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Router Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Output Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Security Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Input Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:12:56 --> Language Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Loader Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Controller Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Model Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Session Class Initialized
DEBUG - 2019-04-12 11:12:56 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:12:56 --> Session routines successfully run
DEBUG - 2019-04-12 11:12:56 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:12:56 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 11:12:56 --> Final output sent to browser
DEBUG - 2019-04-12 11:12:56 --> Total execution time: 0.0582
DEBUG - 2019-04-12 11:13:00 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:00 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:00 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:00 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:13:00 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:00 --> Total execution time: 0.1081
DEBUG - 2019-04-12 11:13:00 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:00 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:00 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:00 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:00 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:00 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:00 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:13:00 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:00 --> Total execution time: 0.1165
DEBUG - 2019-04-12 11:13:01 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:01 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:01 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:01 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:13:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:13:01 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:01 --> Total execution time: 0.0473
DEBUG - 2019-04-12 11:13:01 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:01 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:01 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:01 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:01 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:01 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:13:01 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:13:03 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:03 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:03 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:03 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:03 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:03 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:13:03 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-12 11:13:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:08 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:13:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:13:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:08 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:13:08 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:08 --> Total execution time: 0.0577
DEBUG - 2019-04-12 11:13:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:08 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:13:08 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:13:17 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:17 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:17 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:17 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 11:13:17 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:17 --> Total execution time: 0.0541
DEBUG - 2019-04-12 11:13:17 --> Config Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:13:17 --> URI Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Router Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Output Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Security Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Input Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:13:17 --> Language Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Loader Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Controller Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Session Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:13:17 --> Session routines successfully run
DEBUG - 2019-04-12 11:13:17 --> Model Class Initialized
DEBUG - 2019-04-12 11:13:17 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:13:17 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 11:13:17 --> Final output sent to browser
DEBUG - 2019-04-12 11:13:17 --> Total execution time: 0.0528
DEBUG - 2019-04-12 11:14:06 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:06 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:06 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:07 --> Session garbage collection performed.
DEBUG - 2019-04-12 11:14:07 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:14:07 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:07 --> Total execution time: 0.1756
DEBUG - 2019-04-12 11:14:07 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:07 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:07 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:07 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:07 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:07 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:14:07 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:07 --> Total execution time: 0.0931
DEBUG - 2019-04-12 11:14:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:14:08 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:08 --> Total execution time: 0.0535
DEBUG - 2019-04-12 11:14:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:08 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:14:08 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:14:12 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:12 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:12 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:12 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:12 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:12 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:12 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:12 --> A session cookie was not found.
DEBUG - 2019-04-12 11:14:12 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 11:14:12 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:12 --> Total execution time: 0.1381
DEBUG - 2019-04-12 11:14:12 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:12 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:12 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:12 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:12 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:14:12 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:14:23 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:23 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:23 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:23 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:23 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 11:14:23 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:23 --> Total execution time: 0.0889
DEBUG - 2019-04-12 11:14:23 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:23 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:23 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:23 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:23 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:23 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:14:23 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:14:39 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:39 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:39 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:39 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:39 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-12 11:14:39 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:39 --> Total execution time: 0.0566
DEBUG - 2019-04-12 11:14:39 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:39 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:39 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:39 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:39 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:14:39 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:14:42 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:43 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:43 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:43 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:14:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:14:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:14:43 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 11:14:43 --> Final output sent to browser
DEBUG - 2019-04-12 11:14:43 --> Total execution time: 0.0518
DEBUG - 2019-04-12 11:14:43 --> Config Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:14:43 --> URI Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Router Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Output Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Security Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Input Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:14:43 --> Language Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Loader Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Controller Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Session Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:14:43 --> Session routines successfully run
DEBUG - 2019-04-12 11:14:43 --> Model Class Initialized
DEBUG - 2019-04-12 11:14:43 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:14:43 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:16:13 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:13 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:13 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:13 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:13 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:13 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:16:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:16:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:16:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 11:16:13 --> Final output sent to browser
DEBUG - 2019-04-12 11:16:13 --> Total execution time: 0.0703
DEBUG - 2019-04-12 11:16:14 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:14 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:14 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:14 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:14 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:14 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:16:14 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:16:19 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:20 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:20 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:20 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:16:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:16:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:16:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:16:20 --> Final output sent to browser
DEBUG - 2019-04-12 11:16:20 --> Total execution time: 0.3778
DEBUG - 2019-04-12 11:16:20 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:20 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:20 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:20 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:20 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:20 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:16:20 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:16:21 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:21 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:21 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:21 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:16:21 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:16:21 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:16:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:16:21 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:16:21 --> Final output sent to browser
DEBUG - 2019-04-12 11:16:21 --> Total execution time: 0.0638
DEBUG - 2019-04-12 11:16:21 --> Config Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:16:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:16:21 --> URI Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Router Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Output Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Security Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Input Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:16:21 --> Language Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Loader Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Controller Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Session Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:16:21 --> Session routines successfully run
DEBUG - 2019-04-12 11:16:21 --> Model Class Initialized
DEBUG - 2019-04-12 11:16:21 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:16:21 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:17:09 --> Config Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:17:09 --> URI Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Router Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Output Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Security Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Input Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:17:09 --> Language Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Loader Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Controller Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Session Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:17:09 --> Session routines successfully run
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:17:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:17:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:17:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:17:09 --> Final output sent to browser
DEBUG - 2019-04-12 11:17:09 --> Total execution time: 0.0600
DEBUG - 2019-04-12 11:17:09 --> Config Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:17:09 --> URI Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Router Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Output Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Security Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Input Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:17:09 --> Language Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Loader Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Controller Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Session Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:17:09 --> Session routines successfully run
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:17:09 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:17:09 --> Config Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:17:09 --> URI Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Router Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Output Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Security Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Input Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:17:09 --> Language Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Loader Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Controller Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Session Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:17:09 --> Session routines successfully run
DEBUG - 2019-04-12 11:17:09 --> Model Class Initialized
DEBUG - 2019-04-12 11:17:09 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:17:09 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-12 11:18:07 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:07 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:07 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:07 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:07 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:07 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:07 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-12 11:18:22 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:22 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:22 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:22 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:22 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:18:22 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:22 --> Total execution time: 0.1266
DEBUG - 2019-04-12 11:18:22 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:22 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:22 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:22 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:22 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:22 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:23 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:18:23 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:23 --> Total execution time: 0.1469
DEBUG - 2019-04-12 11:18:25 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:25 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:25 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:25 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:18:25 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:25 --> Total execution time: 0.0664
DEBUG - 2019-04-12 11:18:25 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:25 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:25 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:25 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:25 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:25 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:25 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:18:27 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:27 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:27 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:27 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:27 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:27 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:27 --> 404 Page Not Found --> User/doEditNotice
DEBUG - 2019-04-12 11:18:31 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:31 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:31 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:31 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:31 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:31 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:31 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE
DEBUG - 2019-04-12 11:18:34 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:34 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:34 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:34 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:34 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:18:34 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:18:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:34 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:18:34 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:34 --> Total execution time: 0.0562
DEBUG - 2019-04-12 11:18:34 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:34 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:34 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:34 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:34 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:34 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:34 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:18:39 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:39 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:39 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:39 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:18:39 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:39 --> Total execution time: 0.0626
DEBUG - 2019-04-12 11:18:39 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:39 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:39 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:39 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:39 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:18:39 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:18:42 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:42 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:42 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:42 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:18:42 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:42 --> Total execution time: 0.1325
DEBUG - 2019-04-12 11:18:42 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:42 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:42 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:42 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:42 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:42 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:42 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:18:42 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:42 --> Total execution time: 0.0927
DEBUG - 2019-04-12 11:18:45 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:45 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:45 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:45 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:45 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 11:18:45 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:45 --> Total execution time: 0.0592
DEBUG - 2019-04-12 11:18:45 --> Config Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:18:45 --> URI Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Router Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Output Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Security Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Input Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:18:45 --> Language Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Loader Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Controller Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Model Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Session Class Initialized
DEBUG - 2019-04-12 11:18:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:18:45 --> Session routines successfully run
DEBUG - 2019-04-12 11:18:45 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:18:45 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 11:18:45 --> Final output sent to browser
DEBUG - 2019-04-12 11:18:45 --> Total execution time: 0.0554
DEBUG - 2019-04-12 11:19:38 --> Config Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:19:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:19:38 --> URI Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Router Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Output Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Security Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Input Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:19:38 --> Language Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Loader Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Controller Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Session Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:19:38 --> Session routines successfully run
DEBUG - 2019-04-12 11:19:38 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:38 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:19:39 --> Final output sent to browser
DEBUG - 2019-04-12 11:19:39 --> Total execution time: 0.2066
DEBUG - 2019-04-12 11:19:39 --> Config Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:19:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:19:39 --> URI Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Router Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Output Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Security Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Input Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:19:39 --> Language Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Loader Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Controller Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Session Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:19:39 --> Session routines successfully run
DEBUG - 2019-04-12 11:19:39 --> Model Class Initialized
DEBUG - 2019-04-12 11:19:39 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:19:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:19:39 --> Final output sent to browser
DEBUG - 2019-04-12 11:19:39 --> Total execution time: 0.1670
DEBUG - 2019-04-12 11:22:47 --> Config Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:22:47 --> URI Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Router Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Output Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Security Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Input Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:22:47 --> Language Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Loader Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Controller Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Session Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:22:47 --> Session routines successfully run
DEBUG - 2019-04-12 11:22:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:22:47 --> Config Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:22:47 --> URI Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Router Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Output Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Security Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Input Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:22:47 --> Language Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Loader Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Controller Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Session Class Initialized
DEBUG - 2019-04-12 11:22:47 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:22:47 --> A session cookie was not found.
DEBUG - 2019-04-12 11:22:48 --> Session routines successfully run
DEBUG - 2019-04-12 11:22:48 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:22:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:22:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:22:48 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 11:22:48 --> Final output sent to browser
DEBUG - 2019-04-12 11:22:48 --> Total execution time: 0.1988
DEBUG - 2019-04-12 11:22:48 --> Config Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:22:48 --> URI Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Router Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Output Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Security Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Input Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:22:48 --> Language Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Loader Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Controller Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Session Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:22:48 --> Session routines successfully run
DEBUG - 2019-04-12 11:22:48 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:48 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:22:48 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:22:49 --> Config Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:22:49 --> URI Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Router Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Output Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Security Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Input Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:22:49 --> Language Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Loader Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Controller Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Session Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:22:49 --> Session routines successfully run
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:22:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:22:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:22:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 11:22:49 --> Final output sent to browser
DEBUG - 2019-04-12 11:22:49 --> Total execution time: 0.0487
DEBUG - 2019-04-12 11:22:49 --> Config Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:22:49 --> URI Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Router Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Output Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Security Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Input Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:22:49 --> Language Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Loader Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Controller Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Session Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:22:49 --> Session routines successfully run
DEBUG - 2019-04-12 11:22:49 --> Model Class Initialized
DEBUG - 2019-04-12 11:22:49 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:22:49 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:24:59 --> Config Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:24:59 --> URI Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Router Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Output Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Security Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Input Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:24:59 --> Language Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Loader Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Controller Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Session Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:24:59 --> Session routines successfully run
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:24:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:24:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:24:59 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 11:24:59 --> Final output sent to browser
DEBUG - 2019-04-12 11:24:59 --> Total execution time: 0.0481
DEBUG - 2019-04-12 11:24:59 --> Config Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:24:59 --> URI Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Router Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Output Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Security Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Input Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:24:59 --> Language Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Loader Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Controller Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Session Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:24:59 --> Session routines successfully run
DEBUG - 2019-04-12 11:24:59 --> Model Class Initialized
DEBUG - 2019-04-12 11:24:59 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:24:59 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:25:05 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:05 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:05 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:05 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:25:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:25:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:25:05 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 11:25:05 --> Final output sent to browser
DEBUG - 2019-04-12 11:25:05 --> Total execution time: 0.2378
DEBUG - 2019-04-12 11:25:05 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:05 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:05 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:05 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:05 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:05 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:25:05 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:25:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:25:08 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:25:08 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:25:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:25:08 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:25:08 --> Final output sent to browser
DEBUG - 2019-04-12 11:25:08 --> Total execution time: 0.0601
DEBUG - 2019-04-12 11:25:08 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:08 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:08 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:08 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:08 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:08 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:25:08 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:25:12 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:12 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:12 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:12 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 11:25:12 --> Final output sent to browser
DEBUG - 2019-04-12 11:25:12 --> Total execution time: 0.0472
DEBUG - 2019-04-12 11:25:12 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:12 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:12 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:12 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:12 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:25:12 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 11:25:12 --> Final output sent to browser
DEBUG - 2019-04-12 11:25:12 --> Total execution time: 0.0520
DEBUG - 2019-04-12 11:25:28 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:28 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:28 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:28 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:28 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:28 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:25:28 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:25:28 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:25:29 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:25:29 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:25:29 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:25:29 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:25:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:25:29 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:25:29 --> Final output sent to browser
DEBUG - 2019-04-12 11:25:29 --> Total execution time: 0.0581
DEBUG - 2019-04-12 11:25:29 --> Config Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:25:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:25:29 --> URI Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Router Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Output Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Security Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Input Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:25:29 --> Language Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Loader Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Controller Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Session Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:25:29 --> Session routines successfully run
DEBUG - 2019-04-12 11:25:29 --> Model Class Initialized
DEBUG - 2019-04-12 11:25:29 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:25:29 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:26:53 --> Config Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:26:53 --> URI Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Router Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Output Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Security Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Input Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:26:53 --> Language Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Loader Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Controller Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Session Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:26:53 --> Session routines successfully run
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:26:53 --> File loaded: application/views/header.php
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 11:26:53 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 11:26:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:26:53 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 11:26:53 --> Final output sent to browser
DEBUG - 2019-04-12 11:26:53 --> Total execution time: 0.0612
DEBUG - 2019-04-12 11:26:53 --> Config Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:26:53 --> URI Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Router Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Output Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Security Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Input Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:26:53 --> Language Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Loader Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Controller Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Session Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:26:53 --> Session routines successfully run
DEBUG - 2019-04-12 11:26:53 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:53 --> Helper loaded: url_helper
ERROR - 2019-04-12 11:26:53 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 11:26:55 --> Config Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:26:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:26:55 --> URI Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Router Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Output Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Security Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Input Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:26:55 --> Language Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Loader Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Controller Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Session Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:26:55 --> Session routines successfully run
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 11:26:55 --> Final output sent to browser
DEBUG - 2019-04-12 11:26:55 --> Total execution time: 0.0526
DEBUG - 2019-04-12 11:26:55 --> Config Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 11:26:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 11:26:55 --> URI Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Router Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Output Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Security Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Input Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 11:26:55 --> Language Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Loader Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Controller Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Session Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 11:26:55 --> Session routines successfully run
DEBUG - 2019-04-12 11:26:55 --> Model Class Initialized
DEBUG - 2019-04-12 11:26:55 --> Helper loaded: url_helper
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 11:26:55 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 11:26:55 --> Final output sent to browser
DEBUG - 2019-04-12 11:26:55 --> Total execution time: 0.0563
DEBUG - 2019-04-12 12:40:10 --> Config Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 12:40:10 --> URI Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Router Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Output Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Security Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Input Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 12:40:10 --> Language Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Loader Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Controller Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Session Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 12:40:10 --> Session routines successfully run
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Helper loaded: url_helper
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 12:40:10 --> Final output sent to browser
DEBUG - 2019-04-12 12:40:10 --> Total execution time: 0.1466
DEBUG - 2019-04-12 12:40:10 --> Config Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 12:40:10 --> URI Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Router Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Output Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Security Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Input Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 12:40:10 --> Language Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Loader Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Controller Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Session Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 12:40:10 --> Session routines successfully run
DEBUG - 2019-04-12 12:40:10 --> Model Class Initialized
DEBUG - 2019-04-12 12:40:10 --> Helper loaded: url_helper
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 12:40:10 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 12:40:10 --> Final output sent to browser
DEBUG - 2019-04-12 12:40:10 --> Total execution time: 0.0581
DEBUG - 2019-04-12 13:44:12 --> Config Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:44:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:44:12 --> URI Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Router Class Initialized
DEBUG - 2019-04-12 13:44:12 --> No URI present. Default controller set.
DEBUG - 2019-04-12 13:44:12 --> Output Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Security Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Input Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:44:12 --> Language Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Loader Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Controller Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Session Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:44:12 --> Session routines successfully run
DEBUG - 2019-04-12 13:44:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:44:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:44:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:44:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:44:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 13:44:12 --> Final output sent to browser
DEBUG - 2019-04-12 13:44:12 --> Total execution time: 0.2677
DEBUG - 2019-04-12 13:45:11 --> Config Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:45:11 --> URI Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Router Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Output Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Security Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Input Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:45:11 --> Language Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Loader Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Controller Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Session Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:45:11 --> Session routines successfully run
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:45:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:45:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:45:11 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 13:45:11 --> Final output sent to browser
DEBUG - 2019-04-12 13:45:11 --> Total execution time: 0.0677
DEBUG - 2019-04-12 13:45:11 --> Config Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:45:11 --> URI Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Router Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Output Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Security Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Input Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:45:11 --> Language Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Loader Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Controller Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Session Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:45:11 --> Session routines successfully run
DEBUG - 2019-04-12 13:45:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:45:11 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:45:11 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:47:05 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:05 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:05 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:05 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:05 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:05 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:47:06 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:06 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:06 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:06 --> A session cookie was not found.
DEBUG - 2019-04-12 13:47:06 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:47:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:47:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:47:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 13:47:06 --> Final output sent to browser
DEBUG - 2019-04-12 13:47:06 --> Total execution time: 0.1336
DEBUG - 2019-04-12 13:47:06 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:06 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:06 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:06 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:47:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:47:11 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:11 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:11 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:11 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:12 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:47:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:47:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:47:12 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 13:47:12 --> Final output sent to browser
DEBUG - 2019-04-12 13:47:12 --> Total execution time: 0.0644
DEBUG - 2019-04-12 13:47:12 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:12 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:12 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:12 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:12 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:12 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:47:12 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:47:32 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:32 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:32 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:32 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:47:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:47:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:47:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 13:47:32 --> Final output sent to browser
DEBUG - 2019-04-12 13:47:32 --> Total execution time: 0.1504
DEBUG - 2019-04-12 13:47:32 --> Config Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:47:32 --> URI Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Router Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Output Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Security Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Input Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:47:32 --> Language Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Loader Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Controller Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Session Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:47:32 --> Session routines successfully run
DEBUG - 2019-04-12 13:47:32 --> Model Class Initialized
DEBUG - 2019-04-12 13:47:32 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:47:32 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:52:04 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:04 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:04 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:04 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:52:04 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:04 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:04 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:04 --> A session cookie was not found.
DEBUG - 2019-04-12 13:52:04 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:52:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:52:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:52:04 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 13:52:04 --> Final output sent to browser
DEBUG - 2019-04-12 13:52:04 --> Total execution time: 0.2759
DEBUG - 2019-04-12 13:52:04 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:04 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:04 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:04 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:04 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:04 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:52:04 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:52:44 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:44 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:44 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:44 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:52:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:52:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:52:44 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 13:52:44 --> Final output sent to browser
DEBUG - 2019-04-12 13:52:44 --> Total execution time: 0.0623
DEBUG - 2019-04-12 13:52:44 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:44 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:44 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:44 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:44 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:52:44 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:52:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:52:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:52:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:52:50 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 13:52:50 --> Final output sent to browser
DEBUG - 2019-04-12 13:52:50 --> Total execution time: 0.1859
DEBUG - 2019-04-12 13:52:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:52:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:52:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:52:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:52:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:52:50 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:52:50 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:53:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:53:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:53:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:53:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:53:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:53:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 13:53:50 --> Final output sent to browser
DEBUG - 2019-04-12 13:53:50 --> Total execution time: 0.0524
DEBUG - 2019-04-12 13:53:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:53:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:53:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:53:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:53:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:53:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:53:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:53:50 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-12 13:53:50 --> Final output sent to browser
DEBUG - 2019-04-12 13:53:50 --> Total execution time: 0.0706
DEBUG - 2019-04-12 13:56:19 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:19 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:19 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:19 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:19 --> File loaded: application/views/header.php
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 13:56:19 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 13:56:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:19 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 13:56:19 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:19 --> Total execution time: 0.0615
DEBUG - 2019-04-12 13:56:19 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:19 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:19 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:19 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:19 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:19 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:56:19 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:56:22 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:22 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:22 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:22 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 13:56:22 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:22 --> Total execution time: 0.0716
DEBUG - 2019-04-12 13:56:22 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:22 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:22 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:22 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:22 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:22 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 13:56:22 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:22 --> Total execution time: 0.0392
DEBUG - 2019-04-12 13:56:36 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:36 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:36 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:36 --> Session garbage collection performed.
DEBUG - 2019-04-12 13:56:36 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:36 --> File loaded: application/views/header.php
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 13:56:36 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 13:56:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:36 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 13:56:36 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:36 --> Total execution time: 0.0736
DEBUG - 2019-04-12 13:56:36 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:36 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:36 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:36 --> Session garbage collection performed.
DEBUG - 2019-04-12 13:56:36 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:36 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:56:36 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:56:48 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:48 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:48 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:48 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-12 13:56:48 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:48 --> Total execution time: 0.0574
DEBUG - 2019-04-12 13:56:48 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:48 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:48 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:48 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:48 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:48 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:48 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 13:56:48 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:48 --> Total execution time: 0.0663
DEBUG - 2019-04-12 13:56:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:56:50 --> File loaded: application/views/header.php
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 24
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 26
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 29
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 33
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 36
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 39
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 42
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 46
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 50
ERROR - 2019-04-12 13:56:50 --> Severity: Notice  --> Undefined variable: User C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 54
DEBUG - 2019-04-12 13:56:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:56:50 --> File loaded: application/views/profile.php
DEBUG - 2019-04-12 13:56:50 --> Final output sent to browser
DEBUG - 2019-04-12 13:56:50 --> Total execution time: 0.0597
DEBUG - 2019-04-12 13:56:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:56:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:56:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:56:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:56:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:56:50 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:56:50 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 13:57:02 --> Config Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:57:02 --> URI Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Router Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Output Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Security Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Input Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:57:02 --> Language Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Loader Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Controller Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Session Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:57:02 --> Session routines successfully run
DEBUG - 2019-04-12 13:57:02 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:02 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 13:57:03 --> Final output sent to browser
DEBUG - 2019-04-12 13:57:03 --> Total execution time: 0.1216
DEBUG - 2019-04-12 13:57:03 --> Config Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:57:03 --> URI Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Router Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Output Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Security Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Input Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:57:03 --> Language Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Loader Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Controller Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Session Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:57:03 --> Session routines successfully run
DEBUG - 2019-04-12 13:57:03 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:03 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:57:03 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-12 13:57:03 --> Final output sent to browser
DEBUG - 2019-04-12 13:57:03 --> Total execution time: 0.0736
DEBUG - 2019-04-12 13:57:49 --> Config Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:57:49 --> URI Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Router Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Output Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Security Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Input Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:57:49 --> Language Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Loader Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Controller Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Session Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:57:49 --> Session garbage collection performed.
DEBUG - 2019-04-12 13:57:49 --> Session routines successfully run
DEBUG - 2019-04-12 13:57:49 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:57:49 --> Config Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:57:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:57:49 --> URI Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Router Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Output Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Security Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Input Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:57:49 --> Language Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Loader Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Controller Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:49 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:57:50 --> A session cookie was not found.
DEBUG - 2019-04-12 13:57:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:57:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 13:57:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 13:57:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 13:57:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 13:57:50 --> Final output sent to browser
DEBUG - 2019-04-12 13:57:50 --> Total execution time: 0.1664
DEBUG - 2019-04-12 13:57:50 --> Config Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 13:57:50 --> URI Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Router Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Output Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Security Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Input Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 13:57:50 --> Language Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Loader Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Controller Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Session Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 13:57:50 --> Session routines successfully run
DEBUG - 2019-04-12 13:57:50 --> Model Class Initialized
DEBUG - 2019-04-12 13:57:50 --> Helper loaded: url_helper
ERROR - 2019-04-12 13:57:50 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:01:10 --> Config Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:01:10 --> URI Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Router Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Output Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Security Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Input Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:01:10 --> Language Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Loader Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Controller Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Session Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:01:10 --> Session routines successfully run
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:01:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:01:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:01:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:01:10 --> Final output sent to browser
DEBUG - 2019-04-12 14:01:10 --> Total execution time: 0.0565
DEBUG - 2019-04-12 14:01:10 --> Config Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:01:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:01:10 --> URI Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Router Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Output Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Security Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Input Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:01:10 --> Language Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Loader Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Controller Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Session Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:01:10 --> Session routines successfully run
DEBUG - 2019-04-12 14:01:10 --> Model Class Initialized
DEBUG - 2019-04-12 14:01:10 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:01:10 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:37:26 --> Config Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:37:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:37:26 --> URI Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Router Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Output Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Security Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Input Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:37:26 --> Language Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Loader Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Controller Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Session Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:37:26 --> Session routines successfully run
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:37:26 --> File loaded: application/views/header.php
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined variable: countdivs C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 13
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:26 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
DEBUG - 2019-04-12 14:37:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:37:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:37:26 --> Final output sent to browser
DEBUG - 2019-04-12 14:37:26 --> Total execution time: 0.1335
DEBUG - 2019-04-12 14:37:26 --> Config Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:37:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:37:26 --> URI Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Router Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Output Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Security Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Input Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:37:26 --> Language Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Loader Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Controller Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Session Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:37:26 --> Session routines successfully run
DEBUG - 2019-04-12 14:37:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:26 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:37:26 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:37:57 --> Config Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:37:57 --> URI Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Router Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Output Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Security Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Input Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:37:57 --> Language Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Loader Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Controller Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Session Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:37:57 --> Session routines successfully run
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:37:57 --> File loaded: application/views/header.php
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined variable: countdivs C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 13
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
ERROR - 2019-04-12 14:37:57 --> Severity: Notice  --> Undefined index: headline C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 24
DEBUG - 2019-04-12 14:37:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:37:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:37:57 --> Final output sent to browser
DEBUG - 2019-04-12 14:37:57 --> Total execution time: 0.0805
DEBUG - 2019-04-12 14:37:57 --> Config Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:37:57 --> URI Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Router Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Output Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Security Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Input Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:37:57 --> Language Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Loader Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Controller Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Session Class Initialized
DEBUG - 2019-04-12 14:37:57 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:37:57 --> Session routines successfully run
DEBUG - 2019-04-12 14:37:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:37:58 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:37:58 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:38:41 --> Config Class Initialized
DEBUG - 2019-04-12 14:38:41 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:38:41 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:38:41 --> URI Class Initialized
DEBUG - 2019-04-12 14:38:41 --> Router Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Output Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Security Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Input Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:38:42 --> Language Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Loader Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Controller Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Session Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:38:42 --> Session routines successfully run
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:38:42 --> File loaded: application/views/header.php
ERROR - 2019-04-12 14:38:42 --> Severity: Notice  --> Undefined variable: countdivs C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 13
DEBUG - 2019-04-12 14:38:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:38:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:38:42 --> Final output sent to browser
DEBUG - 2019-04-12 14:38:42 --> Total execution time: 0.0867
DEBUG - 2019-04-12 14:38:42 --> Config Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:38:42 --> URI Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Router Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Output Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Security Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Input Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:38:42 --> Language Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Loader Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Controller Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Session Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:38:42 --> Session routines successfully run
DEBUG - 2019-04-12 14:38:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:38:42 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:38:42 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:39:05 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:05 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:05 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:05 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:39:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:39:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:39:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:39:05 --> Final output sent to browser
DEBUG - 2019-04-12 14:39:05 --> Total execution time: 0.0426
DEBUG - 2019-04-12 14:39:05 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:05 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:05 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:05 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:05 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:39:05 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:39:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:39:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:39:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:39:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:39:53 --> Final output sent to browser
DEBUG - 2019-04-12 14:39:53 --> Total execution time: 0.0757
DEBUG - 2019-04-12 14:39:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:53 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:39:53 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:39:55 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:55 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:55 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:55 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:39:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:39:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:39:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:39:55 --> Final output sent to browser
DEBUG - 2019-04-12 14:39:55 --> Total execution time: 0.0628
DEBUG - 2019-04-12 14:39:55 --> Config Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:39:55 --> URI Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Router Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Output Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Security Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Input Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:39:55 --> Language Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Loader Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Controller Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Session Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:39:55 --> Session routines successfully run
DEBUG - 2019-04-12 14:39:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:39:55 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:39:55 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:40:29 --> Config Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:40:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:40:29 --> URI Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Router Class Initialized
DEBUG - 2019-04-12 14:40:29 --> No URI present. Default controller set.
DEBUG - 2019-04-12 14:40:29 --> Output Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Security Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Input Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:40:29 --> Language Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Loader Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Controller Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Session Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:40:29 --> Session routines successfully run
DEBUG - 2019-04-12 14:40:29 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:29 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:40:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:40:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:40:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:40:29 --> Final output sent to browser
DEBUG - 2019-04-12 14:40:29 --> Total execution time: 0.1879
DEBUG - 2019-04-12 14:40:31 --> Config Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:40:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:40:31 --> URI Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Router Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Output Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Security Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Input Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:40:31 --> Language Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Loader Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Controller Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Session Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:40:31 --> Session routines successfully run
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:40:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:40:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:40:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:40:31 --> Final output sent to browser
DEBUG - 2019-04-12 14:40:31 --> Total execution time: 0.0572
DEBUG - 2019-04-12 14:40:31 --> Config Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:40:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:40:31 --> URI Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Router Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Output Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Security Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Input Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:40:31 --> Language Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Loader Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Controller Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Session Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:40:31 --> Session routines successfully run
DEBUG - 2019-04-12 14:40:31 --> Model Class Initialized
DEBUG - 2019-04-12 14:40:31 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:40:31 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:42:12 --> Config Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:42:12 --> URI Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Router Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Output Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Security Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Input Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:42:12 --> Language Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Loader Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Controller Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Session Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:42:12 --> Session routines successfully run
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:42:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:42:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:42:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:42:12 --> Final output sent to browser
DEBUG - 2019-04-12 14:42:12 --> Total execution time: 0.0683
DEBUG - 2019-04-12 14:42:12 --> Config Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:42:12 --> URI Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Router Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Output Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Security Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Input Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:42:12 --> Language Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Loader Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Controller Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Session Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:42:12 --> Session routines successfully run
DEBUG - 2019-04-12 14:42:12 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:12 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:42:12 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:42:15 --> Config Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:42:15 --> URI Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Router Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Output Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Security Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Input Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:42:15 --> Language Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Loader Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Controller Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Session Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:42:15 --> Session routines successfully run
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:42:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:42:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:42:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:42:15 --> Final output sent to browser
DEBUG - 2019-04-12 14:42:15 --> Total execution time: 0.0524
DEBUG - 2019-04-12 14:42:15 --> Config Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:42:15 --> URI Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Router Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Output Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Security Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Input Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:42:15 --> Language Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Loader Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Controller Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Session Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:42:15 --> Session routines successfully run
DEBUG - 2019-04-12 14:42:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:42:15 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:42:15 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:43:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:43:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:43:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:43:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:43:06 --> Final output sent to browser
DEBUG - 2019-04-12 14:43:06 --> Total execution time: 0.0706
DEBUG - 2019-04-12 14:43:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:43:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:43:11 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:11 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:11 --> No URI present. Default controller set.
DEBUG - 2019-04-12 14:43:11 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:11 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:11 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:11 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:11 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:43:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:43:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:43:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:43:11 --> Final output sent to browser
DEBUG - 2019-04-12 14:43:11 --> Total execution time: 0.1294
DEBUG - 2019-04-12 14:43:13 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:13 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:13 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:13 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:43:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:43:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:43:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:43:13 --> Final output sent to browser
DEBUG - 2019-04-12 14:43:13 --> Total execution time: 0.0529
DEBUG - 2019-04-12 14:43:13 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:13 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:13 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:13 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:13 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:13 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:43:13 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:43:44 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:44 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:44 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:44 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:43:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:43:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:43:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:43:44 --> Final output sent to browser
DEBUG - 2019-04-12 14:43:44 --> Total execution time: 0.0505
DEBUG - 2019-04-12 14:43:44 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:44 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:44 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:44 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:44 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:43:44 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:43:48 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:48 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:48 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:48 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:43:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:43:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:43:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:43:48 --> Final output sent to browser
DEBUG - 2019-04-12 14:43:48 --> Total execution time: 0.0506
DEBUG - 2019-04-12 14:43:48 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:48 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:48 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:48 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:48 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:43:48 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:43:59 --> Config Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:43:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:43:59 --> URI Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Router Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Output Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Security Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Input Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:43:59 --> Language Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Loader Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Controller Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Session Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:43:59 --> Session garbage collection performed.
DEBUG - 2019-04-12 14:43:59 --> Session routines successfully run
DEBUG - 2019-04-12 14:43:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:43:59 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:44:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:44:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:44:00 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:44:00 --> Final output sent to browser
DEBUG - 2019-04-12 14:44:00 --> Total execution time: 0.1871
DEBUG - 2019-04-12 14:44:00 --> Config Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:44:00 --> URI Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Router Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Output Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Security Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Input Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:44:00 --> Language Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Loader Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Controller Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Session Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:44:00 --> Session routines successfully run
DEBUG - 2019-04-12 14:44:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:00 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:44:00 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:44:02 --> Config Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:44:02 --> URI Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Router Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Output Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Security Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Input Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:44:02 --> Language Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Loader Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Controller Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Session Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:44:02 --> Session routines successfully run
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:44:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:44:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:44:02 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 14:44:02 --> Final output sent to browser
DEBUG - 2019-04-12 14:44:02 --> Total execution time: 0.0493
DEBUG - 2019-04-12 14:44:02 --> Config Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:44:02 --> URI Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Router Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Output Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Security Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Input Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:44:02 --> Language Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Loader Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Controller Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Session Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:44:02 --> Session routines successfully run
DEBUG - 2019-04-12 14:44:02 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:02 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:44:02 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:44:03 --> Config Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:44:03 --> URI Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Router Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Output Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Security Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Input Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:44:03 --> Language Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Loader Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Controller Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Session Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:44:03 --> Session routines successfully run
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:44:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:44:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:44:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:44:03 --> Final output sent to browser
DEBUG - 2019-04-12 14:44:03 --> Total execution time: 0.0509
DEBUG - 2019-04-12 14:44:03 --> Config Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:44:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:44:03 --> URI Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Router Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Output Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Security Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Input Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:44:03 --> Language Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Loader Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Controller Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Session Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:44:03 --> Session routines successfully run
DEBUG - 2019-04-12 14:44:03 --> Model Class Initialized
DEBUG - 2019-04-12 14:44:03 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:44:03 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:47:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:47:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:47:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:47:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:47:06 --> Final output sent to browser
DEBUG - 2019-04-12 14:47:06 --> Total execution time: 0.1261
DEBUG - 2019-04-12 14:47:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:47:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:47:19 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:19 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:19 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:19 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:47:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:47:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:47:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:47:19 --> Final output sent to browser
DEBUG - 2019-04-12 14:47:19 --> Total execution time: 0.0533
DEBUG - 2019-04-12 14:47:19 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:19 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:19 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:19 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:19 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:19 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:47:19 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:47:21 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:21 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:21 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:21 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:47:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:47:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:47:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:47:21 --> Final output sent to browser
DEBUG - 2019-04-12 14:47:21 --> Total execution time: 0.0507
DEBUG - 2019-04-12 14:47:21 --> Config Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:47:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:47:22 --> URI Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Router Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Output Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Security Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Input Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:47:22 --> Language Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Loader Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Controller Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Session Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:47:22 --> Session routines successfully run
DEBUG - 2019-04-12 14:47:22 --> Model Class Initialized
DEBUG - 2019-04-12 14:47:22 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:47:22 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:50:54 --> Config Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:50:54 --> URI Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Router Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Output Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Security Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Input Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:50:54 --> Language Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Loader Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Controller Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Session Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:50:54 --> Session routines successfully run
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:50:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:50:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:50:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:50:54 --> Final output sent to browser
DEBUG - 2019-04-12 14:50:54 --> Total execution time: 0.0778
DEBUG - 2019-04-12 14:50:54 --> Config Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:50:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:50:54 --> URI Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Router Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Output Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Security Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Input Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:50:54 --> Language Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Loader Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Controller Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Session Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:50:54 --> Session routines successfully run
DEBUG - 2019-04-12 14:50:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:50:54 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:50:54 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:51:09 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:09 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:09 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:09 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:51:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:51:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:51:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:51:09 --> Final output sent to browser
DEBUG - 2019-04-12 14:51:09 --> Total execution time: 0.0539
DEBUG - 2019-04-12 14:51:09 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:09 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:09 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:09 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:09 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:09 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:51:09 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:51:50 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:50 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:50 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:50 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:51:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:51:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:51:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:51:50 --> Final output sent to browser
DEBUG - 2019-04-12 14:51:50 --> Total execution time: 0.0706
DEBUG - 2019-04-12 14:51:50 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:50 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:50 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:50 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:50 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:50 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:51:50 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:51:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:51:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:51:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:51:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:51:53 --> Final output sent to browser
DEBUG - 2019-04-12 14:51:53 --> Total execution time: 0.0389
DEBUG - 2019-04-12 14:51:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:51:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:51:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:51:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:51:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:51:53 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:51:53 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:06 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:06 --> Total execution time: 0.0487
DEBUG - 2019-04-12 14:52:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:15 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:15 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:15 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:15 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:15 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:15 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:15 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:15 --> Total execution time: 0.1134
DEBUG - 2019-04-12 14:52:16 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:16 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:16 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:16 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:16 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:16 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:16 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:16 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:16 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:16 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:16 --> Total execution time: 0.0605
DEBUG - 2019-04-12 14:52:16 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:16 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:16 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:16 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:16 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:16 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:16 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:18 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:18 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:18 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:18 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:18 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:18 --> Total execution time: 0.0526
DEBUG - 2019-04-12 14:52:18 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:18 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:18 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:18 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:18 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:18 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:18 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:27 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:27 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:27 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:27 --> A session cookie was not found.
DEBUG - 2019-04-12 14:52:27 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:27 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:27 --> Total execution time: 0.1217
DEBUG - 2019-04-12 14:52:27 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:27 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:27 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:27 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:27 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:27 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:27 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:44 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:44 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:44 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:44 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:52:44 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:44 --> Total execution time: 0.0457
DEBUG - 2019-04-12 14:52:44 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:44 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:44 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:44 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:44 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:44 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:44 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:52:45 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:45 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:45 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:45 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:52:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:52:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:52:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:52:45 --> Final output sent to browser
DEBUG - 2019-04-12 14:52:45 --> Total execution time: 0.0810
DEBUG - 2019-04-12 14:52:45 --> Config Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:52:45 --> URI Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Router Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Output Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Security Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Input Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:52:45 --> Language Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Loader Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Controller Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Session Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:52:45 --> Session routines successfully run
DEBUG - 2019-04-12 14:52:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:52:45 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:52:45 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:53:05 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:05 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:05 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:53:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:53:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:53:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:53:06 --> Final output sent to browser
DEBUG - 2019-04-12 14:53:06 --> Total execution time: 0.0770
DEBUG - 2019-04-12 14:53:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:06 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:53:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:53:26 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:26 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:26 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:26 --> Session garbage collection performed.
DEBUG - 2019-04-12 14:53:26 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:53:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:53:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:53:26 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:53:26 --> Final output sent to browser
DEBUG - 2019-04-12 14:53:26 --> Total execution time: 0.0838
DEBUG - 2019-04-12 14:53:26 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:26 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:26 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:26 --> Session garbage collection performed.
DEBUG - 2019-04-12 14:53:26 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:26 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:26 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:53:26 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:53:33 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:33 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:33 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:33 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:33 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:33 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:53:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:53:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:53:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:53:34 --> Final output sent to browser
DEBUG - 2019-04-12 14:53:34 --> Total execution time: 0.0800
DEBUG - 2019-04-12 14:53:34 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:34 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:34 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:34 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:34 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:53:34 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:53:42 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:42 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:42 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:42 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:53:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:53:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:53:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:53:42 --> Final output sent to browser
DEBUG - 2019-04-12 14:53:42 --> Total execution time: 0.1797
DEBUG - 2019-04-12 14:53:42 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:42 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:42 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:42 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:42 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:42 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:53:42 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:53:48 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:48 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:48 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:48 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:53:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:53:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:53:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:53:48 --> Final output sent to browser
DEBUG - 2019-04-12 14:53:48 --> Total execution time: 0.0508
DEBUG - 2019-04-12 14:53:48 --> Config Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:53:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:53:48 --> URI Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Router Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Output Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Security Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Input Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:53:48 --> Language Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Loader Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Controller Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Session Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:53:48 --> Session routines successfully run
DEBUG - 2019-04-12 14:53:48 --> Model Class Initialized
DEBUG - 2019-04-12 14:53:48 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:53:48 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:54:14 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:14 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:14 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:14 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:54:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:54:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:54:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 14:54:14 --> Final output sent to browser
DEBUG - 2019-04-12 14:54:14 --> Total execution time: 0.1826
DEBUG - 2019-04-12 14:54:14 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:14 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:14 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:14 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:14 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:14 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:54:14 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:54:21 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:21 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:21 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:21 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:54:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:54:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:54:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:54:21 --> Final output sent to browser
DEBUG - 2019-04-12 14:54:21 --> Total execution time: 0.0618
DEBUG - 2019-04-12 14:54:21 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:21 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:21 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:21 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:21 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:21 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:54:21 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:54:45 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:45 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:45 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:45 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:54:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:54:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:54:45 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 14:54:45 --> Final output sent to browser
DEBUG - 2019-04-12 14:54:45 --> Total execution time: 0.0511
DEBUG - 2019-04-12 14:54:45 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:45 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:45 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:45 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:45 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:45 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:54:45 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:54:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:54:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:54:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:54:53 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-12 14:54:53 --> Final output sent to browser
DEBUG - 2019-04-12 14:54:53 --> Total execution time: 0.0504
DEBUG - 2019-04-12 14:54:53 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:53 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:53 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:53 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:53 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:53 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:54:53 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:54:59 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:59 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:59 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:59 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:54:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:54:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:54:59 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 14:54:59 --> Final output sent to browser
DEBUG - 2019-04-12 14:54:59 --> Total execution time: 0.0680
DEBUG - 2019-04-12 14:54:59 --> Config Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:54:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:54:59 --> URI Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Router Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Output Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Security Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Input Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:54:59 --> Language Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Loader Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Controller Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Session Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:54:59 --> Session routines successfully run
DEBUG - 2019-04-12 14:54:59 --> Model Class Initialized
DEBUG - 2019-04-12 14:54:59 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:54:59 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:55:34 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:34 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:34 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:34 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:55:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:55:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:55:34 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 14:55:34 --> Final output sent to browser
DEBUG - 2019-04-12 14:55:34 --> Total execution time: 0.0578
DEBUG - 2019-04-12 14:55:34 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:34 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:34 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:34 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:34 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:34 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:55:34 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:55:43 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:43 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:43 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:43 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:55:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:55:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:55:43 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 14:55:43 --> Final output sent to browser
DEBUG - 2019-04-12 14:55:43 --> Total execution time: 0.0557
DEBUG - 2019-04-12 14:55:43 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:43 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:43 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:43 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:43 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:43 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:55:43 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:55:51 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:51 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:51 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:51 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:55:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:55:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:55:51 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-12 14:55:51 --> Final output sent to browser
DEBUG - 2019-04-12 14:55:51 --> Total execution time: 0.0570
DEBUG - 2019-04-12 14:55:51 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:51 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:51 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:51 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:51 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:51 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:55:51 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:55:54 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:54 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:54 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:54 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:54 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:55:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:55:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:55:54 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 14:55:54 --> Final output sent to browser
DEBUG - 2019-04-12 14:55:54 --> Total execution time: 0.0578
DEBUG - 2019-04-12 14:55:54 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:54 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:54 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:55 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:55 --> Session garbage collection performed.
DEBUG - 2019-04-12 14:55:55 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:55 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:55:55 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:55:57 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:57 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:57 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:57 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:55:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:55:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:55:57 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 14:55:57 --> Final output sent to browser
DEBUG - 2019-04-12 14:55:57 --> Total execution time: 0.0496
DEBUG - 2019-04-12 14:55:57 --> Config Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:55:57 --> URI Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Router Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Output Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Security Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Input Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:55:57 --> Language Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Loader Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Controller Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Session Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:55:57 --> Session routines successfully run
DEBUG - 2019-04-12 14:55:57 --> Model Class Initialized
DEBUG - 2019-04-12 14:55:57 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:55:57 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:56:00 --> Config Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:56:00 --> URI Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Router Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Output Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Security Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Input Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:56:00 --> Language Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Loader Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Controller Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Session Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:56:00 --> Session routines successfully run
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:56:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:56:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:56:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:56:00 --> Final output sent to browser
DEBUG - 2019-04-12 14:56:00 --> Total execution time: 0.0514
DEBUG - 2019-04-12 14:56:00 --> Config Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:56:00 --> URI Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Router Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Output Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Security Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Input Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:56:00 --> Language Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Loader Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Controller Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Session Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:56:00 --> Session routines successfully run
DEBUG - 2019-04-12 14:56:00 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:00 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:56:00 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:56:06 --> Config Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:56:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:56:06 --> URI Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Router Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Output Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Security Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Input Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:56:06 --> Language Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Loader Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Controller Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Session Class Initialized
DEBUG - 2019-04-12 14:56:06 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:56:07 --> Session routines successfully run
DEBUG - 2019-04-12 14:56:07 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/noticeUserDetails.php
DEBUG - 2019-04-12 14:56:07 --> Final output sent to browser
DEBUG - 2019-04-12 14:56:07 --> Total execution time: 0.0776
DEBUG - 2019-04-12 14:56:07 --> Config Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:56:07 --> URI Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Router Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Output Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Security Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Input Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:56:07 --> Language Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Loader Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Controller Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Model Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Session Class Initialized
DEBUG - 2019-04-12 14:56:07 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:56:07 --> Session routines successfully run
DEBUG - 2019-04-12 14:56:07 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:56:07 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-12 14:56:07 --> Final output sent to browser
DEBUG - 2019-04-12 14:56:07 --> Total execution time: 0.0574
DEBUG - 2019-04-12 14:57:38 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:38 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:38 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:38 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:39 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:57:39 --> Final output sent to browser
DEBUG - 2019-04-12 14:57:39 --> Total execution time: 0.1146
DEBUG - 2019-04-12 14:57:39 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:39 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:39 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:39 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:57:39 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:57:39 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:39 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:39 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:39 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:57:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:57:39 --> Final output sent to browser
DEBUG - 2019-04-12 14:57:39 --> Total execution time: 0.0518
DEBUG - 2019-04-12 14:57:39 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:39 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:39 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:39 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:39 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:39 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:57:39 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 14:57:55 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:55 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:55 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:55 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Helper loaded: url_helper
DEBUG - 2019-04-12 14:57:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 14:57:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 14:57:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 14:57:55 --> Final output sent to browser
DEBUG - 2019-04-12 14:57:55 --> Total execution time: 0.0628
DEBUG - 2019-04-12 14:57:55 --> Config Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Hooks Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Utf8 Class Initialized
DEBUG - 2019-04-12 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 14:57:55 --> URI Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Router Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Output Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Security Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Input Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 14:57:55 --> Language Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Loader Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Controller Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Database Driver Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Session Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Helper loaded: string_helper
DEBUG - 2019-04-12 14:57:55 --> Session routines successfully run
DEBUG - 2019-04-12 14:57:55 --> Model Class Initialized
DEBUG - 2019-04-12 14:57:55 --> Helper loaded: url_helper
ERROR - 2019-04-12 14:57:55 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:01:31 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:31 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:31 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:31 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:01:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:01:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:01:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:01:31 --> Final output sent to browser
DEBUG - 2019-04-12 15:01:31 --> Total execution time: 0.1253
DEBUG - 2019-04-12 15:01:31 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:31 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:31 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:31 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:31 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:31 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:01:31 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:01:42 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:42 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:42 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:42 --> Session garbage collection performed.
DEBUG - 2019-04-12 15:01:42 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:01:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:01:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:01:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:01:42 --> Final output sent to browser
DEBUG - 2019-04-12 15:01:42 --> Total execution time: 0.0553
DEBUG - 2019-04-12 15:01:42 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:42 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:42 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:42 --> Session garbage collection performed.
DEBUG - 2019-04-12 15:01:42 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:42 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:01:42 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:01:44 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:44 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:44 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:44 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:01:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:01:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:01:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:01:44 --> Final output sent to browser
DEBUG - 2019-04-12 15:01:44 --> Total execution time: 0.0498
DEBUG - 2019-04-12 15:01:44 --> Config Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:01:44 --> URI Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Router Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Output Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Security Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Input Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:01:44 --> Language Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Loader Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Controller Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Session Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:01:44 --> Session routines successfully run
DEBUG - 2019-04-12 15:01:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:01:44 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:01:44 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:03:05 --> Config Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:03:05 --> URI Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Router Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Output Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Security Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Input Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:03:05 --> Language Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Loader Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Controller Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Session Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:03:05 --> Session routines successfully run
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:03:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:03:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:03:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:03:05 --> Final output sent to browser
DEBUG - 2019-04-12 15:03:05 --> Total execution time: 0.1627
DEBUG - 2019-04-12 15:03:05 --> Config Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:03:05 --> URI Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Router Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Output Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Security Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Input Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:03:05 --> Language Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Loader Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Controller Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Session Class Initialized
DEBUG - 2019-04-12 15:03:05 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:03:05 --> Session routines successfully run
DEBUG - 2019-04-12 15:03:05 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:06 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:03:06 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:03:08 --> Config Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:03:08 --> URI Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Router Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Output Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Security Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Input Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:03:08 --> Language Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Loader Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Controller Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Session Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:03:08 --> Session routines successfully run
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:03:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:03:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:03:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:03:08 --> Final output sent to browser
DEBUG - 2019-04-12 15:03:08 --> Total execution time: 0.0587
DEBUG - 2019-04-12 15:03:08 --> Config Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:03:08 --> URI Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Router Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Output Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Security Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Input Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:03:08 --> Language Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Loader Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Controller Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Session Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:03:08 --> Session routines successfully run
DEBUG - 2019-04-12 15:03:08 --> Model Class Initialized
DEBUG - 2019-04-12 15:03:08 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:03:08 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:09:53 --> Config Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:09:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:09:53 --> URI Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Router Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Output Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Security Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Input Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:09:53 --> Language Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Loader Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Controller Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Session Class Initialized
DEBUG - 2019-04-12 15:09:53 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:09:54 --> Session routines successfully run
DEBUG - 2019-04-12 15:09:54 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:09:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:09:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:09:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:09:54 --> Final output sent to browser
DEBUG - 2019-04-12 15:09:54 --> Total execution time: 0.0984
DEBUG - 2019-04-12 15:09:54 --> Config Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:09:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:09:54 --> URI Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Router Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Output Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Security Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Input Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:09:54 --> Language Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Loader Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Controller Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Session Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:09:54 --> Session routines successfully run
DEBUG - 2019-04-12 15:09:54 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:54 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:09:54 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:09:56 --> Config Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:09:56 --> URI Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Router Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Output Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Security Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Input Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:09:56 --> Language Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Loader Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Controller Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Session Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:09:56 --> Session routines successfully run
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:09:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:09:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:09:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:09:56 --> Final output sent to browser
DEBUG - 2019-04-12 15:09:56 --> Total execution time: 0.0399
DEBUG - 2019-04-12 15:09:56 --> Config Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:09:56 --> URI Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Router Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Output Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Security Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Input Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:09:56 --> Language Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Loader Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Controller Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Session Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:09:56 --> Session routines successfully run
DEBUG - 2019-04-12 15:09:56 --> Model Class Initialized
DEBUG - 2019-04-12 15:09:56 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:09:56 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:10:24 --> Config Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:10:24 --> URI Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Router Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Output Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Security Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Input Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:10:24 --> Language Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Loader Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Controller Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Session Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:10:24 --> Session routines successfully run
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:10:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:10:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:10:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:10:24 --> Final output sent to browser
DEBUG - 2019-04-12 15:10:24 --> Total execution time: 0.0467
DEBUG - 2019-04-12 15:10:24 --> Config Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:10:24 --> URI Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Router Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Output Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Security Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Input Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:10:24 --> Language Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Loader Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Controller Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Session Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:10:24 --> Session routines successfully run
DEBUG - 2019-04-12 15:10:24 --> Model Class Initialized
DEBUG - 2019-04-12 15:10:24 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:10:24 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:11:28 --> Config Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:11:28 --> URI Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Router Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Output Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Security Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Input Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:11:28 --> Language Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Loader Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Controller Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Session Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:11:28 --> Session routines successfully run
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:11:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:11:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:11:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:11:28 --> Final output sent to browser
DEBUG - 2019-04-12 15:11:28 --> Total execution time: 0.0662
DEBUG - 2019-04-12 15:11:28 --> Config Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:11:28 --> URI Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Router Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Output Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Security Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Input Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:11:28 --> Language Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Loader Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Controller Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Session Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:11:28 --> Session routines successfully run
DEBUG - 2019-04-12 15:11:28 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:28 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:11:28 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:11:32 --> Config Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:11:32 --> URI Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Router Class Initialized
DEBUG - 2019-04-12 15:11:32 --> No URI present. Default controller set.
DEBUG - 2019-04-12 15:11:32 --> Output Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Security Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Input Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:11:32 --> Language Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Loader Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Controller Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Session Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:11:32 --> Session routines successfully run
DEBUG - 2019-04-12 15:11:32 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:32 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:11:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:11:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:11:32 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 15:11:32 --> Final output sent to browser
DEBUG - 2019-04-12 15:11:32 --> Total execution time: 0.1008
DEBUG - 2019-04-12 15:11:34 --> Config Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:11:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:11:34 --> URI Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Router Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Output Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Security Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Input Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:11:34 --> Language Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Loader Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Controller Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Session Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:11:34 --> Session routines successfully run
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:11:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:11:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:11:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:11:34 --> Final output sent to browser
DEBUG - 2019-04-12 15:11:34 --> Total execution time: 0.0399
DEBUG - 2019-04-12 15:11:34 --> Config Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:11:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:11:34 --> URI Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Router Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Output Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Security Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Input Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:11:34 --> Language Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Loader Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Controller Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Session Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:11:34 --> Session routines successfully run
DEBUG - 2019-04-12 15:11:34 --> Model Class Initialized
DEBUG - 2019-04-12 15:11:34 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:11:34 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:12:27 --> Config Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:12:27 --> URI Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Router Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Output Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Security Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Input Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:12:27 --> Language Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Loader Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Controller Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Session Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:12:27 --> Session routines successfully run
DEBUG - 2019-04-12 15:12:27 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:27 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:12:40 --> Config Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:12:40 --> URI Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Router Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Output Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Security Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Input Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:12:40 --> Language Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Loader Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Controller Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Session Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:12:40 --> Session routines successfully run
DEBUG - 2019-04-12 15:12:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:40 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:12:50 --> Config Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:12:50 --> URI Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Router Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Output Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Security Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Input Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:12:50 --> Language Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Loader Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Controller Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Session Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:12:50 --> Session routines successfully run
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:12:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:12:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:12:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:12:50 --> Final output sent to browser
DEBUG - 2019-04-12 15:12:50 --> Total execution time: 0.0669
DEBUG - 2019-04-12 15:12:50 --> Config Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:12:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:12:50 --> URI Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Router Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Output Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Security Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Input Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:12:50 --> Language Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Loader Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Controller Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Session Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:12:50 --> Session routines successfully run
DEBUG - 2019-04-12 15:12:50 --> Model Class Initialized
DEBUG - 2019-04-12 15:12:50 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:12:50 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:15:40 --> Config Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:15:40 --> URI Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Router Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Output Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Security Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Input Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:15:40 --> Language Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Loader Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Controller Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Session Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:15:40 --> Session routines successfully run
DEBUG - 2019-04-12 15:15:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:15:40 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:16:03 --> Config Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:16:03 --> URI Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Router Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Output Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Security Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Input Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:16:03 --> Language Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Loader Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Controller Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Session Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:16:03 --> Session routines successfully run
DEBUG - 2019-04-12 15:16:03 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:03 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:16:09 --> Config Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:16:09 --> URI Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Router Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Output Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Security Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Input Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:16:09 --> Language Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Loader Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Controller Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Session Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:16:09 --> Session routines successfully run
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:16:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:16:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:16:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:16:09 --> Final output sent to browser
DEBUG - 2019-04-12 15:16:09 --> Total execution time: 0.0614
DEBUG - 2019-04-12 15:16:09 --> Config Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:16:09 --> URI Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Router Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Output Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Security Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Input Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:16:09 --> Language Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Loader Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Controller Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Session Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:16:09 --> Session routines successfully run
DEBUG - 2019-04-12 15:16:09 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:09 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:16:09 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:16:11 --> Config Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:16:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:16:11 --> URI Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Router Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Output Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Security Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Input Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:16:11 --> Language Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Loader Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Controller Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Model Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Session Class Initialized
DEBUG - 2019-04-12 15:16:11 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:16:11 --> Session routines successfully run
DEBUG - 2019-04-12 15:16:11 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:16:11 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE1
DEBUG - 2019-04-12 15:17:48 --> Config Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:17:49 --> URI Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Router Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Output Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Security Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Input Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:17:49 --> Language Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Loader Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Controller Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Session Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:17:49 --> Session routines successfully run
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:17:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:17:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:17:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:17:49 --> Final output sent to browser
DEBUG - 2019-04-12 15:17:49 --> Total execution time: 0.0548
DEBUG - 2019-04-12 15:17:49 --> Config Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:17:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:17:49 --> URI Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Router Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Output Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Security Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Input Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:17:49 --> Language Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Loader Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Controller Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Session Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:17:49 --> Session routines successfully run
DEBUG - 2019-04-12 15:17:49 --> Model Class Initialized
DEBUG - 2019-04-12 15:17:49 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:17:49 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:18:00 --> Config Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:18:00 --> URI Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Router Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Output Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Security Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Input Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:18:00 --> Language Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Loader Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Controller Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Session Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:18:00 --> Session routines successfully run
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:18:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:18:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:18:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:18:00 --> Final output sent to browser
DEBUG - 2019-04-12 15:18:00 --> Total execution time: 0.0572
DEBUG - 2019-04-12 15:18:00 --> Config Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:18:00 --> URI Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Router Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Output Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Security Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Input Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:18:00 --> Language Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Loader Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Controller Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Session Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:18:00 --> Session routines successfully run
DEBUG - 2019-04-12 15:18:00 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:00 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:18:00 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:18:21 --> Config Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:18:21 --> URI Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Router Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Output Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Security Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Input Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:18:21 --> Language Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Loader Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Controller Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Session Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:18:21 --> Session routines successfully run
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:18:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:18:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:18:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:18:21 --> Final output sent to browser
DEBUG - 2019-04-12 15:18:21 --> Total execution time: 0.0533
DEBUG - 2019-04-12 15:18:21 --> Config Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:18:21 --> URI Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Router Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Output Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Security Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Input Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:18:21 --> Language Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Loader Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Controller Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Session Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:18:21 --> Session routines successfully run
DEBUG - 2019-04-12 15:18:21 --> Model Class Initialized
DEBUG - 2019-04-12 15:18:21 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:18:21 --> 404 Page Not Found --> User/js
DEBUG - 2019-04-12 15:25:12 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:12 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:12 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:12 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:12 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:13 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:13 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:13 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:13 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:25:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:25:13 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:13 --> Total execution time: 0.1163
DEBUG - 2019-04-12 15:25:16 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:16 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:16 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:16 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:16 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:16 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:25:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:25:16 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:16 --> Total execution time: 0.0493
DEBUG - 2019-04-12 15:25:19 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:19 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:19 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:19 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:19 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:19 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:25:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 15:25:19 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:19 --> Total execution time: 0.1035
DEBUG - 2019-04-12 15:25:26 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:26 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:26 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:26 --> Session garbage collection performed.
DEBUG - 2019-04-12 15:25:26 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:26 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:26 --> Helper loaded: url_helper
DEBUG - 2019-04-12 15:25:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:26 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 15:25:26 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:26 --> Total execution time: 0.0471
DEBUG - 2019-04-12 15:25:39 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:39 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:39 --> No URI present. Default controller set.
DEBUG - 2019-04-12 15:25:39 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:39 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:39 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:40 --> Session garbage collection performed.
DEBUG - 2019-04-12 15:25:40 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:40 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:40 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:40 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 15:25:40 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:40 --> Total execution time: 0.0988
DEBUG - 2019-04-12 15:25:41 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:41 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:41 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:41 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:41 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:41 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 15:25:41 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:41 --> Total execution time: 0.1324
DEBUG - 2019-04-12 15:25:41 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:41 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:41 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:42 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:42 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:42 --> Session garbage collection performed.
DEBUG - 2019-04-12 15:25:42 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:42 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:42 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-12 15:25:42 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:42 --> Total execution time: 0.0516
DEBUG - 2019-04-12 15:25:42 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:42 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:42 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:43 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:43 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:43 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:43 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:43 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:43 --> File loaded: application/views/producers.php
DEBUG - 2019-04-12 15:25:43 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:43 --> Total execution time: 0.0603
DEBUG - 2019-04-12 15:25:43 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:43 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:43 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:44 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:44 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:44 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:44 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:44 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:44 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-12 15:25:44 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:44 --> Total execution time: 0.0645
DEBUG - 2019-04-12 15:25:44 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:44 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:44 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:45 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:45 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:45 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:45 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:45 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-12 15:25:45 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:45 --> Total execution time: 0.0945
DEBUG - 2019-04-12 15:25:45 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:45 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:45 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:46 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Router Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Output Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Security Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Input Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-12 15:25:46 --> Language Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Loader Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Controller Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Database Driver Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Session Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Helper loaded: string_helper
DEBUG - 2019-04-12 15:25:46 --> Session routines successfully run
DEBUG - 2019-04-12 15:25:46 --> Model Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Helper loaded: url_helper
ERROR - 2019-04-12 15:25:46 --> Severity: Notice  --> Undefined variable: jsbase C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\header.php 18
DEBUG - 2019-04-12 15:25:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-12 15:25:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-12 15:25:46 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-12 15:25:46 --> Final output sent to browser
DEBUG - 2019-04-12 15:25:46 --> Total execution time: 0.0561
DEBUG - 2019-04-12 15:25:46 --> Config Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Hooks Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Utf8 Class Initialized
DEBUG - 2019-04-12 15:25:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-12 15:25:46 --> URI Class Initialized
DEBUG - 2019-04-12 15:25:46 --> Router Class Initialized
