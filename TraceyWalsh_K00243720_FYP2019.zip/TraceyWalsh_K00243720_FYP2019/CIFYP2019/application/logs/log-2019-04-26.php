<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-26 12:22:09 --> Config Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:22:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:22:09 --> URI Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Router Class Initialized
DEBUG - 2019-04-26 12:22:09 --> No URI present. Default controller set.
DEBUG - 2019-04-26 12:22:09 --> Output Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Security Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Input Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:22:09 --> Language Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Loader Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Controller Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Session Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:22:09 --> A session cookie was not found.
DEBUG - 2019-04-26 12:22:09 --> Session routines successfully run
DEBUG - 2019-04-26 12:22:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:09 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:22:09 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:22:09 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:22:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:22:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:22:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-26 12:22:10 --> Final output sent to browser
DEBUG - 2019-04-26 12:22:10 --> Total execution time: 0.4604
DEBUG - 2019-04-26 12:22:19 --> Config Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:22:19 --> URI Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Router Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Output Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Security Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Input Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:22:19 --> Language Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Loader Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Controller Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Session Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:22:19 --> Session routines successfully run
DEBUG - 2019-04-26 12:22:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:19 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:22:19 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:22:19 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:22:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:22:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:22:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-26 12:22:20 --> Final output sent to browser
DEBUG - 2019-04-26 12:22:20 --> Total execution time: 0.1242
DEBUG - 2019-04-26 12:22:21 --> Config Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:22:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:22:21 --> URI Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Router Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Output Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Security Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Input Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:22:21 --> Language Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Loader Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Controller Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Session Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:22:21 --> Session routines successfully run
DEBUG - 2019-04-26 12:22:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:22:21 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:22:21 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:22:21 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:22:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:22:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:22:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:22:21 --> Final output sent to browser
DEBUG - 2019-04-26 12:22:21 --> Total execution time: 0.0634
DEBUG - 2019-04-26 12:42:15 --> Config Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:42:15 --> URI Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Router Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Output Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Security Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Input Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:42:15 --> Language Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Loader Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Controller Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Session Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:42:15 --> Session routines successfully run
DEBUG - 2019-04-26 12:42:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:15 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:42:15 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:42:15 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:42:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:42:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:42:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:42:15 --> Final output sent to browser
DEBUG - 2019-04-26 12:42:15 --> Total execution time: 0.1505
DEBUG - 2019-04-26 12:42:48 --> Config Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:42:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:42:48 --> URI Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Router Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Output Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Security Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Input Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:42:48 --> Language Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Loader Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Controller Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Session Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:42:48 --> Session routines successfully run
DEBUG - 2019-04-26 12:42:48 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:48 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:42:48 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:42:48 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:42:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:42:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:42:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:42:48 --> Final output sent to browser
DEBUG - 2019-04-26 12:42:48 --> Total execution time: 0.0668
DEBUG - 2019-04-26 12:42:58 --> Config Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:42:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:42:58 --> URI Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Router Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Output Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Security Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Input Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:42:58 --> Language Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Loader Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Controller Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Session Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:42:58 --> Session routines successfully run
DEBUG - 2019-04-26 12:42:58 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Model Class Initialized
DEBUG - 2019-04-26 12:42:58 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:42:58 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:42:58 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Config Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:46:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:46:25 --> URI Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Router Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Output Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Security Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Input Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:46:25 --> Language Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Loader Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Controller Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Session Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:46:25 --> Session routines successfully run
DEBUG - 2019-04-26 12:46:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:25 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:46:25 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:46:25 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:46:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:46:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:46:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:46:25 --> Final output sent to browser
DEBUG - 2019-04-26 12:46:25 --> Total execution time: 0.0567
DEBUG - 2019-04-26 12:46:27 --> Config Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:46:27 --> URI Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Router Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Output Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Security Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Input Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:46:27 --> Language Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Loader Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Controller Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Session Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:46:27 --> Session routines successfully run
DEBUG - 2019-04-26 12:46:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:46:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:46:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:46:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:01 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:01 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:01 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:01 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:01 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:01 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:01 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:47:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:47:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:47:01 --> Final output sent to browser
DEBUG - 2019-04-26 12:47:01 --> Total execution time: 0.0673
DEBUG - 2019-04-26 12:47:03 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:03 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:03 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:03 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:03 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:03 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:03 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:03 --> Form Validation Class Initialized
ERROR - 2019-04-26 12:47:03 --> 404 Page Not Found --> User/insertOrder
DEBUG - 2019-04-26 12:47:09 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:09 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:09 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:09 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:09 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:09 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:09 --> Form Validation Class Initialized
ERROR - 2019-04-26 12:47:09 --> 404 Page Not Found --> User/insertOrder
DEBUG - 2019-04-26 12:47:14 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:14 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:14 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:14 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:14 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:15 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:15 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:47:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:47:15 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-26 12:47:15 --> Final output sent to browser
DEBUG - 2019-04-26 12:47:15 --> Total execution time: 0.0612
DEBUG - 2019-04-26 12:47:21 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:21 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:21 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:21 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:22 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:22 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:22 --> Session garbage collection performed.
DEBUG - 2019-04-26 12:47:22 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:22 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:22 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:22 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:22 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:22 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:47:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:47:22 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-26 12:47:22 --> Final output sent to browser
DEBUG - 2019-04-26 12:47:22 --> Total execution time: 0.3901
DEBUG - 2019-04-26 12:47:23 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:23 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:23 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:23 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:23 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:23 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:23 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:47:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:47:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:47:23 --> Final output sent to browser
DEBUG - 2019-04-26 12:47:23 --> Total execution time: 0.0574
DEBUG - 2019-04-26 12:47:24 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:24 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:24 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:24 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:25 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:25 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:25 --> Session garbage collection performed.
DEBUG - 2019-04-26 12:47:25 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:25 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:25 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:25 --> Form Validation Class Initialized
ERROR - 2019-04-26 12:47:25 --> 404 Page Not Found --> User/insertOrder
DEBUG - 2019-04-26 12:47:27 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:27 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:27 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:27 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:35 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:35 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:35 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:35 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:35 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:35 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:35 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:47:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:47:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:47:35 --> File loaded: application/views/profile.php
DEBUG - 2019-04-26 12:47:35 --> Final output sent to browser
DEBUG - 2019-04-26 12:47:35 --> Total execution time: 0.0746
DEBUG - 2019-04-26 12:47:37 --> Config Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:47:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:47:37 --> URI Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Router Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Output Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Security Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Input Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:47:37 --> Language Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Loader Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Controller Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Session Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:47:37 --> Session routines successfully run
DEBUG - 2019-04-26 12:47:37 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Model Class Initialized
DEBUG - 2019-04-26 12:47:37 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:47:37 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:47:37 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:20 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:20 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:20 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:23 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:23 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:23 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:23 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:23 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:23 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:48:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:48:23 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-26 12:48:23 --> Final output sent to browser
DEBUG - 2019-04-26 12:48:23 --> Total execution time: 0.1173
DEBUG - 2019-04-26 12:48:24 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:24 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:24 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:24 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:24 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:24 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:24 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:48:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:48:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:48:24 --> Final output sent to browser
DEBUG - 2019-04-26 12:48:24 --> Total execution time: 0.0617
DEBUG - 2019-04-26 12:48:25 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:25 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:25 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:25 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:25 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:25 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:25 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:25 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:25 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:25 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:51 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:51 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:51 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:51 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:48:51 --> Final output sent to browser
DEBUG - 2019-04-26 12:48:51 --> Total execution time: 0.0696
DEBUG - 2019-04-26 12:48:51 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:51 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:51 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:51 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:51 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:51 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:48:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:48:51 --> Final output sent to browser
DEBUG - 2019-04-26 12:48:51 --> Total execution time: 0.0438
DEBUG - 2019-04-26 12:48:53 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:53 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:53 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:53 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:53 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Config Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:48:53 --> URI Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Router Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Output Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Security Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Input Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:48:53 --> Language Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Loader Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Controller Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Session Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:48:53 --> Session routines successfully run
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Model Class Initialized
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:48:53 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:48:53 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Config Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:49:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:49:41 --> URI Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Router Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Output Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Security Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Input Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:49:41 --> Language Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Loader Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Controller Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Session Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:49:41 --> Session routines successfully run
DEBUG - 2019-04-26 12:49:41 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:41 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:49:41 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:49:41 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:49:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:49:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:49:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:49:41 --> Final output sent to browser
DEBUG - 2019-04-26 12:49:41 --> Total execution time: 0.0667
DEBUG - 2019-04-26 12:49:43 --> Config Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:49:43 --> URI Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Router Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Output Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Security Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Input Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:49:43 --> Language Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Loader Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Controller Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Session Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:49:43 --> Session routines successfully run
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:49:43 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:49:43 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:49:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:49:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:49:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-26 12:49:43 --> Final output sent to browser
DEBUG - 2019-04-26 12:49:43 --> Total execution time: 0.1124
DEBUG - 2019-04-26 12:49:43 --> Config Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:49:43 --> URI Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Router Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Output Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Security Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Input Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:49:43 --> Language Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Loader Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Controller Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:43 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:44 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:49:44 --> Session Class Initialized
DEBUG - 2019-04-26 12:49:44 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:49:44 --> Session routines successfully run
DEBUG - 2019-04-26 12:49:44 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:44 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:44 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:49:44 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:49:44 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:49:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:49:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:49:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:49:44 --> Final output sent to browser
DEBUG - 2019-04-26 12:49:44 --> Total execution time: 0.0602
DEBUG - 2019-04-26 12:49:45 --> Config Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:49:45 --> URI Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Router Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Output Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Security Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Input Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:49:45 --> Language Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Loader Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Controller Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Session Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:49:45 --> Session routines successfully run
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:49:45 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Config Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:49:45 --> URI Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Router Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Output Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Security Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Input Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:49:45 --> Language Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Loader Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Controller Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Session Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:49:45 --> Session routines successfully run
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Model Class Initialized
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:49:45 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:49:45 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Config Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:51:18 --> URI Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Router Class Initialized
DEBUG - 2019-04-26 12:51:18 --> No URI present. Default controller set.
DEBUG - 2019-04-26 12:51:18 --> Output Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Security Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Input Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:51:18 --> Language Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Loader Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Controller Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Session Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:51:18 --> Session routines successfully run
DEBUG - 2019-04-26 12:51:18 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:18 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:51:18 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:51:18 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:51:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:51:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-26 12:51:18 --> Final output sent to browser
DEBUG - 2019-04-26 12:51:18 --> Total execution time: 0.1291
DEBUG - 2019-04-26 12:51:20 --> Config Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:51:20 --> URI Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Router Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Output Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Security Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Input Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:51:20 --> Language Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Loader Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Controller Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Session Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:51:20 --> Session garbage collection performed.
DEBUG - 2019-04-26 12:51:20 --> Session routines successfully run
DEBUG - 2019-04-26 12:51:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:51:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:51:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:20 --> File loaded: application/views/header.php
ERROR - 2019-04-26 12:51:20 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
ERROR - 2019-04-26 12:51:20 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
DEBUG - 2019-04-26 12:51:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:51:20 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 12:51:20 --> Final output sent to browser
DEBUG - 2019-04-26 12:51:20 --> Total execution time: 0.1299
DEBUG - 2019-04-26 12:51:31 --> Config Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:51:31 --> URI Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Router Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Output Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Security Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Input Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:51:31 --> Language Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Loader Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Controller Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Session Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:51:31 --> Session routines successfully run
DEBUG - 2019-04-26 12:51:31 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:31 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:51:31 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:51:31 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:51:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:51:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:51:31 --> Final output sent to browser
DEBUG - 2019-04-26 12:51:31 --> Total execution time: 0.0603
DEBUG - 2019-04-26 12:51:33 --> Config Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:51:33 --> URI Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Router Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Output Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Security Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Input Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:51:33 --> Language Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Loader Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Controller Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Session Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:51:33 --> Session routines successfully run
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:51:33 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Config Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:51:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:51:33 --> URI Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Router Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Output Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Security Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Input Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:51:33 --> Language Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Loader Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Controller Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Session Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:51:33 --> Session routines successfully run
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Model Class Initialized
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:51:33 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:51:33 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:51:33 --> File loaded: application/views/header.php
ERROR - 2019-04-26 12:51:33 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
ERROR - 2019-04-26 12:51:33 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
DEBUG - 2019-04-26 12:51:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:51:33 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 12:51:33 --> Final output sent to browser
DEBUG - 2019-04-26 12:51:33 --> Total execution time: 0.1048
DEBUG - 2019-04-26 12:54:24 --> Config Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:54:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:54:24 --> URI Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Router Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Output Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Security Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Input Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:54:24 --> Language Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Loader Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Controller Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Session Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:54:24 --> Session routines successfully run
DEBUG - 2019-04-26 12:54:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:24 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:54:24 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:54:24 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:54:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:54:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:54:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:54:24 --> Final output sent to browser
DEBUG - 2019-04-26 12:54:24 --> Total execution time: 0.1592
DEBUG - 2019-04-26 12:54:27 --> Config Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:54:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:54:27 --> URI Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Router Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Output Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Security Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Input Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:54:27 --> Language Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Loader Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Controller Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Session Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:54:27 --> Session routines successfully run
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:54:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Config Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:54:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:54:27 --> URI Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Router Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Output Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Security Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Input Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:54:27 --> Language Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Loader Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Controller Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Session Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:54:27 --> Session routines successfully run
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:54:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:54:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:54:27 --> File loaded: application/views/header.php
ERROR - 2019-04-26 12:54:27 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
ERROR - 2019-04-26 12:54:27 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
DEBUG - 2019-04-26 12:54:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:54:27 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 12:54:27 --> Final output sent to browser
DEBUG - 2019-04-26 12:54:27 --> Total execution time: 0.1298
DEBUG - 2019-04-26 12:55:27 --> Config Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:55:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:55:27 --> URI Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Router Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Output Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Security Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Input Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:55:27 --> Language Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Loader Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Controller Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Session Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:55:27 --> Session routines successfully run
DEBUG - 2019-04-26 12:55:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:55:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:55:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:55:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:55:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:55:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:55:27 --> Final output sent to browser
DEBUG - 2019-04-26 12:55:27 --> Total execution time: 0.0641
DEBUG - 2019-04-26 12:55:29 --> Config Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:55:29 --> URI Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Router Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Output Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Security Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Input Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:55:29 --> Language Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Loader Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Controller Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Session Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:55:29 --> Session routines successfully run
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:55:29 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Config Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:55:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:55:29 --> URI Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Router Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Output Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Security Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Input Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:55:29 --> Language Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Loader Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Controller Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Session Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:55:29 --> Session routines successfully run
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Model Class Initialized
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:55:29 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:55:29 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Config Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:56:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:56:14 --> URI Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Router Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Output Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Security Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Input Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:56:14 --> Language Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Loader Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Controller Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Session Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:56:14 --> Session routines successfully run
DEBUG - 2019-04-26 12:56:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:14 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:56:14 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:56:14 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:56:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:56:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:56:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:56:14 --> Final output sent to browser
DEBUG - 2019-04-26 12:56:14 --> Total execution time: 0.0594
DEBUG - 2019-04-26 12:56:15 --> Config Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:56:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:56:15 --> URI Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Router Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Output Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Security Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Input Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:56:15 --> Language Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Loader Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Controller Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Session Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:56:15 --> Session routines successfully run
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:56:15 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Config Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:56:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:56:15 --> URI Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Router Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Output Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Security Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Input Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:56:15 --> Language Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Loader Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Controller Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Session Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:56:15 --> Session routines successfully run
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Model Class Initialized
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:56:15 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:56:15 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:56:15 --> File loaded: application/views/header.php
ERROR - 2019-04-26 12:56:15 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
ERROR - 2019-04-26 12:56:15 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
DEBUG - 2019-04-26 12:56:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:56:15 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 12:56:15 --> Final output sent to browser
DEBUG - 2019-04-26 12:56:15 --> Total execution time: 0.0957
DEBUG - 2019-04-26 12:57:19 --> Config Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:57:19 --> URI Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Router Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Output Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Security Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Input Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:57:19 --> Language Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Loader Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Controller Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Session Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:57:19 --> Session routines successfully run
DEBUG - 2019-04-26 12:57:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:19 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:57:19 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:57:19 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:57:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 12:57:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 12:57:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 12:57:19 --> Final output sent to browser
DEBUG - 2019-04-26 12:57:19 --> Total execution time: 0.0716
DEBUG - 2019-04-26 12:57:20 --> Config Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:57:20 --> URI Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Router Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Output Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Security Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Input Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:57:20 --> Language Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Loader Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Controller Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Session Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:57:20 --> Session routines successfully run
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:57:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Config Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 12:57:20 --> URI Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Router Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Output Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Security Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Input Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 12:57:20 --> Language Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Loader Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Controller Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Session Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 12:57:20 --> Session routines successfully run
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Model Class Initialized
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 12:57:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 12:57:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Config Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:01:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:01:55 --> URI Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Router Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Output Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Security Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Input Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:01:55 --> Language Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Loader Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Controller Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Session Class Initialized
DEBUG - 2019-04-26 13:01:55 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:01:56 --> Session routines successfully run
DEBUG - 2019-04-26 13:01:56 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:56 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:56 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:01:56 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:01:56 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:01:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:01:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:01:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:01:56 --> Final output sent to browser
DEBUG - 2019-04-26 13:01:56 --> Total execution time: 0.1378
DEBUG - 2019-04-26 13:01:57 --> Config Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:01:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:01:57 --> URI Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Router Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Output Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Security Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Input Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:01:57 --> Language Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Loader Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Controller Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Session Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:01:57 --> Session routines successfully run
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:01:57 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Config Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:01:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:01:57 --> URI Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Router Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Output Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Security Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Input Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:01:57 --> Language Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Loader Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Controller Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Session Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:01:57 --> Session routines successfully run
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:01:57 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:01:57 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Config Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:02:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:02:46 --> URI Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Router Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Output Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Security Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Input Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:02:46 --> Language Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Loader Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Controller Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Session Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:02:46 --> Session routines successfully run
DEBUG - 2019-04-26 13:02:46 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:46 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:02:46 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:02:46 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:02:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:02:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:02:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-26 13:02:46 --> Final output sent to browser
DEBUG - 2019-04-26 13:02:46 --> Total execution time: 0.1272
DEBUG - 2019-04-26 13:02:57 --> Config Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:02:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:02:57 --> URI Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Router Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Output Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Security Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Input Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:02:57 --> Language Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Loader Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Controller Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Session Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:02:57 --> Session routines successfully run
DEBUG - 2019-04-26 13:02:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:57 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:02:57 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:02:57 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:02:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:02:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:02:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:02:57 --> Final output sent to browser
DEBUG - 2019-04-26 13:02:57 --> Total execution time: 0.0660
DEBUG - 2019-04-26 13:02:59 --> Config Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:02:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:02:59 --> URI Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Router Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Output Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Security Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Input Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:02:59 --> Language Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Loader Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Controller Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Session Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:02:59 --> Session routines successfully run
DEBUG - 2019-04-26 13:02:59 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Model Class Initialized
DEBUG - 2019-04-26 13:02:59 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:02:59 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:02:59 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Config Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:03:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:03:00 --> URI Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Router Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Output Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Security Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Input Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:03:00 --> Language Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Loader Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Controller Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Session Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:03:00 --> Session routines successfully run
DEBUG - 2019-04-26 13:03:00 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:00 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:03:00 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:03:00 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:03:00 --> File loaded: application/views/header.php
ERROR - 2019-04-26 13:03:00 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
ERROR - 2019-04-26 13:03:00 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderCustDetails.php 23
DEBUG - 2019-04-26 13:03:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:03:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:03:00 --> Final output sent to browser
DEBUG - 2019-04-26 13:03:00 --> Total execution time: 0.1015
DEBUG - 2019-04-26 13:03:26 --> Config Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:03:26 --> URI Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Router Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Output Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Security Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Input Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:03:26 --> Language Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Loader Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Controller Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Session Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:03:26 --> Session routines successfully run
DEBUG - 2019-04-26 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:26 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:03:26 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:03:26 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:03:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:03:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:03:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:03:26 --> Final output sent to browser
DEBUG - 2019-04-26 13:03:26 --> Total execution time: 0.0627
DEBUG - 2019-04-26 13:03:27 --> Config Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:03:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:03:27 --> URI Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Router Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Output Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Security Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Input Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:03:27 --> Language Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Loader Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Controller Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Session Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:03:27 --> Session garbage collection performed.
DEBUG - 2019-04-26 13:03:27 --> Session routines successfully run
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:03:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Config Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:03:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:03:27 --> URI Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Router Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Output Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Security Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Input Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:03:27 --> Language Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Loader Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Controller Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Session Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:03:27 --> Session garbage collection performed.
DEBUG - 2019-04-26 13:03:27 --> Session routines successfully run
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:03:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:03:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:03:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:03:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:03:27 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:03:27 --> Final output sent to browser
DEBUG - 2019-04-26 13:03:27 --> Total execution time: 0.1214
DEBUG - 2019-04-26 13:04:03 --> Config Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:04:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:04:03 --> URI Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Router Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Output Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Security Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Input Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:04:03 --> Language Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Loader Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Controller Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Session Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:04:03 --> Session routines successfully run
DEBUG - 2019-04-26 13:04:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:03 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:04:03 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:04:03 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:04:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:04:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:04:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:04:03 --> Final output sent to browser
DEBUG - 2019-04-26 13:04:03 --> Total execution time: 0.0550
DEBUG - 2019-04-26 13:04:05 --> Config Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:04:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:04:05 --> URI Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Router Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Output Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Security Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Input Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:04:05 --> Language Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Loader Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Controller Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Session Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:04:05 --> Session routines successfully run
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:04:05 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Config Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:04:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:04:05 --> URI Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Router Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Output Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Security Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Input Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:04:05 --> Language Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Loader Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Controller Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Session Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:04:05 --> Session routines successfully run
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:04:05 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:04:05 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:04:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:04:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:04:05 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:04:05 --> Final output sent to browser
DEBUG - 2019-04-26 13:04:05 --> Total execution time: 0.1198
DEBUG - 2019-04-26 13:04:36 --> Config Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:04:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:04:36 --> URI Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Router Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Output Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Security Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Input Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:04:36 --> Language Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Loader Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Controller Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Session Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:04:36 --> Session routines successfully run
DEBUG - 2019-04-26 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Model Class Initialized
DEBUG - 2019-04-26 13:04:36 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:04:36 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:04:36 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:04:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:04:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:04:36 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:04:36 --> Final output sent to browser
DEBUG - 2019-04-26 13:04:36 --> Total execution time: 0.1171
DEBUG - 2019-04-26 13:08:03 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:03 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:03 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:03 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:03 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:03 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:03 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:03 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:08:03 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:03 --> Total execution time: 0.2111
DEBUG - 2019-04-26 13:08:04 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:04 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:04 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:04 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:04 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:04 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:04 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:04 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:08:04 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:04 --> Total execution time: 0.0625
DEBUG - 2019-04-26 13:08:06 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:06 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:06 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:06 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:06 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:06 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:06 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:06 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:08:06 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:06 --> Total execution time: 0.1629
DEBUG - 2019-04-26 13:08:09 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:09 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:09 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:09 --> Session garbage collection performed.
DEBUG - 2019-04-26 13:08:09 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:09 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:09 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:09 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:09 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:09 --> File loaded: application/views/profile.php
DEBUG - 2019-04-26 13:08:09 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:09 --> Total execution time: 0.0612
DEBUG - 2019-04-26 13:08:20 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:20 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:20 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:20 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:08:20 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:20 --> Total execution time: 0.0641
DEBUG - 2019-04-26 13:08:23 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:23 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:23 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:23 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:23 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:23 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:23 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:23 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 13:08:23 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:23 --> Total execution time: 0.1175
DEBUG - 2019-04-26 13:08:27 --> Config Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:08:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:08:27 --> URI Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Router Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Output Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Security Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Input Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:08:27 --> Language Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Loader Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Controller Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Session Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:08:27 --> Session routines successfully run
DEBUG - 2019-04-26 13:08:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Model Class Initialized
DEBUG - 2019-04-26 13:08:27 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:08:27 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:08:27 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:08:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:08:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:08:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:08:27 --> Final output sent to browser
DEBUG - 2019-04-26 13:08:27 --> Total execution time: 0.0556
DEBUG - 2019-04-26 13:42:20 --> Config Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Hooks Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Utf8 Class Initialized
DEBUG - 2019-04-26 13:42:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 13:42:20 --> URI Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Router Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Output Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Security Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Input Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 13:42:20 --> Language Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Loader Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Controller Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Database Driver Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Session Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Helper loaded: string_helper
DEBUG - 2019-04-26 13:42:20 --> Session routines successfully run
DEBUG - 2019-04-26 13:42:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Model Class Initialized
DEBUG - 2019-04-26 13:42:20 --> Helper loaded: url_helper
DEBUG - 2019-04-26 13:42:20 --> Helper loaded: form_helper
DEBUG - 2019-04-26 13:42:20 --> Form Validation Class Initialized
DEBUG - 2019-04-26 13:42:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 13:42:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 13:42:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 13:42:20 --> Final output sent to browser
DEBUG - 2019-04-26 13:42:20 --> Total execution time: 0.1236
DEBUG - 2019-04-26 14:17:45 --> Config Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:17:45 --> URI Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Router Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Output Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Security Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Input Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:17:45 --> Language Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Loader Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Controller Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Session Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:17:45 --> Session routines successfully run
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:17:45 --> Form Validation Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Config Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:17:45 --> URI Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Router Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Output Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Security Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Input Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:17:45 --> Language Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Loader Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Controller Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Session Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:17:45 --> Session routines successfully run
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:17:45 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:17:45 --> Form Validation Class Initialized
DEBUG - 2019-04-26 14:17:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 14:17:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 14:17:45 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-26 14:17:45 --> Final output sent to browser
DEBUG - 2019-04-26 14:17:45 --> Total execution time: 0.1302
DEBUG - 2019-04-26 14:17:57 --> Config Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:17:57 --> URI Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Router Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Output Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Security Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Input Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:17:57 --> Language Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Loader Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Controller Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Session Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:17:57 --> Session routines successfully run
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:17:57 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:17:57 --> Form Validation Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Config Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:17:57 --> URI Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Router Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Output Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Security Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Input Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:17:57 --> Language Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Loader Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Controller Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:57 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Session Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:17:58 --> A session cookie was not found.
DEBUG - 2019-04-26 14:17:58 --> Session routines successfully run
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:17:58 --> Form Validation Class Initialized
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-26 14:17:58 --> Final output sent to browser
DEBUG - 2019-04-26 14:17:58 --> Total execution time: 0.1369
DEBUG - 2019-04-26 14:17:58 --> Config Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:17:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:17:58 --> URI Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Router Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Output Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Security Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Input Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:17:58 --> Language Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Loader Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Controller Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Session Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:17:58 --> Session routines successfully run
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Model Class Initialized
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:17:58 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:17:58 --> Form Validation Class Initialized
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-26 14:17:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-26 14:17:58 --> Final output sent to browser
DEBUG - 2019-04-26 14:17:58 --> Total execution time: 0.0570
DEBUG - 2019-04-26 14:18:00 --> Config Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Hooks Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Utf8 Class Initialized
DEBUG - 2019-04-26 14:18:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-26 14:18:00 --> URI Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Router Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Output Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Security Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Input Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-26 14:18:00 --> Language Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Loader Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Controller Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Model Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Model Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Database Driver Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Session Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Helper loaded: string_helper
DEBUG - 2019-04-26 14:18:00 --> Session routines successfully run
DEBUG - 2019-04-26 14:18:00 --> Model Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Model Class Initialized
DEBUG - 2019-04-26 14:18:00 --> Helper loaded: url_helper
DEBUG - 2019-04-26 14:18:00 --> Helper loaded: form_helper
DEBUG - 2019-04-26 14:18:00 --> Form Validation Class Initialized
