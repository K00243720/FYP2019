<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-02 12:55:23 --> Config Class Initialized
DEBUG - 2019-04-02 12:55:23 --> Hooks Class Initialized
DEBUG - 2019-04-02 12:55:23 --> Utf8 Class Initialized
DEBUG - 2019-04-02 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 12:55:23 --> URI Class Initialized
DEBUG - 2019-04-02 12:55:23 --> Router Class Initialized
DEBUG - 2019-04-02 12:55:23 --> No URI present. Default controller set.
DEBUG - 2019-04-02 12:55:23 --> Output Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Security Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Input Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 12:55:24 --> Language Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Loader Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Controller Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Model Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Model Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Database Driver Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Session Class Initialized
DEBUG - 2019-04-02 12:55:24 --> Helper loaded: string_helper
DEBUG - 2019-04-02 12:55:25 --> Session routines successfully run
DEBUG - 2019-04-02 12:55:25 --> Model Class Initialized
DEBUG - 2019-04-02 12:55:25 --> Helper loaded: url_helper
DEBUG - 2019-04-02 12:55:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 12:55:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 12:55:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-02 12:55:25 --> Final output sent to browser
DEBUG - 2019-04-02 12:55:25 --> Total execution time: 2.4695
DEBUG - 2019-04-02 15:33:06 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:06 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:06 --> No URI present. Default controller set.
DEBUG - 2019-04-02 15:33:06 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:06 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:06 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:06 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:06 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-02 15:33:06 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:06 --> Total execution time: 0.2673
DEBUG - 2019-04-02 15:33:11 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:11 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:11 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:11 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:11 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:11 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-02 15:33:11 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:11 --> Total execution time: 0.0870
DEBUG - 2019-04-02 15:33:16 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:16 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:16 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:16 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:16 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:16 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:16 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-02 15:33:16 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:16 --> Total execution time: 0.0479
DEBUG - 2019-04-02 15:33:18 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:18 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:18 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:18 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:18 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:18 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:18 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-02 15:33:18 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:18 --> Total execution time: 0.0709
DEBUG - 2019-04-02 15:33:19 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:19 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:19 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:19 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:19 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:19 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:19 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-02 15:33:19 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:19 --> Total execution time: 0.0503
DEBUG - 2019-04-02 15:33:23 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:23 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:23 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:23 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:23 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:23 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:24 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-02 15:33:24 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:24 --> Total execution time: 0.2398
DEBUG - 2019-04-02 15:33:25 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:25 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:25 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:25 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:25 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:25 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:25 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-02 15:33:25 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:25 --> Total execution time: 0.0658
DEBUG - 2019-04-02 15:33:29 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:29 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:29 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:29 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:29 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:29 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:29 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-02 15:33:29 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:29 --> Total execution time: 0.0615
DEBUG - 2019-04-02 15:33:30 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:30 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:30 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:30 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:30 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:30 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:30 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-02 15:33:30 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:30 --> Total execution time: 0.0512
DEBUG - 2019-04-02 15:33:35 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:35 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:35 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:35 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:35 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:35 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:36 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-02 15:33:36 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:36 --> Total execution time: 0.2171
DEBUG - 2019-04-02 15:33:39 --> Config Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:33:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:33:39 --> URI Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Router Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Output Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Security Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Input Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:33:39 --> Language Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Loader Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Controller Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Model Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Session Class Initialized
DEBUG - 2019-04-02 15:33:39 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:33:39 --> Session routines successfully run
DEBUG - 2019-04-02 15:33:39 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:33:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:33:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:33:39 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-02 15:33:39 --> Final output sent to browser
DEBUG - 2019-04-02 15:33:39 --> Total execution time: 0.0743
DEBUG - 2019-04-02 15:36:48 --> Config Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:36:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:36:48 --> URI Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Router Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Output Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Security Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Input Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:36:48 --> Language Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Loader Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Controller Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Session Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:36:48 --> Session routines successfully run
DEBUG - 2019-04-02 15:36:48 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:36:48 --> Upload Class Initialized
DEBUG - 2019-04-02 15:36:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-02 15:36:48 --> You did not select a file to upload.
DEBUG - 2019-04-02 15:36:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:36:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:36:48 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-02 15:36:52 --> Config Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:36:52 --> URI Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Router Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Output Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Security Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Input Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:36:52 --> Language Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Loader Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Controller Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Session Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:36:52 --> Session routines successfully run
DEBUG - 2019-04-02 15:36:52 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:52 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:36:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:36:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:36:52 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-02 15:36:52 --> Final output sent to browser
DEBUG - 2019-04-02 15:36:52 --> Total execution time: 0.1233
DEBUG - 2019-04-02 15:36:54 --> Config Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:36:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:36:54 --> URI Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Router Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Output Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Security Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Input Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:36:54 --> Language Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Loader Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Controller Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Session Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:36:54 --> Session garbage collection performed.
DEBUG - 2019-04-02 15:36:54 --> Session routines successfully run
DEBUG - 2019-04-02 15:36:54 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:54 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:36:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:36:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:36:54 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-02 15:36:54 --> Final output sent to browser
DEBUG - 2019-04-02 15:36:54 --> Total execution time: 0.1156
DEBUG - 2019-04-02 15:36:58 --> Config Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Hooks Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Utf8 Class Initialized
DEBUG - 2019-04-02 15:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-02 15:36:58 --> URI Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Router Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Output Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Security Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Input Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-02 15:36:58 --> Language Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Loader Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Controller Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Database Driver Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Session Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Helper loaded: string_helper
DEBUG - 2019-04-02 15:36:58 --> Session routines successfully run
DEBUG - 2019-04-02 15:36:58 --> Model Class Initialized
DEBUG - 2019-04-02 15:36:58 --> Helper loaded: url_helper
DEBUG - 2019-04-02 15:36:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-02 15:36:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-02 15:36:58 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-02 15:36:58 --> Final output sent to browser
DEBUG - 2019-04-02 15:36:58 --> Total execution time: 0.0776
