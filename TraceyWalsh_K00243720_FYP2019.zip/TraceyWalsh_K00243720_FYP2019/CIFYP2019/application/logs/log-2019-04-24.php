<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-24 15:24:05 --> Config Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:24:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:24:05 --> URI Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Router Class Initialized
DEBUG - 2019-04-24 15:24:05 --> No URI present. Default controller set.
DEBUG - 2019-04-24 15:24:05 --> Output Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Security Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Input Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:24:05 --> Language Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Loader Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Controller Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Model Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Model Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Session Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:24:05 --> A session cookie was not found.
DEBUG - 2019-04-24 15:24:05 --> Session routines successfully run
DEBUG - 2019-04-24 15:24:05 --> Model Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Model Class Initialized
DEBUG - 2019-04-24 15:24:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:24:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:24:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:24:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 15:24:05 --> Final output sent to browser
DEBUG - 2019-04-24 15:24:05 --> Total execution time: 0.2728
DEBUG - 2019-04-24 15:31:35 --> Config Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:31:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:31:35 --> URI Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Router Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Output Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Security Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Input Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:31:35 --> Language Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Loader Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Controller Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Session Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:31:35 --> Session routines successfully run
DEBUG - 2019-04-24 15:31:35 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:31:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:31:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:31:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 15:31:35 --> Final output sent to browser
DEBUG - 2019-04-24 15:31:35 --> Total execution time: 0.2040
DEBUG - 2019-04-24 15:31:46 --> Config Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:31:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:31:46 --> URI Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Router Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Output Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Security Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Input Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:31:46 --> Language Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Loader Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Controller Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Session Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:31:46 --> Session routines successfully run
DEBUG - 2019-04-24 15:31:46 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Model Class Initialized
DEBUG - 2019-04-24 15:31:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:31:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:31:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:31:46 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 15:31:46 --> Final output sent to browser
DEBUG - 2019-04-24 15:31:46 --> Total execution time: 0.0592
DEBUG - 2019-04-24 15:32:01 --> Config Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:32:01 --> URI Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Router Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Output Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Security Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Input Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:32:01 --> Language Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Loader Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Controller Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Session Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:32:01 --> Session routines successfully run
DEBUG - 2019-04-24 15:32:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:32:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:32:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:32:01 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-24 15:32:01 --> Final output sent to browser
DEBUG - 2019-04-24 15:32:01 --> Total execution time: 0.0556
DEBUG - 2019-04-24 15:32:23 --> Config Class Initialized
DEBUG - 2019-04-24 15:32:23 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:32:23 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:32:23 --> URI Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Router Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Output Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Security Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Input Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:32:24 --> Language Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Loader Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Controller Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Session Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:32:24 --> Session routines successfully run
DEBUG - 2019-04-24 15:32:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:32:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:32:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:32:24 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 15:32:24 --> Final output sent to browser
DEBUG - 2019-04-24 15:32:24 --> Total execution time: 0.0543
DEBUG - 2019-04-24 15:32:32 --> Config Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:32:32 --> URI Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Router Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Output Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Security Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Input Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:32:32 --> Language Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Loader Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Controller Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Session Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:32:32 --> Session routines successfully run
DEBUG - 2019-04-24 15:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 15:32:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:32:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:32:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:32:32 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 15:32:32 --> Final output sent to browser
DEBUG - 2019-04-24 15:32:32 --> Total execution time: 0.1268
DEBUG - 2019-04-24 15:43:31 --> Config Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:43:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:43:31 --> URI Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Router Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Output Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Security Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Input Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:43:31 --> Language Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Loader Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Controller Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Session Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:43:31 --> Session routines successfully run
DEBUG - 2019-04-24 15:43:31 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:43:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:43:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:43:31 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 15:43:31 --> Final output sent to browser
DEBUG - 2019-04-24 15:43:31 --> Total execution time: 0.1513
DEBUG - 2019-04-24 15:43:38 --> Config Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:43:38 --> URI Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Router Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Output Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Security Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Input Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:43:38 --> Language Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Loader Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Controller Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Session Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:43:38 --> Session routines successfully run
DEBUG - 2019-04-24 15:43:38 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:43:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:43:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:43:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 15:43:39 --> Final output sent to browser
DEBUG - 2019-04-24 15:43:39 --> Total execution time: 0.3010
DEBUG - 2019-04-24 15:43:42 --> Config Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:43:42 --> URI Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Router Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Output Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Security Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Input Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:43:42 --> Language Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Loader Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Controller Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Session Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:43:42 --> Session routines successfully run
DEBUG - 2019-04-24 15:43:42 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:43:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:43:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:43:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 15:43:42 --> Final output sent to browser
DEBUG - 2019-04-24 15:43:42 --> Total execution time: 0.0401
DEBUG - 2019-04-24 15:43:52 --> Config Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:43:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:43:52 --> URI Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Router Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Output Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Security Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Input Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:43:52 --> Language Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Loader Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Controller Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Session Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:43:52 --> Session routines successfully run
DEBUG - 2019-04-24 15:43:52 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:43:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:43:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:43:52 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-24 15:43:52 --> Final output sent to browser
DEBUG - 2019-04-24 15:43:52 --> Total execution time: 0.1208
DEBUG - 2019-04-24 15:43:57 --> Config Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:43:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:43:57 --> URI Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Router Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Output Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Security Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Input Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:43:57 --> Language Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Loader Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Controller Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Session Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:43:57 --> Session routines successfully run
DEBUG - 2019-04-24 15:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:43:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:43:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:43:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:43:57 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:43:57 --> Final output sent to browser
DEBUG - 2019-04-24 15:43:57 --> Total execution time: 0.0773
DEBUG - 2019-04-24 15:46:03 --> Config Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:46:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:46:03 --> URI Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Router Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Output Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Security Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Input Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:46:03 --> Language Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Loader Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Controller Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Session Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:46:03 --> Session routines successfully run
DEBUG - 2019-04-24 15:46:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:46:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:46:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:46:03 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:46:03 --> Final output sent to browser
DEBUG - 2019-04-24 15:46:03 --> Total execution time: 0.0531
DEBUG - 2019-04-24 15:46:07 --> Config Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:46:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:46:07 --> URI Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Router Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Output Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Security Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Input Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:46:07 --> Language Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Loader Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Controller Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Session Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:46:07 --> Session garbage collection performed.
DEBUG - 2019-04-24 15:46:07 --> Session routines successfully run
DEBUG - 2019-04-24 15:46:07 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:46:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:46:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:46:07 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:46:07 --> Final output sent to browser
DEBUG - 2019-04-24 15:46:07 --> Total execution time: 0.1428
DEBUG - 2019-04-24 15:46:11 --> Config Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:46:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:46:11 --> URI Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Router Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Output Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Security Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Input Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:46:11 --> Language Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Loader Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Controller Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Session Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:46:11 --> Session routines successfully run
DEBUG - 2019-04-24 15:46:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:46:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:46:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:46:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:46:11 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:46:11 --> Final output sent to browser
DEBUG - 2019-04-24 15:46:11 --> Total execution time: 0.0665
DEBUG - 2019-04-24 15:49:03 --> Config Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:49:03 --> URI Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Router Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Output Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Security Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Input Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:49:03 --> Language Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Loader Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Controller Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Session Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:49:03 --> Session routines successfully run
DEBUG - 2019-04-24 15:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 15:49:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:49:03 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:49:03 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:49:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:49:03 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:49:03 --> Final output sent to browser
DEBUG - 2019-04-24 15:49:03 --> Total execution time: 0.1272
DEBUG - 2019-04-24 15:50:47 --> Config Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:50:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:50:47 --> URI Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Router Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Output Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Security Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Input Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:50:47 --> Language Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Loader Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Controller Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Session Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:50:47 --> Session routines successfully run
DEBUG - 2019-04-24 15:50:47 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:50:47 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:50:47 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:50:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:50:47 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:50:47 --> Final output sent to browser
DEBUG - 2019-04-24 15:50:47 --> Total execution time: 0.0620
DEBUG - 2019-04-24 15:50:49 --> Config Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:50:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:50:49 --> URI Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Router Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Output Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Security Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Input Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:50:49 --> Language Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Loader Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Controller Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Session Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:50:49 --> Session routines successfully run
DEBUG - 2019-04-24 15:50:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:50:49 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:50:49 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:50:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:50:49 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:50:49 --> Final output sent to browser
DEBUG - 2019-04-24 15:50:49 --> Total execution time: 0.0548
DEBUG - 2019-04-24 15:50:57 --> Config Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:50:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:50:57 --> URI Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Router Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Output Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Security Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Input Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:50:57 --> Language Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Loader Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Controller Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Session Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:50:57 --> Session routines successfully run
DEBUG - 2019-04-24 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:50:57 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:50:57 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:50:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:50:57 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:50:57 --> Final output sent to browser
DEBUG - 2019-04-24 15:50:57 --> Total execution time: 0.0712
DEBUG - 2019-04-24 15:50:59 --> Config Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:50:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:50:59 --> URI Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Router Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Output Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Security Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Input Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:50:59 --> Language Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Loader Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Controller Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Session Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:50:59 --> Session routines successfully run
DEBUG - 2019-04-24 15:50:59 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Model Class Initialized
DEBUG - 2019-04-24 15:50:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:50:59 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:50:59 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:50:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:50:59 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:50:59 --> Final output sent to browser
DEBUG - 2019-04-24 15:50:59 --> Total execution time: 0.0556
DEBUG - 2019-04-24 15:51:09 --> Config Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:51:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:51:09 --> URI Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Router Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Output Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Security Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Input Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:51:09 --> Language Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Loader Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Controller Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Model Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Model Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Session Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:51:09 --> A session cookie was not found.
DEBUG - 2019-04-24 15:51:09 --> Session routines successfully run
DEBUG - 2019-04-24 15:51:09 --> Model Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Model Class Initialized
DEBUG - 2019-04-24 15:51:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:51:09 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:51:09 --> Severity: Notice  --> Undefined index: pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:51:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:51:09 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:51:09 --> Final output sent to browser
DEBUG - 2019-04-24 15:51:09 --> Total execution time: 0.1236
DEBUG - 2019-04-24 15:52:16 --> Config Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:52:16 --> URI Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Router Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Output Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Security Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Input Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:52:16 --> Language Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Loader Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Controller Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Session Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:52:16 --> Session routines successfully run
DEBUG - 2019-04-24 15:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 15:52:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:52:16 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:52:16 --> Severity: Notice  --> Undefined index: Pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:52:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:52:16 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:52:16 --> Final output sent to browser
DEBUG - 2019-04-24 15:52:16 --> Total execution time: 0.0649
DEBUG - 2019-04-24 15:54:13 --> Config Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:54:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:54:13 --> URI Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Router Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Output Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Security Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Input Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:54:13 --> Language Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Loader Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Controller Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Session Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:54:13 --> Session routines successfully run
DEBUG - 2019-04-24 15:54:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:54:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:54:13 --> File loaded: application/views/header.php
ERROR - 2019-04-24 15:54:13 --> Severity: Notice  --> Undefined index: Pickup C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\updateUserDetails.php 57
DEBUG - 2019-04-24 15:54:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:54:13 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:54:13 --> Final output sent to browser
DEBUG - 2019-04-24 15:54:13 --> Total execution time: 0.1293
DEBUG - 2019-04-24 15:55:23 --> Config Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:55:23 --> URI Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Router Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Output Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Security Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Input Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:55:23 --> Language Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Loader Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Controller Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Session Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:55:23 --> Session routines successfully run
DEBUG - 2019-04-24 15:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:23 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:55:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:55:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:55:23 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:55:23 --> Final output sent to browser
DEBUG - 2019-04-24 15:55:23 --> Total execution time: 0.0513
DEBUG - 2019-04-24 15:55:48 --> Config Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:55:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:55:48 --> URI Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Router Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Output Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Security Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Input Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:55:48 --> Language Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Loader Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Controller Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Session Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:55:48 --> Session routines successfully run
DEBUG - 2019-04-24 15:55:48 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:48 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:55:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:55:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:55:48 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 15:55:48 --> Final output sent to browser
DEBUG - 2019-04-24 15:55:48 --> Total execution time: 0.0579
DEBUG - 2019-04-24 15:55:49 --> Config Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:55:49 --> URI Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Router Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Output Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Security Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Input Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:55:49 --> Language Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Loader Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Controller Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Session Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:55:49 --> Session routines successfully run
DEBUG - 2019-04-24 15:55:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:55:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:55:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:55:49 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 15:55:49 --> Final output sent to browser
DEBUG - 2019-04-24 15:55:49 --> Total execution time: 0.0425
DEBUG - 2019-04-24 15:55:57 --> Config Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:55:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:55:57 --> URI Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Router Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Output Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Security Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Input Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:55:57 --> Language Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Loader Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Controller Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Session Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:55:57 --> Session routines successfully run
DEBUG - 2019-04-24 15:55:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Model Class Initialized
DEBUG - 2019-04-24 15:55:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:55:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:55:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:55:57 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 15:55:57 --> Final output sent to browser
DEBUG - 2019-04-24 15:55:57 --> Total execution time: 0.2093
DEBUG - 2019-04-24 15:56:00 --> Config Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:56:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:56:00 --> URI Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Router Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Output Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Security Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Input Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:56:00 --> Language Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Loader Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Controller Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Session Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:56:00 --> Session routines successfully run
DEBUG - 2019-04-24 15:56:00 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:56:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:56:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:56:00 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:56:00 --> Final output sent to browser
DEBUG - 2019-04-24 15:56:00 --> Total execution time: 0.0556
DEBUG - 2019-04-24 15:56:01 --> Config Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:56:01 --> URI Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Router Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Output Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Security Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Input Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:56:01 --> Language Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Loader Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Controller Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Session Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:56:01 --> Session routines successfully run
DEBUG - 2019-04-24 15:56:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:56:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:56:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:56:01 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-24 15:56:01 --> Final output sent to browser
DEBUG - 2019-04-24 15:56:01 --> Total execution time: 0.1161
DEBUG - 2019-04-24 15:56:02 --> Config Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:56:02 --> URI Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Router Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Output Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Security Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Input Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:56:02 --> Language Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Loader Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Controller Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Session Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:56:02 --> Session routines successfully run
DEBUG - 2019-04-24 15:56:02 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:56:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:56:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:56:02 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:56:02 --> Final output sent to browser
DEBUG - 2019-04-24 15:56:02 --> Total execution time: 0.0533
DEBUG - 2019-04-24 15:56:20 --> Config Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:56:20 --> URI Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Router Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Output Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Security Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Input Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:56:20 --> Language Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Loader Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Controller Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Session Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:56:20 --> Session routines successfully run
DEBUG - 2019-04-24 15:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:56:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:56:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:56:20 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 15:56:20 --> Final output sent to browser
DEBUG - 2019-04-24 15:56:20 --> Total execution time: 0.1195
DEBUG - 2019-04-24 15:56:24 --> Config Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:56:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:56:24 --> URI Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Router Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Output Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Security Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Input Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:56:24 --> Language Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Loader Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Controller Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Session Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:56:24 --> Session routines successfully run
DEBUG - 2019-04-24 15:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 15:56:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:56:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:56:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:56:24 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:56:24 --> Final output sent to browser
DEBUG - 2019-04-24 15:56:24 --> Total execution time: 0.0707
DEBUG - 2019-04-24 15:57:11 --> Config Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:57:11 --> URI Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Router Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Output Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Security Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Input Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:57:11 --> Language Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Loader Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Controller Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Session Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:57:11 --> Session routines successfully run
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:57:11 --> Config Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:57:11 --> URI Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Router Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Output Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Security Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Input Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:57:11 --> Language Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Loader Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Controller Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Session Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:57:11 --> A session cookie was not found.
DEBUG - 2019-04-24 15:57:11 --> Session routines successfully run
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:57:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:57:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:57:11 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 15:57:11 --> Final output sent to browser
DEBUG - 2019-04-24 15:57:11 --> Total execution time: 0.2044
DEBUG - 2019-04-24 15:57:13 --> Config Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:57:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:57:13 --> URI Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Router Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Output Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Security Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Input Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:57:13 --> Language Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Loader Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Controller Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Session Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:57:13 --> Session routines successfully run
DEBUG - 2019-04-24 15:57:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:57:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:57:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:57:13 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 15:57:13 --> Final output sent to browser
DEBUG - 2019-04-24 15:57:13 --> Total execution time: 0.0527
DEBUG - 2019-04-24 15:57:20 --> Config Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:57:20 --> URI Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Router Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Output Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Security Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Input Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:57:20 --> Language Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Loader Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Controller Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Session Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:57:20 --> Session routines successfully run
DEBUG - 2019-04-24 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:57:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:57:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:57:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 15:57:20 --> Final output sent to browser
DEBUG - 2019-04-24 15:57:20 --> Total execution time: 0.2315
DEBUG - 2019-04-24 15:57:22 --> Config Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 15:57:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 15:57:22 --> URI Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Router Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Output Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Security Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Input Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 15:57:22 --> Language Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Loader Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Controller Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Session Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 15:57:22 --> Session routines successfully run
DEBUG - 2019-04-24 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Model Class Initialized
DEBUG - 2019-04-24 15:57:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 15:57:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 15:57:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 15:57:22 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 15:57:22 --> Final output sent to browser
DEBUG - 2019-04-24 15:57:22 --> Total execution time: 0.0411
DEBUG - 2019-04-24 16:21:14 --> Config Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:21:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:21:14 --> URI Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Router Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Output Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Security Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Input Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:21:14 --> Language Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Loader Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Controller Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Session Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:21:14 --> Session routines successfully run
DEBUG - 2019-04-24 16:21:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:21:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:21:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:21:14 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 16:21:14 --> Final output sent to browser
DEBUG - 2019-04-24 16:21:14 --> Total execution time: 0.3051
DEBUG - 2019-04-24 16:21:29 --> Config Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:21:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:21:29 --> URI Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Router Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Output Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Security Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Input Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:21:29 --> Language Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Loader Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Controller Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Session Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:21:29 --> Session routines successfully run
DEBUG - 2019-04-24 16:21:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:29 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:21:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:21:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:21:29 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 16:21:29 --> Final output sent to browser
DEBUG - 2019-04-24 16:21:29 --> Total execution time: 0.0560
DEBUG - 2019-04-24 16:21:32 --> Config Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:21:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:21:32 --> URI Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Router Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Output Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Security Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Input Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:21:32 --> Language Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Loader Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Controller Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Session Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:21:32 --> Session garbage collection performed.
DEBUG - 2019-04-24 16:21:32 --> Session routines successfully run
DEBUG - 2019-04-24 16:21:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:21:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:21:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:21:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:21:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 16:21:32 --> Final output sent to browser
DEBUG - 2019-04-24 16:21:32 --> Total execution time: 0.0572
DEBUG - 2019-04-24 16:27:26 --> Config Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:27:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:27:26 --> URI Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Router Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Output Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Security Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Input Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:27:26 --> Language Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Loader Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Controller Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Model Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Model Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Session Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:27:26 --> Session routines successfully run
DEBUG - 2019-04-24 16:27:26 --> Model Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Model Class Initialized
DEBUG - 2019-04-24 16:27:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:27:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:27:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:27:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:27:26 --> Final output sent to browser
DEBUG - 2019-04-24 16:27:26 --> Total execution time: 0.1228
DEBUG - 2019-04-24 16:41:04 --> Config Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:41:04 --> URI Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Router Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Output Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Security Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Input Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:41:04 --> Language Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Loader Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Controller Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Session Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:41:04 --> Session routines successfully run
DEBUG - 2019-04-24 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:41:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:41:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:41:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:41:04 --> Final output sent to browser
DEBUG - 2019-04-24 16:41:04 --> Total execution time: 0.1281
DEBUG - 2019-04-24 16:41:32 --> Config Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:41:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:41:32 --> URI Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Router Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Output Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Security Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Input Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:41:32 --> Language Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Loader Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Controller Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Session Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:41:32 --> Session routines successfully run
DEBUG - 2019-04-24 16:41:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:41:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:41:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:41:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:41:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:41:32 --> Final output sent to browser
DEBUG - 2019-04-24 16:41:32 --> Total execution time: 0.0580
DEBUG - 2019-04-24 16:42:47 --> Config Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:42:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:42:47 --> URI Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Router Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Output Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Security Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Input Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:42:47 --> Language Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Loader Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Controller Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Session Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:42:47 --> Session routines successfully run
DEBUG - 2019-04-24 16:42:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:42:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:42:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:42:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:42:47 --> Final output sent to browser
DEBUG - 2019-04-24 16:42:47 --> Total execution time: 0.0619
DEBUG - 2019-04-24 16:42:49 --> Config Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:42:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:42:49 --> URI Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Router Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Output Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Security Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Input Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:42:49 --> Language Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Loader Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Controller Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Session Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:42:49 --> Session routines successfully run
DEBUG - 2019-04-24 16:42:49 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Model Class Initialized
DEBUG - 2019-04-24 16:42:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:42:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:42:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:42:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:42:49 --> Final output sent to browser
DEBUG - 2019-04-24 16:42:49 --> Total execution time: 0.0561
DEBUG - 2019-04-24 16:43:07 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:07 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:07 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:07 --> Session garbage collection performed.
DEBUG - 2019-04-24 16:43:07 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:07 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:07 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:07 --> Total execution time: 0.0523
DEBUG - 2019-04-24 16:43:09 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:09 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:09 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:09 --> Session garbage collection performed.
DEBUG - 2019-04-24 16:43:09 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:09 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:09 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:09 --> Total execution time: 0.0435
DEBUG - 2019-04-24 16:43:12 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:12 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:12 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:12 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:12 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:12 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:12 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:12 --> Total execution time: 0.0558
DEBUG - 2019-04-24 16:43:13 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:13 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:13 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:13 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:13 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:13 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 16:43:13 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:13 --> Total execution time: 0.0977
DEBUG - 2019-04-24 16:43:14 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:14 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:14 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:14 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:14 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:14 --> Total execution time: 0.0631
DEBUG - 2019-04-24 16:43:15 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:15 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:15 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:15 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:16 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:16 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:16 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:16 --> A session cookie was not found.
DEBUG - 2019-04-24 16:43:16 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 16:43:16 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:16 --> Total execution time: 0.1821
DEBUG - 2019-04-24 16:43:17 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:17 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:17 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:17 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:17 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:17 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:17 --> Total execution time: 0.0613
DEBUG - 2019-04-24 16:43:19 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:19 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:19 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:19 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:19 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:19 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:19 --> Total execution time: 0.0623
DEBUG - 2019-04-24 16:43:34 --> Config Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:43:34 --> URI Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Router Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Output Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Security Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Input Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:43:34 --> Language Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Loader Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Controller Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Session Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:43:34 --> Session garbage collection performed.
DEBUG - 2019-04-24 16:43:34 --> Session routines successfully run
DEBUG - 2019-04-24 16:43:34 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Model Class Initialized
DEBUG - 2019-04-24 16:43:34 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:43:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:43:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:43:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:43:34 --> Final output sent to browser
DEBUG - 2019-04-24 16:43:34 --> Total execution time: 0.0753
DEBUG - 2019-04-24 16:44:31 --> Config Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:44:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:44:31 --> URI Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Router Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Output Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Security Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Input Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:44:31 --> Language Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Loader Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Controller Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Session Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:44:31 --> Session routines successfully run
DEBUG - 2019-04-24 16:44:31 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:44:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:44:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:44:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:44:31 --> Final output sent to browser
DEBUG - 2019-04-24 16:44:31 --> Total execution time: 0.0661
DEBUG - 2019-04-24 16:44:32 --> Config Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:44:32 --> URI Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Router Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Output Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Security Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Input Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:44:32 --> Language Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Loader Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Controller Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Session Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:44:32 --> Session routines successfully run
DEBUG - 2019-04-24 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:44:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:44:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:44:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:44:32 --> Final output sent to browser
DEBUG - 2019-04-24 16:44:32 --> Total execution time: 0.0616
DEBUG - 2019-04-24 16:44:47 --> Config Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:44:47 --> URI Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Router Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Output Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Security Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Input Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:44:47 --> Language Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Loader Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Controller Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Session Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:44:47 --> Session routines successfully run
DEBUG - 2019-04-24 16:44:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:44:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:44:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:44:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:44:47 --> Final output sent to browser
DEBUG - 2019-04-24 16:44:47 --> Total execution time: 0.0607
DEBUG - 2019-04-24 16:44:59 --> Config Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:44:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:44:59 --> URI Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Router Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Output Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Security Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Input Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:44:59 --> Language Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Loader Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Controller Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Session Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:44:59 --> Session routines successfully run
DEBUG - 2019-04-24 16:44:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:44:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:44:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:44:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:44:59 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:44:59 --> Final output sent to browser
DEBUG - 2019-04-24 16:44:59 --> Total execution time: 0.0708
DEBUG - 2019-04-24 16:45:20 --> Config Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:45:20 --> URI Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Router Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Output Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Security Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Input Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:45:20 --> Language Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Loader Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Controller Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Session Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:45:20 --> Session routines successfully run
DEBUG - 2019-04-24 16:45:20 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:45:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:45:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:45:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:45:20 --> Final output sent to browser
DEBUG - 2019-04-24 16:45:20 --> Total execution time: 0.0590
DEBUG - 2019-04-24 16:45:22 --> Config Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:45:22 --> URI Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Router Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Output Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Security Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Input Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:45:22 --> Language Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Loader Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Controller Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Session Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:45:22 --> Session routines successfully run
DEBUG - 2019-04-24 16:45:22 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:45:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:45:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:45:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:45:22 --> Final output sent to browser
DEBUG - 2019-04-24 16:45:22 --> Total execution time: 0.0608
DEBUG - 2019-04-24 16:45:39 --> Config Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:45:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:45:39 --> URI Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Router Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Output Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Security Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Input Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:45:39 --> Language Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Loader Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Controller Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Session Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:45:39 --> Session routines successfully run
DEBUG - 2019-04-24 16:45:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:45:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:45:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:45:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:45:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:45:39 --> Final output sent to browser
DEBUG - 2019-04-24 16:45:39 --> Total execution time: 0.0575
DEBUG - 2019-04-24 16:49:01 --> Config Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:49:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:49:01 --> URI Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Router Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Output Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Security Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Input Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:49:01 --> Language Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Loader Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Controller Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Session Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:49:01 --> Session routines successfully run
DEBUG - 2019-04-24 16:49:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:49:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:49:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:49:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:49:01 --> Final output sent to browser
DEBUG - 2019-04-24 16:49:01 --> Total execution time: 0.1061
DEBUG - 2019-04-24 16:49:08 --> Config Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:49:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:49:08 --> URI Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Router Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Output Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Security Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Input Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:49:08 --> Language Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Loader Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Controller Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Session Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:49:08 --> Session routines successfully run
DEBUG - 2019-04-24 16:49:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:08 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:49:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:49:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:49:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:49:08 --> Final output sent to browser
DEBUG - 2019-04-24 16:49:08 --> Total execution time: 0.0550
DEBUG - 2019-04-24 16:49:28 --> Config Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:49:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:49:28 --> URI Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Router Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Output Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Security Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Input Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:49:28 --> Language Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Loader Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Controller Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Session Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:49:28 --> Session routines successfully run
DEBUG - 2019-04-24 16:49:28 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:49:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:49:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:49:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:49:28 --> Final output sent to browser
DEBUG - 2019-04-24 16:49:28 --> Total execution time: 0.0734
DEBUG - 2019-04-24 16:49:48 --> Config Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:49:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:49:48 --> URI Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Router Class Initialized
DEBUG - 2019-04-24 16:49:48 --> No URI present. Default controller set.
DEBUG - 2019-04-24 16:49:48 --> Output Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Security Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Input Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:49:48 --> Language Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Loader Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Controller Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Session Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:49:48 --> Session routines successfully run
DEBUG - 2019-04-24 16:49:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:48 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:49:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:49:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:49:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 16:49:49 --> Final output sent to browser
DEBUG - 2019-04-24 16:49:49 --> Total execution time: 0.2270
DEBUG - 2019-04-24 16:49:51 --> Config Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:49:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:49:51 --> URI Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Router Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Output Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Security Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Input Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:49:51 --> Language Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Loader Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Controller Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Session Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:49:51 --> Session routines successfully run
DEBUG - 2019-04-24 16:49:51 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Model Class Initialized
DEBUG - 2019-04-24 16:49:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:49:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:49:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:49:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:49:51 --> Final output sent to browser
DEBUG - 2019-04-24 16:49:51 --> Total execution time: 0.0536
DEBUG - 2019-04-24 16:50:10 --> Config Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:50:10 --> URI Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Router Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Output Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Security Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Input Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:50:10 --> Language Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Loader Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Controller Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Session Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:50:10 --> Session routines successfully run
DEBUG - 2019-04-24 16:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:50:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:50:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:50:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:50:10 --> Final output sent to browser
DEBUG - 2019-04-24 16:50:10 --> Total execution time: 0.0650
DEBUG - 2019-04-24 16:50:41 --> Config Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:50:41 --> URI Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Router Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Output Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Security Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Input Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:50:41 --> Language Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Loader Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Controller Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Session Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:50:41 --> Session routines successfully run
DEBUG - 2019-04-24 16:50:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:50:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:50:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:50:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:50:41 --> Final output sent to browser
DEBUG - 2019-04-24 16:50:41 --> Total execution time: 0.0511
DEBUG - 2019-04-24 16:50:57 --> Config Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:50:57 --> URI Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Router Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Output Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Security Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Input Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:50:57 --> Language Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Loader Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Controller Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Session Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:50:57 --> Session routines successfully run
DEBUG - 2019-04-24 16:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Model Class Initialized
DEBUG - 2019-04-24 16:50:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:50:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:50:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:50:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:50:57 --> Final output sent to browser
DEBUG - 2019-04-24 16:50:57 --> Total execution time: 0.0680
DEBUG - 2019-04-24 16:51:08 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:08 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:08 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:08 --> A session cookie was not found.
DEBUG - 2019-04-24 16:51:08 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:08 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:08 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:08 --> Total execution time: 0.1246
DEBUG - 2019-04-24 16:51:24 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:24 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:25 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:25 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:25 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:25 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:25 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:25 --> Total execution time: 0.0636
DEBUG - 2019-04-24 16:51:38 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:38 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:38 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:38 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:38 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:38 --> Total execution time: 0.0635
DEBUG - 2019-04-24 16:51:50 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:50 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:50 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:50 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:50 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:50 --> Total execution time: 0.0724
DEBUG - 2019-04-24 16:51:53 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:53 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:53 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:53 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:53 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:53 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:53 --> Total execution time: 0.0534
DEBUG - 2019-04-24 16:51:58 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:58 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:58 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:58 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:58 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:58 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 16:51:58 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:58 --> Total execution time: 0.0670
DEBUG - 2019-04-24 16:51:59 --> Config Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:51:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:51:59 --> URI Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Router Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Output Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Security Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Input Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:51:59 --> Language Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Loader Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Controller Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Session Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:51:59 --> Session routines successfully run
DEBUG - 2019-04-24 16:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 16:51:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:51:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:51:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:51:59 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:51:59 --> Final output sent to browser
DEBUG - 2019-04-24 16:51:59 --> Total execution time: 0.0574
DEBUG - 2019-04-24 16:52:00 --> Config Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:52:00 --> URI Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Router Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Output Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Security Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Input Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:52:00 --> Language Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Loader Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Controller Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Session Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:52:00 --> Session routines successfully run
DEBUG - 2019-04-24 16:52:00 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:52:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:52:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:52:00 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 16:52:00 --> Final output sent to browser
DEBUG - 2019-04-24 16:52:00 --> Total execution time: 0.1152
DEBUG - 2019-04-24 16:52:01 --> Config Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:52:01 --> URI Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Router Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Output Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Security Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Input Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:52:01 --> Language Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Loader Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Controller Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Session Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:52:01 --> Session routines successfully run
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:52:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:52:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:52:01 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 16:52:01 --> Final output sent to browser
DEBUG - 2019-04-24 16:52:01 --> Total execution time: 0.0568
DEBUG - 2019-04-24 16:52:01 --> Config Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:52:01 --> URI Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Router Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Output Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Security Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Input Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:52:01 --> Language Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Loader Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Controller Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:52:02 --> Session Class Initialized
DEBUG - 2019-04-24 16:52:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:52:02 --> Session routines successfully run
DEBUG - 2019-04-24 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:52:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:52:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:52:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:52:02 --> Final output sent to browser
DEBUG - 2019-04-24 16:52:02 --> Total execution time: 0.0542
DEBUG - 2019-04-24 16:52:48 --> Config Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:52:48 --> URI Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Router Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Output Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Security Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Input Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:52:48 --> Language Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Loader Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Controller Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Session Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:52:48 --> Session routines successfully run
DEBUG - 2019-04-24 16:52:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Model Class Initialized
DEBUG - 2019-04-24 16:52:48 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:52:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:52:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:52:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:52:48 --> Final output sent to browser
DEBUG - 2019-04-24 16:52:48 --> Total execution time: 0.0676
DEBUG - 2019-04-24 16:54:14 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:14 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:14 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:15 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:15 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:15 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:15 --> Total execution time: 0.0532
DEBUG - 2019-04-24 16:54:16 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:16 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:16 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:16 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:16 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:16 --> Total execution time: 0.0614
DEBUG - 2019-04-24 16:54:21 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:21 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:21 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:21 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:21 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:21 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:21 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:21 --> Total execution time: 0.0678
DEBUG - 2019-04-24 16:54:35 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:35 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:35 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:35 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:35 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:35 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:35 --> Total execution time: 0.0752
DEBUG - 2019-04-24 16:54:37 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:37 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:37 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:37 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:37 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:37 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:37 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:37 --> Total execution time: 0.0603
DEBUG - 2019-04-24 16:54:39 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:39 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:39 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:39 --> Session garbage collection performed.
DEBUG - 2019-04-24 16:54:39 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:39 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:39 --> Total execution time: 0.0528
DEBUG - 2019-04-24 16:54:39 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:39 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:39 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:40 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:40 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:40 --> Total execution time: 0.0556
DEBUG - 2019-04-24 16:54:40 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:40 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:40 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:40 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:40 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:40 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:40 --> Total execution time: 0.0544
DEBUG - 2019-04-24 16:54:41 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:41 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:41 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:41 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:41 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:41 --> Total execution time: 0.0525
DEBUG - 2019-04-24 16:54:41 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:41 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:41 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:41 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:41 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:41 --> Total execution time: 0.0549
DEBUG - 2019-04-24 16:54:41 --> Config Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:54:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:54:41 --> URI Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Router Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Output Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Security Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Input Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:54:41 --> Language Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Loader Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Controller Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Session Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:54:41 --> Session routines successfully run
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Model Class Initialized
DEBUG - 2019-04-24 16:54:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:54:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:54:41 --> Final output sent to browser
DEBUG - 2019-04-24 16:54:41 --> Total execution time: 0.0532
DEBUG - 2019-04-24 16:55:23 --> Config Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:55:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:55:23 --> URI Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Router Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Output Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Security Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Input Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:55:23 --> Language Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Loader Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Controller Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Session Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:55:23 --> Session routines successfully run
DEBUG - 2019-04-24 16:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:23 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:55:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:55:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:55:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:55:23 --> Final output sent to browser
DEBUG - 2019-04-24 16:55:23 --> Total execution time: 0.0580
DEBUG - 2019-04-24 16:55:24 --> Config Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:55:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:55:24 --> URI Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Router Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Output Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Security Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Input Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:55:24 --> Language Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Loader Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Controller Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Session Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:55:24 --> Session routines successfully run
DEBUG - 2019-04-24 16:55:24 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:55:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:55:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:55:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:55:25 --> Final output sent to browser
DEBUG - 2019-04-24 16:55:25 --> Total execution time: 0.0734
DEBUG - 2019-04-24 16:55:33 --> Config Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:55:33 --> URI Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Router Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Output Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Security Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Input Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:55:33 --> Language Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Loader Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Controller Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Session Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:55:33 --> Session routines successfully run
DEBUG - 2019-04-24 16:55:33 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Model Class Initialized
DEBUG - 2019-04-24 16:55:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:55:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:55:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:55:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:55:33 --> Final output sent to browser
DEBUG - 2019-04-24 16:55:33 --> Total execution time: 0.0530
DEBUG - 2019-04-24 16:56:29 --> Config Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:56:29 --> URI Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Router Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Output Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Security Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Input Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:56:29 --> Language Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Loader Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Controller Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Session Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:56:29 --> Session routines successfully run
DEBUG - 2019-04-24 16:56:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Model Class Initialized
DEBUG - 2019-04-24 16:56:29 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:56:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:56:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:56:29 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:56:29 --> Final output sent to browser
DEBUG - 2019-04-24 16:56:29 --> Total execution time: 0.1361
DEBUG - 2019-04-24 16:58:11 --> Config Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 16:58:11 --> URI Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Router Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Output Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Security Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Input Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 16:58:11 --> Language Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Loader Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Controller Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Session Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 16:58:11 --> Session routines successfully run
DEBUG - 2019-04-24 16:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 16:58:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 16:58:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 16:58:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 16:58:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 16:58:11 --> Final output sent to browser
DEBUG - 2019-04-24 16:58:11 --> Total execution time: 0.1165
DEBUG - 2019-04-24 17:00:46 --> Config Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:00:46 --> URI Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Router Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Output Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Security Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Input Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:00:46 --> Language Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Loader Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Controller Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Session Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:00:46 --> Session garbage collection performed.
DEBUG - 2019-04-24 17:00:46 --> Session routines successfully run
DEBUG - 2019-04-24 17:00:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:00:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:00:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:00:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:00:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:00:46 --> Final output sent to browser
DEBUG - 2019-04-24 17:00:46 --> Total execution time: 0.0693
DEBUG - 2019-04-24 17:01:57 --> Config Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:01:57 --> URI Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Router Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Output Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Security Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Input Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:01:57 --> Language Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Loader Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Controller Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Session Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:01:57 --> Session routines successfully run
DEBUG - 2019-04-24 17:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:01:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:01:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:01:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:01:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:01:57 --> Final output sent to browser
DEBUG - 2019-04-24 17:01:57 --> Total execution time: 0.0530
DEBUG - 2019-04-24 17:06:16 --> Config Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:06:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:06:16 --> URI Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Router Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Output Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Security Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Input Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:06:16 --> Language Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Loader Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Controller Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Session Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:06:16 --> Session routines successfully run
DEBUG - 2019-04-24 17:06:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:06:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:06:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:06:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:06:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:06:16 --> Final output sent to browser
DEBUG - 2019-04-24 17:06:16 --> Total execution time: 0.1834
DEBUG - 2019-04-24 17:07:08 --> Config Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:07:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:07:08 --> URI Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Router Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Output Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Security Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Input Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:07:08 --> Language Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Loader Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Controller Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Session Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:07:08 --> Session routines successfully run
DEBUG - 2019-04-24 17:07:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:07:08 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:07:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:07:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:07:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:07:08 --> Final output sent to browser
DEBUG - 2019-04-24 17:07:08 --> Total execution time: 0.0434
DEBUG - 2019-04-24 17:08:13 --> Config Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:08:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:08:13 --> URI Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Router Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Output Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Security Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Input Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:08:13 --> Language Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Loader Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Controller Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Session Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:08:13 --> Session routines successfully run
DEBUG - 2019-04-24 17:08:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:08:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:08:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:08:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:08:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:08:13 --> Final output sent to browser
DEBUG - 2019-04-24 17:08:13 --> Total execution time: 0.0630
DEBUG - 2019-04-24 17:13:01 --> Config Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:13:01 --> URI Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Router Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Output Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Security Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Input Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:13:01 --> Language Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Loader Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Controller Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Session Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:13:01 --> Session routines successfully run
DEBUG - 2019-04-24 17:13:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:13:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:13:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:13:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:13:01 --> Final output sent to browser
DEBUG - 2019-04-24 17:13:01 --> Total execution time: 0.1321
DEBUG - 2019-04-24 17:13:05 --> Config Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:13:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:13:05 --> URI Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Router Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Output Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Security Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Input Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:13:05 --> Language Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Loader Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Controller Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Session Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:13:05 --> Session routines successfully run
DEBUG - 2019-04-24 17:13:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:13:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:13:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:13:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:13:05 --> Final output sent to browser
DEBUG - 2019-04-24 17:13:05 --> Total execution time: 0.0681
DEBUG - 2019-04-24 17:13:57 --> Config Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:13:57 --> URI Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Router Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Output Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Security Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Input Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:13:57 --> Language Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Loader Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Controller Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Session Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:13:57 --> Session routines successfully run
DEBUG - 2019-04-24 17:13:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Model Class Initialized
DEBUG - 2019-04-24 17:13:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:13:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:13:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:13:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:13:57 --> Final output sent to browser
DEBUG - 2019-04-24 17:13:57 --> Total execution time: 0.1025
DEBUG - 2019-04-24 17:14:04 --> Config Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:14:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:14:04 --> URI Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Router Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Output Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Security Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Input Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:14:04 --> Language Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Loader Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Controller Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Session Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:14:04 --> Session routines successfully run
DEBUG - 2019-04-24 17:14:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:14:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:14:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:14:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:14:04 --> Final output sent to browser
DEBUG - 2019-04-24 17:14:04 --> Total execution time: 0.0662
DEBUG - 2019-04-24 17:14:16 --> Config Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:14:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:14:16 --> URI Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Router Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Output Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Security Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Input Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:14:16 --> Language Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Loader Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Controller Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Session Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:14:16 --> A session cookie was not found.
DEBUG - 2019-04-24 17:14:16 --> Session routines successfully run
DEBUG - 2019-04-24 17:14:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:14:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:14:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:14:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:14:16 --> Final output sent to browser
DEBUG - 2019-04-24 17:14:16 --> Total execution time: 0.1115
DEBUG - 2019-04-24 17:14:18 --> Config Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:14:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:14:18 --> URI Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Router Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Output Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Security Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Input Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:14:18 --> Language Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Loader Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Controller Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Session Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:14:18 --> Session routines successfully run
DEBUG - 2019-04-24 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:18 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:14:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:14:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:14:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:14:18 --> Final output sent to browser
DEBUG - 2019-04-24 17:14:18 --> Total execution time: 0.0440
DEBUG - 2019-04-24 17:14:55 --> Config Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:14:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:14:55 --> URI Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Router Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Output Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Security Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Input Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:14:55 --> Language Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Loader Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Controller Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Session Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:14:55 --> Session routines successfully run
DEBUG - 2019-04-24 17:14:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:55 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:14:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:14:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:14:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:14:55 --> Final output sent to browser
DEBUG - 2019-04-24 17:14:55 --> Total execution time: 0.0783
DEBUG - 2019-04-24 17:14:56 --> Config Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:14:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:14:56 --> URI Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Router Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Output Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Security Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Input Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:14:56 --> Language Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Loader Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Controller Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Session Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:14:56 --> Session routines successfully run
DEBUG - 2019-04-24 17:14:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:14:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:14:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:14:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:14:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:14:56 --> Final output sent to browser
DEBUG - 2019-04-24 17:14:56 --> Total execution time: 0.0510
DEBUG - 2019-04-24 17:15:50 --> Config Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:15:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:15:50 --> URI Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Router Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Output Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Security Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Input Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:15:50 --> Language Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Loader Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Controller Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Session Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:15:50 --> Session routines successfully run
DEBUG - 2019-04-24 17:15:50 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:15:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:15:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:15:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:15:50 --> Final output sent to browser
DEBUG - 2019-04-24 17:15:50 --> Total execution time: 0.0706
DEBUG - 2019-04-24 17:15:55 --> Config Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:15:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:15:55 --> URI Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Router Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Output Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Security Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Input Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:15:55 --> Language Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Loader Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Controller Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Session Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:15:55 --> Session routines successfully run
DEBUG - 2019-04-24 17:15:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:15:55 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:15:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:15:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:15:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:15:55 --> Final output sent to browser
DEBUG - 2019-04-24 17:15:55 --> Total execution time: 0.0548
DEBUG - 2019-04-24 17:16:07 --> Config Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:16:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:16:07 --> URI Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Router Class Initialized
DEBUG - 2019-04-24 17:16:07 --> No URI present. Default controller set.
DEBUG - 2019-04-24 17:16:07 --> Output Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Security Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Input Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:16:07 --> Language Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Loader Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Controller Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Session Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:16:07 --> Session routines successfully run
DEBUG - 2019-04-24 17:16:07 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:16:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:16:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:16:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:16:07 --> Final output sent to browser
DEBUG - 2019-04-24 17:16:07 --> Total execution time: 0.0921
DEBUG - 2019-04-24 17:16:09 --> Config Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:16:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:16:09 --> URI Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Router Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Output Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Security Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Input Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:16:09 --> Language Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Loader Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Controller Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Session Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:16:09 --> Session routines successfully run
DEBUG - 2019-04-24 17:16:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:16:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:16:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:16:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:16:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:16:09 --> Final output sent to browser
DEBUG - 2019-04-24 17:16:09 --> Total execution time: 0.0632
DEBUG - 2019-04-24 17:25:45 --> Config Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:25:45 --> URI Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Router Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Output Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Security Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Input Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:25:45 --> Language Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Loader Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Controller Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Session Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:25:45 --> Session routines successfully run
DEBUG - 2019-04-24 17:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:25:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:25:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:25:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:25:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:25:45 --> Final output sent to browser
DEBUG - 2019-04-24 17:25:45 --> Total execution time: 0.1300
DEBUG - 2019-04-24 17:29:10 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:10 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:10 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:10 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:29:10 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:10 --> Total execution time: 0.0831
DEBUG - 2019-04-24 17:29:44 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:44 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:44 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:44 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:44 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:29:44 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:44 --> Total execution time: 0.0638
DEBUG - 2019-04-24 17:29:46 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:46 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:46 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:46 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:29:46 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:46 --> Total execution time: 0.0699
DEBUG - 2019-04-24 17:29:54 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:54 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:54 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:54 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:29:54 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:54 --> Total execution time: 0.2441
DEBUG - 2019-04-24 17:29:56 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:56 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:56 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:56 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:29:56 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:56 --> Total execution time: 0.0515
DEBUG - 2019-04-24 17:29:59 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:59 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:59 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:59 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:29:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:29:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:29:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:29:59 --> Final output sent to browser
DEBUG - 2019-04-24 17:29:59 --> Total execution time: 0.1026
DEBUG - 2019-04-24 17:29:59 --> Config Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:29:59 --> URI Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Router Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Output Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Security Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Input Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:29:59 --> Language Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Loader Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Controller Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Session Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:29:59 --> Session routines successfully run
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:29:59 --> Model Class Initialized
DEBUG - 2019-04-24 17:30:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:30:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:30:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:30:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:30:00 --> Final output sent to browser
DEBUG - 2019-04-24 17:30:00 --> Total execution time: 0.0630
DEBUG - 2019-04-24 17:31:33 --> Config Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:31:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:31:33 --> URI Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Router Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Output Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Security Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Input Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:31:33 --> Language Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Loader Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Controller Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Session Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:31:33 --> Session routines successfully run
DEBUG - 2019-04-24 17:31:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:31:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:31:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:31:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:31:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:31:33 --> Final output sent to browser
DEBUG - 2019-04-24 17:31:33 --> Total execution time: 0.0710
DEBUG - 2019-04-24 17:37:31 --> Config Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:37:31 --> URI Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Router Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Output Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Security Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Input Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:37:31 --> Language Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Loader Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Controller Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Model Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Model Class Initialized
DEBUG - 2019-04-24 17:37:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:37:32 --> Session Class Initialized
DEBUG - 2019-04-24 17:37:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:37:32 --> Session routines successfully run
DEBUG - 2019-04-24 17:37:32 --> Model Class Initialized
DEBUG - 2019-04-24 17:37:32 --> Model Class Initialized
DEBUG - 2019-04-24 17:37:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:37:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:37:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:37:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:37:32 --> Final output sent to browser
DEBUG - 2019-04-24 17:37:32 --> Total execution time: 0.2327
DEBUG - 2019-04-24 17:38:18 --> Config Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:38:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:38:18 --> URI Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Router Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Output Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Security Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Input Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:38:18 --> Language Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Loader Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Controller Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Session Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:38:18 --> Session routines successfully run
DEBUG - 2019-04-24 17:38:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:18 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:38:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:38:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:38:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:38:18 --> Final output sent to browser
DEBUG - 2019-04-24 17:38:18 --> Total execution time: 0.1134
DEBUG - 2019-04-24 17:38:33 --> Config Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:38:33 --> URI Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Router Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Output Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Security Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Input Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:38:33 --> Language Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Loader Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Controller Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Session Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:38:33 --> Session routines successfully run
DEBUG - 2019-04-24 17:38:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:38:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:38:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:38:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:38:33 --> Final output sent to browser
DEBUG - 2019-04-24 17:38:33 --> Total execution time: 0.0563
DEBUG - 2019-04-24 17:38:42 --> Config Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:38:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:38:42 --> URI Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Router Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Output Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Security Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Input Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:38:42 --> Language Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Loader Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Controller Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Session Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:38:42 --> Session routines successfully run
DEBUG - 2019-04-24 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:38:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:38:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:38:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:38:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:38:42 --> Final output sent to browser
DEBUG - 2019-04-24 17:38:42 --> Total execution time: 0.0537
DEBUG - 2019-04-24 17:40:36 --> Config Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:40:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:40:36 --> URI Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Router Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Output Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Security Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Input Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:40:36 --> Language Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Loader Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Controller Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Session Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:40:36 --> Session routines successfully run
DEBUG - 2019-04-24 17:40:36 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:40:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:40:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:40:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:40:36 --> Final output sent to browser
DEBUG - 2019-04-24 17:40:36 --> Total execution time: 0.0519
DEBUG - 2019-04-24 17:40:40 --> Config Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:40:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:40:40 --> URI Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Router Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Output Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Security Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Input Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:40:40 --> Language Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Loader Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Controller Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Session Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:40:40 --> Session routines successfully run
DEBUG - 2019-04-24 17:40:40 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:40 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:40:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:40:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:40:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:40:40 --> Final output sent to browser
DEBUG - 2019-04-24 17:40:40 --> Total execution time: 0.0534
DEBUG - 2019-04-24 17:40:51 --> Config Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:40:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:40:51 --> URI Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Router Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Output Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Security Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Input Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:40:51 --> Language Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Loader Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Controller Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Session Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:40:51 --> Session routines successfully run
DEBUG - 2019-04-24 17:40:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:40:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:40:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:40:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:40:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:40:51 --> Final output sent to browser
DEBUG - 2019-04-24 17:40:51 --> Total execution time: 0.0461
DEBUG - 2019-04-24 17:41:01 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:01 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:01 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:01 --> A session cookie was not found.
DEBUG - 2019-04-24 17:41:01 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:01 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:01 --> Total execution time: 0.1053
DEBUG - 2019-04-24 17:41:03 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:03 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:03 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:03 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:03 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:03 --> Total execution time: 0.0539
DEBUG - 2019-04-24 17:41:04 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:04 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:04 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:04 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:04 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:04 --> Total execution time: 0.0510
DEBUG - 2019-04-24 17:41:05 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:05 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:05 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:05 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:05 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:05 --> Total execution time: 0.0436
DEBUG - 2019-04-24 17:41:05 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:05 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:05 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:05 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:05 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:05 --> Total execution time: 0.0476
DEBUG - 2019-04-24 17:41:06 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:06 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:06 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:06 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:06 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:06 --> Total execution time: 0.0440
DEBUG - 2019-04-24 17:41:06 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:06 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:06 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:06 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:06 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:06 --> Total execution time: 0.0461
DEBUG - 2019-04-24 17:41:06 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:06 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:06 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:06 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:06 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:06 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:06 --> Total execution time: 0.0522
DEBUG - 2019-04-24 17:41:24 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:24 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:24 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:24 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:24 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:24 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:24 --> Total execution time: 0.0778
DEBUG - 2019-04-24 17:41:25 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:25 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:25 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:25 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:25 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:25 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:25 --> Total execution time: 0.0527
DEBUG - 2019-04-24 17:41:27 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:27 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:27 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:27 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:27 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:27 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:27 --> Total execution time: 0.0625
DEBUG - 2019-04-24 17:41:42 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:42 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:42 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:42 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:42 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:42 --> Total execution time: 0.0642
DEBUG - 2019-04-24 17:41:51 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:51 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:51 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:51 --> A session cookie was not found.
DEBUG - 2019-04-24 17:41:51 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:51 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:51 --> Total execution time: 0.1100
DEBUG - 2019-04-24 17:41:53 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:53 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:53 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:53 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:53 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:53 --> Total execution time: 0.0524
DEBUG - 2019-04-24 17:41:53 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:53 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:53 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:53 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:41:53 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:53 --> Total execution time: 0.0909
DEBUG - 2019-04-24 17:41:54 --> Config Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:41:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:41:54 --> URI Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Router Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Output Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Security Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Input Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:41:54 --> Language Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Loader Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Controller Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Session Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:41:54 --> Session routines successfully run
DEBUG - 2019-04-24 17:41:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:41:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:41:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:41:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:41:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:41:54 --> Final output sent to browser
DEBUG - 2019-04-24 17:41:54 --> Total execution time: 0.0414
DEBUG - 2019-04-24 17:42:01 --> Config Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:42:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:42:01 --> URI Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Router Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Output Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Security Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Input Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:42:01 --> Language Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Loader Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Controller Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Session Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:42:01 --> Session routines successfully run
DEBUG - 2019-04-24 17:42:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:42:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:42:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:42:01 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 17:42:01 --> Final output sent to browser
DEBUG - 2019-04-24 17:42:01 --> Total execution time: 0.0677
DEBUG - 2019-04-24 17:42:02 --> Config Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:42:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:42:02 --> URI Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Router Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Output Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Security Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Input Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:42:02 --> Language Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Loader Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Controller Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Session Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:42:02 --> Session routines successfully run
DEBUG - 2019-04-24 17:42:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:42:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:42:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:42:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:42:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:42:02 --> Final output sent to browser
DEBUG - 2019-04-24 17:42:02 --> Total execution time: 0.0527
DEBUG - 2019-04-24 17:44:27 --> Config Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:44:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:44:27 --> URI Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Router Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Output Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Security Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Input Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:44:27 --> Language Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Loader Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Controller Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Session Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:44:27 --> Session routines successfully run
DEBUG - 2019-04-24 17:44:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:27 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:44:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:44:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:44:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:44:27 --> Final output sent to browser
DEBUG - 2019-04-24 17:44:27 --> Total execution time: 0.0575
DEBUG - 2019-04-24 17:44:33 --> Config Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:44:33 --> URI Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Router Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Output Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Security Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Input Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:44:33 --> Language Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Loader Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Controller Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Session Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:44:33 --> Session routines successfully run
DEBUG - 2019-04-24 17:44:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:44:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:44:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:44:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:44:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:44:33 --> Final output sent to browser
DEBUG - 2019-04-24 17:44:33 --> Total execution time: 0.0632
DEBUG - 2019-04-24 17:46:08 --> Config Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:46:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:46:08 --> URI Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Router Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Output Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Security Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Input Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:46:08 --> Language Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Loader Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Controller Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Session Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:46:08 --> Session routines successfully run
DEBUG - 2019-04-24 17:46:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:08 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:46:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:46:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:46:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:46:08 --> Final output sent to browser
DEBUG - 2019-04-24 17:46:08 --> Total execution time: 0.0543
DEBUG - 2019-04-24 17:46:38 --> Config Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:46:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:46:38 --> URI Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Router Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Output Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Security Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Input Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:46:38 --> Language Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Loader Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Controller Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Session Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:46:38 --> Session routines successfully run
DEBUG - 2019-04-24 17:46:38 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Model Class Initialized
DEBUG - 2019-04-24 17:46:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:46:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:46:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:46:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:46:38 --> Final output sent to browser
DEBUG - 2019-04-24 17:46:38 --> Total execution time: 0.0707
DEBUG - 2019-04-24 17:48:30 --> Config Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:48:30 --> URI Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Router Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Output Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Security Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Input Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:48:30 --> Language Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Loader Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Controller Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Session Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:48:30 --> Session routines successfully run
DEBUG - 2019-04-24 17:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 17:48:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:48:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:48:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:48:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:48:30 --> Final output sent to browser
DEBUG - 2019-04-24 17:48:30 --> Total execution time: 0.1430
DEBUG - 2019-04-24 17:49:03 --> Config Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:49:03 --> URI Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Router Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Output Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Security Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Input Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:49:03 --> Language Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Loader Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Controller Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Session Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:49:03 --> Session routines successfully run
DEBUG - 2019-04-24 17:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:49:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:49:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:49:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:49:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:49:03 --> Final output sent to browser
DEBUG - 2019-04-24 17:49:03 --> Total execution time: 0.0459
DEBUG - 2019-04-24 17:50:10 --> Config Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:50:10 --> URI Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Router Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Output Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Security Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Input Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:50:10 --> Language Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Loader Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Controller Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Session Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:50:10 --> Session routines successfully run
DEBUG - 2019-04-24 17:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:50:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:50:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:50:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:50:10 --> Final output sent to browser
DEBUG - 2019-04-24 17:50:10 --> Total execution time: 0.0706
DEBUG - 2019-04-24 17:50:53 --> Config Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:50:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:50:53 --> URI Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Router Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Output Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Security Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Input Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:50:53 --> Language Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Loader Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Controller Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Session Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:50:53 --> Session routines successfully run
DEBUG - 2019-04-24 17:50:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Model Class Initialized
DEBUG - 2019-04-24 17:50:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:50:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:50:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:50:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:50:53 --> Final output sent to browser
DEBUG - 2019-04-24 17:50:53 --> Total execution time: 0.0665
DEBUG - 2019-04-24 17:51:11 --> Config Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:51:11 --> URI Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Router Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Output Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Security Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Input Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:51:11 --> Language Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Loader Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Controller Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Session Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:51:11 --> A session cookie was not found.
DEBUG - 2019-04-24 17:51:11 --> Session routines successfully run
DEBUG - 2019-04-24 17:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:51:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:51:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:51:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:51:11 --> Final output sent to browser
DEBUG - 2019-04-24 17:51:11 --> Total execution time: 0.1373
DEBUG - 2019-04-24 17:51:13 --> Config Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:51:13 --> URI Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Router Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Output Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Security Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Input Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:51:13 --> Language Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Loader Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Controller Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Session Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:51:13 --> Session routines successfully run
DEBUG - 2019-04-24 17:51:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:51:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:51:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:51:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:51:13 --> Final output sent to browser
DEBUG - 2019-04-24 17:51:13 --> Total execution time: 0.0756
DEBUG - 2019-04-24 17:51:14 --> Config Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:51:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:51:14 --> URI Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Router Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Output Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Security Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Input Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:51:14 --> Language Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Loader Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Controller Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Session Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:51:14 --> Session routines successfully run
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:51:14 --> Final output sent to browser
DEBUG - 2019-04-24 17:51:14 --> Total execution time: 0.1120
DEBUG - 2019-04-24 17:51:14 --> Config Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:51:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:51:14 --> URI Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Router Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Output Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Security Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Input Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:51:14 --> Language Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Loader Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Controller Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Session Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:51:14 --> Session routines successfully run
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Model Class Initialized
DEBUG - 2019-04-24 17:51:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:51:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:51:14 --> Final output sent to browser
DEBUG - 2019-04-24 17:51:14 --> Total execution time: 0.0431
DEBUG - 2019-04-24 17:54:42 --> Config Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:54:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:54:42 --> URI Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Router Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Output Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Security Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Input Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:54:42 --> Language Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Loader Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Controller Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Session Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:54:42 --> Session routines successfully run
DEBUG - 2019-04-24 17:54:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:54:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:54:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:54:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:54:42 --> Final output sent to browser
DEBUG - 2019-04-24 17:54:42 --> Total execution time: 0.0827
DEBUG - 2019-04-24 17:54:52 --> Config Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:54:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:54:52 --> URI Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Router Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Output Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Security Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Input Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:54:52 --> Language Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Loader Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Controller Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Session Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:54:52 --> A session cookie was not found.
DEBUG - 2019-04-24 17:54:52 --> Session routines successfully run
DEBUG - 2019-04-24 17:54:52 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:54:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:54:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:54:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:54:52 --> Final output sent to browser
DEBUG - 2019-04-24 17:54:52 --> Total execution time: 0.1111
DEBUG - 2019-04-24 17:54:54 --> Config Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:54:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:54:54 --> URI Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Router Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Output Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Security Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Input Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:54:54 --> Language Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Loader Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Controller Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Session Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:54:54 --> Session routines successfully run
DEBUG - 2019-04-24 17:54:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:54:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:54:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:54:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:54:54 --> Final output sent to browser
DEBUG - 2019-04-24 17:54:54 --> Total execution time: 0.1039
DEBUG - 2019-04-24 17:54:55 --> Config Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:54:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:54:55 --> URI Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Router Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Output Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Security Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Input Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:54:55 --> Language Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Loader Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Controller Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Session Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:54:55 --> Session routines successfully run
DEBUG - 2019-04-24 17:54:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Model Class Initialized
DEBUG - 2019-04-24 17:54:55 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:54:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:54:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:54:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:54:55 --> Final output sent to browser
DEBUG - 2019-04-24 17:54:55 --> Total execution time: 0.0544
DEBUG - 2019-04-24 17:56:09 --> Config Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:56:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:56:09 --> URI Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Router Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Output Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Security Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Input Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:56:09 --> Language Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Loader Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Controller Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Session Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:56:09 --> Session routines successfully run
DEBUG - 2019-04-24 17:56:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:56:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:56:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:56:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:56:09 --> Final output sent to browser
DEBUG - 2019-04-24 17:56:09 --> Total execution time: 0.0482
DEBUG - 2019-04-24 17:56:20 --> Config Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:56:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:56:20 --> URI Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Router Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Output Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Security Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Input Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:56:20 --> Language Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Loader Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Controller Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Session Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:56:20 --> Session routines successfully run
DEBUG - 2019-04-24 17:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:56:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:56:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:56:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:56:20 --> Final output sent to browser
DEBUG - 2019-04-24 17:56:20 --> Total execution time: 0.0649
DEBUG - 2019-04-24 17:56:22 --> Config Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:56:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:56:22 --> URI Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Router Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Output Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Security Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Input Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:56:22 --> Language Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Loader Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Controller Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Session Class Initialized
DEBUG - 2019-04-24 17:56:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:56:22 --> Session routines successfully run
DEBUG - 2019-04-24 17:56:22 --> Helper loaded: url_helper
ERROR - 2019-04-24 17:56:22 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE2
DEBUG - 2019-04-24 17:56:25 --> Config Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:56:25 --> URI Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Router Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Output Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Security Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Input Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:56:25 --> Language Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Loader Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Controller Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Session Class Initialized
DEBUG - 2019-04-24 17:56:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:56:25 --> Session routines successfully run
DEBUG - 2019-04-24 17:56:25 --> Helper loaded: url_helper
ERROR - 2019-04-24 17:56:25 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE1
DEBUG - 2019-04-24 17:56:43 --> Config Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:56:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:56:43 --> URI Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Router Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Output Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Security Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Input Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:56:43 --> Language Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Loader Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Controller Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Session Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:56:43 --> Session routines successfully run
DEBUG - 2019-04-24 17:56:43 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Model Class Initialized
DEBUG - 2019-04-24 17:56:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:56:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:56:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:56:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:56:43 --> Final output sent to browser
DEBUG - 2019-04-24 17:56:43 --> Total execution time: 0.0568
DEBUG - 2019-04-24 17:57:00 --> Config Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:57:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:57:00 --> URI Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Router Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Output Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Security Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Input Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:57:00 --> Language Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Loader Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Controller Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Session Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:57:00 --> A session cookie was not found.
DEBUG - 2019-04-24 17:57:00 --> Session routines successfully run
DEBUG - 2019-04-24 17:57:00 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:57:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:57:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:57:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:57:00 --> Final output sent to browser
DEBUG - 2019-04-24 17:57:00 --> Total execution time: 0.1140
DEBUG - 2019-04-24 17:57:02 --> Config Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:57:02 --> URI Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Router Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Output Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Security Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Input Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:57:02 --> Language Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Loader Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Controller Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Session Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:57:02 --> Session garbage collection performed.
DEBUG - 2019-04-24 17:57:02 --> Session routines successfully run
DEBUG - 2019-04-24 17:57:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:57:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:57:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:57:02 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 17:57:02 --> Final output sent to browser
DEBUG - 2019-04-24 17:57:02 --> Total execution time: 0.1193
DEBUG - 2019-04-24 17:57:03 --> Config Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:57:03 --> URI Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Router Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Output Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Security Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Input Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:57:03 --> Language Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Loader Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Controller Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Session Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:57:03 --> Session garbage collection performed.
DEBUG - 2019-04-24 17:57:03 --> Session routines successfully run
DEBUG - 2019-04-24 17:57:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:57:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:57:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:57:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:57:03 --> Final output sent to browser
DEBUG - 2019-04-24 17:57:03 --> Total execution time: 0.0579
DEBUG - 2019-04-24 17:57:33 --> Config Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:57:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:57:33 --> URI Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Router Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Output Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Security Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Input Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:57:33 --> Language Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Loader Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Controller Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Session Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:57:33 --> Session routines successfully run
DEBUG - 2019-04-24 17:57:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Model Class Initialized
DEBUG - 2019-04-24 17:57:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:57:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:57:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:57:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:57:33 --> Final output sent to browser
DEBUG - 2019-04-24 17:57:33 --> Total execution time: 0.0665
DEBUG - 2019-04-24 17:58:04 --> Config Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:58:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:58:04 --> URI Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Router Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Output Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Security Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Input Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:58:04 --> Language Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Loader Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Controller Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Session Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:58:04 --> Session routines successfully run
DEBUG - 2019-04-24 17:58:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:58:11 --> Config Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:58:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:58:11 --> URI Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Router Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Output Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Security Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Input Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:58:11 --> Language Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Loader Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Controller Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:11 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:58:12 --> Session Class Initialized
DEBUG - 2019-04-24 17:58:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:58:12 --> Session routines successfully run
DEBUG - 2019-04-24 17:58:12 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:12 --> Model Class Initialized
DEBUG - 2019-04-24 17:58:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:59:16 --> Config Class Initialized
DEBUG - 2019-04-24 17:59:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:59:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:59:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:59:16 --> URI Class Initialized
DEBUG - 2019-04-24 17:59:16 --> Router Class Initialized
DEBUG - 2019-04-24 17:59:16 --> Output Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Security Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Input Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:59:17 --> Language Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Loader Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Controller Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Session Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:59:17 --> Session routines successfully run
DEBUG - 2019-04-24 17:59:17 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:59:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:59:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:59:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:59:17 --> Final output sent to browser
DEBUG - 2019-04-24 17:59:17 --> Total execution time: 0.0685
DEBUG - 2019-04-24 17:59:45 --> Config Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 17:59:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 17:59:45 --> URI Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Router Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Output Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Security Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Input Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 17:59:45 --> Language Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Loader Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Controller Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Session Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 17:59:45 --> Session routines successfully run
DEBUG - 2019-04-24 17:59:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Model Class Initialized
DEBUG - 2019-04-24 17:59:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 17:59:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 17:59:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 17:59:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 17:59:45 --> Final output sent to browser
DEBUG - 2019-04-24 17:59:45 --> Total execution time: 0.0459
DEBUG - 2019-04-24 18:00:05 --> Config Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:00:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:00:05 --> URI Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Router Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Output Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Security Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Input Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:00:05 --> Language Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Loader Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Controller Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Session Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:00:05 --> Session routines successfully run
DEBUG - 2019-04-24 18:00:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:00:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:00:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:00:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:00:05 --> Final output sent to browser
DEBUG - 2019-04-24 18:00:05 --> Total execution time: 0.0710
DEBUG - 2019-04-24 18:00:06 --> Config Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:00:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:00:06 --> URI Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Router Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Output Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Security Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Input Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:00:06 --> Language Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Loader Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Controller Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Session Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:00:06 --> Session routines successfully run
DEBUG - 2019-04-24 18:00:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:06 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:00:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:00:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:00:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:00:06 --> Final output sent to browser
DEBUG - 2019-04-24 18:00:06 --> Total execution time: 0.0617
DEBUG - 2019-04-24 18:00:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:00:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:00:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:00:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:00:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:00:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:00:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:00:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:00:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:00:33 --> Final output sent to browser
DEBUG - 2019-04-24 18:00:33 --> Total execution time: 0.0557
DEBUG - 2019-04-24 18:00:58 --> Config Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:00:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:00:58 --> URI Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Router Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Output Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Security Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Input Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:00:58 --> Language Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Loader Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Controller Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Session Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:00:58 --> Session routines successfully run
DEBUG - 2019-04-24 18:00:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:00:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:00:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:00:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:00:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:00:58 --> Final output sent to browser
DEBUG - 2019-04-24 18:00:58 --> Total execution time: 0.0580
DEBUG - 2019-04-24 18:01:28 --> Config Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:01:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:01:28 --> URI Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Router Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Output Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Security Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Input Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:01:28 --> Language Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Loader Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Controller Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Session Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:01:28 --> Session routines successfully run
DEBUG - 2019-04-24 18:01:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:01:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:01:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:01:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:01:28 --> Final output sent to browser
DEBUG - 2019-04-24 18:01:28 --> Total execution time: 0.0606
DEBUG - 2019-04-24 18:01:44 --> Config Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:01:44 --> URI Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Router Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Output Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Security Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Input Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:01:44 --> Language Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Loader Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Controller Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Session Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:01:44 --> Session routines successfully run
DEBUG - 2019-04-24 18:01:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:01:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:01:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:01:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:01:44 --> Final output sent to browser
DEBUG - 2019-04-24 18:01:44 --> Total execution time: 0.0581
DEBUG - 2019-04-24 18:01:57 --> Config Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:01:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:01:57 --> URI Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Router Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Output Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Security Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Input Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:01:57 --> Language Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Loader Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Controller Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Session Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:01:57 --> Session routines successfully run
DEBUG - 2019-04-24 18:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:01:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:01:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:01:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:01:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:01:57 --> Final output sent to browser
DEBUG - 2019-04-24 18:01:57 --> Total execution time: 0.0589
DEBUG - 2019-04-24 18:02:09 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:09 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:09 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:09 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:09 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:09 --> Total execution time: 0.0803
DEBUG - 2019-04-24 18:02:19 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:19 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:19 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:19 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:19 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:19 --> Total execution time: 0.0642
DEBUG - 2019-04-24 18:02:21 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:21 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:21 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:21 --> Session garbage collection performed.
DEBUG - 2019-04-24 18:02:21 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:21 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:22 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:22 --> Total execution time: 0.0762
DEBUG - 2019-04-24 18:02:28 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:28 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:28 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:28 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:28 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:28 --> Total execution time: 0.0672
DEBUG - 2019-04-24 18:02:37 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:37 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:37 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:37 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:37 --> A session cookie was not found.
DEBUG - 2019-04-24 18:02:38 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:38 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:38 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:38 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:38 --> Total execution time: 0.1286
DEBUG - 2019-04-24 18:02:40 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:40 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:40 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:40 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:40 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:40 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:40 --> Total execution time: 0.0613
DEBUG - 2019-04-24 18:02:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:02:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:41 --> Total execution time: 0.0832
DEBUG - 2019-04-24 18:02:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:02:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:02:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:02:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:02:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:02:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:02:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:02:41 --> Total execution time: 0.0437
DEBUG - 2019-04-24 18:03:04 --> Config Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:03:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:03:04 --> URI Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Router Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Output Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Security Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Input Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:03:04 --> Language Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Loader Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Controller Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Session Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:03:04 --> Session routines successfully run
DEBUG - 2019-04-24 18:03:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:03:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:03:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:03:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:03:04 --> Final output sent to browser
DEBUG - 2019-04-24 18:03:04 --> Total execution time: 0.0668
DEBUG - 2019-04-24 18:03:40 --> Config Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:03:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:03:40 --> URI Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Router Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Output Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Security Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Input Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:03:40 --> Language Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Loader Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Controller Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Session Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:03:40 --> Session routines successfully run
DEBUG - 2019-04-24 18:03:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Model Class Initialized
DEBUG - 2019-04-24 18:03:40 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:03:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:03:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:03:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:03:40 --> Final output sent to browser
DEBUG - 2019-04-24 18:03:40 --> Total execution time: 0.0558
DEBUG - 2019-04-24 18:05:03 --> Config Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:05:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:05:03 --> URI Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Router Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Output Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Security Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Input Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:05:03 --> Language Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Loader Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Controller Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Session Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:05:03 --> Session routines successfully run
DEBUG - 2019-04-24 18:05:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:05:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:05:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:05:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:05:03 --> Final output sent to browser
DEBUG - 2019-04-24 18:05:03 --> Total execution time: 0.0644
DEBUG - 2019-04-24 18:05:13 --> Config Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:05:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:05:13 --> URI Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Router Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Output Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Security Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Input Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:05:13 --> Language Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Loader Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Controller Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Session Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:05:13 --> A session cookie was not found.
DEBUG - 2019-04-24 18:05:13 --> Session routines successfully run
DEBUG - 2019-04-24 18:05:13 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:13 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:05:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:05:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:05:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:05:13 --> Final output sent to browser
DEBUG - 2019-04-24 18:05:13 --> Total execution time: 0.1143
DEBUG - 2019-04-24 18:05:14 --> Config Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:05:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:05:14 --> URI Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Router Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Output Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Security Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Input Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:05:14 --> Language Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Loader Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Controller Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Session Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:05:14 --> Session routines successfully run
DEBUG - 2019-04-24 18:05:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:05:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:05:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:05:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:05:14 --> Final output sent to browser
DEBUG - 2019-04-24 18:05:14 --> Total execution time: 0.0751
DEBUG - 2019-04-24 18:05:15 --> Config Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:05:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:05:15 --> URI Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Router Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Output Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Security Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Input Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:05:15 --> Language Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Loader Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Controller Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Session Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:05:15 --> Session routines successfully run
DEBUG - 2019-04-24 18:05:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:05:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:05:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:05:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:05:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:05:15 --> Final output sent to browser
DEBUG - 2019-04-24 18:05:15 --> Total execution time: 0.0619
DEBUG - 2019-04-24 18:06:03 --> Config Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:06:03 --> URI Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Router Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Output Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Security Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Input Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:06:03 --> Language Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Loader Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Controller Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Session Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:06:03 --> Session routines successfully run
DEBUG - 2019-04-24 18:06:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:06:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:06:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:06:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:06:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:06:03 --> Final output sent to browser
DEBUG - 2019-04-24 18:06:03 --> Total execution time: 0.0512
DEBUG - 2019-04-24 18:07:26 --> Config Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:07:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:07:26 --> URI Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Router Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Output Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Security Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Input Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:07:26 --> Language Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Loader Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Controller Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Session Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:07:26 --> Session routines successfully run
DEBUG - 2019-04-24 18:07:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:07:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:07:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:07:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:07:26 --> Final output sent to browser
DEBUG - 2019-04-24 18:07:26 --> Total execution time: 0.0659
DEBUG - 2019-04-24 18:07:34 --> Config Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:07:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:07:34 --> URI Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Router Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Output Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Security Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Input Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:07:34 --> Language Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Loader Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Controller Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:07:34 --> Session Class Initialized
DEBUG - 2019-04-24 18:07:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:07:35 --> Session routines successfully run
DEBUG - 2019-04-24 18:07:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:07:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:07:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:07:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:07:35 --> Final output sent to browser
DEBUG - 2019-04-24 18:07:35 --> Total execution time: 0.1176
DEBUG - 2019-04-24 18:07:55 --> Config Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:07:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:07:55 --> URI Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Router Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Output Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Security Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Input Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:07:55 --> Language Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Loader Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Controller Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Session Class Initialized
DEBUG - 2019-04-24 18:07:55 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:07:55 --> A session cookie was not found.
DEBUG - 2019-04-24 18:07:56 --> Session routines successfully run
DEBUG - 2019-04-24 18:07:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:07:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:07:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:07:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:07:56 --> Final output sent to browser
DEBUG - 2019-04-24 18:07:56 --> Total execution time: 0.1221
DEBUG - 2019-04-24 18:07:57 --> Config Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:07:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:07:57 --> URI Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Router Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Output Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Security Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Input Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:07:57 --> Language Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Loader Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Controller Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Session Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:07:57 --> Session routines successfully run
DEBUG - 2019-04-24 18:07:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:07:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:07:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:07:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:07:57 --> Final output sent to browser
DEBUG - 2019-04-24 18:07:57 --> Total execution time: 0.1228
DEBUG - 2019-04-24 18:07:58 --> Config Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:07:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:07:58 --> URI Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Router Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Output Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Security Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Input Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:07:58 --> Language Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Loader Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Controller Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Session Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:07:58 --> Session routines successfully run
DEBUG - 2019-04-24 18:07:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Model Class Initialized
DEBUG - 2019-04-24 18:07:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:07:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:07:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:07:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:07:58 --> Final output sent to browser
DEBUG - 2019-04-24 18:07:58 --> Total execution time: 0.0458
DEBUG - 2019-04-24 18:08:49 --> Config Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:08:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:08:49 --> URI Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Router Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Output Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Security Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Input Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:08:49 --> Language Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Loader Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Controller Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Session Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:08:49 --> Session routines successfully run
DEBUG - 2019-04-24 18:08:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:08:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:08:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:08:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:08:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:08:49 --> Final output sent to browser
DEBUG - 2019-04-24 18:08:49 --> Total execution time: 0.0578
DEBUG - 2019-04-24 18:10:53 --> Config Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:10:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:10:53 --> URI Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Router Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Output Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Security Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Input Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:10:53 --> Language Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Loader Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Controller Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Session Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:10:53 --> Session routines successfully run
DEBUG - 2019-04-24 18:10:53 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:10:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:10:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:10:53 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:10:53 --> Final output sent to browser
DEBUG - 2019-04-24 18:10:53 --> Total execution time: 0.0583
DEBUG - 2019-04-24 18:10:56 --> Config Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:10:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:10:56 --> URI Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Router Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Output Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Security Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Input Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:10:56 --> Language Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Loader Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Controller Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Session Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:10:56 --> Session routines successfully run
DEBUG - 2019-04-24 18:10:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:10:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:10:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:10:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:10:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:10:56 --> Final output sent to browser
DEBUG - 2019-04-24 18:10:56 --> Total execution time: 0.0609
DEBUG - 2019-04-24 18:14:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:14:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:14:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:14:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:14:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:14:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:14:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:14:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:14:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:14:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:14:33 --> Final output sent to browser
DEBUG - 2019-04-24 18:14:33 --> Total execution time: 0.1514
DEBUG - 2019-04-24 18:15:05 --> Config Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:15:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:15:05 --> URI Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Router Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Output Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Security Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Input Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:15:05 --> Language Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Loader Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Controller Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Session Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:15:05 --> Session routines successfully run
DEBUG - 2019-04-24 18:15:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:15:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:15:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:15:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:15:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:15:05 --> Final output sent to browser
DEBUG - 2019-04-24 18:15:05 --> Total execution time: 0.0493
DEBUG - 2019-04-24 18:16:34 --> Config Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:16:34 --> URI Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Router Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Output Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Security Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Input Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:16:34 --> Language Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Loader Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Controller Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Session Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:16:34 --> Session garbage collection performed.
DEBUG - 2019-04-24 18:16:34 --> Session routines successfully run
DEBUG - 2019-04-24 18:16:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:34 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:16:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:16:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:16:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:16:34 --> Final output sent to browser
DEBUG - 2019-04-24 18:16:34 --> Total execution time: 0.0553
DEBUG - 2019-04-24 18:16:46 --> Config Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:16:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:16:46 --> URI Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Router Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Output Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Security Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Input Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:16:46 --> Language Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Loader Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Controller Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Session Class Initialized
DEBUG - 2019-04-24 18:16:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:16:46 --> Session routines successfully run
DEBUG - 2019-04-24 18:16:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:16:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:16:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:16:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:16:47 --> Final output sent to browser
DEBUG - 2019-04-24 18:16:47 --> Total execution time: 0.0646
DEBUG - 2019-04-24 18:16:56 --> Config Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:16:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:16:56 --> URI Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Router Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Output Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Security Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Input Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:16:56 --> Language Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Loader Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Controller Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Session Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:16:56 --> Session routines successfully run
DEBUG - 2019-04-24 18:16:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:16:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:16:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:16:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:16:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:16:56 --> Final output sent to browser
DEBUG - 2019-04-24 18:16:56 --> Total execution time: 0.0623
DEBUG - 2019-04-24 18:17:03 --> Config Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:17:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:17:03 --> URI Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Router Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Output Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Security Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Input Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:17:03 --> Language Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Loader Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Controller Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Session Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:17:03 --> Session routines successfully run
DEBUG - 2019-04-24 18:17:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:17:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:17:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:17:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:17:03 --> Final output sent to browser
DEBUG - 2019-04-24 18:17:03 --> Total execution time: 0.0734
DEBUG - 2019-04-24 18:17:48 --> Config Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:17:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:17:48 --> URI Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Router Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Output Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Security Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Input Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:17:48 --> Language Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Loader Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Controller Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Session Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:17:48 --> Session routines successfully run
DEBUG - 2019-04-24 18:17:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:17:48 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:17:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:17:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:17:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:17:48 --> Final output sent to browser
DEBUG - 2019-04-24 18:17:48 --> Total execution time: 0.0590
DEBUG - 2019-04-24 18:18:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:18:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:18:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:18:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:18:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:18:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:18:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:18:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:18:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:18:33 --> Final output sent to browser
DEBUG - 2019-04-24 18:18:33 --> Total execution time: 0.0716
DEBUG - 2019-04-24 18:18:36 --> Config Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:18:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:18:36 --> URI Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Router Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Output Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Security Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Input Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:18:36 --> Language Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Loader Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Controller Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Session Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:18:36 --> Session routines successfully run
DEBUG - 2019-04-24 18:18:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:18:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:18:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:18:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:18:36 --> Final output sent to browser
DEBUG - 2019-04-24 18:18:36 --> Total execution time: 0.0555
DEBUG - 2019-04-24 18:18:56 --> Config Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:18:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:18:56 --> URI Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Router Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Output Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Security Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Input Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:18:56 --> Language Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Loader Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Controller Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Session Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:18:56 --> Session routines successfully run
DEBUG - 2019-04-24 18:18:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:18:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:18:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:18:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:18:56 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:18:56 --> Final output sent to browser
DEBUG - 2019-04-24 18:18:56 --> Total execution time: 0.0567
DEBUG - 2019-04-24 18:19:16 --> Config Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:19:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:19:16 --> URI Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Router Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Output Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Security Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Input Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:19:16 --> Language Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Loader Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Controller Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Session Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:19:16 --> Session routines successfully run
DEBUG - 2019-04-24 18:19:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:19:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:19:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:19:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:19:16 --> Final output sent to browser
DEBUG - 2019-04-24 18:19:16 --> Total execution time: 0.1531
DEBUG - 2019-04-24 18:19:19 --> Config Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:19:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:19:19 --> URI Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Router Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Output Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Security Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Input Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:19:19 --> Language Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Loader Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Controller Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Session Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:19:19 --> Session routines successfully run
DEBUG - 2019-04-24 18:19:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:19:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:19:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:19:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:19:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:19:20 --> Final output sent to browser
DEBUG - 2019-04-24 18:19:20 --> Total execution time: 0.0600
DEBUG - 2019-04-24 18:20:28 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:28 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:28 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:28 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:20:28 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:28 --> Total execution time: 0.1451
DEBUG - 2019-04-24 18:20:30 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:30 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:30 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:30 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:20:30 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:30 --> Total execution time: 0.0435
DEBUG - 2019-04-24 18:20:39 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:39 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:39 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:39 --> A session cookie was not found.
DEBUG - 2019-04-24 18:20:39 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:39 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:20:39 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:39 --> Total execution time: 0.0806
DEBUG - 2019-04-24 18:20:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 18:20:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:41 --> Total execution time: 0.0530
DEBUG - 2019-04-24 18:20:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:20:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:41 --> Total execution time: 0.0533
DEBUG - 2019-04-24 18:20:43 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:43 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:43 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:43 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:20:43 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:43 --> Total execution time: 0.0810
DEBUG - 2019-04-24 18:20:43 --> Config Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:20:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:20:43 --> URI Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Router Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Output Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Security Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Input Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:20:43 --> Language Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Loader Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Controller Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Session Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:20:43 --> Session routines successfully run
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:20:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:20:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:20:43 --> Final output sent to browser
DEBUG - 2019-04-24 18:20:43 --> Total execution time: 0.0403
DEBUG - 2019-04-24 18:22:09 --> Config Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:22:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:22:09 --> URI Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Router Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Output Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Security Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Input Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:22:09 --> Language Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Loader Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Controller Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Session Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:22:09 --> Session routines successfully run
DEBUG - 2019-04-24 18:22:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:22:09 --> File loaded: application/views/header.php
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 40
ERROR - 2019-04-24 18:22:09 --> Severity: Notice  --> Undefined index: Producer C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\market.php 43
DEBUG - 2019-04-24 18:22:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:22:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:22:09 --> Final output sent to browser
DEBUG - 2019-04-24 18:22:09 --> Total execution time: 0.0845
DEBUG - 2019-04-24 18:22:27 --> Config Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:22:27 --> URI Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Router Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Output Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Security Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Input Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:22:27 --> Language Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Loader Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Controller Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Session Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:22:27 --> Session routines successfully run
DEBUG - 2019-04-24 18:22:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:27 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:22:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:22:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:22:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:22:27 --> Final output sent to browser
DEBUG - 2019-04-24 18:22:27 --> Total execution time: 0.0548
DEBUG - 2019-04-24 18:22:31 --> Config Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:22:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:22:31 --> URI Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Router Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Output Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Security Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Input Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:22:31 --> Language Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Loader Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Controller Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Session Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:22:31 --> Session routines successfully run
DEBUG - 2019-04-24 18:22:31 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:22:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:22:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:22:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:22:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:22:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:22:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:23:02 --> Config Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:23:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:23:02 --> URI Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Router Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Output Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Security Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Input Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:23:02 --> Language Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Loader Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Controller Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Session Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:23:02 --> Session routines successfully run
DEBUG - 2019-04-24 18:23:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:23:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:23:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:23:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:23:02 --> Final output sent to browser
DEBUG - 2019-04-24 18:23:02 --> Total execution time: 0.0574
DEBUG - 2019-04-24 18:23:25 --> Config Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:23:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:23:25 --> URI Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Router Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Output Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Security Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Input Class Initialized
DEBUG - 2019-04-24 18:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:23:25 --> Language Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Loader Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Controller Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Session Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:23:26 --> Session routines successfully run
DEBUG - 2019-04-24 18:23:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:23:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:23:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:23:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:23:26 --> Final output sent to browser
DEBUG - 2019-04-24 18:23:26 --> Total execution time: 0.0457
DEBUG - 2019-04-24 18:23:52 --> Config Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:23:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:23:52 --> URI Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Router Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Output Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Security Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Input Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:23:52 --> Language Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Loader Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Controller Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Session Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:23:52 --> Session routines successfully run
DEBUG - 2019-04-24 18:23:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:23:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:23:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:23:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:23:52 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 18:23:52 --> Final output sent to browser
DEBUG - 2019-04-24 18:23:52 --> Total execution time: 0.0490
DEBUG - 2019-04-24 18:24:03 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:03 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:03 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:03 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:03 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 18:24:03 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:03 --> Total execution time: 0.0449
DEBUG - 2019-04-24 18:24:11 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:11 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:11 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:11 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:11 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-24 18:24:11 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:11 --> Total execution time: 0.0806
DEBUG - 2019-04-24 18:24:14 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:14 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:14 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:14 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:14 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 18:24:14 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:14 --> Total execution time: 0.0517
DEBUG - 2019-04-24 18:24:21 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:21 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:21 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:21 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:21 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:21 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:24:21 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:21 --> Total execution time: 0.1893
DEBUG - 2019-04-24 18:24:24 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:24 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:24 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:24 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:24 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:24:24 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:24 --> Total execution time: 0.0505
DEBUG - 2019-04-24 18:24:32 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:32 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:32 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:32 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:32 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:24:32 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:32 --> Total execution time: 0.0464
DEBUG - 2019-04-24 18:24:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:33 --> A session cookie was not found.
DEBUG - 2019-04-24 18:24:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:24:33 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:33 --> Total execution time: 0.1737
DEBUG - 2019-04-24 18:24:34 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:34 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:34 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:34 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:35 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:35 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:35 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 18:24:35 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:35 --> Total execution time: 0.0524
DEBUG - 2019-04-24 18:24:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:24:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:41 --> Total execution time: 0.1375
DEBUG - 2019-04-24 18:24:44 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:44 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:44 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:44 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:24:44 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:44 --> Total execution time: 0.0984
DEBUG - 2019-04-24 18:24:45 --> Config Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:24:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:24:45 --> URI Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Router Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Output Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Security Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Input Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:24:45 --> Language Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Loader Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Controller Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Session Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:24:45 --> Session routines successfully run
DEBUG - 2019-04-24 18:24:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:24:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:24:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:24:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:24:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:24:45 --> Final output sent to browser
DEBUG - 2019-04-24 18:24:45 --> Total execution time: 0.0516
DEBUG - 2019-04-24 18:25:35 --> Config Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:25:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:25:35 --> URI Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Router Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Output Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Security Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Input Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:25:35 --> Language Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Loader Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Controller Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Session Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:25:35 --> Session routines successfully run
DEBUG - 2019-04-24 18:25:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:25:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:25:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:25:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:25:35 --> Final output sent to browser
DEBUG - 2019-04-24 18:25:35 --> Total execution time: 0.0675
DEBUG - 2019-04-24 18:25:45 --> Config Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:25:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:25:45 --> URI Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Router Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Output Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Security Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Input Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:25:45 --> Language Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Loader Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Controller Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Session Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:25:45 --> Session routines successfully run
DEBUG - 2019-04-24 18:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:25:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:25:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:25:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:25:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:25:45 --> Final output sent to browser
DEBUG - 2019-04-24 18:25:45 --> Total execution time: 0.0611
DEBUG - 2019-04-24 18:26:04 --> Config Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:26:04 --> URI Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Router Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Output Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Security Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Input Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:26:04 --> Language Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Loader Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Controller Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Session Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:26:04 --> Session routines successfully run
DEBUG - 2019-04-24 18:26:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:26:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:26:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:26:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:26:04 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:26:04 --> Final output sent to browser
DEBUG - 2019-04-24 18:26:04 --> Total execution time: 0.0614
DEBUG - 2019-04-24 18:31:50 --> Config Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:31:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:31:50 --> URI Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Router Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Output Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Security Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Input Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:31:50 --> Language Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Loader Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Controller Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Session Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:31:50 --> Session routines successfully run
DEBUG - 2019-04-24 18:31:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:31:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:31:50 --> File loaded: application/views/header.php
ERROR - 2019-04-24 18:31:50 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\profile.php 7
DEBUG - 2019-04-24 18:31:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:31:50 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:31:50 --> Final output sent to browser
DEBUG - 2019-04-24 18:31:50 --> Total execution time: 0.1490
DEBUG - 2019-04-24 18:32:10 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:10 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:10 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:10 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:32:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:32:10 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:32:10 --> Final output sent to browser
DEBUG - 2019-04-24 18:32:10 --> Total execution time: 0.0692
DEBUG - 2019-04-24 18:32:15 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:15 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:15 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:15 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:15 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:15 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:15 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:15 --> A session cookie was not found.
DEBUG - 2019-04-24 18:32:15 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:32:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:32:15 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:32:15 --> Final output sent to browser
DEBUG - 2019-04-24 18:32:15 --> Total execution time: 0.1529
DEBUG - 2019-04-24 18:32:17 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:17 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:17 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:17 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:32:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:32:17 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 18:32:17 --> Final output sent to browser
DEBUG - 2019-04-24 18:32:17 --> Total execution time: 0.0546
DEBUG - 2019-04-24 18:32:25 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:25 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:25 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:25 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:25 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:32:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:32:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:32:25 --> Final output sent to browser
DEBUG - 2019-04-24 18:32:25 --> Total execution time: 0.2106
DEBUG - 2019-04-24 18:32:27 --> Config Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:32:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:32:27 --> URI Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Router Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Output Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Security Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Input Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:32:27 --> Language Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Loader Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Controller Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Session Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:32:27 --> Session routines successfully run
DEBUG - 2019-04-24 18:32:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Model Class Initialized
DEBUG - 2019-04-24 18:32:27 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:32:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:32:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:32:27 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:32:27 --> Final output sent to browser
DEBUG - 2019-04-24 18:32:27 --> Total execution time: 0.0419
DEBUG - 2019-04-24 18:34:00 --> Config Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:34:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:34:00 --> URI Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Router Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Output Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Security Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Input Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:34:00 --> Language Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Loader Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Controller Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Session Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:34:00 --> Session routines successfully run
DEBUG - 2019-04-24 18:34:00 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:34:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:34:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:34:00 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 18:34:00 --> Final output sent to browser
DEBUG - 2019-04-24 18:34:00 --> Total execution time: 0.0622
DEBUG - 2019-04-24 18:34:19 --> Config Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:34:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:34:19 --> URI Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Router Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Output Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Security Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Input Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:34:19 --> Language Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Loader Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Controller Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Session Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:34:19 --> Session routines successfully run
DEBUG - 2019-04-24 18:34:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Model Class Initialized
DEBUG - 2019-04-24 18:34:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:34:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:34:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:34:19 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 18:34:19 --> Final output sent to browser
DEBUG - 2019-04-24 18:34:19 --> Total execution time: 0.0566
DEBUG - 2019-04-24 18:35:16 --> Config Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:35:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:35:16 --> URI Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Router Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Output Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Security Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Input Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:35:16 --> Language Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Loader Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Controller Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Session Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:35:16 --> Session routines successfully run
DEBUG - 2019-04-24 18:35:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:35:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:35:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:35:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:35:16 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 18:35:16 --> Final output sent to browser
DEBUG - 2019-04-24 18:35:16 --> Total execution time: 0.0647
DEBUG - 2019-04-24 18:36:30 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:30 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:30 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:30 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:30 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-24 18:36:30 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:30 --> Total execution time: 0.1025
DEBUG - 2019-04-24 18:36:33 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:33 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:33 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:33 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:33 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-24 18:36:33 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:33 --> Total execution time: 0.0867
DEBUG - 2019-04-24 18:36:36 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:36 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:36 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:36 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:36:36 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:36 --> Total execution time: 0.0700
DEBUG - 2019-04-24 18:36:44 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:44 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:44 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:44 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:36:44 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:44 --> Total execution time: 0.1212
DEBUG - 2019-04-24 18:36:46 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:46 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:46 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:46 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:36:47 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:47 --> Total execution time: 0.0592
DEBUG - 2019-04-24 18:36:47 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:47 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:47 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:47 --> Session garbage collection performed.
DEBUG - 2019-04-24 18:36:47 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:47 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-24 18:36:47 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:47 --> Total execution time: 0.1061
DEBUG - 2019-04-24 18:36:48 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:48 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:48 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:48 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:48 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:48 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:36:48 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:48 --> Total execution time: 0.0535
DEBUG - 2019-04-24 18:36:50 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:50 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:50 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:50 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:50 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:50 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:50 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:50 --> A session cookie was not found.
DEBUG - 2019-04-24 18:36:50 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 18:36:50 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:50 --> Total execution time: 0.1116
DEBUG - 2019-04-24 18:36:52 --> Config Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:36:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:36:52 --> URI Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Router Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Output Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Security Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Input Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:36:52 --> Language Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Loader Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Controller Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Session Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:36:52 --> Session routines successfully run
DEBUG - 2019-04-24 18:36:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Model Class Initialized
DEBUG - 2019-04-24 18:36:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:36:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:36:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:36:52 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 18:36:52 --> Final output sent to browser
DEBUG - 2019-04-24 18:36:52 --> Total execution time: 0.0534
DEBUG - 2019-04-24 18:37:02 --> Config Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:37:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:37:02 --> URI Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Router Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Output Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Security Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Input Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:37:02 --> Language Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Loader Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Controller Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Session Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:37:02 --> Session routines successfully run
DEBUG - 2019-04-24 18:37:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Model Class Initialized
DEBUG - 2019-04-24 18:37:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:37:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:37:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:37:02 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:37:02 --> Final output sent to browser
DEBUG - 2019-04-24 18:37:02 --> Total execution time: 0.2215
DEBUG - 2019-04-24 18:42:09 --> Config Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:42:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:42:09 --> URI Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Router Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Output Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Security Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Input Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:42:09 --> Language Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Loader Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Controller Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Session Class Initialized
DEBUG - 2019-04-24 18:42:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:42:09 --> Session garbage collection performed.
DEBUG - 2019-04-24 18:42:09 --> Session routines successfully run
DEBUG - 2019-04-24 18:42:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:42:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:42:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:42:09 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 18:42:09 --> Final output sent to browser
DEBUG - 2019-04-24 18:42:09 --> Total execution time: 0.1281
DEBUG - 2019-04-24 18:42:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:42:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:42:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:42:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:42:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:42:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:42:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:42:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:42:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:42:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:42:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:42:41 --> Total execution time: 0.1835
DEBUG - 2019-04-24 18:43:05 --> Config Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:43:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:43:05 --> URI Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Router Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Output Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Security Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Input Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:43:05 --> Language Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Loader Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Controller Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Session Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:43:05 --> Session routines successfully run
DEBUG - 2019-04-24 18:43:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:05 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:43:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:43:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:43:05 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:43:05 --> Final output sent to browser
DEBUG - 2019-04-24 18:43:05 --> Total execution time: 0.1597
DEBUG - 2019-04-24 18:43:57 --> Config Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:43:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:43:57 --> URI Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Router Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Output Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Security Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Input Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:43:57 --> Language Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Loader Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Controller Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Session Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:43:57 --> Session routines successfully run
DEBUG - 2019-04-24 18:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Model Class Initialized
DEBUG - 2019-04-24 18:43:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:43:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:43:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:43:57 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:43:57 --> Final output sent to browser
DEBUG - 2019-04-24 18:43:57 --> Total execution time: 0.1989
DEBUG - 2019-04-24 18:44:43 --> Config Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:44:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:44:43 --> URI Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Router Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Output Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Security Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Input Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:44:43 --> Language Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Loader Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Controller Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Session Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:44:43 --> Session routines successfully run
DEBUG - 2019-04-24 18:44:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:43 --> Helper loaded: url_helper
ERROR - 2019-04-24 18:44:43 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 82
ERROR - 2019-04-24 18:44:43 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 83
DEBUG - 2019-04-24 18:44:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:44:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:44:43 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-24 18:44:43 --> Final output sent to browser
DEBUG - 2019-04-24 18:44:43 --> Total execution time: 0.0600
DEBUG - 2019-04-24 18:44:45 --> Config Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:44:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:44:45 --> URI Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Router Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Output Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Security Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Input Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:44:45 --> Language Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Loader Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Controller Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Session Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:44:45 --> Session routines successfully run
DEBUG - 2019-04-24 18:44:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:45 --> Helper loaded: url_helper
ERROR - 2019-04-24 18:44:45 --> Severity: Notice  --> Undefined index: UserName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 82
ERROR - 2019-04-24 18:44:45 --> Severity: Notice  --> Undefined index: password C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 83
DEBUG - 2019-04-24 18:44:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:44:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:44:45 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-24 18:44:45 --> Final output sent to browser
DEBUG - 2019-04-24 18:44:45 --> Total execution time: 0.0641
DEBUG - 2019-04-24 18:44:49 --> Config Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:44:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:44:49 --> URI Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Router Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Output Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Security Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Input Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:44:49 --> Language Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Loader Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Controller Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Session Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:44:49 --> Session routines successfully run
DEBUG - 2019-04-24 18:44:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Model Class Initialized
DEBUG - 2019-04-24 18:44:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:44:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:44:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:44:49 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 18:44:49 --> Final output sent to browser
DEBUG - 2019-04-24 18:44:49 --> Total execution time: 0.0522
DEBUG - 2019-04-24 18:45:01 --> Config Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:45:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:45:01 --> URI Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Router Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Output Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Security Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Input Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:45:01 --> Language Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Loader Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Controller Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Session Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:45:01 --> Session routines successfully run
DEBUG - 2019-04-24 18:45:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:45:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:45:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:45:01 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-24 18:45:01 --> Final output sent to browser
DEBUG - 2019-04-24 18:45:01 --> Total execution time: 0.0590
DEBUG - 2019-04-24 18:45:11 --> Config Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:45:11 --> URI Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Router Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Output Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Security Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Input Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:45:11 --> Language Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Loader Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Controller Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Session Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:45:11 --> Session routines successfully run
DEBUG - 2019-04-24 18:45:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:45:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:45:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:45:11 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 18:45:11 --> Final output sent to browser
DEBUG - 2019-04-24 18:45:11 --> Total execution time: 0.1591
DEBUG - 2019-04-24 18:45:28 --> Config Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:45:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:45:28 --> URI Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Router Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Output Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Security Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Input Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:45:28 --> Language Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Loader Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Controller Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Session Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:45:28 --> Session routines successfully run
DEBUG - 2019-04-24 18:45:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:45:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:45:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:45:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 18:45:28 --> Final output sent to browser
DEBUG - 2019-04-24 18:45:28 --> Total execution time: 0.0662
DEBUG - 2019-04-24 18:45:30 --> Config Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:45:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:45:30 --> URI Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Router Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Output Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Security Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Input Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:45:30 --> Language Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Loader Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Controller Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Session Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:45:30 --> Session routines successfully run
DEBUG - 2019-04-24 18:45:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Model Class Initialized
DEBUG - 2019-04-24 18:45:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:45:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:45:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:45:30 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:45:30 --> Final output sent to browser
DEBUG - 2019-04-24 18:45:30 --> Total execution time: 0.1209
DEBUG - 2019-04-24 18:47:10 --> Config Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:47:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:47:10 --> URI Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Router Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Output Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Security Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Input Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:47:10 --> Language Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Loader Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Controller Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Session Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:47:10 --> Session routines successfully run
DEBUG - 2019-04-24 18:47:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:47:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:47:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:47:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:47:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:47:10 --> Final output sent to browser
DEBUG - 2019-04-24 18:47:10 --> Total execution time: 0.1984
DEBUG - 2019-04-24 18:49:12 --> Config Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:49:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:49:12 --> URI Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Router Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Output Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Security Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Input Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:49:12 --> Language Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Loader Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Controller Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Model Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Model Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Session Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:49:12 --> Session routines successfully run
DEBUG - 2019-04-24 18:49:12 --> Model Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Model Class Initialized
DEBUG - 2019-04-24 18:49:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:49:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:49:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:49:12 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:49:12 --> Final output sent to browser
DEBUG - 2019-04-24 18:49:12 --> Total execution time: 0.1038
DEBUG - 2019-04-24 18:50:10 --> Config Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:50:10 --> URI Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Router Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Output Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Security Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Input Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:50:10 --> Language Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Loader Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Controller Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Session Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:50:10 --> Session garbage collection performed.
DEBUG - 2019-04-24 18:50:10 --> Session routines successfully run
DEBUG - 2019-04-24 18:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:50:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:50:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:50:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:50:10 --> Final output sent to browser
DEBUG - 2019-04-24 18:50:10 --> Total execution time: 0.2762
DEBUG - 2019-04-24 18:50:17 --> Config Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:50:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:50:17 --> URI Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Router Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Output Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Security Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Input Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:50:17 --> Language Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Loader Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Controller Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Session Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:50:17 --> Session routines successfully run
DEBUG - 2019-04-24 18:50:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:50:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:50:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:50:18 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:50:18 --> Final output sent to browser
DEBUG - 2019-04-24 18:50:18 --> Total execution time: 0.1171
DEBUG - 2019-04-24 18:50:19 --> Config Class Initialized
DEBUG - 2019-04-24 18:50:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:50:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:50:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:50:20 --> URI Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Router Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Output Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Security Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Input Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:50:20 --> Language Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Loader Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Controller Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Session Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:50:20 --> Session routines successfully run
DEBUG - 2019-04-24 18:50:20 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:50:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:50:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:50:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:50:20 --> Final output sent to browser
DEBUG - 2019-04-24 18:50:20 --> Total execution time: 0.1035
DEBUG - 2019-04-24 18:50:24 --> Config Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:50:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:50:24 --> URI Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Router Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Output Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Security Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Input Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:50:24 --> Language Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Loader Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Controller Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Session Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:50:24 --> Session routines successfully run
DEBUG - 2019-04-24 18:50:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:50:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:50:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:50:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:50:24 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:50:24 --> Final output sent to browser
DEBUG - 2019-04-24 18:50:24 --> Total execution time: 0.1233
DEBUG - 2019-04-24 18:51:24 --> Config Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:51:24 --> URI Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Router Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Output Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Security Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Input Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:51:24 --> Language Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Loader Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Controller Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Session Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:51:24 --> Session routines successfully run
DEBUG - 2019-04-24 18:51:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:51:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:51:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:51:24 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:51:24 --> Final output sent to browser
DEBUG - 2019-04-24 18:51:24 --> Total execution time: 0.1028
DEBUG - 2019-04-24 18:51:44 --> Config Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:51:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:51:44 --> URI Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Router Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Output Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Security Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Input Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:51:44 --> Language Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Loader Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Controller Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Session Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:51:44 --> Session routines successfully run
DEBUG - 2019-04-24 18:51:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:51:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:51:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:51:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:51:45 --> Final output sent to browser
DEBUG - 2019-04-24 18:51:45 --> Total execution time: 0.1246
DEBUG - 2019-04-24 18:51:47 --> Config Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:51:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:51:47 --> URI Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Router Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Output Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Security Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Input Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:51:47 --> Language Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Loader Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Controller Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Session Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:51:47 --> Session routines successfully run
DEBUG - 2019-04-24 18:51:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:51:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:51:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:51:47 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:51:47 --> Final output sent to browser
DEBUG - 2019-04-24 18:51:47 --> Total execution time: 0.1014
DEBUG - 2019-04-24 18:51:51 --> Config Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:51:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:51:51 --> URI Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Router Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Output Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Security Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Input Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:51:51 --> Language Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Loader Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Controller Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Session Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:51:51 --> Session routines successfully run
DEBUG - 2019-04-24 18:51:51 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Model Class Initialized
DEBUG - 2019-04-24 18:51:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:51:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:51:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:51:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:51:51 --> Final output sent to browser
DEBUG - 2019-04-24 18:51:51 --> Total execution time: 0.3246
DEBUG - 2019-04-24 18:52:01 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:01 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:01 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:01 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:01 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:01 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:01 --> Total execution time: 0.0988
DEBUG - 2019-04-24 18:52:03 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:03 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:03 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:03 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:03 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:03 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:03 --> Total execution time: 0.1194
DEBUG - 2019-04-24 18:52:16 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:16 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:16 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:16 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:16 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:16 --> Total execution time: 0.1566
DEBUG - 2019-04-24 18:52:29 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:29 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:29 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:29 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:29 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:29 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:29 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:29 --> Total execution time: 0.1027
DEBUG - 2019-04-24 18:52:41 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:41 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:41 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:41 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:41 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:41 --> Total execution time: 0.1410
DEBUG - 2019-04-24 18:52:56 --> Config Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:52:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:52:56 --> URI Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Router Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Output Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Security Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Input Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:52:56 --> Language Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Loader Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Controller Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Session Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:52:56 --> Session routines successfully run
DEBUG - 2019-04-24 18:52:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Model Class Initialized
DEBUG - 2019-04-24 18:52:56 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:52:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:52:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:52:56 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:52:56 --> Final output sent to browser
DEBUG - 2019-04-24 18:52:56 --> Total execution time: 0.0806
DEBUG - 2019-04-24 18:53:04 --> Config Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:53:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:53:04 --> URI Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Router Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Output Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Security Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Input Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:53:04 --> Language Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Loader Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Controller Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Session Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:53:04 --> Session routines successfully run
DEBUG - 2019-04-24 18:53:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:04 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:53:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:53:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:53:04 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:53:04 --> Final output sent to browser
DEBUG - 2019-04-24 18:53:04 --> Total execution time: 0.0934
DEBUG - 2019-04-24 18:53:36 --> Config Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:53:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:53:36 --> URI Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Router Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Output Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Security Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Input Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:53:36 --> Language Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Loader Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Controller Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Session Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:53:36 --> Session routines successfully run
DEBUG - 2019-04-24 18:53:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Model Class Initialized
DEBUG - 2019-04-24 18:53:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:53:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:53:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:53:36 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:53:36 --> Final output sent to browser
DEBUG - 2019-04-24 18:53:36 --> Total execution time: 0.0918
DEBUG - 2019-04-24 18:55:25 --> Config Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:55:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:55:25 --> URI Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Router Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Output Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Security Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Input Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:55:25 --> Language Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Loader Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Controller Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Session Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:55:25 --> Session routines successfully run
DEBUG - 2019-04-24 18:55:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:25 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:55:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:55:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:55:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:55:25 --> Final output sent to browser
DEBUG - 2019-04-24 18:55:25 --> Total execution time: 0.0972
DEBUG - 2019-04-24 18:55:54 --> Config Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:55:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:55:54 --> URI Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Router Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Output Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Security Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Input Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:55:54 --> Language Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Loader Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Controller Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Session Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:55:54 --> Session routines successfully run
DEBUG - 2019-04-24 18:55:54 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Model Class Initialized
DEBUG - 2019-04-24 18:55:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:55:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:55:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:55:54 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:55:54 --> Final output sent to browser
DEBUG - 2019-04-24 18:55:54 --> Total execution time: 0.1251
DEBUG - 2019-04-24 18:56:15 --> Config Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:56:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:56:15 --> URI Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Router Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Output Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Security Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Input Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:56:15 --> Language Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Loader Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Controller Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Session Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:56:15 --> Session routines successfully run
DEBUG - 2019-04-24 18:56:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:56:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:56:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:56:15 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:56:15 --> Final output sent to browser
DEBUG - 2019-04-24 18:56:15 --> Total execution time: 0.0922
DEBUG - 2019-04-24 18:56:16 --> Config Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:56:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:56:16 --> URI Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Router Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Output Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Security Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Input Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:56:16 --> Language Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Loader Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Controller Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Session Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:56:16 --> Session routines successfully run
DEBUG - 2019-04-24 18:56:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:56:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:56:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:56:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:56:16 --> Final output sent to browser
DEBUG - 2019-04-24 18:56:16 --> Total execution time: 0.1229
DEBUG - 2019-04-24 18:56:24 --> Config Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:56:24 --> URI Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Router Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Output Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Security Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Input Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:56:24 --> Language Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Loader Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Controller Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Session Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:56:24 --> Session routines successfully run
DEBUG - 2019-04-24 18:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Model Class Initialized
DEBUG - 2019-04-24 18:56:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:56:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:56:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:56:24 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:56:24 --> Final output sent to browser
DEBUG - 2019-04-24 18:56:24 --> Total execution time: 0.0807
DEBUG - 2019-04-24 18:57:11 --> Config Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:57:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:57:11 --> URI Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Router Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Output Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Security Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Input Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:57:11 --> Language Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Loader Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Controller Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Session Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:57:11 --> Session routines successfully run
DEBUG - 2019-04-24 18:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Model Class Initialized
DEBUG - 2019-04-24 18:57:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:57:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:57:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:57:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:57:11 --> Final output sent to browser
DEBUG - 2019-04-24 18:57:11 --> Total execution time: 0.0793
DEBUG - 2019-04-24 18:58:26 --> Config Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:58:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:58:26 --> URI Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Router Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Output Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Security Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Input Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:58:26 --> Language Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Loader Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Controller Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Session Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:58:26 --> Session routines successfully run
DEBUG - 2019-04-24 18:58:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Model Class Initialized
DEBUG - 2019-04-24 18:58:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:58:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:58:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:58:26 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:58:26 --> Final output sent to browser
DEBUG - 2019-04-24 18:58:26 --> Total execution time: 0.1995
DEBUG - 2019-04-24 18:59:06 --> Config Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:59:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:59:06 --> URI Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Router Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Output Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Security Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Input Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:59:06 --> Language Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Loader Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Controller Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Session Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:59:06 --> Session routines successfully run
DEBUG - 2019-04-24 18:59:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:06 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:59:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:59:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:59:06 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:59:06 --> Final output sent to browser
DEBUG - 2019-04-24 18:59:06 --> Total execution time: 0.1082
DEBUG - 2019-04-24 18:59:32 --> Config Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:59:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:59:32 --> URI Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Router Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Output Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Security Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Input Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:59:32 --> Language Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Loader Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Controller Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Session Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:59:32 --> Session routines successfully run
DEBUG - 2019-04-24 18:59:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:59:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:59:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:59:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:59:32 --> Final output sent to browser
DEBUG - 2019-04-24 18:59:32 --> Total execution time: 0.1110
DEBUG - 2019-04-24 18:59:46 --> Config Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:59:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:59:46 --> URI Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Router Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Output Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Security Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Input Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:59:46 --> Language Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Loader Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Controller Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Session Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:59:46 --> Session routines successfully run
DEBUG - 2019-04-24 18:59:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:59:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:59:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:59:46 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:59:46 --> Final output sent to browser
DEBUG - 2019-04-24 18:59:46 --> Total execution time: 0.1216
DEBUG - 2019-04-24 18:59:59 --> Config Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 18:59:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 18:59:59 --> URI Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Router Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Output Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Security Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Input Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 18:59:59 --> Language Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Loader Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Controller Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Session Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 18:59:59 --> Session routines successfully run
DEBUG - 2019-04-24 18:59:59 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Model Class Initialized
DEBUG - 2019-04-24 18:59:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 18:59:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 18:59:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 18:59:59 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 18:59:59 --> Final output sent to browser
DEBUG - 2019-04-24 18:59:59 --> Total execution time: 0.1283
DEBUG - 2019-04-24 19:00:09 --> Config Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:00:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:00:09 --> URI Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Router Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Output Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Security Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Input Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:00:09 --> Language Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Loader Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Controller Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Session Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:00:09 --> Session routines successfully run
DEBUG - 2019-04-24 19:00:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:00:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:00:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:00:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:00:09 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:00:09 --> Final output sent to browser
DEBUG - 2019-04-24 19:00:09 --> Total execution time: 0.1014
DEBUG - 2019-04-24 19:05:39 --> Config Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:05:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:05:39 --> URI Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Router Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Output Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Security Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Input Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:05:39 --> Language Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Loader Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Controller Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Session Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:05:39 --> Session routines successfully run
DEBUG - 2019-04-24 19:05:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:05:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:05:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:05:39 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:05:39 --> Final output sent to browser
DEBUG - 2019-04-24 19:05:39 --> Total execution time: 0.1674
DEBUG - 2019-04-24 19:05:41 --> Config Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:05:41 --> URI Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Router Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Output Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Security Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Input Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:05:41 --> Language Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Loader Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Controller Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Session Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:05:41 --> Session garbage collection performed.
DEBUG - 2019-04-24 19:05:41 --> Session routines successfully run
DEBUG - 2019-04-24 19:05:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:05:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:05:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:05:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:05:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:05:41 --> Final output sent to browser
DEBUG - 2019-04-24 19:05:41 --> Total execution time: 0.0712
DEBUG - 2019-04-24 19:06:07 --> Config Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:06:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:06:07 --> URI Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Router Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Output Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Security Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Input Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:06:07 --> Language Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Loader Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Controller Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Session Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:06:07 --> Session routines successfully run
DEBUG - 2019-04-24 19:06:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:06:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:06:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:06:07 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:06:07 --> Final output sent to browser
DEBUG - 2019-04-24 19:06:07 --> Total execution time: 0.0931
DEBUG - 2019-04-24 19:06:34 --> Config Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:06:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:06:34 --> URI Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Router Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Output Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Security Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Input Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:06:34 --> Language Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Loader Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Controller Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Session Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:06:34 --> Session garbage collection performed.
DEBUG - 2019-04-24 19:06:34 --> Session routines successfully run
DEBUG - 2019-04-24 19:06:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:34 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:06:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:06:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:06:34 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:06:34 --> Final output sent to browser
DEBUG - 2019-04-24 19:06:34 --> Total execution time: 0.1222
DEBUG - 2019-04-24 19:06:51 --> Config Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:06:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:06:51 --> URI Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Router Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Output Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Security Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Input Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:06:51 --> Language Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Loader Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Controller Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Session Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:06:51 --> Session routines successfully run
DEBUG - 2019-04-24 19:06:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:06:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:06:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:06:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:06:51 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:06:51 --> Final output sent to browser
DEBUG - 2019-04-24 19:06:51 --> Total execution time: 0.0977
DEBUG - 2019-04-24 19:07:32 --> Config Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:07:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:07:32 --> URI Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Router Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Output Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Security Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Input Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:07:32 --> Language Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Loader Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Controller Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Session Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:07:32 --> Session routines successfully run
DEBUG - 2019-04-24 19:07:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:07:32 --> File loaded: application/views/header.php
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
ERROR - 2019-04-24 19:07:32 --> Severity: Notice  --> Undefined index: UserID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\usersHomePage.php 28
DEBUG - 2019-04-24 19:07:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:07:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:07:32 --> Final output sent to browser
DEBUG - 2019-04-24 19:07:32 --> Total execution time: 0.0951
DEBUG - 2019-04-24 19:07:46 --> Config Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:07:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:07:46 --> URI Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Router Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Output Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Security Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Input Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:07:46 --> Language Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Loader Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Controller Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Session Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:07:46 --> Session routines successfully run
DEBUG - 2019-04-24 19:07:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:07:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:07:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:07:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:07:47 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:07:47 --> Final output sent to browser
DEBUG - 2019-04-24 19:07:47 --> Total execution time: 0.0969
DEBUG - 2019-04-24 19:08:22 --> Config Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:08:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:08:22 --> URI Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Router Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Output Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Security Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Input Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:08:22 --> Language Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Loader Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Controller Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Session Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:08:22 --> Session routines successfully run
DEBUG - 2019-04-24 19:08:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:08:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:08:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:08:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:08:22 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:08:22 --> Final output sent to browser
DEBUG - 2019-04-24 19:08:22 --> Total execution time: 0.1158
DEBUG - 2019-04-24 19:09:10 --> Config Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:09:10 --> URI Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Router Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Output Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Security Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Input Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:09:10 --> Language Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Loader Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Controller Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Session Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:09:10 --> Session routines successfully run
DEBUG - 2019-04-24 19:09:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:09:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:09:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:09:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:09:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:09:11 --> Final output sent to browser
DEBUG - 2019-04-24 19:09:11 --> Total execution time: 0.1279
DEBUG - 2019-04-24 19:10:08 --> Config Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:10:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:10:08 --> URI Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Router Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Output Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Security Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Input Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:10:08 --> Language Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Loader Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Controller Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Model Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Model Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Session Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:10:08 --> Session routines successfully run
DEBUG - 2019-04-24 19:10:08 --> Model Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Model Class Initialized
DEBUG - 2019-04-24 19:10:08 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:10:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:10:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:10:08 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:10:08 --> Final output sent to browser
DEBUG - 2019-04-24 19:10:08 --> Total execution time: 0.1939
DEBUG - 2019-04-24 19:11:58 --> Config Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:11:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:11:58 --> URI Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Router Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Output Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Security Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Input Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:11:58 --> Language Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Loader Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Controller Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Model Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Model Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Session Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:11:58 --> Session routines successfully run
DEBUG - 2019-04-24 19:11:58 --> Model Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Model Class Initialized
DEBUG - 2019-04-24 19:11:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:11:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:11:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:11:58 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:11:58 --> Final output sent to browser
DEBUG - 2019-04-24 19:11:58 --> Total execution time: 0.1698
DEBUG - 2019-04-24 19:12:11 --> Config Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:12:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:12:11 --> URI Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Router Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Output Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Security Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Input Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:12:11 --> Language Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Loader Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Controller Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Session Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:12:11 --> Session routines successfully run
DEBUG - 2019-04-24 19:12:11 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:12:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:12:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:12:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:12:11 --> Final output sent to browser
DEBUG - 2019-04-24 19:12:11 --> Total execution time: 0.1340
DEBUG - 2019-04-24 19:12:25 --> Config Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:12:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:12:25 --> URI Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Router Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Output Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Security Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Input Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:12:25 --> Language Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Loader Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Controller Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Session Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:12:25 --> Session routines successfully run
DEBUG - 2019-04-24 19:12:25 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Model Class Initialized
DEBUG - 2019-04-24 19:12:25 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:12:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:12:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:12:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:12:25 --> Final output sent to browser
DEBUG - 2019-04-24 19:12:25 --> Total execution time: 0.0976
DEBUG - 2019-04-24 19:13:20 --> Config Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:13:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:13:20 --> URI Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Router Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Output Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Security Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Input Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:13:20 --> Language Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Loader Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Controller Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Session Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:13:20 --> Session routines successfully run
DEBUG - 2019-04-24 19:13:20 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:13:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:13:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:13:20 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:13:20 --> Final output sent to browser
DEBUG - 2019-04-24 19:13:20 --> Total execution time: 0.1010
DEBUG - 2019-04-24 19:13:38 --> Config Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:13:38 --> URI Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Router Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Output Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Security Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Input Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:13:38 --> Language Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Loader Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Controller Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Session Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:13:38 --> Session routines successfully run
DEBUG - 2019-04-24 19:13:38 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Model Class Initialized
DEBUG - 2019-04-24 19:13:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:13:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:13:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:13:38 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:13:38 --> Final output sent to browser
DEBUG - 2019-04-24 19:13:38 --> Total execution time: 0.0885
DEBUG - 2019-04-24 19:14:14 --> Config Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:14:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:14:14 --> URI Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Router Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Output Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Security Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Input Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:14:14 --> Language Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Loader Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Controller Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Session Class Initialized
DEBUG - 2019-04-24 19:14:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:14:14 --> Session routines successfully run
DEBUG - 2019-04-24 19:14:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:14:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:14:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:14:14 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:14:14 --> Final output sent to browser
DEBUG - 2019-04-24 19:14:14 --> Total execution time: 0.0725
DEBUG - 2019-04-24 19:15:14 --> Config Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:15:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:15:14 --> URI Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Router Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Output Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Security Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Input Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:15:14 --> Language Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Loader Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Controller Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Session Class Initialized
DEBUG - 2019-04-24 19:15:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:15:14 --> Session routines successfully run
DEBUG - 2019-04-24 19:15:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:15:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:15:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:15:14 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:15:14 --> Final output sent to browser
DEBUG - 2019-04-24 19:15:14 --> Total execution time: 0.0659
DEBUG - 2019-04-24 19:15:30 --> Config Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:15:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:15:30 --> URI Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Router Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Output Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Security Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Input Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:15:30 --> Language Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Loader Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Controller Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Session Class Initialized
DEBUG - 2019-04-24 19:15:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:15:30 --> Session routines successfully run
DEBUG - 2019-04-24 19:15:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:15:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:15:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:15:30 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:15:30 --> Final output sent to browser
DEBUG - 2019-04-24 19:15:30 --> Total execution time: 0.0574
DEBUG - 2019-04-24 19:15:34 --> Config Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:15:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:15:34 --> URI Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Router Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Output Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Security Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Input Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:15:34 --> Language Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Loader Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Controller Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Model Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Session Class Initialized
DEBUG - 2019-04-24 19:15:34 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:15:34 --> Session routines successfully run
DEBUG - 2019-04-24 19:15:34 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:15:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:15:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:15:34 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:15:34 --> Final output sent to browser
DEBUG - 2019-04-24 19:15:34 --> Total execution time: 0.0733
DEBUG - 2019-04-24 19:18:02 --> Config Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:18:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:18:02 --> URI Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Router Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Output Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Security Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Input Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:18:02 --> Language Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Loader Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Controller Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Session Class Initialized
DEBUG - 2019-04-24 19:18:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:18:02 --> Session routines successfully run
DEBUG - 2019-04-24 19:18:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:18:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:18:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:18:02 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:18:02 --> Final output sent to browser
DEBUG - 2019-04-24 19:18:02 --> Total execution time: 0.1126
DEBUG - 2019-04-24 19:18:31 --> Config Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:18:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:18:31 --> URI Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Router Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Output Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Security Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Input Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:18:31 --> Language Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Loader Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Controller Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Session Class Initialized
DEBUG - 2019-04-24 19:18:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:18:31 --> Session garbage collection performed.
DEBUG - 2019-04-24 19:18:31 --> Session routines successfully run
DEBUG - 2019-04-24 19:18:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:18:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:18:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:18:31 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:18:31 --> Final output sent to browser
DEBUG - 2019-04-24 19:18:31 --> Total execution time: 0.1133
DEBUG - 2019-04-24 19:19:47 --> Config Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:19:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:19:47 --> URI Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Router Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Output Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Security Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Input Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:19:47 --> Language Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Loader Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Controller Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Model Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Model Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Model Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Session Class Initialized
DEBUG - 2019-04-24 19:19:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:19:47 --> Session routines successfully run
DEBUG - 2019-04-24 19:19:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:19:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:19:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:19:47 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:19:47 --> Final output sent to browser
DEBUG - 2019-04-24 19:19:47 --> Total execution time: 0.0638
DEBUG - 2019-04-24 19:28:07 --> Config Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:28:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:28:07 --> URI Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Router Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Output Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Security Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Input Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:28:07 --> Language Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Loader Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Controller Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Session Class Initialized
DEBUG - 2019-04-24 19:28:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:28:07 --> Session routines successfully run
DEBUG - 2019-04-24 19:28:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:28:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:28:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:28:07 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:28:07 --> Final output sent to browser
DEBUG - 2019-04-24 19:28:07 --> Total execution time: 0.1238
DEBUG - 2019-04-24 19:28:10 --> Config Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:28:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:28:10 --> URI Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Router Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Output Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Security Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Input Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:28:10 --> Language Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Loader Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Controller Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Session Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:28:10 --> Session routines successfully run
DEBUG - 2019-04-24 19:28:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:28:10 --> Upload Class Initialized
DEBUG - 2019-04-24 19:28:10 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-24 19:28:10 --> The upload path does not appear to be valid.
DEBUG - 2019-04-24 19:28:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:28:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:28:10 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-24 19:28:52 --> Config Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:28:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:28:52 --> URI Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Router Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Output Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Security Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Input Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:28:52 --> Language Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Loader Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Controller Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Session Class Initialized
DEBUG - 2019-04-24 19:28:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:28:52 --> Session routines successfully run
DEBUG - 2019-04-24 19:28:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:28:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:28:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:28:52 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:28:52 --> Final output sent to browser
DEBUG - 2019-04-24 19:28:52 --> Total execution time: 0.0406
DEBUG - 2019-04-24 19:30:57 --> Config Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:30:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:30:57 --> URI Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Router Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Output Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Security Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Input Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:30:57 --> Language Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Loader Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Controller Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Model Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Model Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Model Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Session Class Initialized
DEBUG - 2019-04-24 19:30:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:30:57 --> Session routines successfully run
DEBUG - 2019-04-24 19:30:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:30:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:30:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:30:57 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:30:57 --> Final output sent to browser
DEBUG - 2019-04-24 19:30:57 --> Total execution time: 0.0695
DEBUG - 2019-04-24 19:33:12 --> Config Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:33:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:33:12 --> URI Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Router Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Output Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Security Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Input Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:33:12 --> Language Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Loader Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Controller Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Session Class Initialized
DEBUG - 2019-04-24 19:33:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:33:12 --> Session routines successfully run
DEBUG - 2019-04-24 19:33:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:33:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:33:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:33:12 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:33:12 --> Final output sent to browser
DEBUG - 2019-04-24 19:33:12 --> Total execution time: 0.1052
DEBUG - 2019-04-24 19:34:14 --> Config Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:34:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:34:14 --> URI Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Router Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Output Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Security Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Input Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:34:14 --> Language Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Loader Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Controller Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Model Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Session Class Initialized
DEBUG - 2019-04-24 19:34:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:34:14 --> Session routines successfully run
DEBUG - 2019-04-24 19:34:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:34:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:34:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:34:14 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:34:14 --> Final output sent to browser
DEBUG - 2019-04-24 19:34:14 --> Total execution time: 0.0539
DEBUG - 2019-04-24 19:35:39 --> Config Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:35:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:35:39 --> URI Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Router Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Output Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Security Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Input Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:35:39 --> Language Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Loader Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Controller Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Session Class Initialized
DEBUG - 2019-04-24 19:35:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:35:39 --> Session routines successfully run
DEBUG - 2019-04-24 19:35:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:35:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:35:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:35:39 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:35:39 --> Final output sent to browser
DEBUG - 2019-04-24 19:35:39 --> Total execution time: 0.0616
DEBUG - 2019-04-24 19:36:41 --> Config Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:36:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:36:41 --> URI Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Router Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Output Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Security Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Input Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:36:41 --> Language Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Loader Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Controller Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Session Class Initialized
DEBUG - 2019-04-24 19:36:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:36:41 --> Session routines successfully run
DEBUG - 2019-04-24 19:36:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:36:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:36:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:36:41 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:36:41 --> Final output sent to browser
DEBUG - 2019-04-24 19:36:41 --> Total execution time: 0.0637
DEBUG - 2019-04-24 19:37:31 --> Config Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:37:31 --> URI Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Router Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Output Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Security Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Input Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:37:31 --> Language Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Loader Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Controller Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Session Class Initialized
DEBUG - 2019-04-24 19:37:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:37:31 --> Session routines successfully run
DEBUG - 2019-04-24 19:37:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:37:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:37:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:37:31 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:37:31 --> Final output sent to browser
DEBUG - 2019-04-24 19:37:31 --> Total execution time: 0.0490
DEBUG - 2019-04-24 19:37:51 --> Config Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:37:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:37:51 --> URI Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Router Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Output Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Security Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Input Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:37:51 --> Language Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Loader Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Controller Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Session Class Initialized
DEBUG - 2019-04-24 19:37:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:37:51 --> Session routines successfully run
DEBUG - 2019-04-24 19:37:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:37:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:37:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:37:51 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:37:51 --> Final output sent to browser
DEBUG - 2019-04-24 19:37:51 --> Total execution time: 0.0592
DEBUG - 2019-04-24 19:38:37 --> Config Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:38:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:38:37 --> URI Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Router Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Output Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Security Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Input Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:38:37 --> Language Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Loader Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Controller Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Model Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Model Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Model Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Session Class Initialized
DEBUG - 2019-04-24 19:38:37 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:38:37 --> Session routines successfully run
DEBUG - 2019-04-24 19:38:37 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:38:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:38:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:38:37 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:38:37 --> Final output sent to browser
DEBUG - 2019-04-24 19:38:37 --> Total execution time: 0.1338
DEBUG - 2019-04-24 19:40:31 --> Config Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:40:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:40:31 --> URI Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Router Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Output Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Security Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Input Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:40:31 --> Language Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Loader Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Controller Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Session Class Initialized
DEBUG - 2019-04-24 19:40:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:40:31 --> Session routines successfully run
DEBUG - 2019-04-24 19:40:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:40:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:40:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:40:31 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:40:31 --> Final output sent to browser
DEBUG - 2019-04-24 19:40:31 --> Total execution time: 0.0766
DEBUG - 2019-04-24 19:40:50 --> Config Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:40:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:40:50 --> URI Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Router Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Output Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Security Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Input Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:40:50 --> Language Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Loader Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Controller Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Session Class Initialized
DEBUG - 2019-04-24 19:40:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:40:50 --> Session routines successfully run
DEBUG - 2019-04-24 19:40:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:40:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:40:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:40:50 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:40:50 --> Final output sent to browser
DEBUG - 2019-04-24 19:40:50 --> Total execution time: 0.0666
DEBUG - 2019-04-24 19:41:01 --> Config Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:41:01 --> URI Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Router Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Output Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Security Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Input Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:41:01 --> Language Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Loader Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Controller Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Session Class Initialized
DEBUG - 2019-04-24 19:41:01 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:41:01 --> Session routines successfully run
DEBUG - 2019-04-24 19:41:01 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:41:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:41:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:41:01 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:41:01 --> Final output sent to browser
DEBUG - 2019-04-24 19:41:01 --> Total execution time: 0.0436
DEBUG - 2019-04-24 19:41:17 --> Config Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:41:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:41:17 --> URI Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Router Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Output Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Security Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Input Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:41:17 --> Language Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Loader Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Controller Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Model Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Session Class Initialized
DEBUG - 2019-04-24 19:41:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:41:17 --> Session garbage collection performed.
DEBUG - 2019-04-24 19:41:17 --> Session routines successfully run
DEBUG - 2019-04-24 19:41:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:41:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:41:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:41:17 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:41:17 --> Final output sent to browser
DEBUG - 2019-04-24 19:41:17 --> Total execution time: 0.0840
DEBUG - 2019-04-24 19:42:09 --> Config Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:42:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:42:09 --> URI Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Router Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Output Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Security Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Input Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:42:09 --> Language Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Loader Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Controller Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Session Class Initialized
DEBUG - 2019-04-24 19:42:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:42:09 --> Session routines successfully run
DEBUG - 2019-04-24 19:42:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:42:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:42:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:42:09 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:42:09 --> Final output sent to browser
DEBUG - 2019-04-24 19:42:09 --> Total execution time: 0.0469
DEBUG - 2019-04-24 19:42:51 --> Config Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:42:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:42:51 --> URI Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Router Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Output Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Security Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Input Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:42:51 --> Language Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Loader Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Controller Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Session Class Initialized
DEBUG - 2019-04-24 19:42:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:42:51 --> Session routines successfully run
DEBUG - 2019-04-24 19:42:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:42:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:42:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:42:51 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:42:51 --> Final output sent to browser
DEBUG - 2019-04-24 19:42:51 --> Total execution time: 0.0455
DEBUG - 2019-04-24 19:42:52 --> Config Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:42:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:42:52 --> URI Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Router Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Output Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Security Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Input Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:42:52 --> Language Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Loader Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Controller Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Model Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Session Class Initialized
DEBUG - 2019-04-24 19:42:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:42:52 --> Session routines successfully run
DEBUG - 2019-04-24 19:42:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:42:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:42:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:42:52 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:42:52 --> Final output sent to browser
DEBUG - 2019-04-24 19:42:52 --> Total execution time: 0.0680
DEBUG - 2019-04-24 19:43:15 --> Config Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:43:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:43:15 --> URI Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Router Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Output Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Security Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Input Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:43:15 --> Language Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Loader Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Controller Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Session Class Initialized
DEBUG - 2019-04-24 19:43:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:43:15 --> Session routines successfully run
DEBUG - 2019-04-24 19:43:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:43:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:43:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:43:15 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:43:15 --> Final output sent to browser
DEBUG - 2019-04-24 19:43:15 --> Total execution time: 0.0748
DEBUG - 2019-04-24 19:43:16 --> Config Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:43:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:43:16 --> URI Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Router Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Output Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Security Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Input Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:43:16 --> Language Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Loader Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Controller Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Session Class Initialized
DEBUG - 2019-04-24 19:43:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:43:16 --> Session routines successfully run
DEBUG - 2019-04-24 19:43:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:43:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:43:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:43:16 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:43:16 --> Final output sent to browser
DEBUG - 2019-04-24 19:43:16 --> Total execution time: 0.0463
DEBUG - 2019-04-24 19:43:26 --> Config Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:43:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:43:26 --> URI Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Router Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Output Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Security Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Input Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:43:26 --> Language Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Loader Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Controller Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Session Class Initialized
DEBUG - 2019-04-24 19:43:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:43:26 --> Session routines successfully run
DEBUG - 2019-04-24 19:43:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:43:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:43:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:43:26 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:43:26 --> Final output sent to browser
DEBUG - 2019-04-24 19:43:26 --> Total execution time: 0.0741
DEBUG - 2019-04-24 19:43:41 --> Config Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:43:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:43:41 --> URI Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Router Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Output Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Security Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Input Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:43:41 --> Language Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Loader Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Controller Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Session Class Initialized
DEBUG - 2019-04-24 19:43:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:43:41 --> Session routines successfully run
DEBUG - 2019-04-24 19:43:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:43:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:43:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:43:41 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:43:41 --> Final output sent to browser
DEBUG - 2019-04-24 19:43:41 --> Total execution time: 0.1084
DEBUG - 2019-04-24 19:43:44 --> Config Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:43:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:43:44 --> URI Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Router Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Output Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Security Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Input Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:43:44 --> Language Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Loader Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Controller Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Model Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Session Class Initialized
DEBUG - 2019-04-24 19:43:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:43:44 --> Session routines successfully run
DEBUG - 2019-04-24 19:43:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:43:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:43:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:43:44 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:43:44 --> Final output sent to browser
DEBUG - 2019-04-24 19:43:44 --> Total execution time: 0.0569
DEBUG - 2019-04-24 19:45:24 --> Config Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:45:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:45:24 --> URI Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Router Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Output Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Security Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Input Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:45:24 --> Language Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Loader Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Controller Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Session Class Initialized
DEBUG - 2019-04-24 19:45:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:45:24 --> Session routines successfully run
DEBUG - 2019-04-24 19:45:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:45:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:45:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:45:24 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:45:24 --> Final output sent to browser
DEBUG - 2019-04-24 19:45:24 --> Total execution time: 0.0554
DEBUG - 2019-04-24 19:47:39 --> Config Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:47:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:47:39 --> URI Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Router Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Output Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Security Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Input Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:47:39 --> Language Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Loader Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Controller Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Session Class Initialized
DEBUG - 2019-04-24 19:47:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:47:39 --> Session routines successfully run
DEBUG - 2019-04-24 19:47:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:47:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:47:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:47:39 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:47:39 --> Final output sent to browser
DEBUG - 2019-04-24 19:47:39 --> Total execution time: 0.0674
DEBUG - 2019-04-24 19:47:49 --> Config Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:47:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:47:49 --> URI Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Router Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Output Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Security Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Input Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:47:49 --> Language Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Loader Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Controller Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Session Class Initialized
DEBUG - 2019-04-24 19:47:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:47:49 --> Session routines successfully run
DEBUG - 2019-04-24 19:47:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:47:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:47:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:47:49 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:47:49 --> Final output sent to browser
DEBUG - 2019-04-24 19:47:49 --> Total execution time: 0.0625
DEBUG - 2019-04-24 19:47:51 --> Config Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:47:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:47:51 --> URI Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Router Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Output Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Security Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Input Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:47:51 --> Language Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Loader Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Controller Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Model Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Session Class Initialized
DEBUG - 2019-04-24 19:47:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:47:51 --> Session routines successfully run
DEBUG - 2019-04-24 19:47:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:47:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:47:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:47:51 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:47:51 --> Final output sent to browser
DEBUG - 2019-04-24 19:47:51 --> Total execution time: 0.0602
DEBUG - 2019-04-24 19:48:02 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:02 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:02 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:02 --> A session cookie was not found.
DEBUG - 2019-04-24 19:48:02 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:02 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 19:48:02 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:02 --> Total execution time: 0.2807
DEBUG - 2019-04-24 19:48:12 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:12 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:12 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:12 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:12 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 19:48:12 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:12 --> Total execution time: 0.0446
DEBUG - 2019-04-24 19:48:22 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:22 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:22 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:22 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:22 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:48:22 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:22 --> Total execution time: 0.1961
DEBUG - 2019-04-24 19:48:28 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:28 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:28 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:28 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:28 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:28 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:48:28 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:28 --> Total execution time: 0.1119
DEBUG - 2019-04-24 19:48:30 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:30 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:30 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:30 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:30 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:30 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:30 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:30 --> A session cookie was not found.
DEBUG - 2019-04-24 19:48:30 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 19:48:30 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:30 --> Total execution time: 0.1798
DEBUG - 2019-04-24 19:48:32 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:32 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:32 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:32 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:32 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 19:48:32 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:32 --> Total execution time: 0.0560
DEBUG - 2019-04-24 19:48:42 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:42 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:42 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:42 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:42 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:43 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 19:48:43 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:43 --> Total execution time: 0.2201
DEBUG - 2019-04-24 19:48:46 --> Config Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:48:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:48:46 --> URI Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Router Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Output Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Security Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Input Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:48:46 --> Language Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Loader Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Controller Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Model Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Session Class Initialized
DEBUG - 2019-04-24 19:48:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:48:46 --> Session routines successfully run
DEBUG - 2019-04-24 19:48:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:48:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:48:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:48:46 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 19:48:46 --> Final output sent to browser
DEBUG - 2019-04-24 19:48:46 --> Total execution time: 0.0547
DEBUG - 2019-04-24 19:51:50 --> Config Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:51:50 --> URI Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Router Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Output Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Security Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Input Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:51:50 --> Language Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Loader Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Controller Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Session Class Initialized
DEBUG - 2019-04-24 19:51:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:51:50 --> Session routines successfully run
DEBUG - 2019-04-24 19:51:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:51:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:51:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:51:50 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 19:51:50 --> Final output sent to browser
DEBUG - 2019-04-24 19:51:50 --> Total execution time: 0.0611
DEBUG - 2019-04-24 19:51:54 --> Config Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:51:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:51:54 --> URI Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Router Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Output Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Security Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Input Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:51:54 --> Language Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Loader Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Controller Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Model Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Session Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:51:54 --> Session routines successfully run
DEBUG - 2019-04-24 19:51:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:51:54 --> Upload Class Initialized
DEBUG - 2019-04-24 19:51:54 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-24 19:51:54 --> The upload path does not appear to be valid.
DEBUG - 2019-04-24 19:51:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:51:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:51:54 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-24 19:57:24 --> Config Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:57:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:57:24 --> URI Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Router Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Output Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Security Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Input Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:57:24 --> Language Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Loader Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Controller Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Model Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Session Class Initialized
DEBUG - 2019-04-24 19:57:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:57:24 --> Session routines successfully run
DEBUG - 2019-04-24 19:57:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:57:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:57:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:57:24 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 19:57:24 --> Final output sent to browser
DEBUG - 2019-04-24 19:57:24 --> Total execution time: 0.1202
DEBUG - 2019-04-24 19:58:31 --> Config Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 19:58:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 19:58:31 --> URI Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Router Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Output Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Security Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Input Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 19:58:31 --> Language Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Loader Class Initialized
DEBUG - 2019-04-24 19:58:31 --> Controller Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Model Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Session Class Initialized
DEBUG - 2019-04-24 19:58:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 19:58:32 --> Session routines successfully run
DEBUG - 2019-04-24 19:58:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 19:58:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 19:58:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 19:58:32 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 19:58:32 --> Final output sent to browser
DEBUG - 2019-04-24 19:58:32 --> Total execution time: 0.0507
DEBUG - 2019-04-24 20:18:43 --> Config Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:18:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:18:43 --> URI Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Router Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Output Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Security Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Input Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:18:43 --> Language Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Loader Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Controller Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Session Class Initialized
DEBUG - 2019-04-24 20:18:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:18:43 --> Session routines successfully run
DEBUG - 2019-04-24 20:18:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:18:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:18:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:18:43 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:18:43 --> Final output sent to browser
DEBUG - 2019-04-24 20:18:43 --> Total execution time: 0.1309
DEBUG - 2019-04-24 20:18:58 --> Config Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:18:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:18:58 --> URI Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Router Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Output Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Security Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Input Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:18:58 --> Language Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Loader Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Controller Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Session Class Initialized
DEBUG - 2019-04-24 20:18:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:18:58 --> Session routines successfully run
DEBUG - 2019-04-24 20:18:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:18:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:18:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:18:58 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:18:58 --> Final output sent to browser
DEBUG - 2019-04-24 20:18:58 --> Total execution time: 0.0803
DEBUG - 2019-04-24 20:19:26 --> Config Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:19:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:19:26 --> URI Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Router Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Output Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Security Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Input Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:19:26 --> Language Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Loader Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Controller Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Model Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Model Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Model Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Session Class Initialized
DEBUG - 2019-04-24 20:19:26 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:19:26 --> Session routines successfully run
DEBUG - 2019-04-24 20:19:26 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:19:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:19:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:19:26 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:19:26 --> Final output sent to browser
DEBUG - 2019-04-24 20:19:26 --> Total execution time: 0.0568
DEBUG - 2019-04-24 20:23:20 --> Config Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:23:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:23:20 --> URI Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Router Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Output Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Security Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Input Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:23:20 --> Language Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Loader Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Controller Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Session Class Initialized
DEBUG - 2019-04-24 20:23:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:23:20 --> Session routines successfully run
DEBUG - 2019-04-24 20:23:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:23:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:23:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:23:20 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:23:20 --> Final output sent to browser
DEBUG - 2019-04-24 20:23:20 --> Total execution time: 0.0576
DEBUG - 2019-04-24 20:23:50 --> Config Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:23:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:23:50 --> URI Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Router Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Output Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Security Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Input Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:23:50 --> Language Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Loader Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Controller Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Model Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Session Class Initialized
DEBUG - 2019-04-24 20:23:50 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:23:50 --> Session routines successfully run
DEBUG - 2019-04-24 20:23:50 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:23:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:23:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:23:50 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:23:50 --> Final output sent to browser
DEBUG - 2019-04-24 20:23:50 --> Total execution time: 0.1000
DEBUG - 2019-04-24 20:25:31 --> Config Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:25:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:25:31 --> URI Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Router Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Output Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Security Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Input Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:25:31 --> Language Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Loader Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Controller Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Model Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Model Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Model Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Session Class Initialized
DEBUG - 2019-04-24 20:25:31 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:25:31 --> Session routines successfully run
DEBUG - 2019-04-24 20:25:31 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:25:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:25:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:25:31 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:25:31 --> Final output sent to browser
DEBUG - 2019-04-24 20:25:31 --> Total execution time: 0.0471
DEBUG - 2019-04-24 20:27:47 --> Config Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:27:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:27:47 --> URI Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Router Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Output Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Security Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Input Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:27:47 --> Language Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Loader Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Controller Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Model Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Model Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Model Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Session Class Initialized
DEBUG - 2019-04-24 20:27:47 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:27:47 --> Session routines successfully run
DEBUG - 2019-04-24 20:27:47 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:27:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:27:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:27:47 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:27:47 --> Final output sent to browser
DEBUG - 2019-04-24 20:27:47 --> Total execution time: 0.0572
DEBUG - 2019-04-24 20:28:15 --> Config Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:28:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:28:15 --> URI Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Router Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Output Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Security Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Input Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:28:15 --> Language Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Loader Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Controller Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Session Class Initialized
DEBUG - 2019-04-24 20:28:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:28:15 --> Session routines successfully run
DEBUG - 2019-04-24 20:28:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:28:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:28:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:28:15 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:28:15 --> Final output sent to browser
DEBUG - 2019-04-24 20:28:15 --> Total execution time: 0.0599
DEBUG - 2019-04-24 20:30:17 --> Config Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:30:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:30:17 --> URI Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Router Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Output Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Security Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Input Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:30:17 --> Language Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Loader Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Controller Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Session Class Initialized
DEBUG - 2019-04-24 20:30:17 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:30:17 --> Session routines successfully run
DEBUG - 2019-04-24 20:30:17 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:30:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:30:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:30:17 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:30:17 --> Final output sent to browser
DEBUG - 2019-04-24 20:30:17 --> Total execution time: 0.1457
DEBUG - 2019-04-24 20:30:45 --> Config Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:30:45 --> URI Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Router Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Output Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Security Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Input Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:30:45 --> Language Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Loader Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Controller Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Session Class Initialized
DEBUG - 2019-04-24 20:30:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:30:45 --> Session routines successfully run
DEBUG - 2019-04-24 20:30:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:30:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:30:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:30:45 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:30:45 --> Final output sent to browser
DEBUG - 2019-04-24 20:30:45 --> Total execution time: 0.0632
DEBUG - 2019-04-24 20:31:08 --> Config Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:31:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:31:08 --> URI Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Router Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Output Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Security Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Input Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:31:08 --> Language Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Loader Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Controller Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:08 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:31:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:09 --> Session Class Initialized
DEBUG - 2019-04-24 20:31:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:31:09 --> Session routines successfully run
DEBUG - 2019-04-24 20:31:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:31:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:31:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:31:09 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:31:09 --> Final output sent to browser
DEBUG - 2019-04-24 20:31:09 --> Total execution time: 0.0620
DEBUG - 2019-04-24 20:31:36 --> Config Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:31:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:31:36 --> URI Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Router Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Output Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Security Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Input Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:31:36 --> Language Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Loader Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Controller Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Session Class Initialized
DEBUG - 2019-04-24 20:31:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:31:36 --> Session routines successfully run
DEBUG - 2019-04-24 20:31:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:31:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:31:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:31:36 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:31:36 --> Final output sent to browser
DEBUG - 2019-04-24 20:31:36 --> Total execution time: 0.0557
DEBUG - 2019-04-24 20:31:58 --> Config Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:31:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:31:58 --> URI Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Router Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Output Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Security Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Input Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:31:58 --> Language Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Loader Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Controller Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Model Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Session Class Initialized
DEBUG - 2019-04-24 20:31:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:31:58 --> Session routines successfully run
DEBUG - 2019-04-24 20:31:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:31:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:31:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:31:58 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:31:58 --> Final output sent to browser
DEBUG - 2019-04-24 20:31:58 --> Total execution time: 0.0545
DEBUG - 2019-04-24 20:32:16 --> Config Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:32:16 --> URI Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Router Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Output Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Security Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Input Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:32:16 --> Language Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Loader Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Controller Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Session Class Initialized
DEBUG - 2019-04-24 20:32:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:32:16 --> Session routines successfully run
DEBUG - 2019-04-24 20:32:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:32:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:32:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:32:16 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:32:16 --> Final output sent to browser
DEBUG - 2019-04-24 20:32:16 --> Total execution time: 0.0456
DEBUG - 2019-04-24 20:32:32 --> Config Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:32:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:32:32 --> URI Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Router Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Output Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Security Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Input Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:32:32 --> Language Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Loader Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Controller Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Session Class Initialized
DEBUG - 2019-04-24 20:32:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:32:33 --> Session garbage collection performed.
DEBUG - 2019-04-24 20:32:33 --> Session routines successfully run
DEBUG - 2019-04-24 20:32:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:32:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:32:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:32:33 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:32:33 --> Final output sent to browser
DEBUG - 2019-04-24 20:32:33 --> Total execution time: 0.1367
DEBUG - 2019-04-24 20:33:22 --> Config Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:33:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:33:22 --> URI Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Router Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Output Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Security Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Input Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:33:22 --> Language Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Loader Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Controller Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Session Class Initialized
DEBUG - 2019-04-24 20:33:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:33:22 --> Session routines successfully run
DEBUG - 2019-04-24 20:33:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:33:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:33:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:33:22 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:33:22 --> Final output sent to browser
DEBUG - 2019-04-24 20:33:22 --> Total execution time: 0.0847
DEBUG - 2019-04-24 20:33:33 --> Config Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:33:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:33:33 --> URI Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Router Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Output Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Security Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Input Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:33:33 --> Language Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Loader Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Controller Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Session Class Initialized
DEBUG - 2019-04-24 20:33:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:33:33 --> Session routines successfully run
DEBUG - 2019-04-24 20:33:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:33:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:33:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:33:33 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:33:33 --> Final output sent to browser
DEBUG - 2019-04-24 20:33:33 --> Total execution time: 0.0630
DEBUG - 2019-04-24 20:33:46 --> Config Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:33:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:33:46 --> URI Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Router Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Output Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Security Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Input Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:33:46 --> Language Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Loader Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Controller Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Model Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Session Class Initialized
DEBUG - 2019-04-24 20:33:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:33:46 --> Session routines successfully run
DEBUG - 2019-04-24 20:33:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:33:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:33:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:33:46 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:33:46 --> Final output sent to browser
DEBUG - 2019-04-24 20:33:46 --> Total execution time: 0.0411
DEBUG - 2019-04-24 20:34:11 --> Config Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:34:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:34:11 --> URI Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Router Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Output Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Security Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Input Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:34:11 --> Language Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Loader Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Controller Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Session Class Initialized
DEBUG - 2019-04-24 20:34:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:34:11 --> Session routines successfully run
DEBUG - 2019-04-24 20:34:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:34:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:34:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:34:11 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:34:11 --> Final output sent to browser
DEBUG - 2019-04-24 20:34:11 --> Total execution time: 0.0638
DEBUG - 2019-04-24 20:34:49 --> Config Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:34:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:34:49 --> URI Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Router Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Output Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Security Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Input Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:34:49 --> Language Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Loader Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Controller Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Model Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Session Class Initialized
DEBUG - 2019-04-24 20:34:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:34:49 --> Session routines successfully run
DEBUG - 2019-04-24 20:34:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:34:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:34:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:34:49 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:34:49 --> Final output sent to browser
DEBUG - 2019-04-24 20:34:49 --> Total execution time: 0.0609
DEBUG - 2019-04-24 20:35:07 --> Config Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:35:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:35:07 --> URI Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Router Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Output Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Security Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Input Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:35:07 --> Language Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Loader Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Controller Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Session Class Initialized
DEBUG - 2019-04-24 20:35:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:35:07 --> Session routines successfully run
DEBUG - 2019-04-24 20:35:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:35:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:35:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:35:07 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:35:07 --> Final output sent to browser
DEBUG - 2019-04-24 20:35:07 --> Total execution time: 0.0593
DEBUG - 2019-04-24 20:36:07 --> Config Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:36:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:36:07 --> URI Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Router Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Output Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Security Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Input Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:36:07 --> Language Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Loader Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Controller Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Session Class Initialized
DEBUG - 2019-04-24 20:36:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:36:07 --> Session routines successfully run
DEBUG - 2019-04-24 20:36:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:36:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:36:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:36:07 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:36:07 --> Final output sent to browser
DEBUG - 2019-04-24 20:36:07 --> Total execution time: 0.1140
DEBUG - 2019-04-24 20:36:15 --> Config Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:36:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:36:15 --> URI Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Router Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Output Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Security Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Input Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:36:15 --> Language Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Loader Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Controller Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Session Class Initialized
DEBUG - 2019-04-24 20:36:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:36:15 --> Session routines successfully run
DEBUG - 2019-04-24 20:36:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:36:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:36:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:36:15 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:36:15 --> Final output sent to browser
DEBUG - 2019-04-24 20:36:15 --> Total execution time: 0.0506
DEBUG - 2019-04-24 20:37:45 --> Config Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:37:45 --> URI Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Router Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Output Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Security Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Input Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:37:45 --> Language Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Loader Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Controller Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:37:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:37:46 --> Model Class Initialized
DEBUG - 2019-04-24 20:37:46 --> Session Class Initialized
DEBUG - 2019-04-24 20:37:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:37:46 --> Session routines successfully run
DEBUG - 2019-04-24 20:37:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:37:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:37:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:37:46 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:37:46 --> Final output sent to browser
DEBUG - 2019-04-24 20:37:46 --> Total execution time: 0.0539
DEBUG - 2019-04-24 20:38:01 --> Config Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:38:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:38:01 --> URI Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Router Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Output Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Security Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Input Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:38:01 --> Language Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Loader Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Controller Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Model Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Model Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Model Class Initialized
DEBUG - 2019-04-24 20:38:01 --> Session Class Initialized
DEBUG - 2019-04-24 20:38:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:38:02 --> Session routines successfully run
DEBUG - 2019-04-24 20:38:02 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:38:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:38:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:38:02 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:38:02 --> Final output sent to browser
DEBUG - 2019-04-24 20:38:02 --> Total execution time: 0.0668
DEBUG - 2019-04-24 20:39:10 --> Config Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:39:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:39:10 --> URI Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Router Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Output Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Security Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Input Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:39:10 --> Language Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Loader Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Controller Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Session Class Initialized
DEBUG - 2019-04-24 20:39:10 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:39:10 --> Session routines successfully run
DEBUG - 2019-04-24 20:39:10 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:39:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:39:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:39:10 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:39:10 --> Final output sent to browser
DEBUG - 2019-04-24 20:39:10 --> Total execution time: 0.0693
DEBUG - 2019-04-24 20:39:18 --> Config Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:39:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:39:18 --> URI Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Router Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Output Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Security Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Input Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:39:18 --> Language Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Loader Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Controller Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Model Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Session Class Initialized
DEBUG - 2019-04-24 20:39:18 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:39:18 --> Session routines successfully run
DEBUG - 2019-04-24 20:39:18 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:39:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:39:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:39:18 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:39:18 --> Final output sent to browser
DEBUG - 2019-04-24 20:39:18 --> Total execution time: 0.0596
DEBUG - 2019-04-24 20:40:11 --> Config Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:40:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:40:11 --> URI Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Router Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Output Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Security Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Input Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:40:11 --> Language Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Loader Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Controller Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Session Class Initialized
DEBUG - 2019-04-24 20:40:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:40:11 --> Session routines successfully run
DEBUG - 2019-04-24 20:40:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:40:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:40:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:40:11 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:40:11 --> Final output sent to browser
DEBUG - 2019-04-24 20:40:11 --> Total execution time: 0.0511
DEBUG - 2019-04-24 20:44:00 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:00 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:00 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:00 --> Session garbage collection performed.
DEBUG - 2019-04-24 20:44:00 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:00 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:00 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:00 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:44:00 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:00 --> Total execution time: 0.2034
DEBUG - 2019-04-24 20:44:07 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:07 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:07 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:07 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:07 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:07 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:44:07 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:07 --> Total execution time: 0.1194
DEBUG - 2019-04-24 20:44:09 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:09 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:09 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:09 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 20:44:09 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:09 --> Total execution time: 0.0652
DEBUG - 2019-04-24 20:44:12 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:12 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:12 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:12 --> Session garbage collection performed.
DEBUG - 2019-04-24 20:44:12 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:12 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:12 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:12 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 20:44:12 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:12 --> Total execution time: 0.0588
DEBUG - 2019-04-24 20:44:15 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:15 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:15 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:15 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:15 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 20:44:15 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:15 --> Total execution time: 0.0945
DEBUG - 2019-04-24 20:44:22 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:22 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:22 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:22 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:22 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:22 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:22 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:44:22 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:22 --> Total execution time: 0.0538
DEBUG - 2019-04-24 20:44:32 --> Config Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:44:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:44:32 --> URI Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Router Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Output Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Security Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Input Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:44:32 --> Language Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Loader Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Controller Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Model Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Session Class Initialized
DEBUG - 2019-04-24 20:44:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:44:32 --> Session routines successfully run
DEBUG - 2019-04-24 20:44:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:44:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:44:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:44:32 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:44:32 --> Final output sent to browser
DEBUG - 2019-04-24 20:44:32 --> Total execution time: 0.0533
DEBUG - 2019-04-24 20:45:37 --> Config Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:45:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:45:37 --> URI Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Router Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Output Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Security Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Input Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:45:37 --> Language Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Loader Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Controller Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Session Class Initialized
DEBUG - 2019-04-24 20:45:37 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:45:37 --> Session garbage collection performed.
DEBUG - 2019-04-24 20:45:37 --> Session routines successfully run
DEBUG - 2019-04-24 20:45:37 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:45:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:45:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:45:37 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:45:37 --> Final output sent to browser
DEBUG - 2019-04-24 20:45:37 --> Total execution time: 0.0449
DEBUG - 2019-04-24 20:45:51 --> Config Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:45:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:45:51 --> URI Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Router Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Output Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Security Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Input Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:45:51 --> Language Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Loader Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Controller Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Session Class Initialized
DEBUG - 2019-04-24 20:45:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:45:51 --> Session routines successfully run
DEBUG - 2019-04-24 20:45:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:45:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:45:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:45:51 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:45:51 --> Final output sent to browser
DEBUG - 2019-04-24 20:45:51 --> Total execution time: 0.0468
DEBUG - 2019-04-24 20:46:09 --> Config Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:46:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:46:09 --> URI Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Router Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Output Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Security Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Input Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:46:09 --> Language Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Loader Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Controller Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Session Class Initialized
DEBUG - 2019-04-24 20:46:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:46:09 --> Session routines successfully run
DEBUG - 2019-04-24 20:46:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:46:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:46:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:46:09 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:46:09 --> Final output sent to browser
DEBUG - 2019-04-24 20:46:09 --> Total execution time: 0.0737
DEBUG - 2019-04-24 20:46:42 --> Config Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:46:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:46:42 --> URI Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Router Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Output Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Security Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Input Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:46:42 --> Language Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Loader Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Controller Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Session Class Initialized
DEBUG - 2019-04-24 20:46:42 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:46:42 --> Session routines successfully run
DEBUG - 2019-04-24 20:46:42 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:46:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:46:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:46:42 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:46:42 --> Final output sent to browser
DEBUG - 2019-04-24 20:46:42 --> Total execution time: 0.0545
DEBUG - 2019-04-24 20:46:43 --> Config Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:46:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:46:43 --> URI Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Router Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Output Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Security Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Input Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:46:43 --> Language Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Loader Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Controller Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Model Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Session Class Initialized
DEBUG - 2019-04-24 20:46:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:46:43 --> Session routines successfully run
DEBUG - 2019-04-24 20:46:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:46:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:46:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:46:43 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 20:46:43 --> Final output sent to browser
DEBUG - 2019-04-24 20:46:43 --> Total execution time: 0.0701
DEBUG - 2019-04-24 20:47:44 --> Config Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:47:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:47:44 --> URI Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Router Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Output Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Security Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Input Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:47:44 --> Language Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Loader Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Controller Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Session Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:47:44 --> Session routines successfully run
DEBUG - 2019-04-24 20:47:44 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:44 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:47:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:47:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:47:44 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 20:47:44 --> Final output sent to browser
DEBUG - 2019-04-24 20:47:44 --> Total execution time: 0.0894
DEBUG - 2019-04-24 20:47:57 --> Config Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:47:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:47:57 --> URI Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Router Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Output Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Security Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Input Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:47:57 --> Language Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Loader Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Controller Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Model Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Session Class Initialized
DEBUG - 2019-04-24 20:47:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:47:57 --> Session routines successfully run
DEBUG - 2019-04-24 20:47:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:47:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:47:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:47:57 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 20:47:57 --> Final output sent to browser
DEBUG - 2019-04-24 20:47:57 --> Total execution time: 0.0640
DEBUG - 2019-04-24 20:48:03 --> Config Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:48:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:48:03 --> URI Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Router Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Output Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Security Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Input Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:48:03 --> Language Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Loader Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Controller Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Session Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:48:03 --> Session routines successfully run
DEBUG - 2019-04-24 20:48:03 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:48:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:48:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:48:03 --> File loaded: application/views/profile.php
DEBUG - 2019-04-24 20:48:03 --> Final output sent to browser
DEBUG - 2019-04-24 20:48:03 --> Total execution time: 0.0566
DEBUG - 2019-04-24 20:48:09 --> Config Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:48:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:48:09 --> URI Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Router Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Output Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Security Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Input Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:48:09 --> Language Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Loader Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Controller Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Session Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:48:09 --> Session routines successfully run
DEBUG - 2019-04-24 20:48:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:48:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:48:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:48:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 20:48:09 --> Final output sent to browser
DEBUG - 2019-04-24 20:48:09 --> Total execution time: 0.0474
DEBUG - 2019-04-24 20:48:11 --> Config Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:48:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:48:11 --> URI Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Router Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Output Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Security Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Input Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:48:11 --> Language Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Loader Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Controller Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Session Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:48:11 --> Session routines successfully run
DEBUG - 2019-04-24 20:48:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:48:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:48:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:48:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:48:11 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:48:11 --> Final output sent to browser
DEBUG - 2019-04-24 20:48:11 --> Total execution time: 0.1709
DEBUG - 2019-04-24 20:50:51 --> Config Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:50:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:50:51 --> URI Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Router Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Output Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Security Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Input Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:50:51 --> Language Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Loader Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Controller Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Session Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:50:51 --> Session routines successfully run
DEBUG - 2019-04-24 20:50:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:50:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:50:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:50:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:50:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 20:50:51 --> Final output sent to browser
DEBUG - 2019-04-24 20:50:51 --> Total execution time: 0.1161
DEBUG - 2019-04-24 20:51:07 --> Config Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:51:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:51:07 --> URI Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Router Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Output Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Security Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Input Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:51:07 --> Language Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Loader Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Controller Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Session Class Initialized
DEBUG - 2019-04-24 20:51:07 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:51:07 --> Session routines successfully run
DEBUG - 2019-04-24 20:51:07 --> Helper loaded: url_helper
ERROR - 2019-04-24 20:51:07 --> 404 Page Not Found --> Notice/ORDERS%20PAGE%20NEEDS%20TO%20GO%20HERE2
DEBUG - 2019-04-24 20:51:11 --> Config Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:51:11 --> URI Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Router Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Output Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Security Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Input Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:51:11 --> Language Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Loader Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Controller Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Session Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:51:11 --> Session routines successfully run
DEBUG - 2019-04-24 20:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:11 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:51:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:51:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:51:11 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:51:11 --> Final output sent to browser
DEBUG - 2019-04-24 20:51:11 --> Total execution time: 0.1307
DEBUG - 2019-04-24 20:51:59 --> Config Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:51:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:51:59 --> URI Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Router Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Output Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Security Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Input Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:51:59 --> Language Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Loader Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Controller Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Session Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:51:59 --> Session routines successfully run
DEBUG - 2019-04-24 20:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Model Class Initialized
DEBUG - 2019-04-24 20:51:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:52:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:52:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:52:00 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:52:00 --> Final output sent to browser
DEBUG - 2019-04-24 20:52:00 --> Total execution time: 0.0919
DEBUG - 2019-04-24 20:53:24 --> Config Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:53:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:53:24 --> URI Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Router Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Output Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Security Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Input Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:53:24 --> Language Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Loader Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Controller Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Session Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:53:24 --> Session routines successfully run
DEBUG - 2019-04-24 20:53:24 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:24 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:53:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:53:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:53:24 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:53:24 --> Final output sent to browser
DEBUG - 2019-04-24 20:53:24 --> Total execution time: 0.1444
DEBUG - 2019-04-24 20:53:35 --> Config Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:53:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:53:35 --> URI Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Router Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Output Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Security Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Input Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:53:35 --> Language Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Loader Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Controller Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Session Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:53:35 --> Session routines successfully run
DEBUG - 2019-04-24 20:53:35 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Model Class Initialized
DEBUG - 2019-04-24 20:53:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:53:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 20:53:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:53:35 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:53:35 --> Final output sent to browser
DEBUG - 2019-04-24 20:53:35 --> Total execution time: 0.1195
DEBUG - 2019-04-24 20:58:45 --> Config Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:58:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:58:45 --> URI Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Router Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Output Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Security Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Input Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:58:45 --> Language Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Loader Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Controller Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Session Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:58:45 --> Session routines successfully run
DEBUG - 2019-04-24 20:58:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Model Class Initialized
DEBUG - 2019-04-24 20:58:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:58:45 --> File loaded: application/views/header.php
ERROR - 2019-04-24 20:58:45 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 20:58:45 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 20:58:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:58:45 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:58:45 --> Final output sent to browser
DEBUG - 2019-04-24 20:58:45 --> Total execution time: 0.3003
DEBUG - 2019-04-24 20:59:28 --> Config Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:59:28 --> URI Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Router Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Output Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Security Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Input Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:59:28 --> Language Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Loader Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Controller Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Session Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:59:28 --> Session routines successfully run
DEBUG - 2019-04-24 20:59:28 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:59:29 --> File loaded: application/views/header.php
ERROR - 2019-04-24 20:59:29 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 7
ERROR - 2019-04-24 20:59:29 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
ERROR - 2019-04-24 20:59:29 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
DEBUG - 2019-04-24 20:59:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:59:29 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:59:29 --> Final output sent to browser
DEBUG - 2019-04-24 20:59:29 --> Total execution time: 0.1109
DEBUG - 2019-04-24 20:59:51 --> Config Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Hooks Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Utf8 Class Initialized
DEBUG - 2019-04-24 20:59:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 20:59:51 --> URI Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Router Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Output Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Security Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Input Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 20:59:51 --> Language Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Loader Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Controller Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Database Driver Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Session Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Helper loaded: string_helper
DEBUG - 2019-04-24 20:59:51 --> Session routines successfully run
DEBUG - 2019-04-24 20:59:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Model Class Initialized
DEBUG - 2019-04-24 20:59:51 --> Helper loaded: url_helper
DEBUG - 2019-04-24 20:59:51 --> File loaded: application/views/header.php
ERROR - 2019-04-24 20:59:51 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 7
DEBUG - 2019-04-24 20:59:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 20:59:51 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 20:59:51 --> Final output sent to browser
DEBUG - 2019-04-24 20:59:51 --> Total execution time: 0.1133
DEBUG - 2019-04-24 21:00:18 --> Config Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:00:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:00:18 --> URI Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Router Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Output Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Security Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Input Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:00:18 --> Language Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Loader Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Controller Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Session Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:00:18 --> Session routines successfully run
DEBUG - 2019-04-24 21:00:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:18 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:00:18 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:00:18 --> Severity: Notice  --> Undefined variable: image C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:00:18 --> Severity: Notice  --> Undefined variable: image C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:00:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:00:18 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:00:18 --> Final output sent to browser
DEBUG - 2019-04-24 21:00:18 --> Total execution time: 0.1277
DEBUG - 2019-04-24 21:00:29 --> Config Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:00:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:00:29 --> URI Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Router Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Output Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Security Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Input Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:00:29 --> Language Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Loader Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Controller Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Session Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:00:29 --> Session routines successfully run
DEBUG - 2019-04-24 21:00:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:00:29 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:00:29 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:00:29 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:00:29 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:00:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:00:29 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:00:29 --> Final output sent to browser
DEBUG - 2019-04-24 21:00:29 --> Total execution time: 0.1134
DEBUG - 2019-04-24 21:02:41 --> Config Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:02:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:02:41 --> URI Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Router Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Output Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Security Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Input Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:02:41 --> Language Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Loader Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Controller Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Session Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:02:41 --> Session routines successfully run
DEBUG - 2019-04-24 21:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Model Class Initialized
DEBUG - 2019-04-24 21:02:41 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:02:42 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:02:42 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:02:42 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:02:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:02:42 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:02:42 --> Final output sent to browser
DEBUG - 2019-04-24 21:02:42 --> Total execution time: 0.1686
DEBUG - 2019-04-24 21:09:02 --> Config Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:09:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:09:02 --> URI Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Router Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Output Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Security Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Input Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:09:02 --> Language Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Loader Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Controller Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Session Class Initialized
DEBUG - 2019-04-24 21:09:02 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:09:03 --> Session routines successfully run
DEBUG - 2019-04-24 21:09:03 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:03 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:03 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:09:04 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:09:04 --> Severity: Notice  --> Undefined property: CI_Loader::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:09:04 --> Severity: Notice  --> Undefined property: CI_Loader::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:09:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:09:04 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:09:04 --> Final output sent to browser
DEBUG - 2019-04-24 21:09:04 --> Total execution time: 1.9148
DEBUG - 2019-04-24 21:09:14 --> Config Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:09:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:09:14 --> URI Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Router Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Output Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Security Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Input Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:09:14 --> Language Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Loader Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Controller Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Session Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:09:14 --> Session routines successfully run
DEBUG - 2019-04-24 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:14 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:09:21 --> Config Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:09:21 --> URI Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Router Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Output Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Security Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Input Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:09:21 --> Language Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Loader Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Controller Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Session Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:09:21 --> Session routines successfully run
DEBUG - 2019-04-24 21:09:21 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Model Class Initialized
DEBUG - 2019-04-24 21:09:21 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:09:22 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:09:22 --> Severity: 4096  --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:09:22 --> Severity: 4096  --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:09:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:09:22 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:09:22 --> Final output sent to browser
DEBUG - 2019-04-24 21:09:22 --> Total execution time: 0.2192
DEBUG - 2019-04-24 21:10:09 --> Config Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:10:09 --> URI Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Router Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Output Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Security Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Input Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:10:09 --> Language Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Loader Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Controller Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Session Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:10:09 --> Session routines successfully run
DEBUG - 2019-04-24 21:10:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:10:09 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:10:09 --> Severity: 4096  --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:10:09 --> Severity: 4096  --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:10:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:10:09 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:10:09 --> Final output sent to browser
DEBUG - 2019-04-24 21:10:09 --> Total execution time: 0.1028
DEBUG - 2019-04-24 21:10:19 --> Config Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:10:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:10:19 --> URI Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Router Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Output Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Security Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Input Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:10:19 --> Language Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Loader Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Controller Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Session Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:10:19 --> Session routines successfully run
DEBUG - 2019-04-24 21:10:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:10:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:10:19 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:10:19 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:10:19 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:10:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:10:19 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:10:19 --> Final output sent to browser
DEBUG - 2019-04-24 21:10:19 --> Total execution time: 0.0861
DEBUG - 2019-04-24 21:15:52 --> Config Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:15:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:15:52 --> URI Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Router Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Output Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Security Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Input Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:15:52 --> Language Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Loader Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Controller Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Session Class Initialized
DEBUG - 2019-04-24 21:15:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:15:53 --> Session routines successfully run
DEBUG - 2019-04-24 21:15:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:15:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:15:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:15:53 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:15:53 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:15:53 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:15:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:15:53 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:15:53 --> Final output sent to browser
DEBUG - 2019-04-24 21:15:53 --> Total execution time: 0.8947
DEBUG - 2019-04-24 21:16:18 --> Config Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:16:18 --> URI Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Router Class Initialized
DEBUG - 2019-04-24 21:16:18 --> No URI present. Default controller set.
DEBUG - 2019-04-24 21:16:18 --> Output Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Security Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Input Class Initialized
DEBUG - 2019-04-24 21:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:16:19 --> Language Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Loader Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Controller Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Session Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:16:19 --> Session routines successfully run
DEBUG - 2019-04-24 21:16:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Model Class Initialized
DEBUG - 2019-04-24 21:16:19 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:16:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:16:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:16:19 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 21:16:19 --> Final output sent to browser
DEBUG - 2019-04-24 21:16:19 --> Total execution time: 0.5561
DEBUG - 2019-04-24 21:19:15 --> Config Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:19:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:19:15 --> URI Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Router Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Output Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Security Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Input Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:19:15 --> Language Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Loader Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Controller Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Session Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:19:15 --> Session routines successfully run
DEBUG - 2019-04-24 21:19:15 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:15 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:19:16 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:19:16 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:19:16 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:19:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:19:16 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:19:16 --> Final output sent to browser
DEBUG - 2019-04-24 21:19:16 --> Total execution time: 0.1915
DEBUG - 2019-04-24 21:19:20 --> Config Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:19:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:19:20 --> URI Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Router Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Output Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Security Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Input Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:19:20 --> Language Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Loader Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Controller Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Session Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:19:20 --> Session routines successfully run
DEBUG - 2019-04-24 21:19:20 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Model Class Initialized
DEBUG - 2019-04-24 21:19:20 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:19:20 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:19:20 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:19:20 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:19:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:19:20 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:19:20 --> Final output sent to browser
DEBUG - 2019-04-24 21:19:20 --> Total execution time: 0.2339
DEBUG - 2019-04-24 21:20:53 --> Config Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:20:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:20:53 --> URI Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Router Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Output Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Security Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Input Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:20:53 --> Language Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Loader Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Controller Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Session Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:20:53 --> Session routines successfully run
DEBUG - 2019-04-24 21:20:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Model Class Initialized
DEBUG - 2019-04-24 21:20:53 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:20:53 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:20:53 --> Severity: Notice  --> Undefined variable: order C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 7
ERROR - 2019-04-24 21:20:53 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
ERROR - 2019-04-24 21:20:53 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 25
DEBUG - 2019-04-24 21:20:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:20:53 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:20:53 --> Final output sent to browser
DEBUG - 2019-04-24 21:20:53 --> Total execution time: 0.4651
DEBUG - 2019-04-24 21:22:18 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:18 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:18 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:18 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:18 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:19 --> File loaded: application/views/header.php
ERROR - 2019-04-24 21:22:19 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-24 21:22:19 --> Severity: Notice  --> Undefined index: largeImage C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-24 21:22:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:19 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:22:19 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:19 --> Total execution time: 0.3301
DEBUG - 2019-04-24 21:22:32 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:33 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:33 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:33 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:33 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:22:33 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:33 --> Total execution time: 0.8196
DEBUG - 2019-04-24 21:22:35 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:35 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:35 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:35 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 21:22:36 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:36 --> Total execution time: 0.1229
DEBUG - 2019-04-24 21:22:36 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:36 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:36 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:36 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:22:36 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:36 --> Total execution time: 0.0421
DEBUG - 2019-04-24 21:22:43 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:43 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:43 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:43 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:43 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 21:22:43 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:43 --> Total execution time: 0.0459
DEBUG - 2019-04-24 21:22:45 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:45 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:45 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:45 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:45 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:45 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:45 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 21:22:45 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:45 --> Total execution time: 0.0545
DEBUG - 2019-04-24 21:22:55 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:55 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:55 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:55 --> A session cookie was not found.
DEBUG - 2019-04-24 21:22:55 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:55 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:55 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:56 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:22:56 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:56 --> Total execution time: 0.4639
DEBUG - 2019-04-24 21:22:58 --> Config Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:22:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:22:58 --> URI Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Router Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Output Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Security Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Input Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:22:58 --> Language Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Loader Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Controller Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Session Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:22:58 --> Session routines successfully run
DEBUG - 2019-04-24 21:22:58 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Model Class Initialized
DEBUG - 2019-04-24 21:22:58 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:22:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:22:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:22:58 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-24 21:22:58 --> Final output sent to browser
DEBUG - 2019-04-24 21:22:58 --> Total execution time: 0.0595
DEBUG - 2019-04-24 21:23:09 --> Config Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:23:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:23:09 --> URI Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Router Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Output Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Security Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Input Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:23:09 --> Language Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Loader Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Controller Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Session Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:23:09 --> Session routines successfully run
DEBUG - 2019-04-24 21:23:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:09 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:23:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:23:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:23:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 21:23:10 --> Final output sent to browser
DEBUG - 2019-04-24 21:23:10 --> Total execution time: 0.8085
DEBUG - 2019-04-24 21:23:16 --> Config Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:23:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:23:16 --> URI Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Router Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Output Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Security Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Input Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:23:16 --> Language Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Loader Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Controller Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Session Class Initialized
DEBUG - 2019-04-24 21:23:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:23:16 --> Session routines successfully run
DEBUG - 2019-04-24 21:23:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:23:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:23:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:23:16 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-24 21:23:16 --> Final output sent to browser
DEBUG - 2019-04-24 21:23:16 --> Total execution time: 0.0904
DEBUG - 2019-04-24 21:23:23 --> Config Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:23:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:23:23 --> URI Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Router Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Output Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Security Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Input Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:23:23 --> Language Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Loader Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Controller Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Session Class Initialized
DEBUG - 2019-04-24 21:23:23 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:23:23 --> Session routines successfully run
DEBUG - 2019-04-24 21:23:23 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:23:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:23:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:23:23 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-24 21:23:23 --> Final output sent to browser
DEBUG - 2019-04-24 21:23:23 --> Total execution time: 0.0625
DEBUG - 2019-04-24 21:23:57 --> Config Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:23:57 --> URI Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Router Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Output Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Security Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Input Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:23:57 --> Language Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Loader Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Controller Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Session Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:23:57 --> Session routines successfully run
DEBUG - 2019-04-24 21:23:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:23:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:23:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:23:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:23:57 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:23:57 --> Final output sent to browser
DEBUG - 2019-04-24 21:23:57 --> Total execution time: 0.3036
DEBUG - 2019-04-24 21:24:16 --> Config Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:24:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:24:16 --> URI Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Router Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Output Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Security Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Input Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:24:16 --> Language Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Loader Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Controller Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Session Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:24:16 --> Session routines successfully run
DEBUG - 2019-04-24 21:24:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Model Class Initialized
DEBUG - 2019-04-24 21:24:16 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:24:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:24:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:24:16 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:24:16 --> Final output sent to browser
DEBUG - 2019-04-24 21:24:16 --> Total execution time: 0.4155
DEBUG - 2019-04-24 21:25:43 --> Config Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:25:43 --> URI Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Router Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Output Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Security Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Input Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:25:43 --> Language Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Loader Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Controller Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Session Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:25:43 --> Session routines successfully run
DEBUG - 2019-04-24 21:25:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:43 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:25:54 --> Config Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:25:54 --> URI Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Router Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Output Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Security Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Input Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:25:54 --> Language Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Loader Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Controller Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Session Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:25:54 --> Session routines successfully run
DEBUG - 2019-04-24 21:25:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:25:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:25:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:25:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:25:54 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:25:54 --> Final output sent to browser
DEBUG - 2019-04-24 21:25:54 --> Total execution time: 0.3592
DEBUG - 2019-04-24 21:26:27 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:27 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:27 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:27 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:27 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:27 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:26:27 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:27 --> Total execution time: 0.0635
DEBUG - 2019-04-24 21:26:28 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:28 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:28 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:28 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:28 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:28 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:26:29 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:29 --> Total execution time: 0.3079
DEBUG - 2019-04-24 21:26:29 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:29 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:29 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:29 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:29 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 21:26:29 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:29 --> Total execution time: 0.2873
DEBUG - 2019-04-24 21:26:30 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:30 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:30 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:30 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:30 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:26:30 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:30 --> Total execution time: 0.0656
DEBUG - 2019-04-24 21:26:32 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:32 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:32 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:32 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:32 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:32 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:26:32 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:32 --> Total execution time: 0.0533
DEBUG - 2019-04-24 21:26:33 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:33 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:33 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:33 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:33 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:33 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 21:26:33 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:33 --> Total execution time: 0.3536
DEBUG - 2019-04-24 21:26:35 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:35 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:35 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:35 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:35 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:26:35 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:35 --> Total execution time: 0.0619
DEBUG - 2019-04-24 21:26:36 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:36 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:36 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:36 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:36 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:36 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-24 21:26:36 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:36 --> Total execution time: 0.3098
DEBUG - 2019-04-24 21:26:37 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:37 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:37 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:37 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:37 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:37 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:37 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:26:37 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:37 --> Total execution time: 0.0802
DEBUG - 2019-04-24 21:26:49 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:49 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:49 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:49 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:50 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 21:26:50 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:50 --> Total execution time: 0.4907
DEBUG - 2019-04-24 21:26:52 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:52 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:52 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:52 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:52 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:52 --> File loaded: application/views/producers.php
DEBUG - 2019-04-24 21:26:52 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:52 --> Total execution time: 0.0447
DEBUG - 2019-04-24 21:26:54 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:54 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:54 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:54 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:54 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:55 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 21:26:55 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:55 --> Total execution time: 0.2441
DEBUG - 2019-04-24 21:26:57 --> Config Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:26:57 --> URI Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Router Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Output Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Security Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Input Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:26:57 --> Language Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Loader Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Controller Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Session Class Initialized
DEBUG - 2019-04-24 21:26:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:26:57 --> Session routines successfully run
DEBUG - 2019-04-24 21:26:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:26:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:26:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:26:57 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 21:26:57 --> Final output sent to browser
DEBUG - 2019-04-24 21:26:57 --> Total execution time: 0.0647
DEBUG - 2019-04-24 21:27:58 --> Config Class Initialized
DEBUG - 2019-04-24 21:27:58 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:27:59 --> URI Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Router Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Output Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Security Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Input Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:27:59 --> Language Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Loader Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Controller Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Session Class Initialized
DEBUG - 2019-04-24 21:27:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:27:59 --> Session garbage collection performed.
DEBUG - 2019-04-24 21:27:59 --> Session routines successfully run
DEBUG - 2019-04-24 21:27:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:27:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:27:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:27:59 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 21:27:59 --> Final output sent to browser
DEBUG - 2019-04-24 21:27:59 --> Total execution time: 0.3786
DEBUG - 2019-04-24 21:28:57 --> Config Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:28:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:28:57 --> URI Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Router Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Output Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Security Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Input Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:28:57 --> Language Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Loader Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Controller Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Model Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Session Class Initialized
DEBUG - 2019-04-24 21:28:57 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:28:57 --> Session routines successfully run
DEBUG - 2019-04-24 21:28:57 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:28:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:28:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:28:57 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 21:28:57 --> Final output sent to browser
DEBUG - 2019-04-24 21:28:57 --> Total execution time: 0.0545
DEBUG - 2019-04-24 21:29:46 --> Config Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:29:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:29:46 --> URI Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Router Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Output Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Security Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Input Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:29:46 --> Language Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Loader Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Controller Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Model Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Session Class Initialized
DEBUG - 2019-04-24 21:29:46 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:29:46 --> Session routines successfully run
DEBUG - 2019-04-24 21:29:46 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:29:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:29:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:29:46 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 21:29:46 --> Final output sent to browser
DEBUG - 2019-04-24 21:29:46 --> Total execution time: 0.0686
DEBUG - 2019-04-24 21:31:39 --> Config Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:31:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:31:39 --> URI Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Router Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Output Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Security Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Input Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:31:39 --> Language Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Loader Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Controller Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Model Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Model Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Model Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Session Class Initialized
DEBUG - 2019-04-24 21:31:39 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:31:39 --> Session routines successfully run
DEBUG - 2019-04-24 21:31:39 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:31:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:31:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:31:39 --> File loaded: application/views/noticeDetails.php
DEBUG - 2019-04-24 21:31:39 --> Final output sent to browser
DEBUG - 2019-04-24 21:31:39 --> Total execution time: 0.0479
DEBUG - 2019-04-24 21:33:38 --> Config Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:33:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:33:38 --> URI Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Router Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Output Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Security Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Input Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:33:38 --> Language Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Loader Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Controller Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Session Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:33:38 --> Session routines successfully run
DEBUG - 2019-04-24 21:33:38 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:38 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:33:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:33:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:33:38 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-24 21:33:38 --> Final output sent to browser
DEBUG - 2019-04-24 21:33:38 --> Total execution time: 0.1876
DEBUG - 2019-04-24 21:33:49 --> Config Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:33:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:33:49 --> URI Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Router Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Output Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Security Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Input Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:33:49 --> Language Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Loader Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Controller Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Session Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:33:49 --> Session routines successfully run
DEBUG - 2019-04-24 21:33:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:49 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:33:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:33:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:33:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-24 21:33:49 --> Final output sent to browser
DEBUG - 2019-04-24 21:33:49 --> Total execution time: 0.0585
DEBUG - 2019-04-24 21:33:59 --> Config Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:33:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:33:59 --> URI Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Router Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Output Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Security Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Input Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:33:59 --> Language Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Loader Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Controller Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Session Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:33:59 --> Session routines successfully run
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:33:59 --> Config Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Hooks Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Utf8 Class Initialized
DEBUG - 2019-04-24 21:33:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-24 21:33:59 --> URI Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Router Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Output Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Security Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Input Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-24 21:33:59 --> Language Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Loader Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Controller Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Database Driver Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Session Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Helper loaded: string_helper
DEBUG - 2019-04-24 21:33:59 --> A session cookie was not found.
DEBUG - 2019-04-24 21:33:59 --> Session routines successfully run
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Model Class Initialized
DEBUG - 2019-04-24 21:33:59 --> Helper loaded: url_helper
DEBUG - 2019-04-24 21:34:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-24 21:34:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-24 21:34:00 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-24 21:34:00 --> Final output sent to browser
DEBUG - 2019-04-24 21:34:00 --> Total execution time: 0.2538
