<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2019-04-27 12:08:14 --> Config Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:08:14 --> URI Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Router Class Initialized
DEBUG - 2019-04-27 12:08:14 --> No URI present. Default controller set.
DEBUG - 2019-04-27 12:08:14 --> Output Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Security Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Input Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:08:14 --> Language Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Loader Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Controller Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Model Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Model Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Session Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:08:14 --> A session cookie was not found.
DEBUG - 2019-04-27 12:08:14 --> Session routines successfully run
DEBUG - 2019-04-27 12:08:14 --> Model Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Model Class Initialized
DEBUG - 2019-04-27 12:08:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:08:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:08:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:08:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:08:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:08:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 12:08:14 --> Final output sent to browser
DEBUG - 2019-04-27 12:08:14 --> Total execution time: 0.2254
DEBUG - 2019-04-27 12:33:16 --> Config Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:33:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:33:16 --> URI Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Router Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Output Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Security Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Input Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:33:16 --> Language Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Loader Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Controller Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Session Class Initialized
DEBUG - 2019-04-27 12:33:16 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:33:17 --> Session routines successfully run
DEBUG - 2019-04-27 12:33:17 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:17 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:33:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:33:17 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:33:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:33:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:33:17 --> File loaded: application/views/producers.php
DEBUG - 2019-04-27 12:33:17 --> Final output sent to browser
DEBUG - 2019-04-27 12:33:17 --> Total execution time: 0.3548
DEBUG - 2019-04-27 12:33:18 --> Config Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:33:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:33:18 --> URI Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Router Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Output Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Security Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Input Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:33:18 --> Language Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Loader Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Controller Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Session Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:33:18 --> Session routines successfully run
DEBUG - 2019-04-27 12:33:18 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Model Class Initialized
DEBUG - 2019-04-27 12:33:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:33:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:33:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:33:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:33:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:33:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:33:18 --> Final output sent to browser
DEBUG - 2019-04-27 12:33:18 --> Total execution time: 0.0556
DEBUG - 2019-04-27 12:39:40 --> Config Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:39:40 --> URI Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Router Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Output Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Security Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Input Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:39:40 --> Language Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Loader Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Controller Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Session Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:39:40 --> Session routines successfully run
DEBUG - 2019-04-27 12:39:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:39:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:39:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:39:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:39:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:39:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:39:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:39:40 --> Final output sent to browser
DEBUG - 2019-04-27 12:39:40 --> Total execution time: 0.1418
DEBUG - 2019-04-27 12:40:21 --> Config Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:40:21 --> URI Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Router Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Output Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Security Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Input Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:40:21 --> Language Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Loader Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Controller Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Session Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:40:21 --> Session routines successfully run
DEBUG - 2019-04-27 12:40:21 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:21 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:40:21 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:40:21 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:40:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:40:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:40:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:40:21 --> Final output sent to browser
DEBUG - 2019-04-27 12:40:21 --> Total execution time: 0.0692
DEBUG - 2019-04-27 12:40:22 --> Config Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:40:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:40:22 --> URI Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Router Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Output Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Security Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Input Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:40:22 --> Language Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Loader Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Controller Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Session Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:40:22 --> Session routines successfully run
DEBUG - 2019-04-27 12:40:22 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:40:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:40:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:40:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:40:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:40:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:40:22 --> Final output sent to browser
DEBUG - 2019-04-27 12:40:22 --> Total execution time: 0.0546
DEBUG - 2019-04-27 12:40:25 --> Config Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:40:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:40:25 --> URI Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Router Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Output Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Security Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Input Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:40:25 --> Language Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Loader Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Controller Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Session Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:40:25 --> Session routines successfully run
DEBUG - 2019-04-27 12:40:25 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:40:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:40:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:40:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:40:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:40:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:40:25 --> Final output sent to browser
DEBUG - 2019-04-27 12:40:25 --> Total execution time: 0.0556
DEBUG - 2019-04-27 12:40:40 --> Config Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:40:40 --> URI Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Router Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Output Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Security Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Input Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:40:40 --> Language Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Loader Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Controller Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Session Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:40:40 --> Session routines successfully run
DEBUG - 2019-04-27 12:40:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:40:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:40:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:40:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:40:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:40:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:40:40 --> Final output sent to browser
DEBUG - 2019-04-27 12:40:40 --> Total execution time: 0.0733
DEBUG - 2019-04-27 12:40:42 --> Config Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:40:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:40:42 --> URI Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Router Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Output Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Security Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Input Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:40:42 --> Language Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Loader Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Controller Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Session Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:40:42 --> Session garbage collection performed.
DEBUG - 2019-04-27 12:40:42 --> Session routines successfully run
DEBUG - 2019-04-27 12:40:42 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Model Class Initialized
DEBUG - 2019-04-27 12:40:42 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:40:42 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:40:42 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:40:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:40:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:40:42 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:40:42 --> Final output sent to browser
DEBUG - 2019-04-27 12:40:42 --> Total execution time: 0.1479
DEBUG - 2019-04-27 12:44:11 --> Config Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:44:11 --> URI Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Router Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Output Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Security Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Input Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:44:11 --> Language Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Loader Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Controller Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Model Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Model Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Session Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:44:11 --> Session routines successfully run
DEBUG - 2019-04-27 12:44:11 --> Model Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Model Class Initialized
DEBUG - 2019-04-27 12:44:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:44:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:44:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:44:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:44:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:44:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:44:11 --> Final output sent to browser
DEBUG - 2019-04-27 12:44:11 --> Total execution time: 0.0808
DEBUG - 2019-04-27 12:50:39 --> Config Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:50:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:50:39 --> URI Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Router Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Output Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Security Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Input Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:50:39 --> Language Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Loader Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Controller Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Session Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:50:39 --> Session routines successfully run
DEBUG - 2019-04-27 12:50:39 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:39 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:50:39 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:50:39 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:50:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:50:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:50:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:50:39 --> Final output sent to browser
DEBUG - 2019-04-27 12:50:39 --> Total execution time: 0.1394
DEBUG - 2019-04-27 12:50:41 --> Config Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:50:41 --> URI Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Router Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Output Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Security Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Input Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:50:41 --> Language Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Loader Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Controller Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Session Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:50:41 --> Session routines successfully run
DEBUG - 2019-04-27 12:50:41 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Model Class Initialized
DEBUG - 2019-04-27 12:50:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:50:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:50:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:50:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:50:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:50:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:50:41 --> Final output sent to browser
DEBUG - 2019-04-27 12:50:41 --> Total execution time: 0.0560
DEBUG - 2019-04-27 12:51:48 --> Config Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:51:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:51:48 --> URI Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Router Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Output Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Security Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Input Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:51:48 --> Language Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Loader Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Controller Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Session Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:51:48 --> Session routines successfully run
DEBUG - 2019-04-27 12:51:48 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:48 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:51:48 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:51:48 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:51:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:51:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:51:48 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:51:48 --> Final output sent to browser
DEBUG - 2019-04-27 12:51:48 --> Total execution time: 0.0758
DEBUG - 2019-04-27 12:51:58 --> Config Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:51:58 --> URI Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Router Class Initialized
DEBUG - 2019-04-27 12:51:58 --> No URI present. Default controller set.
DEBUG - 2019-04-27 12:51:58 --> Output Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Security Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Input Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:51:58 --> Language Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Loader Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Controller Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Session Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:51:58 --> A session cookie was not found.
DEBUG - 2019-04-27 12:51:58 --> Session routines successfully run
DEBUG - 2019-04-27 12:51:58 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Model Class Initialized
DEBUG - 2019-04-27 12:51:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:51:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:51:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:51:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:51:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:51:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 12:51:58 --> Final output sent to browser
DEBUG - 2019-04-27 12:51:58 --> Total execution time: 0.1642
DEBUG - 2019-04-27 12:52:00 --> Config Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:52:00 --> URI Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Router Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Output Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Security Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Input Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:52:00 --> Language Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Loader Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Controller Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Session Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:52:00 --> Session routines successfully run
DEBUG - 2019-04-27 12:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:52:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:52:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:52:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:52:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:52:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:52:00 --> Final output sent to browser
DEBUG - 2019-04-27 12:52:00 --> Total execution time: 0.0576
DEBUG - 2019-04-27 12:52:47 --> Config Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:52:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:52:47 --> URI Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Router Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Output Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Security Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Input Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:52:47 --> Language Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Loader Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Controller Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Session Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:52:47 --> Session routines successfully run
DEBUG - 2019-04-27 12:52:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:52:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:52:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:52:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:52:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:52:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:52:47 --> Final output sent to browser
DEBUG - 2019-04-27 12:52:47 --> Total execution time: 0.0749
DEBUG - 2019-04-27 12:52:49 --> Config Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:52:49 --> URI Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Router Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Output Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Security Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Input Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:52:49 --> Language Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Loader Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Controller Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Session Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:52:49 --> Session routines successfully run
DEBUG - 2019-04-27 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:52:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:52:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:52:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:52:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:52:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:52:49 --> Final output sent to browser
DEBUG - 2019-04-27 12:52:49 --> Total execution time: 0.0563
DEBUG - 2019-04-27 12:52:50 --> Config Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:52:50 --> URI Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Router Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Output Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Security Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Input Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:52:50 --> Language Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Loader Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Controller Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Session Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:52:50 --> Session routines successfully run
DEBUG - 2019-04-27 12:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 12:52:50 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:52:50 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:52:50 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:52:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:52:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:52:50 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:52:50 --> Final output sent to browser
DEBUG - 2019-04-27 12:52:50 --> Total execution time: 0.0563
DEBUG - 2019-04-27 12:55:52 --> Config Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:55:52 --> URI Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Router Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Output Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Security Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Input Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:55:52 --> Language Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Loader Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Controller Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Model Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Model Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Session Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:55:52 --> Session routines successfully run
DEBUG - 2019-04-27 12:55:52 --> Model Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Model Class Initialized
DEBUG - 2019-04-27 12:55:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:55:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:55:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:55:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:55:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:55:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:55:52 --> Final output sent to browser
DEBUG - 2019-04-27 12:55:52 --> Total execution time: 0.1384
DEBUG - 2019-04-27 12:56:02 --> Config Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:56:02 --> URI Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Router Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Output Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Security Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Input Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:56:02 --> Language Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Loader Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Controller Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Session Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:56:02 --> Session routines successfully run
DEBUG - 2019-04-27 12:56:02 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:56:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:56:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:56:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:56:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:56:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:56:02 --> Final output sent to browser
DEBUG - 2019-04-27 12:56:02 --> Total execution time: 0.0511
DEBUG - 2019-04-27 12:56:54 --> Config Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:56:54 --> URI Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Router Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Output Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Security Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Input Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:56:54 --> Language Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Loader Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Controller Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Session Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:56:54 --> Session routines successfully run
DEBUG - 2019-04-27 12:56:54 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Model Class Initialized
DEBUG - 2019-04-27 12:56:54 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:56:54 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:56:54 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:56:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:56:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:56:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:56:54 --> Final output sent to browser
DEBUG - 2019-04-27 12:56:54 --> Total execution time: 0.0587
DEBUG - 2019-04-27 12:57:00 --> Config Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:57:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:57:00 --> URI Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Router Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Output Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Security Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Input Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:57:00 --> Language Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Loader Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Controller Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Session Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:57:00 --> Session routines successfully run
DEBUG - 2019-04-27 12:57:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Model Class Initialized
DEBUG - 2019-04-27 12:57:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:57:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:57:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:57:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:57:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:57:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:57:00 --> Final output sent to browser
DEBUG - 2019-04-27 12:57:00 --> Total execution time: 0.1151
DEBUG - 2019-04-27 12:59:24 --> Config Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:59:24 --> URI Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Router Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Output Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Security Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Input Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:59:24 --> Language Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Loader Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Controller Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Session Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:59:24 --> Session routines successfully run
DEBUG - 2019-04-27 12:59:24 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:59:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:59:24 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:59:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:59:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:59:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:59:24 --> Final output sent to browser
DEBUG - 2019-04-27 12:59:24 --> Total execution time: 0.0801
DEBUG - 2019-04-27 12:59:36 --> Config Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:59:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:59:36 --> URI Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Router Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Output Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Security Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Input Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:59:36 --> Language Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Loader Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Controller Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Session Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:59:36 --> Session routines successfully run
DEBUG - 2019-04-27 12:59:36 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:59:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:59:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:59:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:59:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:59:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:59:36 --> Final output sent to browser
DEBUG - 2019-04-27 12:59:36 --> Total execution time: 0.0626
DEBUG - 2019-04-27 12:59:47 --> Config Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:59:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:59:47 --> URI Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Router Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Output Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Security Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Input Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:59:47 --> Language Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Loader Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Controller Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Session Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:59:47 --> Session routines successfully run
DEBUG - 2019-04-27 12:59:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:59:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:59:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:59:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:59:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:59:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:59:47 --> Final output sent to browser
DEBUG - 2019-04-27 12:59:47 --> Total execution time: 0.0557
DEBUG - 2019-04-27 12:59:55 --> Config Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:59:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:59:55 --> URI Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Router Class Initialized
DEBUG - 2019-04-27 12:59:55 --> No URI present. Default controller set.
DEBUG - 2019-04-27 12:59:55 --> Output Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Security Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Input Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:59:55 --> Language Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Loader Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Controller Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Session Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:59:55 --> Session routines successfully run
DEBUG - 2019-04-27 12:59:55 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:59:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:59:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:59:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:59:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:59:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 12:59:55 --> Final output sent to browser
DEBUG - 2019-04-27 12:59:55 --> Total execution time: 0.2197
DEBUG - 2019-04-27 12:59:57 --> Config Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Hooks Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Utf8 Class Initialized
DEBUG - 2019-04-27 12:59:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 12:59:57 --> URI Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Router Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Output Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Security Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Input Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 12:59:57 --> Language Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Loader Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Controller Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Database Driver Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Session Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 12:59:57 --> Session routines successfully run
DEBUG - 2019-04-27 12:59:57 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Model Class Initialized
DEBUG - 2019-04-27 12:59:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 12:59:57 --> Helper loaded: form_helper
DEBUG - 2019-04-27 12:59:57 --> Form Validation Class Initialized
DEBUG - 2019-04-27 12:59:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 12:59:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 12:59:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 12:59:57 --> Final output sent to browser
DEBUG - 2019-04-27 12:59:57 --> Total execution time: 0.0415
DEBUG - 2019-04-27 13:01:07 --> Config Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:01:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:01:07 --> URI Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Router Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Output Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Security Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Input Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:01:07 --> Language Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Loader Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Controller Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Session Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:01:07 --> Session routines successfully run
DEBUG - 2019-04-27 13:01:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:01:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:01:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:01:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:01:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:01:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:01:07 --> Final output sent to browser
DEBUG - 2019-04-27 13:01:07 --> Total execution time: 0.0555
DEBUG - 2019-04-27 13:01:47 --> Config Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:01:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:01:47 --> URI Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Router Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Output Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Security Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Input Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:01:47 --> Language Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Loader Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Controller Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Session Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:01:47 --> Session routines successfully run
DEBUG - 2019-04-27 13:01:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:01:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:01:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:01:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:01:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:01:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:01:47 --> Final output sent to browser
DEBUG - 2019-04-27 13:01:47 --> Total execution time: 0.0591
DEBUG - 2019-04-27 13:01:49 --> Config Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:01:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:01:49 --> URI Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Router Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Output Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Security Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Input Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:01:49 --> Language Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Loader Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Controller Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Session Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:01:49 --> Session routines successfully run
DEBUG - 2019-04-27 13:01:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:01:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:01:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:01:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:01:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:01:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:01:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:01:49 --> Final output sent to browser
DEBUG - 2019-04-27 13:01:49 --> Total execution time: 0.0700
DEBUG - 2019-04-27 13:02:54 --> Config Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:02:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:02:54 --> URI Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Router Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Output Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Security Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Input Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:02:54 --> Language Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Loader Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Controller Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Model Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Model Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Session Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:02:54 --> Session routines successfully run
DEBUG - 2019-04-27 13:02:54 --> Model Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Model Class Initialized
DEBUG - 2019-04-27 13:02:54 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:02:54 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:02:54 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:02:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:02:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:02:54 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:02:54 --> Final output sent to browser
DEBUG - 2019-04-27 13:02:54 --> Total execution time: 0.1113
DEBUG - 2019-04-27 13:03:08 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:08 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:08 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:08 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:08 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:08 --> Total execution time: 0.0766
DEBUG - 2019-04-27 13:03:08 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:08 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:08 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:08 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:08 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:08 --> Total execution time: 0.0559
DEBUG - 2019-04-27 13:03:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:10 --> Total execution time: 0.0635
DEBUG - 2019-04-27 13:03:20 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:20 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:20 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:20 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:20 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:20 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:20 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:20 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:20 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:20 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:20 --> Total execution time: 0.0602
DEBUG - 2019-04-27 13:03:21 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:21 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:21 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:21 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:21 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:21 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:21 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:21 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:21 --> Total execution time: 0.0592
DEBUG - 2019-04-27 13:03:28 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:28 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:28 --> No URI present. Default controller set.
DEBUG - 2019-04-27 13:03:28 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:28 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:28 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:03:29 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:29 --> Total execution time: 0.1061
DEBUG - 2019-04-27 13:03:30 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:30 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:30 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:30 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:30 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:30 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:30 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:30 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:30 --> Total execution time: 0.0537
DEBUG - 2019-04-27 13:03:50 --> Config Class Initialized
DEBUG - 2019-04-27 13:03:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:03:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:03:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:03:50 --> URI Class Initialized
DEBUG - 2019-04-27 13:03:50 --> Router Class Initialized
DEBUG - 2019-04-27 13:03:50 --> Output Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Security Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Input Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:03:51 --> Language Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Loader Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Controller Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Session Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:03:51 --> Session routines successfully run
DEBUG - 2019-04-27 13:03:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:03:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:03:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:03:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:03:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:03:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:03:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:03:51 --> Final output sent to browser
DEBUG - 2019-04-27 13:03:51 --> Total execution time: 0.0732
DEBUG - 2019-04-27 13:04:09 --> Config Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:04:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:04:09 --> URI Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Router Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Output Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Security Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Input Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:04:09 --> Language Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Loader Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Controller Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Session Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:04:09 --> Session routines successfully run
DEBUG - 2019-04-27 13:04:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:04:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:04:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:04:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:04:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:04:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:04:09 --> Final output sent to browser
DEBUG - 2019-04-27 13:04:09 --> Total execution time: 0.0848
DEBUG - 2019-04-27 13:04:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:04:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:04:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:04:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:04:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:04:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:04:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:04:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:04:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:04:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:04:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:04:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:04:10 --> Total execution time: 0.0452
DEBUG - 2019-04-27 13:05:09 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:09 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:09 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:09 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:09 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:09 --> Total execution time: 0.0721
DEBUG - 2019-04-27 13:05:17 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:17 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:17 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:17 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:17 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:17 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:17 --> Total execution time: 0.0670
DEBUG - 2019-04-27 13:05:18 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:18 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:18 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:18 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:18 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:18 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:18 --> Total execution time: 0.0567
DEBUG - 2019-04-27 13:05:25 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:25 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:25 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:25 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:25 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:25 --> Total execution time: 0.0557
DEBUG - 2019-04-27 13:05:26 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:26 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:26 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:26 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:26 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:26 --> Total execution time: 0.0627
DEBUG - 2019-04-27 13:05:49 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:49 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:49 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:49 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:49 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:49 --> Total execution time: 0.0505
DEBUG - 2019-04-27 13:05:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:56 --> No URI present. Default controller set.
DEBUG - 2019-04-27 13:05:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:56 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:56 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:56 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:05:56 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:56 --> Total execution time: 0.1098
DEBUG - 2019-04-27 13:05:58 --> Config Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:05:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:05:58 --> URI Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Router Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Output Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Security Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Input Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:05:58 --> Language Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Loader Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Controller Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Session Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:05:58 --> Session routines successfully run
DEBUG - 2019-04-27 13:05:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:05:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:05:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:05:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:05:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:05:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:05:58 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:05:58 --> Final output sent to browser
DEBUG - 2019-04-27 13:05:58 --> Total execution time: 0.0672
DEBUG - 2019-04-27 13:06:44 --> Config Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:06:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:06:44 --> URI Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Router Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Output Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Security Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Input Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:06:44 --> Language Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Loader Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Controller Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Session Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:06:44 --> Session routines successfully run
DEBUG - 2019-04-27 13:06:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:06:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:06:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:06:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:06:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:06:44 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:06:44 --> Final output sent to browser
DEBUG - 2019-04-27 13:06:44 --> Total execution time: 0.0724
DEBUG - 2019-04-27 13:06:45 --> Config Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:06:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:06:45 --> URI Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Router Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Output Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Security Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Input Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:06:45 --> Language Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Loader Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Controller Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Session Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:06:45 --> Session routines successfully run
DEBUG - 2019-04-27 13:06:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:06:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:06:45 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:06:45 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:06:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:06:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:06:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:06:45 --> Final output sent to browser
DEBUG - 2019-04-27 13:06:45 --> Total execution time: 0.0541
DEBUG - 2019-04-27 13:07:17 --> Config Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:07:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:07:17 --> URI Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Router Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Output Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Security Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Input Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:07:17 --> Language Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Loader Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Controller Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Session Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:07:17 --> Session routines successfully run
DEBUG - 2019-04-27 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:07:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:07:17 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:07:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:07:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:07:17 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:07:17 --> Final output sent to browser
DEBUG - 2019-04-27 13:07:17 --> Total execution time: 0.0612
DEBUG - 2019-04-27 13:07:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:07:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:07:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:07:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:07:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:07:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:07:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:07:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:07:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:07:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:07:34 --> Final output sent to browser
DEBUG - 2019-04-27 13:07:34 --> Total execution time: 0.0511
DEBUG - 2019-04-27 13:07:35 --> Config Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:07:35 --> URI Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Router Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Output Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Security Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Input Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:07:35 --> Language Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Loader Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Controller Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Session Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:07:35 --> Session routines successfully run
DEBUG - 2019-04-27 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:07:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:07:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:07:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:07:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:07:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:07:35 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:07:35 --> Final output sent to browser
DEBUG - 2019-04-27 13:07:35 --> Total execution time: 0.0563
DEBUG - 2019-04-27 13:08:19 --> Config Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:08:19 --> URI Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Router Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Output Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Security Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Input Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:08:19 --> Language Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Loader Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Controller Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Session Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:08:19 --> Session routines successfully run
DEBUG - 2019-04-27 13:08:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:08:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:08:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:08:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:08:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:08:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:08:19 --> Final output sent to browser
DEBUG - 2019-04-27 13:08:19 --> Total execution time: 0.1431
DEBUG - 2019-04-27 13:08:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:08:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:08:34 --> No URI present. Default controller set.
DEBUG - 2019-04-27 13:08:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:08:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:08:34 --> A session cookie was not found.
DEBUG - 2019-04-27 13:08:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:08:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:08:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:08:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:08:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:08:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:08:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:08:34 --> Final output sent to browser
DEBUG - 2019-04-27 13:08:34 --> Total execution time: 0.1649
DEBUG - 2019-04-27 13:08:36 --> Config Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:08:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:08:36 --> URI Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Router Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Output Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Security Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Input Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:08:36 --> Language Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Loader Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Controller Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Session Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:08:36 --> Session routines successfully run
DEBUG - 2019-04-27 13:08:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:08:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:08:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:08:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:08:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:08:36 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:08:36 --> Final output sent to browser
DEBUG - 2019-04-27 13:08:36 --> Total execution time: 0.0642
DEBUG - 2019-04-27 13:08:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:08:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:08:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:08:52 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:08:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:08:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:08:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:08:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:08:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:08:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:08:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:08:52 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:08:52 --> Final output sent to browser
DEBUG - 2019-04-27 13:08:52 --> Total execution time: 0.0636
DEBUG - 2019-04-27 13:09:11 --> Config Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:09:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:09:11 --> URI Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Router Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Output Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Security Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Input Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:09:11 --> Language Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Loader Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Controller Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Session Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:09:11 --> Session routines successfully run
DEBUG - 2019-04-27 13:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:09:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:09:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:09:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:09:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:09:11 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:09:11 --> Final output sent to browser
DEBUG - 2019-04-27 13:09:11 --> Total execution time: 0.0487
DEBUG - 2019-04-27 13:09:21 --> Config Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:09:21 --> URI Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Router Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Output Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Security Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Input Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:09:21 --> Language Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Loader Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Controller Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Session Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:09:21 --> Session routines successfully run
DEBUG - 2019-04-27 13:09:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:21 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:09:21 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:09:21 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:09:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:09:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:09:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:09:21 --> Final output sent to browser
DEBUG - 2019-04-27 13:09:21 --> Total execution time: 0.0784
DEBUG - 2019-04-27 13:09:22 --> Config Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:09:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:09:22 --> URI Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Router Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Output Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Security Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Input Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:09:22 --> Language Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Loader Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Controller Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Session Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:09:22 --> Session routines successfully run
DEBUG - 2019-04-27 13:09:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:09:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:09:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:09:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:09:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:09:22 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:09:22 --> Final output sent to browser
DEBUG - 2019-04-27 13:09:22 --> Total execution time: 0.0616
DEBUG - 2019-04-27 13:09:41 --> Config Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:09:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:09:41 --> URI Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Router Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Output Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Security Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Input Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:09:41 --> Language Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Loader Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Controller Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Session Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:09:41 --> Session routines successfully run
DEBUG - 2019-04-27 13:09:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:09:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:09:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:09:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:09:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:09:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:09:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:09:41 --> Final output sent to browser
DEBUG - 2019-04-27 13:09:41 --> Total execution time: 0.0561
DEBUG - 2019-04-27 13:10:02 --> Config Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:10:02 --> URI Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Router Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Output Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Security Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Input Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:10:02 --> Language Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Loader Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Controller Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Session Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:10:02 --> Session routines successfully run
DEBUG - 2019-04-27 13:10:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:10:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:10:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:10:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:10:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:10:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:10:02 --> Final output sent to browser
DEBUG - 2019-04-27 13:10:02 --> Total execution time: 0.0654
DEBUG - 2019-04-27 13:10:30 --> Config Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:10:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:10:30 --> URI Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Router Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Output Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Security Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Input Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:10:30 --> Language Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Loader Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Controller Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Session Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:10:30 --> Session routines successfully run
DEBUG - 2019-04-27 13:10:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:30 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:10:30 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:10:30 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:10:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:10:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:10:30 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:10:30 --> Final output sent to browser
DEBUG - 2019-04-27 13:10:30 --> Total execution time: 0.0600
DEBUG - 2019-04-27 13:10:39 --> Config Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:10:39 --> URI Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Router Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Output Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Security Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Input Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:10:39 --> Language Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Loader Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Controller Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Session Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:10:39 --> Session routines successfully run
DEBUG - 2019-04-27 13:10:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:39 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:10:39 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:10:39 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:10:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:10:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:10:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:10:39 --> Final output sent to browser
DEBUG - 2019-04-27 13:10:39 --> Total execution time: 0.0656
DEBUG - 2019-04-27 13:10:47 --> Config Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:10:47 --> URI Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Router Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Output Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Security Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Input Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:10:47 --> Language Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Loader Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Controller Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Session Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:10:47 --> Session routines successfully run
DEBUG - 2019-04-27 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:10:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:10:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:10:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:10:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:10:47 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:10:47 --> Final output sent to browser
DEBUG - 2019-04-27 13:10:47 --> Total execution time: 0.0547
DEBUG - 2019-04-27 13:10:54 --> Config Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:10:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:10:54 --> URI Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Router Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Output Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Security Class Initialized
DEBUG - 2019-04-27 13:10:54 --> Input Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:10:55 --> Language Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Loader Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Controller Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Session Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:10:55 --> Session routines successfully run
DEBUG - 2019-04-27 13:10:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:10:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:10:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:10:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:10:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:10:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:10:55 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:10:55 --> Final output sent to browser
DEBUG - 2019-04-27 13:10:55 --> Total execution time: 0.0652
DEBUG - 2019-04-27 13:11:39 --> Config Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:11:39 --> URI Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Router Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Output Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Security Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Input Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:11:39 --> Language Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Loader Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Controller Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Session Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:11:39 --> Session routines successfully run
DEBUG - 2019-04-27 13:11:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:39 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:11:39 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:11:39 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:11:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:11:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:11:39 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:11:39 --> Final output sent to browser
DEBUG - 2019-04-27 13:11:39 --> Total execution time: 0.0731
DEBUG - 2019-04-27 13:11:40 --> Config Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:11:40 --> URI Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Router Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Output Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Security Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Input Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:11:40 --> Language Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Loader Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Controller Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Session Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:11:40 --> Session routines successfully run
DEBUG - 2019-04-27 13:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:11:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:11:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:11:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:11:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:11:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:11:40 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:11:40 --> Final output sent to browser
DEBUG - 2019-04-27 13:11:40 --> Total execution time: 0.0688
DEBUG - 2019-04-27 13:14:26 --> Config Class Initialized
DEBUG - 2019-04-27 13:14:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:14:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:14:27 --> URI Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Router Class Initialized
DEBUG - 2019-04-27 13:14:27 --> No URI present. Default controller set.
DEBUG - 2019-04-27 13:14:27 --> Output Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Security Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Input Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:14:27 --> Language Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Loader Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Controller Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Session Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:14:27 --> A session cookie was not found.
DEBUG - 2019-04-27 13:14:27 --> Session routines successfully run
DEBUG - 2019-04-27 13:14:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:14:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:14:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:14:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:14:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:14:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:14:27 --> Final output sent to browser
DEBUG - 2019-04-27 13:14:27 --> Total execution time: 0.2043
DEBUG - 2019-04-27 13:14:29 --> Config Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:14:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:14:29 --> URI Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Router Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Output Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Security Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Input Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:14:29 --> Language Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Loader Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Controller Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Session Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:14:29 --> Session routines successfully run
DEBUG - 2019-04-27 13:14:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:14:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:14:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:14:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:14:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:14:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:14:29 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:14:29 --> Final output sent to browser
DEBUG - 2019-04-27 13:14:29 --> Total execution time: 0.0465
DEBUG - 2019-04-27 13:15:06 --> Config Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:15:06 --> URI Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Router Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Output Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Security Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Input Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:15:06 --> Language Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Loader Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Controller Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Session Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:15:06 --> Session routines successfully run
DEBUG - 2019-04-27 13:15:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:06 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:15:06 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:15:06 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:15:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:15:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:15:06 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:15:06 --> Final output sent to browser
DEBUG - 2019-04-27 13:15:06 --> Total execution time: 0.0662
DEBUG - 2019-04-27 13:15:15 --> Config Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:15:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:15:15 --> URI Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Router Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Output Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Security Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Input Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:15:15 --> Language Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Loader Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Controller Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Session Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:15:15 --> Session routines successfully run
DEBUG - 2019-04-27 13:15:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:15 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:15:15 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:15:15 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:15:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:15:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:15:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:15:15 --> Final output sent to browser
DEBUG - 2019-04-27 13:15:15 --> Total execution time: 0.0738
DEBUG - 2019-04-27 13:15:26 --> Config Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:15:26 --> URI Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Router Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Output Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Security Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Input Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:15:26 --> Language Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Loader Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Controller Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Session Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:15:26 --> Session routines successfully run
DEBUG - 2019-04-27 13:15:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:15:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:15:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:15:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:15:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:15:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:15:26 --> Final output sent to browser
DEBUG - 2019-04-27 13:15:26 --> Total execution time: 0.0552
DEBUG - 2019-04-27 13:15:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:15:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:15:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:15:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:15:57 --> Session Class Initialized
DEBUG - 2019-04-27 13:15:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:15:57 --> Session routines successfully run
DEBUG - 2019-04-27 13:15:57 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:57 --> Model Class Initialized
DEBUG - 2019-04-27 13:15:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:15:57 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:15:57 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:15:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:15:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:15:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:15:57 --> Final output sent to browser
DEBUG - 2019-04-27 13:15:57 --> Total execution time: 0.0611
DEBUG - 2019-04-27 13:16:43 --> Config Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:16:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:16:43 --> URI Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Router Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Output Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Security Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Input Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:16:43 --> Language Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Loader Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Controller Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Session Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:16:43 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:16:43 --> Session routines successfully run
DEBUG - 2019-04-27 13:16:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:16:43 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:16:43 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:16:43 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:16:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:16:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:16:43 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:16:43 --> Final output sent to browser
DEBUG - 2019-04-27 13:16:43 --> Total execution time: 0.0641
DEBUG - 2019-04-27 13:17:18 --> Config Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:17:18 --> URI Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Router Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Output Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Security Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Input Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:17:18 --> Language Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Loader Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Controller Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Session Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:17:18 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:17:18 --> Session routines successfully run
DEBUG - 2019-04-27 13:17:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:17:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:17:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Config Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:17:28 --> URI Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Router Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Output Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Security Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Input Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:17:28 --> Language Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Loader Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Controller Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Session Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:17:28 --> Session routines successfully run
DEBUG - 2019-04-27 13:17:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:17:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:17:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:17:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:17:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:17:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:17:28 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:17:28 --> Final output sent to browser
DEBUG - 2019-04-27 13:17:28 --> Total execution time: 0.0601
DEBUG - 2019-04-27 13:18:24 --> Config Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:18:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:18:24 --> URI Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Router Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Output Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Security Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Input Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:18:24 --> Language Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Loader Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Controller Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Session Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:18:24 --> Session routines successfully run
DEBUG - 2019-04-27 13:18:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:18:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:18:24 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:18:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:18:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:18:24 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:18:24 --> Final output sent to browser
DEBUG - 2019-04-27 13:18:24 --> Total execution time: 0.0691
DEBUG - 2019-04-27 13:18:26 --> Config Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:18:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:18:26 --> URI Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Router Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Output Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Security Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Input Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:18:26 --> Language Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Loader Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Controller Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Session Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:18:26 --> Session routines successfully run
DEBUG - 2019-04-27 13:18:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:18:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:18:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:18:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:22:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:22:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:22:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:22:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:22:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:22:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:22:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:22:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:22:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:22:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:24:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:24:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:24:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:24:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:24:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:24:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:24:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:25:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:25:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:25:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:25:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:25:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:25:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:25:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:25:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:21 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:21 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:21 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:21 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:21 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:21 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:27:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:27:21 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:27:21 --> Final output sent to browser
DEBUG - 2019-04-27 13:27:21 --> Total execution time: 0.0677
DEBUG - 2019-04-27 13:27:24 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:24 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:24 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:24 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:24 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:44 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:44 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:44 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:27:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:27:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:27:44 --> Final output sent to browser
DEBUG - 2019-04-27 13:27:44 --> Total execution time: 0.1681
DEBUG - 2019-04-27 13:27:49 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:49 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:49 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:49 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:27:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:27:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:27:49 --> Final output sent to browser
DEBUG - 2019-04-27 13:27:49 --> Total execution time: 0.0638
DEBUG - 2019-04-27 13:27:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:27:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:27:52 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-27 13:27:52 --> Final output sent to browser
DEBUG - 2019-04-27 13:27:52 --> Total execution time: 0.0647
DEBUG - 2019-04-27 13:27:59 --> Config Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:27:59 --> URI Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Router Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Output Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Security Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Input Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:27:59 --> Language Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Loader Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Controller Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Session Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:27:59 --> Session routines successfully run
DEBUG - 2019-04-27 13:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 13:27:59 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:27:59 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:27:59 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:27:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:27:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:27:59 --> File loaded: application/views/producers.php
DEBUG - 2019-04-27 13:27:59 --> Final output sent to browser
DEBUG - 2019-04-27 13:27:59 --> Total execution time: 0.0464
DEBUG - 2019-04-27 13:30:23 --> Config Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:30:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:30:23 --> URI Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Router Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Output Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Security Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Input Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:30:23 --> Language Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Loader Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Controller Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Session Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:30:23 --> Session routines successfully run
DEBUG - 2019-04-27 13:30:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:30:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:30:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:30:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:30:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:30:23 --> File loaded: application/views/producers.php
DEBUG - 2019-04-27 13:30:23 --> Final output sent to browser
DEBUG - 2019-04-27 13:30:23 --> Total execution time: 0.0691
DEBUG - 2019-04-27 13:30:25 --> Config Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:30:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:30:25 --> URI Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Router Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Output Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Security Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Input Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:30:25 --> Language Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Loader Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Controller Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Session Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:30:25 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:30:25 --> Session routines successfully run
DEBUG - 2019-04-27 13:30:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:30:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:30:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:30:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:30:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:30:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:30:25 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:30:25 --> Final output sent to browser
DEBUG - 2019-04-27 13:30:25 --> Total execution time: 0.0703
DEBUG - 2019-04-27 13:31:40 --> Config Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:31:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:31:40 --> URI Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Router Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Output Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Security Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Input Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:31:40 --> Language Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Loader Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Controller Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Session Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:31:40 --> Session routines successfully run
DEBUG - 2019-04-27 13:31:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Model Class Initialized
DEBUG - 2019-04-27 13:31:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:31:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:31:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:31:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:31:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:31:40 --> File loaded: application/views/producers.php
DEBUG - 2019-04-27 13:31:40 --> Final output sent to browser
DEBUG - 2019-04-27 13:31:40 --> Total execution time: 0.0812
DEBUG - 2019-04-27 13:35:04 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:04 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:04 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:04 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:04 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:04 --> File loaded: application/views/producers.php
DEBUG - 2019-04-27 13:35:04 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:04 --> Total execution time: 0.0994
DEBUG - 2019-04-27 13:35:05 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:05 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:05 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:05 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:05 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:05 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:05 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:05 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:05 --> File loaded: application/views/insertUser.php
DEBUG - 2019-04-27 13:35:05 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:05 --> Total execution time: 0.0643
DEBUG - 2019-04-27 13:35:11 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:11 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:11 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:11 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:35:11 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:11 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 13:35:11 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:11 --> Total execution time: 0.0653
DEBUG - 2019-04-27 13:35:25 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:25 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:25 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:25 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:25 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:35:25 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:25 --> Total execution time: 0.1910
DEBUG - 2019-04-27 13:35:29 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:29 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:29 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:29 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:35:29 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:29 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:35:29 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:29 --> Total execution time: 0.0702
DEBUG - 2019-04-27 13:35:31 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:31 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:31 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:31 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:31 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:35:31 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:31 --> Total execution time: 0.0454
DEBUG - 2019-04-27 13:35:33 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:33 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:33 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:33 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:33 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:33 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:33 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:33 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:35:33 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:33 --> Total execution time: 0.1607
DEBUG - 2019-04-27 13:35:42 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:42 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:42 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:42 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:35:42 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:42 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:42 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:42 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:42 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:42 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:35:42 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:42 --> Total execution time: 0.1102
DEBUG - 2019-04-27 13:35:43 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:43 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:43 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:43 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:43 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:43 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:43 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:43 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 13:35:43 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:43 --> Total execution time: 0.0566
DEBUG - 2019-04-27 13:35:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:35:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:35:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:35:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:35:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:35:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:35:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:35:52 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:35:52 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:35:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:35:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:35:52 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 13:35:52 --> Final output sent to browser
DEBUG - 2019-04-27 13:35:52 --> Total execution time: 0.0849
DEBUG - 2019-04-27 13:36:01 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:01 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:01 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:01 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:36:01 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:36:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:01 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:01 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:01 --> A session cookie was not found.
DEBUG - 2019-04-27 13:36:01 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:36:01 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:36:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:36:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:36:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:36:01 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:36:01 --> Final output sent to browser
DEBUG - 2019-04-27 13:36:01 --> Total execution time: 0.1394
DEBUG - 2019-04-27 13:36:02 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:02 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:02 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:02 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:36:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:36:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:36:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:36:02 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 13:36:02 --> Final output sent to browser
DEBUG - 2019-04-27 13:36:02 --> Total execution time: 0.0681
DEBUG - 2019-04-27 13:36:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:36:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:36:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:36:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:36:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:36:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:36:10 --> Total execution time: 0.1723
DEBUG - 2019-04-27 13:36:17 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:17 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:17 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:17 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:36:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:36:17 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:36:17 --> Final output sent to browser
DEBUG - 2019-04-27 13:36:17 --> Total execution time: 0.0597
DEBUG - 2019-04-27 13:36:57 --> Config Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:36:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:36:57 --> URI Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Router Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Output Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Security Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Input Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:36:57 --> Language Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Loader Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Controller Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Model Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Session Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:36:57 --> Session routines successfully run
DEBUG - 2019-04-27 13:36:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:36:57 --> Upload Class Initialized
DEBUG - 2019-04-27 13:36:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2019-04-27 13:36:57 --> You did not select a file to upload.
DEBUG - 2019-04-27 13:36:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:36:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:36:57 --> File loaded: application/views/msgpage.php
DEBUG - 2019-04-27 13:37:31 --> Config Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:37:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:37:31 --> URI Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Router Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Output Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Security Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Input Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:37:31 --> Language Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Loader Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Controller Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Session Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:37:31 --> Session routines successfully run
DEBUG - 2019-04-27 13:37:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:37:31 --> Upload Class Initialized
DEBUG - 2019-04-27 13:37:31 --> Image Lib Class Initialized
DEBUG - 2019-04-27 13:37:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:37:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:37:31 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:37:31 --> Final output sent to browser
DEBUG - 2019-04-27 13:37:31 --> Total execution time: 0.2450
DEBUG - 2019-04-27 13:37:53 --> Config Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:37:53 --> URI Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Router Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Output Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Security Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Input Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:37:53 --> Language Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Loader Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Controller Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Session Class Initialized
DEBUG - 2019-04-27 13:37:53 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:37:53 --> Session routines successfully run
DEBUG - 2019-04-27 13:37:53 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:37:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:37:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:37:53 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-27 13:37:53 --> Final output sent to browser
DEBUG - 2019-04-27 13:37:53 --> Total execution time: 0.0896
DEBUG - 2019-04-27 13:38:00 --> Config Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:38:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:38:00 --> URI Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Router Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Output Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Security Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Input Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:38:00 --> Language Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Loader Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Controller Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Session Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:38:00 --> Session routines successfully run
DEBUG - 2019-04-27 13:38:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:38:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:38:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:38:01 --> File loaded: application/views/header.php
ERROR - 2019-04-27 13:38:01 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-27 13:38:01 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-27 13:38:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:38:01 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:38:01 --> Final output sent to browser
DEBUG - 2019-04-27 13:38:01 --> Total execution time: 0.1365
DEBUG - 2019-04-27 13:38:09 --> Config Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:38:09 --> URI Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Router Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Output Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Security Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Input Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:38:09 --> Language Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Loader Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Controller Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Session Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:38:09 --> Session routines successfully run
DEBUG - 2019-04-27 13:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:38:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:38:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:38:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:38:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:38:09 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:38:09 --> Final output sent to browser
DEBUG - 2019-04-27 13:38:09 --> Total execution time: 0.0804
DEBUG - 2019-04-27 13:38:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:38:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:38:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:38:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:38:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:38:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:38:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:38:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:38:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:38:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:38:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:38:10 --> Total execution time: 0.1159
DEBUG - 2019-04-27 13:38:24 --> Config Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:38:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:38:24 --> URI Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Router Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Output Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Security Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Input Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:38:24 --> Language Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Loader Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Controller Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Session Class Initialized
DEBUG - 2019-04-27 13:38:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:38:24 --> Session routines successfully run
DEBUG - 2019-04-27 13:38:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:38:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:38:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:38:24 --> File loaded: application/views/insertNotice.php
DEBUG - 2019-04-27 13:38:24 --> Final output sent to browser
DEBUG - 2019-04-27 13:38:24 --> Total execution time: 0.0648
DEBUG - 2019-04-27 13:38:45 --> Config Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:38:45 --> URI Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Router Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Output Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Security Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Input Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:38:45 --> Language Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Loader Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Controller Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Session Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:38:45 --> Session routines successfully run
DEBUG - 2019-04-27 13:38:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:38:45 --> Upload Class Initialized
DEBUG - 2019-04-27 13:38:45 --> Image Lib Class Initialized
DEBUG - 2019-04-27 13:38:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:38:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:38:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:38:45 --> Final output sent to browser
DEBUG - 2019-04-27 13:38:45 --> Total execution time: 0.1982
DEBUG - 2019-04-27 13:39:04 --> Config Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:39:04 --> URI Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Router Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Output Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Security Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Input Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:39:04 --> Language Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Loader Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Controller Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Session Class Initialized
DEBUG - 2019-04-27 13:39:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:39:04 --> Session routines successfully run
DEBUG - 2019-04-27 13:39:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:39:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:39:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:39:04 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:39:04 --> Final output sent to browser
DEBUG - 2019-04-27 13:39:04 --> Total execution time: 0.2245
DEBUG - 2019-04-27 13:39:12 --> Config Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:39:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:39:12 --> URI Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Router Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Output Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Security Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Input Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:39:12 --> Language Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Loader Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Controller Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Session Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:39:12 --> Session routines successfully run
DEBUG - 2019-04-27 13:39:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:39:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:39:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:39:12 --> File loaded: application/views/header.php
ERROR - 2019-04-27 13:39:12 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-27 13:39:12 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-27 13:39:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:39:12 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:39:12 --> Final output sent to browser
DEBUG - 2019-04-27 13:39:12 --> Total execution time: 0.1853
DEBUG - 2019-04-27 13:39:23 --> Config Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:39:23 --> URI Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Router Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Output Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Security Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Input Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:39:23 --> Language Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Loader Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Controller Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Session Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:39:23 --> Session routines successfully run
DEBUG - 2019-04-27 13:39:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:39:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:39:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:39:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:39:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:39:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:39:23 --> Final output sent to browser
DEBUG - 2019-04-27 13:39:23 --> Total execution time: 0.0848
DEBUG - 2019-04-27 13:39:53 --> Config Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:39:53 --> URI Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Router Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Output Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Security Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Input Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:39:53 --> Language Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Loader Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Controller Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Session Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:39:53 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:39:53 --> Session routines successfully run
DEBUG - 2019-04-27 13:39:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Model Class Initialized
DEBUG - 2019-04-27 13:39:53 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:39:53 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:39:53 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:39:53 --> File loaded: application/views/header.php
ERROR - 2019-04-27 13:39:53 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
ERROR - 2019-04-27 13:39:53 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 24
DEBUG - 2019-04-27 13:39:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:39:53 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:39:53 --> Final output sent to browser
DEBUG - 2019-04-27 13:39:53 --> Total execution time: 0.1010
DEBUG - 2019-04-27 13:40:27 --> Config Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:40:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:40:27 --> URI Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Router Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Output Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Security Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Input Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:40:27 --> Language Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Loader Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Controller Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Session Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:40:27 --> Session routines successfully run
DEBUG - 2019-04-27 13:40:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:40:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:40:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:40:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:40:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:40:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:40:27 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:40:27 --> Final output sent to browser
DEBUG - 2019-04-27 13:40:27 --> Total execution time: 0.0772
DEBUG - 2019-04-27 13:41:13 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:13 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:13 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:13 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:13 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:13 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:41:13 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:13 --> Total execution time: 0.2660
DEBUG - 2019-04-27 13:41:23 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:23 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:23 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:23 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:23 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:41:23 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:23 --> Total execution time: 0.0713
DEBUG - 2019-04-27 13:41:24 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:24 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:24 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:24 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:24 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:24 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:41:24 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:24 --> Total execution time: 0.1055
DEBUG - 2019-04-27 13:41:35 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:35 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:35 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:35 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:35 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 13:41:35 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:35 --> Total execution time: 0.0898
DEBUG - 2019-04-27 13:41:41 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:41 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:41 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:41 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:41 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 13:41:41 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:41 --> Total execution time: 0.0570
DEBUG - 2019-04-27 13:41:46 --> Config Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:41:46 --> URI Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Router Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Output Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Security Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Input Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:41:46 --> Language Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Loader Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Controller Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Session Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:41:46 --> Session routines successfully run
DEBUG - 2019-04-27 13:41:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:41:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:41:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:41:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:41:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:41:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:41:46 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:41:46 --> Final output sent to browser
DEBUG - 2019-04-27 13:41:46 --> Total execution time: 0.1119
DEBUG - 2019-04-27 13:43:27 --> Config Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:43:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:43:27 --> URI Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Router Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Output Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Security Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Input Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:43:27 --> Language Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Loader Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Controller Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Session Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:43:27 --> Session routines successfully run
DEBUG - 2019-04-27 13:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:43:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:43:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:43:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:43:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:43:27 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:43:27 --> Final output sent to browser
DEBUG - 2019-04-27 13:43:27 --> Total execution time: 0.2977
DEBUG - 2019-04-27 13:43:28 --> Config Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:43:28 --> URI Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Router Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Output Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Security Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Input Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:43:28 --> Language Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Loader Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Controller Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Session Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:43:28 --> Session routines successfully run
DEBUG - 2019-04-27 13:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:43:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:43:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:43:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:43:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:43:28 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:43:28 --> Final output sent to browser
DEBUG - 2019-04-27 13:43:28 --> Total execution time: 0.1271
DEBUG - 2019-04-27 13:43:49 --> Config Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:43:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:43:49 --> URI Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Router Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Output Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Security Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Input Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:43:49 --> Language Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Loader Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Controller Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Session Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:43:49 --> Session routines successfully run
DEBUG - 2019-04-27 13:43:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:43:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:43:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:43:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:43:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:43:49 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:43:49 --> Final output sent to browser
DEBUG - 2019-04-27 13:43:49 --> Total execution time: 0.0948
DEBUG - 2019-04-27 13:43:50 --> Config Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:43:50 --> URI Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Router Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Output Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Security Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Input Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:43:50 --> Language Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Loader Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Controller Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Session Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:43:50 --> Session routines successfully run
DEBUG - 2019-04-27 13:43:50 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Model Class Initialized
DEBUG - 2019-04-27 13:43:50 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:43:50 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:43:50 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:43:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:43:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:43:50 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:43:50 --> Final output sent to browser
DEBUG - 2019-04-27 13:43:50 --> Total execution time: 0.1081
DEBUG - 2019-04-27 13:44:19 --> Config Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:44:19 --> URI Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Router Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Output Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Security Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Input Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:44:19 --> Language Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Loader Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Controller Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Session Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:44:19 --> Session routines successfully run
DEBUG - 2019-04-27 13:44:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:44:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:44:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:44:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:44:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:44:19 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:44:19 --> Final output sent to browser
DEBUG - 2019-04-27 13:44:19 --> Total execution time: 0.1293
DEBUG - 2019-04-27 13:44:37 --> Config Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:44:37 --> URI Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Router Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Output Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Security Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Input Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:44:37 --> Language Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Loader Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Controller Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Session Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:44:37 --> Session routines successfully run
DEBUG - 2019-04-27 13:44:37 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:37 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:44:37 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:44:37 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:44:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:44:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:44:37 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:44:37 --> Final output sent to browser
DEBUG - 2019-04-27 13:44:37 --> Total execution time: 0.0828
DEBUG - 2019-04-27 13:44:55 --> Config Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:44:55 --> URI Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Router Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Output Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Security Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Input Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:44:55 --> Language Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Loader Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Controller Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Session Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:44:55 --> Session routines successfully run
DEBUG - 2019-04-27 13:44:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:44:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:44:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:44:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:44:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:44:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:44:55 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:44:55 --> Final output sent to browser
DEBUG - 2019-04-27 13:44:55 --> Total execution time: 0.1191
DEBUG - 2019-04-27 13:45:03 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:03 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:03 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:03 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:03 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:03 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:03 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:03 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:45:03 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:03 --> Total execution time: 0.0997
DEBUG - 2019-04-27 13:45:08 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:08 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:08 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:08 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:45:08 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:08 --> Total execution time: 0.0719
DEBUG - 2019-04-27 13:45:08 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:08 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:08 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:08 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:08 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:45:08 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:08 --> Total execution time: 0.0590
DEBUG - 2019-04-27 13:45:09 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:09 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:09 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:09 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:09 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:45:09 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:09 --> Total execution time: 0.1028
DEBUG - 2019-04-27 13:45:22 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:22 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:22 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:22 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:22 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:22 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:22 --> A session cookie was not found.
DEBUG - 2019-04-27 13:45:22 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:45:22 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:22 --> Total execution time: 0.1289
DEBUG - 2019-04-27 13:45:25 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:25 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:25 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:25 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:25 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 13:45:25 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:25 --> Total execution time: 0.0484
DEBUG - 2019-04-27 13:45:32 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:32 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:32 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:32 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:45:32 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:32 --> Total execution time: 0.1123
DEBUG - 2019-04-27 13:45:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:45:34 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:34 --> Total execution time: 0.0741
DEBUG - 2019-04-27 13:45:35 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:35 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:35 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:36 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:36 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:36 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:45:36 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:36 --> Total execution time: 0.1002
DEBUG - 2019-04-27 13:45:55 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:55 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:55 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:55 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:55 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:45:55 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:55 --> Total execution time: 0.1165
DEBUG - 2019-04-27 13:45:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:56 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:56 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:56 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:56 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:45:56 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:56 --> Total execution time: 0.1008
DEBUG - 2019-04-27 13:45:58 --> Config Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:45:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:45:58 --> URI Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Router Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Output Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Security Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Input Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:45:58 --> Language Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Loader Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Controller Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Session Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:45:58 --> Session routines successfully run
DEBUG - 2019-04-27 13:45:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:45:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:45:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:45:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:45:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:45:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:45:58 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:45:58 --> Final output sent to browser
DEBUG - 2019-04-27 13:45:58 --> Total execution time: 0.1669
DEBUG - 2019-04-27 13:46:09 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:09 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:09 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:09 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:09 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:46:09 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:09 --> Total execution time: 0.0816
DEBUG - 2019-04-27 13:46:19 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:19 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:19 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:19 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:46:19 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:19 --> Total execution time: 0.0752
DEBUG - 2019-04-27 13:46:23 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:23 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:23 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:23 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:23 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:23 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:23 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:23 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:46:23 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:23 --> Total execution time: 0.0699
DEBUG - 2019-04-27 13:46:26 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:26 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:26 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:26 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:26 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 13:46:26 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:26 --> Total execution time: 0.0941
DEBUG - 2019-04-27 13:46:28 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:28 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:28 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:28 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:28 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 13:46:28 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:28 --> Total execution time: 0.0659
DEBUG - 2019-04-27 13:46:33 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:33 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:33 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:33 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:33 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:33 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:33 --> A session cookie was not found.
DEBUG - 2019-04-27 13:46:33 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:46:33 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:33 --> Total execution time: 0.1191
DEBUG - 2019-04-27 13:46:35 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:35 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:35 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:35 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:35 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 13:46:35 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:35 --> Total execution time: 0.0642
DEBUG - 2019-04-27 13:46:45 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:45 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:45 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:45 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:45 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:46:45 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:46:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:45 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:46:45 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:45 --> Total execution time: 0.1243
DEBUG - 2019-04-27 13:46:48 --> Config Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:46:48 --> URI Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Router Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Output Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Security Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Input Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:46:48 --> Language Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Loader Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Controller Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Model Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Session Class Initialized
DEBUG - 2019-04-27 13:46:48 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:46:48 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:46:48 --> Session routines successfully run
DEBUG - 2019-04-27 13:46:48 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:46:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:46:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:46:48 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:46:48 --> Final output sent to browser
DEBUG - 2019-04-27 13:46:48 --> Total execution time: 0.0515
DEBUG - 2019-04-27 13:47:52 --> Config Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:47:52 --> URI Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Router Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Output Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Security Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Input Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:47:52 --> Language Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Loader Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Controller Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Session Class Initialized
DEBUG - 2019-04-27 13:47:52 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:47:52 --> Session routines successfully run
DEBUG - 2019-04-27 13:47:52 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:47:52 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:47:52 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:47:52 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:47:52 --> Final output sent to browser
DEBUG - 2019-04-27 13:47:52 --> Total execution time: 0.0830
DEBUG - 2019-04-27 13:47:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:47:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:47:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:47:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Session Class Initialized
DEBUG - 2019-04-27 13:47:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:47:56 --> Session routines successfully run
DEBUG - 2019-04-27 13:47:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:47:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:47:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:47:56 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:47:56 --> Final output sent to browser
DEBUG - 2019-04-27 13:47:56 --> Total execution time: 0.0500
DEBUG - 2019-04-27 13:48:32 --> Config Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:48:32 --> URI Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Router Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Output Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Security Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Input Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:48:32 --> Language Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Loader Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Controller Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Session Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:48:32 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:48:32 --> Session routines successfully run
DEBUG - 2019-04-27 13:48:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Model Class Initialized
DEBUG - 2019-04-27 13:48:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:48:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:48:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:48:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:48:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:48:32 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:48:32 --> Final output sent to browser
DEBUG - 2019-04-27 13:48:32 --> Total execution time: 0.1321
DEBUG - 2019-04-27 13:50:06 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:06 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:06 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:06 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:06 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:06 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:50:06 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:50:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:06 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:50:06 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:06 --> Total execution time: 0.1052
DEBUG - 2019-04-27 13:50:07 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:07 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:07 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:07 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:50:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:50:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:50:07 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:07 --> Total execution time: 0.0515
DEBUG - 2019-04-27 13:50:08 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:08 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:08 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:08 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:50:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:50:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:08 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 13:50:08 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:08 --> Total execution time: 0.1125
DEBUG - 2019-04-27 13:50:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:50:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:50:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:10 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:50:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:10 --> Total execution time: 0.0722
DEBUG - 2019-04-27 13:50:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:11 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:50:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:50:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:11 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 13:50:11 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:11 --> Total execution time: 0.1142
DEBUG - 2019-04-27 13:50:12 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:12 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:12 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:12 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:12 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:50:12 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:12 --> Total execution time: 0.0531
DEBUG - 2019-04-27 13:50:36 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:36 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:36 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:36 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:36 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:50:36 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:36 --> Total execution time: 0.0596
DEBUG - 2019-04-27 13:50:38 --> Config Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:50:38 --> URI Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Router Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Output Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Security Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Input Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:50:38 --> Language Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Loader Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Controller Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Session Class Initialized
DEBUG - 2019-04-27 13:50:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:50:38 --> Session routines successfully run
DEBUG - 2019-04-27 13:50:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:50:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:50:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:50:38 --> File loaded: application/views/editNotice.php
DEBUG - 2019-04-27 13:50:38 --> Final output sent to browser
DEBUG - 2019-04-27 13:50:38 --> Total execution time: 0.0550
DEBUG - 2019-04-27 13:51:19 --> Config Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:51:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:51:19 --> URI Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Router Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Output Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Security Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Input Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:51:19 --> Language Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Loader Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Controller Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Session Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:51:19 --> Session routines successfully run
DEBUG - 2019-04-27 13:51:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:51:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:51:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:51:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:51:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:51:19 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:51:19 --> Final output sent to browser
DEBUG - 2019-04-27 13:51:19 --> Total execution time: 0.0687
DEBUG - 2019-04-27 13:51:46 --> Config Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:51:46 --> URI Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Router Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Output Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Security Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Input Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:51:46 --> Language Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Loader Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Controller Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Session Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:51:46 --> Session routines successfully run
DEBUG - 2019-04-27 13:51:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:51:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:51:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:51:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:51:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:51:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:51:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:51:46 --> Final output sent to browser
DEBUG - 2019-04-27 13:51:46 --> Total execution time: 0.1511
DEBUG - 2019-04-27 13:52:00 --> Config Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:52:00 --> URI Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Router Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Output Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Security Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Input Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:52:00 --> Language Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Loader Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Controller Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Session Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:52:00 --> Session routines successfully run
DEBUG - 2019-04-27 13:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:52:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:52:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:52:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:52:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:52:00 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:52:00 --> Final output sent to browser
DEBUG - 2019-04-27 13:52:00 --> Total execution time: 0.0631
DEBUG - 2019-04-27 13:52:16 --> Config Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:52:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:52:16 --> URI Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Router Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Output Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Security Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Input Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:52:16 --> Language Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Loader Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Controller Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Session Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:52:16 --> Session routines successfully run
DEBUG - 2019-04-27 13:52:16 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:16 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:52:16 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:52:16 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:52:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:52:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:52:16 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:52:16 --> Final output sent to browser
DEBUG - 2019-04-27 13:52:16 --> Total execution time: 0.0540
DEBUG - 2019-04-27 13:52:51 --> Config Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:52:51 --> URI Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Router Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Output Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Security Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Input Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:52:51 --> Language Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Loader Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Controller Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Session Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:52:51 --> Session routines successfully run
DEBUG - 2019-04-27 13:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 13:52:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:52:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:52:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:52:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:52:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:52:51 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:52:51 --> Final output sent to browser
DEBUG - 2019-04-27 13:52:51 --> Total execution time: 0.0648
DEBUG - 2019-04-27 13:54:15 --> Config Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:54:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:54:15 --> URI Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Router Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Output Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Security Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Input Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:54:15 --> Language Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Loader Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Controller Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Session Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:54:15 --> Session routines successfully run
DEBUG - 2019-04-27 13:54:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Model Class Initialized
DEBUG - 2019-04-27 13:54:15 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:54:15 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:54:15 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:54:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:54:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:54:15 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:54:15 --> Final output sent to browser
DEBUG - 2019-04-27 13:54:15 --> Total execution time: 0.0649
DEBUG - 2019-04-27 13:55:07 --> Config Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:55:07 --> URI Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Router Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Output Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Security Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Input Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:55:07 --> Language Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Loader Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Controller Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Session Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:55:07 --> Session routines successfully run
DEBUG - 2019-04-27 13:55:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:55:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:55:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:55:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:55:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:55:07 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:55:07 --> Final output sent to browser
DEBUG - 2019-04-27 13:55:07 --> Total execution time: 0.0758
DEBUG - 2019-04-27 13:55:31 --> Config Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:55:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:55:31 --> URI Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Router Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Output Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Security Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Input Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:55:31 --> Language Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Loader Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Controller Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Session Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:55:31 --> Session routines successfully run
DEBUG - 2019-04-27 13:55:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:55:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:55:31 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:55:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:55:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:55:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:55:31 --> Final output sent to browser
DEBUG - 2019-04-27 13:55:31 --> Total execution time: 0.0635
DEBUG - 2019-04-27 13:55:45 --> Config Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:55:45 --> URI Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Router Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Output Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Security Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Input Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:55:45 --> Language Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Loader Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Controller Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Session Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:55:45 --> Session routines successfully run
DEBUG - 2019-04-27 13:55:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:55:45 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:55:45 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:55:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:55:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:55:45 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:55:45 --> Final output sent to browser
DEBUG - 2019-04-27 13:55:45 --> Total execution time: 0.0808
DEBUG - 2019-04-27 13:55:46 --> Config Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:55:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:55:46 --> URI Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Router Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Output Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Security Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Input Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:55:46 --> Language Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Loader Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Controller Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Session Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:55:46 --> Session routines successfully run
DEBUG - 2019-04-27 13:55:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Model Class Initialized
DEBUG - 2019-04-27 13:55:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:55:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:55:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:55:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:55:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:55:46 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:55:46 --> Final output sent to browser
DEBUG - 2019-04-27 13:55:46 --> Total execution time: 0.0534
DEBUG - 2019-04-27 13:56:03 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:03 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:03 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:03 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:03 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:03 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:03 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:03 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:56:03 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:03 --> Total execution time: 0.0579
DEBUG - 2019-04-27 13:56:04 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:04 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:04 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:04 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:04 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:04 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 13:56:04 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:04 --> Total execution time: 0.0549
DEBUG - 2019-04-27 13:56:14 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:14 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:14 --> No URI present. Default controller set.
DEBUG - 2019-04-27 13:56:14 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:14 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:14 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:56:14 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:14 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:14 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:14 --> Total execution time: 0.1020
DEBUG - 2019-04-27 13:56:22 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:22 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:22 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:22 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:22 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:22 --> Total execution time: 0.0773
DEBUG - 2019-04-27 13:56:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:34 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:34 --> Total execution time: 0.1195
DEBUG - 2019-04-27 13:56:34 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:34 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:34 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:34 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:34 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:34 --> Total execution time: 0.1034
DEBUG - 2019-04-27 13:56:36 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:36 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:36 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:36 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:36 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:36 --> Total execution time: 0.1190
DEBUG - 2019-04-27 13:56:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:56:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:56:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Session Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:56:56 --> Session routines successfully run
DEBUG - 2019-04-27 13:56:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:56:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:56:56 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:56:56 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:56:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:56:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:56:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:56:56 --> Final output sent to browser
DEBUG - 2019-04-27 13:56:56 --> Total execution time: 0.1963
DEBUG - 2019-04-27 13:57:10 --> Config Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:57:10 --> URI Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Router Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Output Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Security Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Input Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:57:10 --> Language Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Loader Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Controller Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Session Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:57:10 --> Session garbage collection performed.
DEBUG - 2019-04-27 13:57:10 --> Session routines successfully run
DEBUG - 2019-04-27 13:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:57:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:57:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:57:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:57:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:57:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:57:10 --> Final output sent to browser
DEBUG - 2019-04-27 13:57:10 --> Total execution time: 0.1648
DEBUG - 2019-04-27 13:57:38 --> Config Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:57:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:57:38 --> URI Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Router Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Output Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Security Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Input Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:57:38 --> Language Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Loader Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Controller Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Session Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:57:38 --> Session routines successfully run
DEBUG - 2019-04-27 13:57:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Model Class Initialized
DEBUG - 2019-04-27 13:57:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:57:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:57:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:57:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:57:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:57:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:57:38 --> Final output sent to browser
DEBUG - 2019-04-27 13:57:38 --> Total execution time: 0.1175
DEBUG - 2019-04-27 13:58:47 --> Config Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:58:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:58:47 --> URI Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Router Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Output Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Security Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Input Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:58:47 --> Language Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Loader Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Controller Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Session Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:58:47 --> Session routines successfully run
DEBUG - 2019-04-27 13:58:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:58:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:58:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:58:47 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:58:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:58:47 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:58:47 --> Final output sent to browser
DEBUG - 2019-04-27 13:58:47 --> Total execution time: 0.1240
DEBUG - 2019-04-27 13:58:56 --> Config Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:58:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:58:56 --> URI Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Router Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Output Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Security Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Input Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:58:56 --> Language Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Loader Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Controller Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Session Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:58:56 --> Session routines successfully run
DEBUG - 2019-04-27 13:58:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:58:56 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:58:56 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:58:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:58:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:58:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:58:56 --> Final output sent to browser
DEBUG - 2019-04-27 13:58:56 --> Total execution time: 0.1837
DEBUG - 2019-04-27 13:58:58 --> Config Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 13:58:58 --> URI Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Router Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Output Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Security Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Input Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 13:58:58 --> Language Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Loader Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Controller Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Session Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 13:58:58 --> Session routines successfully run
DEBUG - 2019-04-27 13:58:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Model Class Initialized
DEBUG - 2019-04-27 13:58:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 13:58:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 13:58:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 13:58:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 13:58:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 13:58:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 13:58:58 --> Final output sent to browser
DEBUG - 2019-04-27 13:58:58 --> Total execution time: 0.0983
DEBUG - 2019-04-27 14:00:33 --> Config Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:00:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:00:33 --> URI Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Router Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Output Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Security Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Input Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:00:33 --> Language Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Loader Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Controller Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Session Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:00:33 --> Session routines successfully run
DEBUG - 2019-04-27 14:00:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:00:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:00:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:00:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:00:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:00:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:00:33 --> Final output sent to browser
DEBUG - 2019-04-27 14:00:33 --> Total execution time: 0.1465
DEBUG - 2019-04-27 14:00:34 --> Config Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:00:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:00:34 --> URI Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Router Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Output Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Security Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Input Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:00:34 --> Language Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Loader Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Controller Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Session Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:00:34 --> Session routines successfully run
DEBUG - 2019-04-27 14:00:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:00:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:00:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:00:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:00:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:00:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:00:34 --> Final output sent to browser
DEBUG - 2019-04-27 14:00:34 --> Total execution time: 0.1186
DEBUG - 2019-04-27 14:00:35 --> Config Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:00:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:00:35 --> URI Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Router Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Output Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Security Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Input Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:00:35 --> Language Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Loader Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Controller Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Session Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:00:35 --> Session routines successfully run
DEBUG - 2019-04-27 14:00:35 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:00:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:00:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:00:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:00:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:00:35 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:00:35 --> Final output sent to browser
DEBUG - 2019-04-27 14:00:35 --> Total execution time: 0.1077
DEBUG - 2019-04-27 14:00:45 --> Config Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:00:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:00:45 --> URI Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Router Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Output Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Security Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Input Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:00:45 --> Language Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Loader Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Controller Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Session Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:00:45 --> Session routines successfully run
DEBUG - 2019-04-27 14:00:45 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:00:45 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:00:45 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:00:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:00:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:00:45 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:00:45 --> Final output sent to browser
DEBUG - 2019-04-27 14:00:45 --> Total execution time: 0.0886
DEBUG - 2019-04-27 14:00:46 --> Config Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:00:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:00:46 --> URI Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Router Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Output Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Security Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Input Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:00:46 --> Language Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Loader Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Controller Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Session Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:00:46 --> Session routines successfully run
DEBUG - 2019-04-27 14:00:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:00:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:00:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:00:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:00:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:00:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:00:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:00:46 --> Final output sent to browser
DEBUG - 2019-04-27 14:00:46 --> Total execution time: 0.0949
DEBUG - 2019-04-27 14:01:03 --> Config Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:01:03 --> URI Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Router Class Initialized
DEBUG - 2019-04-27 14:01:03 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:01:03 --> Output Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Security Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Input Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:01:03 --> Language Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Loader Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Controller Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Session Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:01:03 --> Session routines successfully run
DEBUG - 2019-04-27 14:01:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:01:03 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:01:03 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:01:03 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:01:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:01:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:01:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:01:03 --> Final output sent to browser
DEBUG - 2019-04-27 14:01:03 --> Total execution time: 0.1129
DEBUG - 2019-04-27 14:02:09 --> Config Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:02:09 --> URI Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Router Class Initialized
DEBUG - 2019-04-27 14:02:09 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:02:09 --> Output Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Security Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Input Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:02:09 --> Language Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Loader Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Controller Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Session Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:02:09 --> Session routines successfully run
DEBUG - 2019-04-27 14:02:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:02:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:02:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:02:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:02:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:02:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:02:09 --> Final output sent to browser
DEBUG - 2019-04-27 14:02:09 --> Total execution time: 0.1700
DEBUG - 2019-04-27 14:02:28 --> Config Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:02:28 --> URI Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Router Class Initialized
DEBUG - 2019-04-27 14:02:28 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:02:28 --> Output Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Security Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Input Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:02:28 --> Language Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Loader Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Controller Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Session Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:02:28 --> Session routines successfully run
DEBUG - 2019-04-27 14:02:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:02:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:02:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:02:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:02:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:02:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:02:28 --> Final output sent to browser
DEBUG - 2019-04-27 14:02:28 --> Total execution time: 0.2644
DEBUG - 2019-04-27 14:02:55 --> Config Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:02:55 --> URI Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Router Class Initialized
DEBUG - 2019-04-27 14:02:55 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:02:55 --> Output Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Security Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Input Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:02:55 --> Language Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Loader Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Controller Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Session Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:02:55 --> Session routines successfully run
DEBUG - 2019-04-27 14:02:55 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Model Class Initialized
DEBUG - 2019-04-27 14:02:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:02:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:02:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:02:55 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:02:55 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:02:55 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:02:55 --> Final output sent to browser
DEBUG - 2019-04-27 14:02:55 --> Total execution time: 0.1128
DEBUG - 2019-04-27 14:08:13 --> Config Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:08:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:08:13 --> URI Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Router Class Initialized
DEBUG - 2019-04-27 14:08:13 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:08:13 --> Output Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Security Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Input Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:08:13 --> Language Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Loader Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Controller Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Model Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Model Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Session Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:08:13 --> Session routines successfully run
DEBUG - 2019-04-27 14:08:13 --> Model Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Model Class Initialized
DEBUG - 2019-04-27 14:08:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:08:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:08:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:08:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:08:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:08:13 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:08:13 --> Final output sent to browser
DEBUG - 2019-04-27 14:08:13 --> Total execution time: 0.1773
DEBUG - 2019-04-27 14:09:06 --> Config Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:09:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:09:06 --> URI Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Router Class Initialized
DEBUG - 2019-04-27 14:09:06 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:09:06 --> Output Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Security Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Input Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:09:06 --> Language Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Loader Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Controller Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Session Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:09:06 --> Session routines successfully run
DEBUG - 2019-04-27 14:09:06 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:06 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:09:06 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:09:06 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:09:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:09:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:09:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:09:06 --> Final output sent to browser
DEBUG - 2019-04-27 14:09:06 --> Total execution time: 0.1181
DEBUG - 2019-04-27 14:09:17 --> Config Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:09:17 --> URI Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Router Class Initialized
DEBUG - 2019-04-27 14:09:17 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:09:17 --> Output Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Security Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Input Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:09:17 --> Language Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Loader Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Controller Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Session Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:09:17 --> Session garbage collection performed.
DEBUG - 2019-04-27 14:09:17 --> Session routines successfully run
DEBUG - 2019-04-27 14:09:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:09:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:09:17 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:09:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:09:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:09:17 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:09:17 --> Final output sent to browser
DEBUG - 2019-04-27 14:09:17 --> Total execution time: 0.1187
DEBUG - 2019-04-27 14:09:20 --> Config Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:09:20 --> URI Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Router Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Output Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Security Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Input Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:09:20 --> Language Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Loader Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Controller Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Session Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:09:20 --> Session routines successfully run
DEBUG - 2019-04-27 14:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:20 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:09:20 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:09:20 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:09:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:09:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:09:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:09:20 --> Final output sent to browser
DEBUG - 2019-04-27 14:09:20 --> Total execution time: 0.0917
DEBUG - 2019-04-27 14:09:48 --> Config Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:09:48 --> URI Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Router Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Output Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Security Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Input Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:09:48 --> Language Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Loader Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Controller Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Session Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:09:48 --> Session routines successfully run
DEBUG - 2019-04-27 14:09:48 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:48 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:09:48 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:09:48 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:09:48 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:09:48 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:09:48 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:09:48 --> Final output sent to browser
DEBUG - 2019-04-27 14:09:48 --> Total execution time: 0.1230
DEBUG - 2019-04-27 14:09:57 --> Config Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:09:57 --> URI Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Router Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Output Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Security Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Input Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:09:57 --> Language Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Loader Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Controller Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Session Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:09:57 --> Session routines successfully run
DEBUG - 2019-04-27 14:09:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:09:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:09:57 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:09:57 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:09:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:09:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:09:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:09:57 --> Final output sent to browser
DEBUG - 2019-04-27 14:09:57 --> Total execution time: 0.1216
DEBUG - 2019-04-27 14:10:21 --> Config Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:10:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:10:21 --> URI Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Router Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Output Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Security Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Input Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:10:21 --> Language Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Loader Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Controller Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Session Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:10:21 --> Session routines successfully run
DEBUG - 2019-04-27 14:10:21 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:21 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:10:21 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:10:21 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:10:21 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:10:21 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:10:21 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:10:21 --> Final output sent to browser
DEBUG - 2019-04-27 14:10:21 --> Total execution time: 0.1050
DEBUG - 2019-04-27 14:10:28 --> Config Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:10:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:10:28 --> URI Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Router Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Output Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Security Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Input Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:10:28 --> Language Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Loader Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Controller Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Session Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:10:28 --> Session routines successfully run
DEBUG - 2019-04-27 14:10:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:10:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:10:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:10:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:10:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:10:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:10:28 --> Final output sent to browser
DEBUG - 2019-04-27 14:10:28 --> Total execution time: 0.0852
DEBUG - 2019-04-27 14:10:36 --> Config Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:10:36 --> URI Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Router Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Output Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Security Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Input Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:10:36 --> Language Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Loader Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Controller Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Session Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:10:36 --> Session routines successfully run
DEBUG - 2019-04-27 14:10:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:10:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:10:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:10:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:10:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:10:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:10:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:10:36 --> Final output sent to browser
DEBUG - 2019-04-27 14:10:36 --> Total execution time: 0.0778
DEBUG - 2019-04-27 14:11:10 --> Config Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:11:10 --> URI Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Router Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Output Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Security Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Input Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:11:10 --> Language Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Loader Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Controller Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Session Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:11:10 --> Session routines successfully run
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:11:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:11:10 --> Final output sent to browser
DEBUG - 2019-04-27 14:11:10 --> Total execution time: 0.0867
DEBUG - 2019-04-27 14:11:10 --> Config Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:11:10 --> URI Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Router Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Output Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Security Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Input Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:11:10 --> Language Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Loader Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Controller Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Session Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:11:10 --> Session routines successfully run
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:11:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:11:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:11:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:11:10 --> Final output sent to browser
DEBUG - 2019-04-27 14:11:10 --> Total execution time: 0.0883
DEBUG - 2019-04-27 14:11:14 --> Config Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:11:14 --> URI Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Router Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Output Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Security Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Input Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:11:14 --> Language Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Loader Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Controller Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Session Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:11:14 --> Session routines successfully run
DEBUG - 2019-04-27 14:11:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:11:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:11:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:11:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:11:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:11:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:11:14 --> Final output sent to browser
DEBUG - 2019-04-27 14:11:14 --> Total execution time: 0.1291
DEBUG - 2019-04-27 14:11:38 --> Config Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:11:38 --> URI Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Router Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Output Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Security Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Input Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:11:38 --> Language Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Loader Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Controller Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Session Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:11:38 --> Session routines successfully run
DEBUG - 2019-04-27 14:11:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:11:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:11:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:11:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:11:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:11:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:11:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:11:38 --> Final output sent to browser
DEBUG - 2019-04-27 14:11:38 --> Total execution time: 0.1240
DEBUG - 2019-04-27 14:12:09 --> Config Class Initialized
DEBUG - 2019-04-27 14:12:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:12:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:12:10 --> URI Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Router Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Output Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Security Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Input Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:12:10 --> Language Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Loader Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Controller Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Session Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:12:10 --> Session routines successfully run
DEBUG - 2019-04-27 14:12:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:12:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:12:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:12:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:12:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:12:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:12:10 --> Final output sent to browser
DEBUG - 2019-04-27 14:12:10 --> Total execution time: 0.1232
DEBUG - 2019-04-27 14:12:18 --> Config Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:12:18 --> URI Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Router Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Output Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Security Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Input Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:12:18 --> Language Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Loader Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Controller Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Session Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:12:18 --> Session routines successfully run
DEBUG - 2019-04-27 14:12:18 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:12:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:12:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:12:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:12:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:12:18 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:12:18 --> Final output sent to browser
DEBUG - 2019-04-27 14:12:18 --> Total execution time: 0.1662
DEBUG - 2019-04-27 14:12:27 --> Config Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:12:27 --> URI Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Router Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Output Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Security Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Input Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:12:27 --> Language Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Loader Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Controller Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Session Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:12:27 --> Session routines successfully run
DEBUG - 2019-04-27 14:12:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:12:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:12:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:12:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:12:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:12:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:12:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:12:28 --> Final output sent to browser
DEBUG - 2019-04-27 14:12:28 --> Total execution time: 0.0946
DEBUG - 2019-04-27 14:13:10 --> Config Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:13:10 --> URI Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Router Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Output Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Security Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Input Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:13:10 --> Language Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Loader Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Controller Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Session Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:13:10 --> Session routines successfully run
DEBUG - 2019-04-27 14:13:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:13:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:13:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:13:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:13:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:13:10 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:13:10 --> Final output sent to browser
DEBUG - 2019-04-27 14:13:10 --> Total execution time: 0.1123
DEBUG - 2019-04-27 14:13:34 --> Config Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:13:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:13:34 --> URI Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Router Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Output Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Security Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Input Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:13:34 --> Language Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Loader Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Controller Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Session Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:13:34 --> Session routines successfully run
DEBUG - 2019-04-27 14:13:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:13:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:13:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:13:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:13:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:13:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:13:34 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:13:34 --> Final output sent to browser
DEBUG - 2019-04-27 14:13:34 --> Total execution time: 0.1679
DEBUG - 2019-04-27 14:14:34 --> Config Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:14:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:14:34 --> URI Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Router Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Output Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Security Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Input Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:14:34 --> Language Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Loader Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Controller Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Session Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:14:34 --> Session routines successfully run
DEBUG - 2019-04-27 14:14:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Model Class Initialized
DEBUG - 2019-04-27 14:14:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:14:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:14:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:14:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:14:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:14:35 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:14:35 --> Final output sent to browser
DEBUG - 2019-04-27 14:14:35 --> Total execution time: 0.1266
DEBUG - 2019-04-27 14:15:02 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:02 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:02 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:02 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:02 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:02 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:02 --> Total execution time: 0.1226
DEBUG - 2019-04-27 14:15:28 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:28 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:28 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:28 --> Session garbage collection performed.
DEBUG - 2019-04-27 14:15:28 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:28 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:28 --> Total execution time: 0.0953
DEBUG - 2019-04-27 14:15:30 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:30 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:30 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:30 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:30 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:30 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:30 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:30 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:30 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:30 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:30 --> Total execution time: 0.1015
DEBUG - 2019-04-27 14:15:36 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:36 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:36 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:36 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:36 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:36 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:36 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:36 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:36 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:36 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:36 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:36 --> Total execution time: 0.2149
DEBUG - 2019-04-27 14:15:42 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:42 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:42 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:42 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:42 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:42 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:42 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:42 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:42 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:42 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:42 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:42 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:42 --> Total execution time: 0.0836
DEBUG - 2019-04-27 14:15:44 --> Config Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:15:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:15:44 --> URI Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Router Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Output Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Security Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Input Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:15:44 --> Language Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Loader Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Controller Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Session Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:15:44 --> Session routines successfully run
DEBUG - 2019-04-27 14:15:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:15:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:15:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:15:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:15:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:15:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:15:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:15:44 --> Final output sent to browser
DEBUG - 2019-04-27 14:15:44 --> Total execution time: 0.1387
DEBUG - 2019-04-27 14:16:03 --> Config Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:16:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:16:03 --> URI Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Router Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Output Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Security Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Input Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:16:03 --> Language Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Loader Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Controller Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Session Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:16:03 --> Session routines successfully run
DEBUG - 2019-04-27 14:16:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:03 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:16:03 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:16:03 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:16:03 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:16:03 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:16:03 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:16:03 --> Final output sent to browser
DEBUG - 2019-04-27 14:16:03 --> Total execution time: 0.1133
DEBUG - 2019-04-27 14:16:56 --> Config Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:16:56 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:16:56 --> URI Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Router Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Output Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Security Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Input Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:16:56 --> Language Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Loader Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Controller Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Session Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:16:56 --> Session routines successfully run
DEBUG - 2019-04-27 14:16:56 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Model Class Initialized
DEBUG - 2019-04-27 14:16:56 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:16:56 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:16:56 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:16:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:16:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:16:56 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:16:56 --> Final output sent to browser
DEBUG - 2019-04-27 14:16:56 --> Total execution time: 0.1676
DEBUG - 2019-04-27 14:17:01 --> Config Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:17:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:17:01 --> URI Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Router Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Output Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Security Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Input Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:17:01 --> Language Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Loader Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Controller Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Session Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:17:01 --> Session routines successfully run
DEBUG - 2019-04-27 14:17:01 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:17:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:17:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:17:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:17:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:17:01 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:17:01 --> Final output sent to browser
DEBUG - 2019-04-27 14:17:01 --> Total execution time: 0.0858
DEBUG - 2019-04-27 14:17:59 --> Config Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:17:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:17:59 --> URI Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Router Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Output Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Security Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Input Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:17:59 --> Language Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Loader Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Controller Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Session Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:17:59 --> Session routines successfully run
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:17:59 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Config Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:17:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:17:59 --> URI Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Router Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Output Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Security Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Input Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:17:59 --> Language Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Loader Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Controller Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Session Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:17:59 --> A session cookie was not found.
DEBUG - 2019-04-27 14:17:59 --> Session routines successfully run
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:17:59 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:17:59 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:17:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:17:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:17:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:17:59 --> Final output sent to browser
DEBUG - 2019-04-27 14:17:59 --> Total execution time: 0.0867
DEBUG - 2019-04-27 14:18:49 --> Config Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:18:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:18:49 --> URI Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Router Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Output Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Security Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Input Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:18:49 --> Language Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Loader Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Controller Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Session Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:18:49 --> Session routines successfully run
DEBUG - 2019-04-27 14:18:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:18:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:18:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:18:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:18:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:18:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:18:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:18:49 --> Final output sent to browser
DEBUG - 2019-04-27 14:18:49 --> Total execution time: 0.0961
DEBUG - 2019-04-27 14:19:21 --> Config Class Initialized
DEBUG - 2019-04-27 14:19:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:19:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:19:22 --> URI Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Router Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Output Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Security Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Input Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:19:22 --> Language Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Loader Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Controller Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Session Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:19:22 --> Session routines successfully run
DEBUG - 2019-04-27 14:19:22 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:19:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:19:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:19:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:19:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:19:22 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:19:22 --> Final output sent to browser
DEBUG - 2019-04-27 14:19:22 --> Total execution time: 0.0931
DEBUG - 2019-04-27 14:19:33 --> Config Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:19:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:19:33 --> URI Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Router Class Initialized
DEBUG - 2019-04-27 14:19:33 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:19:33 --> Output Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Security Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Input Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:19:33 --> Language Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Loader Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Controller Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Session Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:19:33 --> Session routines successfully run
DEBUG - 2019-04-27 14:19:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:19:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:19:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:19:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:19:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:19:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:19:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:19:33 --> Final output sent to browser
DEBUG - 2019-04-27 14:19:33 --> Total execution time: 0.0871
DEBUG - 2019-04-27 14:20:07 --> Config Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:20:07 --> URI Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Router Class Initialized
DEBUG - 2019-04-27 14:20:07 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:20:07 --> Output Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Security Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Input Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:20:07 --> Language Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Loader Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Controller Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Session Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:20:07 --> Session routines successfully run
DEBUG - 2019-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:20:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:20:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:20:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:20:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:20:07 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:20:07 --> Final output sent to browser
DEBUG - 2019-04-27 14:20:07 --> Total execution time: 0.1002
DEBUG - 2019-04-27 14:20:40 --> Config Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:20:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:20:40 --> URI Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Router Class Initialized
DEBUG - 2019-04-27 14:20:40 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:20:40 --> Output Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Security Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Input Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:20:40 --> Language Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Loader Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Controller Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Session Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:20:40 --> Session routines successfully run
DEBUG - 2019-04-27 14:20:40 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:20:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:20:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:20:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:20:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:20:40 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:20:40 --> Final output sent to browser
DEBUG - 2019-04-27 14:20:40 --> Total execution time: 0.0664
DEBUG - 2019-04-27 14:20:57 --> Config Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:20:57 --> URI Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Router Class Initialized
DEBUG - 2019-04-27 14:20:57 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:20:57 --> Output Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Security Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Input Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:20:57 --> Language Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Loader Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Controller Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Session Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:20:57 --> Session routines successfully run
DEBUG - 2019-04-27 14:20:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Model Class Initialized
DEBUG - 2019-04-27 14:20:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:20:57 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:20:57 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:20:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:20:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:20:57 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:20:57 --> Final output sent to browser
DEBUG - 2019-04-27 14:20:57 --> Total execution time: 0.0789
DEBUG - 2019-04-27 14:21:31 --> Config Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:21:31 --> URI Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Router Class Initialized
DEBUG - 2019-04-27 14:21:31 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:21:31 --> Output Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Security Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Input Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:21:31 --> Language Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Loader Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Controller Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Session Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:21:31 --> Session routines successfully run
DEBUG - 2019-04-27 14:21:31 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:21:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:21:31 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:21:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:21:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:21:31 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:21:31 --> Final output sent to browser
DEBUG - 2019-04-27 14:21:31 --> Total execution time: 0.1030
DEBUG - 2019-04-27 14:21:44 --> Config Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:21:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:21:44 --> URI Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Router Class Initialized
DEBUG - 2019-04-27 14:21:44 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:21:44 --> Output Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Security Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Input Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:21:44 --> Language Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Loader Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Controller Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Session Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:21:44 --> Session routines successfully run
DEBUG - 2019-04-27 14:21:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Model Class Initialized
DEBUG - 2019-04-27 14:21:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:21:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:21:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:21:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:21:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:21:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:21:44 --> Final output sent to browser
DEBUG - 2019-04-27 14:21:44 --> Total execution time: 0.1003
DEBUG - 2019-04-27 14:22:33 --> Config Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:22:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:22:33 --> URI Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Router Class Initialized
DEBUG - 2019-04-27 14:22:33 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:22:33 --> Output Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Security Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Input Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:22:33 --> Language Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Loader Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Controller Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Session Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:22:33 --> Session routines successfully run
DEBUG - 2019-04-27 14:22:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:22:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:22:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:22:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:22:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:22:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:22:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:22:33 --> Final output sent to browser
DEBUG - 2019-04-27 14:22:33 --> Total execution time: 0.0878
DEBUG - 2019-04-27 14:23:17 --> Config Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:23:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:23:17 --> URI Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Router Class Initialized
DEBUG - 2019-04-27 14:23:17 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:23:17 --> Output Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Security Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Input Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:23:17 --> Language Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Loader Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Controller Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Session Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:23:17 --> Session routines successfully run
DEBUG - 2019-04-27 14:23:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:23:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:23:17 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:23:17 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:23:17 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:23:17 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:23:17 --> Final output sent to browser
DEBUG - 2019-04-27 14:23:17 --> Total execution time: 0.1773
DEBUG - 2019-04-27 14:23:39 --> Config Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:23:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:23:39 --> URI Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Router Class Initialized
DEBUG - 2019-04-27 14:23:39 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:23:39 --> Output Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Security Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Input Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:23:39 --> Language Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Loader Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Controller Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Session Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:23:39 --> Session routines successfully run
DEBUG - 2019-04-27 14:23:39 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Model Class Initialized
DEBUG - 2019-04-27 14:23:39 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:23:39 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:23:39 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:23:39 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:23:39 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:23:39 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:23:39 --> Final output sent to browser
DEBUG - 2019-04-27 14:23:39 --> Total execution time: 0.1179
DEBUG - 2019-04-27 14:24:05 --> Config Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:24:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:24:05 --> URI Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Router Class Initialized
DEBUG - 2019-04-27 14:24:05 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:24:05 --> Output Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Security Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Input Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:24:05 --> Language Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Loader Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Controller Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Session Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:24:05 --> Session routines successfully run
DEBUG - 2019-04-27 14:24:05 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:05 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:24:05 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:24:05 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:24:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:24:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:24:05 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:24:05 --> Final output sent to browser
DEBUG - 2019-04-27 14:24:05 --> Total execution time: 0.1130
DEBUG - 2019-04-27 14:24:15 --> Config Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:24:15 --> URI Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Router Class Initialized
DEBUG - 2019-04-27 14:24:15 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:24:15 --> Output Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Security Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Input Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:24:15 --> Language Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Loader Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Controller Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:24:16 --> Session Class Initialized
DEBUG - 2019-04-27 14:24:16 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:24:16 --> Session routines successfully run
DEBUG - 2019-04-27 14:24:16 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:16 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:16 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:24:16 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:24:16 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:24:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:24:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:24:16 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:24:16 --> Final output sent to browser
DEBUG - 2019-04-27 14:24:16 --> Total execution time: 0.0964
DEBUG - 2019-04-27 14:24:27 --> Config Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:24:27 --> URI Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Router Class Initialized
DEBUG - 2019-04-27 14:24:27 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:24:27 --> Output Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Security Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Input Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:24:27 --> Language Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Loader Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Controller Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Session Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:24:27 --> Session routines successfully run
DEBUG - 2019-04-27 14:24:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:24:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:24:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:24:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:24:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:24:27 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:24:27 --> Final output sent to browser
DEBUG - 2019-04-27 14:24:27 --> Total execution time: 0.1336
DEBUG - 2019-04-27 14:24:46 --> Config Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:24:46 --> URI Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Router Class Initialized
DEBUG - 2019-04-27 14:24:46 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:24:46 --> Output Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Security Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Input Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:24:46 --> Language Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Loader Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Controller Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Session Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:24:46 --> Session routines successfully run
DEBUG - 2019-04-27 14:24:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:24:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:24:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:24:46 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:24:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:24:46 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:24:46 --> Final output sent to browser
DEBUG - 2019-04-27 14:24:46 --> Total execution time: 0.0910
DEBUG - 2019-04-27 14:24:54 --> Config Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:24:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:24:54 --> URI Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Router Class Initialized
DEBUG - 2019-04-27 14:24:54 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:24:54 --> Output Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Security Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Input Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:24:54 --> Language Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Loader Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Controller Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Session Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:24:54 --> Session routines successfully run
DEBUG - 2019-04-27 14:24:54 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Model Class Initialized
DEBUG - 2019-04-27 14:24:54 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:24:54 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:24:54 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:24:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:24:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:24:54 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:24:54 --> Final output sent to browser
DEBUG - 2019-04-27 14:24:54 --> Total execution time: 0.1176
DEBUG - 2019-04-27 14:25:01 --> Config Class Initialized
DEBUG - 2019-04-27 14:25:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:25:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:25:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:25:01 --> URI Class Initialized
DEBUG - 2019-04-27 14:25:01 --> Router Class Initialized
DEBUG - 2019-04-27 14:25:01 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:25:02 --> Output Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Security Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Input Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:25:02 --> Language Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Loader Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Controller Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Session Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:25:02 --> Session routines successfully run
DEBUG - 2019-04-27 14:25:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:25:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:25:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:25:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:25:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:25:02 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:25:02 --> Final output sent to browser
DEBUG - 2019-04-27 14:25:02 --> Total execution time: 0.1012
DEBUG - 2019-04-27 14:25:09 --> Config Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:25:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:25:09 --> URI Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Router Class Initialized
DEBUG - 2019-04-27 14:25:09 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:25:09 --> Output Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Security Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Input Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:25:09 --> Language Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Loader Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Controller Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Session Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:25:09 --> Session routines successfully run
DEBUG - 2019-04-27 14:25:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Model Class Initialized
DEBUG - 2019-04-27 14:25:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:25:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:25:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:25:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:25:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:25:09 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:25:09 --> Final output sent to browser
DEBUG - 2019-04-27 14:25:09 --> Total execution time: 0.0710
DEBUG - 2019-04-27 14:26:20 --> Config Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:26:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:26:20 --> URI Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Router Class Initialized
DEBUG - 2019-04-27 14:26:20 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:26:20 --> Output Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Security Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Input Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:26:20 --> Language Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Loader Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Controller Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Session Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:26:20 --> Session routines successfully run
DEBUG - 2019-04-27 14:26:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:20 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:26:20 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:26:20 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:26:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:26:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:26:20 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:26:20 --> Final output sent to browser
DEBUG - 2019-04-27 14:26:20 --> Total execution time: 0.0947
DEBUG - 2019-04-27 14:26:28 --> Config Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:26:28 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:26:28 --> URI Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Router Class Initialized
DEBUG - 2019-04-27 14:26:28 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:26:28 --> Output Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Security Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Input Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:26:28 --> Language Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Loader Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Controller Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Session Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:26:28 --> Session routines successfully run
DEBUG - 2019-04-27 14:26:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:26:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:26:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:26:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:26:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:26:28 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:26:28 --> Final output sent to browser
DEBUG - 2019-04-27 14:26:28 --> Total execution time: 0.1114
DEBUG - 2019-04-27 14:26:41 --> Config Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:26:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:26:41 --> URI Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Router Class Initialized
DEBUG - 2019-04-27 14:26:41 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:26:41 --> Output Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Security Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Input Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:26:41 --> Language Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Loader Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Controller Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Session Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:26:41 --> Session routines successfully run
DEBUG - 2019-04-27 14:26:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:26:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:26:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:26:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:26:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:26:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:26:41 --> Final output sent to browser
DEBUG - 2019-04-27 14:26:41 --> Total execution time: 0.1279
DEBUG - 2019-04-27 14:26:49 --> Config Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:26:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:26:49 --> URI Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Router Class Initialized
DEBUG - 2019-04-27 14:26:49 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:26:49 --> Output Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Security Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Input Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:26:49 --> Language Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Loader Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Controller Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Session Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:26:49 --> Session routines successfully run
DEBUG - 2019-04-27 14:26:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:26:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:26:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:26:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:26:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:26:49 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:26:49 --> Final output sent to browser
DEBUG - 2019-04-27 14:26:49 --> Total execution time: 0.1110
DEBUG - 2019-04-27 14:26:58 --> Config Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:26:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:26:58 --> URI Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Router Class Initialized
DEBUG - 2019-04-27 14:26:58 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:26:58 --> Output Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Security Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Input Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:26:58 --> Language Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Loader Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Controller Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Session Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:26:58 --> Session routines successfully run
DEBUG - 2019-04-27 14:26:58 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Model Class Initialized
DEBUG - 2019-04-27 14:26:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:26:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:26:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:26:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:26:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:26:58 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:26:58 --> Final output sent to browser
DEBUG - 2019-04-27 14:26:58 --> Total execution time: 0.2118
DEBUG - 2019-04-27 14:27:12 --> Config Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:27:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:27:12 --> URI Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Router Class Initialized
DEBUG - 2019-04-27 14:27:12 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:27:12 --> Output Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Security Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Input Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:27:12 --> Language Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Loader Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Controller Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Session Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:27:12 --> Session routines successfully run
DEBUG - 2019-04-27 14:27:12 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:27:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:27:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:27:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:27:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:27:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:27:12 --> Final output sent to browser
DEBUG - 2019-04-27 14:27:12 --> Total execution time: 0.1184
DEBUG - 2019-04-27 14:27:29 --> Config Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:27:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:27:29 --> URI Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Router Class Initialized
DEBUG - 2019-04-27 14:27:29 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:27:29 --> Output Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Security Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Input Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:27:29 --> Language Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Loader Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Controller Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Session Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:27:29 --> Session routines successfully run
DEBUG - 2019-04-27 14:27:29 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:27:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:27:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:27:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:27:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:27:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:27:29 --> Final output sent to browser
DEBUG - 2019-04-27 14:27:29 --> Total execution time: 0.1057
DEBUG - 2019-04-27 14:27:38 --> Config Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:27:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:27:38 --> URI Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Router Class Initialized
DEBUG - 2019-04-27 14:27:38 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:27:38 --> Output Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Security Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Input Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:27:38 --> Language Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Loader Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Controller Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Session Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:27:38 --> Session routines successfully run
DEBUG - 2019-04-27 14:27:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:27:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:27:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:27:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:27:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:27:38 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:27:38 --> Final output sent to browser
DEBUG - 2019-04-27 14:27:38 --> Total execution time: 0.1072
DEBUG - 2019-04-27 14:27:51 --> Config Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:27:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:27:51 --> URI Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Router Class Initialized
DEBUG - 2019-04-27 14:27:51 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:27:51 --> Output Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Security Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Input Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:27:51 --> Language Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Loader Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Controller Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Session Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:27:51 --> Session routines successfully run
DEBUG - 2019-04-27 14:27:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:27:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:27:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:27:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:27:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:27:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:27:51 --> Final output sent to browser
DEBUG - 2019-04-27 14:27:51 --> Total execution time: 0.1050
DEBUG - 2019-04-27 14:27:59 --> Config Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:27:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:27:59 --> URI Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Router Class Initialized
DEBUG - 2019-04-27 14:27:59 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:27:59 --> Output Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Security Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Input Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:27:59 --> Language Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Loader Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Controller Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Session Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:27:59 --> Session garbage collection performed.
DEBUG - 2019-04-27 14:27:59 --> Session routines successfully run
DEBUG - 2019-04-27 14:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:27:59 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:27:59 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:27:59 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:27:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:27:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:27:59 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:27:59 --> Final output sent to browser
DEBUG - 2019-04-27 14:27:59 --> Total execution time: 0.2091
DEBUG - 2019-04-27 14:28:08 --> Config Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:28:08 --> URI Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Router Class Initialized
DEBUG - 2019-04-27 14:28:08 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:28:08 --> Output Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Security Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Input Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:28:08 --> Language Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Loader Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Controller Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Session Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:28:08 --> Session routines successfully run
DEBUG - 2019-04-27 14:28:08 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:28:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:28:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:28:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:28:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:28:08 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:28:08 --> Final output sent to browser
DEBUG - 2019-04-27 14:28:08 --> Total execution time: 0.1171
DEBUG - 2019-04-27 14:28:14 --> Config Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:28:14 --> URI Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Router Class Initialized
DEBUG - 2019-04-27 14:28:14 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:28:14 --> Output Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Security Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Input Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:28:14 --> Language Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Loader Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Controller Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Session Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:28:14 --> Session routines successfully run
DEBUG - 2019-04-27 14:28:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:28:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:28:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:28:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:28:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:28:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:28:14 --> Final output sent to browser
DEBUG - 2019-04-27 14:28:14 --> Total execution time: 0.0982
DEBUG - 2019-04-27 14:28:53 --> Config Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:28:53 --> URI Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Router Class Initialized
DEBUG - 2019-04-27 14:28:53 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:28:53 --> Output Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Security Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Input Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:28:53 --> Language Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Loader Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Controller Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Session Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:28:53 --> Session routines successfully run
DEBUG - 2019-04-27 14:28:53 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Model Class Initialized
DEBUG - 2019-04-27 14:28:53 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:28:53 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:28:53 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:28:53 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:28:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:28:53 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:28:53 --> Final output sent to browser
DEBUG - 2019-04-27 14:28:53 --> Total execution time: 0.2021
DEBUG - 2019-04-27 14:29:41 --> Config Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:29:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:29:41 --> URI Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Router Class Initialized
DEBUG - 2019-04-27 14:29:41 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:29:41 --> Output Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Security Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Input Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:29:41 --> Language Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Loader Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Controller Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Session Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:29:41 --> Session routines successfully run
DEBUG - 2019-04-27 14:29:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:29:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:29:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:29:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:29:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:29:41 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:29:41 --> Final output sent to browser
DEBUG - 2019-04-27 14:29:41 --> Total execution time: 0.1199
DEBUG - 2019-04-27 14:29:51 --> Config Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:29:51 --> URI Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Router Class Initialized
DEBUG - 2019-04-27 14:29:51 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:29:51 --> Output Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Security Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Input Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:29:51 --> Language Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Loader Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Controller Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Session Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:29:51 --> Session routines successfully run
DEBUG - 2019-04-27 14:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 14:29:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:29:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:29:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:29:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:29:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:29:51 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:29:51 --> Final output sent to browser
DEBUG - 2019-04-27 14:29:51 --> Total execution time: 0.1230
DEBUG - 2019-04-27 14:30:14 --> Config Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:30:14 --> URI Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Router Class Initialized
DEBUG - 2019-04-27 14:30:14 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:30:14 --> Output Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Security Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Input Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:30:14 --> Language Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Loader Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Controller Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Session Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:30:14 --> Session routines successfully run
DEBUG - 2019-04-27 14:30:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:30:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:30:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:30:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:30:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:30:14 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:30:14 --> Final output sent to browser
DEBUG - 2019-04-27 14:30:14 --> Total execution time: 0.0887
DEBUG - 2019-04-27 14:30:33 --> Config Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:30:33 --> URI Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Router Class Initialized
DEBUG - 2019-04-27 14:30:33 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:30:33 --> Output Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Security Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Input Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:30:33 --> Language Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Loader Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Controller Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Session Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:30:33 --> Session routines successfully run
DEBUG - 2019-04-27 14:30:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Model Class Initialized
DEBUG - 2019-04-27 14:30:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:30:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:30:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:30:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:30:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:30:33 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:30:33 --> Final output sent to browser
DEBUG - 2019-04-27 14:30:33 --> Total execution time: 0.1598
DEBUG - 2019-04-27 14:39:59 --> Config Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 14:39:59 --> URI Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Router Class Initialized
DEBUG - 2019-04-27 14:39:59 --> No URI present. Default controller set.
DEBUG - 2019-04-27 14:39:59 --> Output Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Security Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Input Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 14:39:59 --> Language Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Loader Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Controller Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:39:59 --> Model Class Initialized
DEBUG - 2019-04-27 14:40:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 14:40:00 --> Session Class Initialized
DEBUG - 2019-04-27 14:40:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 14:40:00 --> Session routines successfully run
DEBUG - 2019-04-27 14:40:00 --> Model Class Initialized
DEBUG - 2019-04-27 14:40:00 --> Model Class Initialized
DEBUG - 2019-04-27 14:40:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 14:40:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 14:40:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 14:40:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 14:40:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 14:40:00 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 14:40:00 --> Final output sent to browser
DEBUG - 2019-04-27 14:40:00 --> Total execution time: 0.1943
DEBUG - 2019-04-27 16:11:25 --> Config Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:11:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:11:25 --> URI Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Router Class Initialized
DEBUG - 2019-04-27 16:11:25 --> No URI present. Default controller set.
DEBUG - 2019-04-27 16:11:25 --> Output Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Security Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Input Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:11:25 --> Language Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Loader Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Controller Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Session Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:11:25 --> Session routines successfully run
DEBUG - 2019-04-27 16:11:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:11:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:11:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:11:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:11:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:11:25 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:11:25 --> Final output sent to browser
DEBUG - 2019-04-27 16:11:25 --> Total execution time: 0.2131
DEBUG - 2019-04-27 16:11:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:11:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:11:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:11:27 --> Session routines successfully run
DEBUG - 2019-04-27 16:11:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:11:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:11:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:11:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:11:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:11:27 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 16:11:27 --> Final output sent to browser
DEBUG - 2019-04-27 16:11:27 --> Total execution time: 0.0569
DEBUG - 2019-04-27 16:11:40 --> Config Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:11:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:11:40 --> URI Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Router Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Output Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Security Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Input Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:11:40 --> Language Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Loader Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Controller Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Session Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:11:40 --> Session routines successfully run
DEBUG - 2019-04-27 16:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:11:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:11:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:11:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:11:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:11:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:11:41 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:11:41 --> Final output sent to browser
DEBUG - 2019-04-27 16:11:41 --> Total execution time: 0.1481
DEBUG - 2019-04-27 16:12:08 --> Config Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:12:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:12:08 --> URI Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Router Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Output Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Security Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Input Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:12:08 --> Language Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Loader Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Controller Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Session Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:12:08 --> Session routines successfully run
DEBUG - 2019-04-27 16:12:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:12:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:12:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:12:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:12:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:12:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:12:08 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:12:08 --> Final output sent to browser
DEBUG - 2019-04-27 16:12:08 --> Total execution time: 0.1077
DEBUG - 2019-04-27 16:14:49 --> Config Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:14:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:14:49 --> URI Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Router Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Output Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Security Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Input Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:14:49 --> Language Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Loader Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Controller Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Session Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:14:49 --> Session routines successfully run
DEBUG - 2019-04-27 16:14:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:14:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:14:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:14:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:14:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:14:49 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:14:49 --> Final output sent to browser
DEBUG - 2019-04-27 16:14:49 --> Total execution time: 0.1476
DEBUG - 2019-04-27 16:14:50 --> Config Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:14:50 --> URI Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Router Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Output Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Security Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Input Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:14:50 --> Language Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Loader Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Controller Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Session Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:14:50 --> Session routines successfully run
DEBUG - 2019-04-27 16:14:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:14:50 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:14:50 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:14:50 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:14:50 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:14:50 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:14:50 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
ERROR - 2019-04-27 16:14:50 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:14:50 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
DEBUG - 2019-04-27 16:14:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:14:50 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:14:50 --> Final output sent to browser
DEBUG - 2019-04-27 16:14:50 --> Total execution time: 0.1374
DEBUG - 2019-04-27 16:15:46 --> Config Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:15:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:15:46 --> URI Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Router Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Output Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Security Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Input Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:15:46 --> Language Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Loader Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Controller Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Model Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Model Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Session Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:15:46 --> Session routines successfully run
DEBUG - 2019-04-27 16:15:46 --> Model Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Model Class Initialized
DEBUG - 2019-04-27 16:15:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:15:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:15:46 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:15:46 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:15:46 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:15:46 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:15:46 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:15:46 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:15:46 --> Final output sent to browser
DEBUG - 2019-04-27 16:15:46 --> Total execution time: 0.1272
DEBUG - 2019-04-27 16:16:18 --> Config Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:16:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:16:18 --> URI Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Router Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Output Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Security Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Input Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:16:18 --> Language Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Loader Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Controller Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Session Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:16:18 --> Session routines successfully run
DEBUG - 2019-04-27 16:16:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:16:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:16:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Config Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:16:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:16:58 --> URI Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Router Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Output Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Security Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Input Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:16:58 --> Language Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Loader Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Controller Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Session Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:16:58 --> Session routines successfully run
DEBUG - 2019-04-27 16:16:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:16:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:16:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:16:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:16:58 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:16:58 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:16:58 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:16:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:16:58 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:16:58 --> Final output sent to browser
DEBUG - 2019-04-27 16:16:58 --> Total execution time: 0.2260
DEBUG - 2019-04-27 16:18:05 --> Config Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:18:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:18:05 --> URI Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Router Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Output Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Security Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Input Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:18:05 --> Language Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Loader Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Controller Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Session Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:18:05 --> Session routines successfully run
DEBUG - 2019-04-27 16:18:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:05 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:18:05 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:18:05 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:18:05 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:18:05 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:18:05 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:18:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:18:05 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:18:05 --> Final output sent to browser
DEBUG - 2019-04-27 16:18:05 --> Total execution time: 0.1491
DEBUG - 2019-04-27 16:18:12 --> Config Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:18:12 --> URI Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Router Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Output Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Security Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Input Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:18:12 --> Language Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Loader Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Controller Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Session Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:18:12 --> Session routines successfully run
DEBUG - 2019-04-27 16:18:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:18:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:18:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:18:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:18:12 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:18:12 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:18:12 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:18:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:18:12 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:18:12 --> Final output sent to browser
DEBUG - 2019-04-27 16:18:12 --> Total execution time: 0.1274
DEBUG - 2019-04-27 16:19:03 --> Config Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:19:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:19:03 --> URI Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Router Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Output Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Security Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Input Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:19:03 --> Language Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Loader Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Controller Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:19:03 --> Session Class Initialized
DEBUG - 2019-04-27 16:19:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:19:04 --> Session routines successfully run
DEBUG - 2019-04-27 16:19:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:19:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:19:04 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:19:04 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:19:04 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:19:04 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:19:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:19:04 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:19:04 --> Final output sent to browser
DEBUG - 2019-04-27 16:19:04 --> Total execution time: 0.1478
DEBUG - 2019-04-27 16:19:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:19:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:19:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:19:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:19:27 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:19:27 --> Session routines successfully run
DEBUG - 2019-04-27 16:19:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:19:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:19:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:19:27 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:19:27 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:19:27 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:19:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:19:27 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:19:27 --> Final output sent to browser
DEBUG - 2019-04-27 16:19:27 --> Total execution time: 0.1906
DEBUG - 2019-04-27 16:19:42 --> Config Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:19:42 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:19:42 --> URI Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Router Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Output Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Security Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Input Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:19:42 --> Language Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Loader Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Controller Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Session Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:19:42 --> Session routines successfully run
DEBUG - 2019-04-27 16:19:42 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Model Class Initialized
DEBUG - 2019-04-27 16:19:42 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:19:42 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:19:42 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Config Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:20:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:20:13 --> URI Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Router Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Output Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Security Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Input Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:20:13 --> Language Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Loader Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Controller Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Session Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:20:13 --> Session routines successfully run
DEBUG - 2019-04-27 16:20:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:20:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:20:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:20:13 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:20:13 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:20:13 --> Severity: Notice  --> Undefined variable: notice C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:20:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:20:13 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:20:13 --> Final output sent to browser
DEBUG - 2019-04-27 16:20:13 --> Total execution time: 0.1536
DEBUG - 2019-04-27 16:20:53 --> Config Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:20:53 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:20:53 --> URI Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Router Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Output Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Security Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Input Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:20:53 --> Language Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Loader Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Controller Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Session Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:20:53 --> Session routines successfully run
DEBUG - 2019-04-27 16:20:53 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Model Class Initialized
DEBUG - 2019-04-27 16:20:53 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:20:53 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:20:53 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:20:53 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:20:53 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:20:53 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:20:53 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:20:53 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:20:53 --> Final output sent to browser
DEBUG - 2019-04-27 16:20:53 --> Total execution time: 0.1292
DEBUG - 2019-04-27 16:24:12 --> Config Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:24:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:24:12 --> URI Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Router Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Output Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Security Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Input Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:24:12 --> Language Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Loader Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Controller Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Session Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:24:12 --> Session routines successfully run
DEBUG - 2019-04-27 16:24:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:24:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:24:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:24:12 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:24:12 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:24:12 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:24:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:24:12 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:24:12 --> Final output sent to browser
DEBUG - 2019-04-27 16:24:12 --> Total execution time: 0.1971
DEBUG - 2019-04-27 16:24:15 --> Config Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:24:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:24:15 --> URI Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Router Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Output Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Security Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Input Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:24:15 --> Language Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Loader Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Controller Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Session Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:24:15 --> Session routines successfully run
DEBUG - 2019-04-27 16:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:15 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:24:15 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:24:15 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:24:15 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:24:15 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:24:15 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:24:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:24:15 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:24:15 --> Final output sent to browser
DEBUG - 2019-04-27 16:24:15 --> Total execution time: 0.1251
DEBUG - 2019-04-27 16:24:30 --> Config Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:24:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:24:30 --> URI Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Router Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Output Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Security Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Input Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:24:30 --> Language Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Loader Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Controller Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Session Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:24:30 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:24:30 --> Session routines successfully run
DEBUG - 2019-04-27 16:24:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:30 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:24:30 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:24:30 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:24:30 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:24:30 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
ERROR - 2019-04-27 16:24:30 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 27
DEBUG - 2019-04-27 16:24:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:24:30 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:24:30 --> Final output sent to browser
DEBUG - 2019-04-27 16:24:30 --> Total execution time: 0.1539
DEBUG - 2019-04-27 16:24:43 --> Config Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:24:43 --> URI Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Router Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Output Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Security Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Input Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:24:43 --> Language Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Loader Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Controller Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Session Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:24:43 --> Session routines successfully run
DEBUG - 2019-04-27 16:24:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:24:43 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:24:43 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:24:43 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:24:43 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:24:43 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
ERROR - 2019-04-27 16:24:43 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
DEBUG - 2019-04-27 16:24:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:24:43 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:24:43 --> Final output sent to browser
DEBUG - 2019-04-27 16:24:43 --> Total execution time: 0.1713
DEBUG - 2019-04-27 16:26:35 --> Config Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:26:35 --> URI Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Router Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Output Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Security Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Input Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:26:35 --> Language Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Loader Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Controller Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Session Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:26:35 --> Session routines successfully run
DEBUG - 2019-04-27 16:26:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:26:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:26:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:26:35 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:26:35 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
ERROR - 2019-04-27 16:26:35 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
DEBUG - 2019-04-27 16:26:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:26:35 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:26:35 --> Final output sent to browser
DEBUG - 2019-04-27 16:26:35 --> Total execution time: 0.1350
DEBUG - 2019-04-27 16:26:38 --> Config Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:26:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:26:38 --> URI Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Router Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Output Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Security Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Input Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:26:38 --> Language Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Loader Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Controller Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Session Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:26:38 --> Session routines successfully run
DEBUG - 2019-04-27 16:26:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:26:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:26:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:26:38 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:26:38 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
ERROR - 2019-04-27 16:26:38 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
DEBUG - 2019-04-27 16:26:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:26:38 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:26:38 --> Final output sent to browser
DEBUG - 2019-04-27 16:26:38 --> Total execution time: 0.0758
DEBUG - 2019-04-27 16:26:47 --> Config Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:26:47 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:26:47 --> URI Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Router Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Output Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Security Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Input Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:26:47 --> Language Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Loader Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Controller Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Session Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:26:47 --> Session routines successfully run
DEBUG - 2019-04-27 16:26:47 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Model Class Initialized
DEBUG - 2019-04-27 16:26:47 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:26:47 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:26:47 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:26:47 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:26:47 --> Severity: Warning  --> Use of undefined constant orderId - assumed 'orderId' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 7
ERROR - 2019-04-27 16:26:47 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
ERROR - 2019-04-27 16:26:47 --> Severity: Notice  --> Undefined index: orderId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 29
DEBUG - 2019-04-27 16:26:47 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:26:47 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:26:47 --> Final output sent to browser
DEBUG - 2019-04-27 16:26:47 --> Total execution time: 0.1174
DEBUG - 2019-04-27 16:27:11 --> Config Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:27:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:27:11 --> URI Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Router Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Output Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Security Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Input Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:27:11 --> Language Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Loader Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Controller Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Session Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:27:11 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:27:11 --> Session routines successfully run
DEBUG - 2019-04-27 16:27:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:27:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:27:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:27:11 --> File loaded: application/views/header.php
ERROR - 2019-04-27 16:27:11 --> Severity: Notice  --> Undefined index: userId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
ERROR - 2019-04-27 16:27:11 --> Severity: Notice  --> Undefined index: userId C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\views\orderDetails.php 28
DEBUG - 2019-04-27 16:27:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:27:11 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:27:11 --> Final output sent to browser
DEBUG - 2019-04-27 16:27:11 --> Total execution time: 0.1337
DEBUG - 2019-04-27 16:27:24 --> Config Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:27:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:27:24 --> URI Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Router Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Output Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Security Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Input Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:27:24 --> Language Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Loader Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Controller Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Session Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:27:24 --> Session routines successfully run
DEBUG - 2019-04-27 16:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:27:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:27:24 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:27:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:27:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:27:24 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:27:24 --> Final output sent to browser
DEBUG - 2019-04-27 16:27:24 --> Total execution time: 0.1085
DEBUG - 2019-04-27 16:27:35 --> Config Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:27:35 --> URI Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Router Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Output Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Security Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Input Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:27:35 --> Language Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Loader Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Controller Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Session Class Initialized
DEBUG - 2019-04-27 16:27:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:27:35 --> Session routines successfully run
DEBUG - 2019-04-27 16:27:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:28:32 --> Config Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:28:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:28:32 --> URI Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Router Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Output Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Security Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Input Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:28:32 --> Language Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Loader Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Controller Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Session Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:28:32 --> Session routines successfully run
DEBUG - 2019-04-27 16:28:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:28:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:28:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:28:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:28:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:28:32 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:28:32 --> Final output sent to browser
DEBUG - 2019-04-27 16:28:32 --> Total execution time: 0.0982
DEBUG - 2019-04-27 16:28:34 --> Config Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:28:34 --> URI Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Router Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Output Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Security Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Input Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:28:34 --> Language Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Loader Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Controller Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Session Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:28:34 --> Session routines successfully run
DEBUG - 2019-04-27 16:28:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:28:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:28:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:28:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:28:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:28:34 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:28:34 --> Final output sent to browser
DEBUG - 2019-04-27 16:28:34 --> Total execution time: 0.0887
DEBUG - 2019-04-27 16:28:35 --> Config Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:28:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:28:35 --> URI Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Router Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Output Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Security Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Input Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:28:35 --> Language Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Loader Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Controller Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Session Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:28:35 --> Session routines successfully run
DEBUG - 2019-04-27 16:28:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:28:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:28:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:28:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:28:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:28:35 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:28:35 --> Final output sent to browser
DEBUG - 2019-04-27 16:28:35 --> Total execution time: 0.1193
DEBUG - 2019-04-27 16:28:38 --> Config Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:28:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:28:38 --> URI Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Router Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Output Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Security Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Input Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:28:38 --> Language Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Loader Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Controller Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Session Class Initialized
DEBUG - 2019-04-27 16:28:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:28:38 --> Session routines successfully run
DEBUG - 2019-04-27 16:28:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:28:38 --> DB Transaction Failure
ERROR - 2019-04-27 16:28:38 --> Query error: Unknown column 'orderId' in 'where clause'
DEBUG - 2019-04-27 16:28:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-27 16:29:51 --> Config Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:29:51 --> URI Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Router Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Output Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Security Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Input Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:29:51 --> Language Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Loader Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Controller Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Session Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:29:51 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:29:51 --> Session routines successfully run
DEBUG - 2019-04-27 16:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:29:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:29:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:29:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:29:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:29:51 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:29:51 --> Final output sent to browser
DEBUG - 2019-04-27 16:29:51 --> Total execution time: 0.1325
DEBUG - 2019-04-27 16:29:54 --> Config Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:29:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:29:54 --> URI Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Router Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Output Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Security Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Input Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:29:54 --> Language Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Loader Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Controller Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Session Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:29:54 --> Session routines successfully run
DEBUG - 2019-04-27 16:29:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:54 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:29:54 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:29:54 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:29:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:29:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:29:54 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:29:54 --> Final output sent to browser
DEBUG - 2019-04-27 16:29:54 --> Total execution time: 0.1008
DEBUG - 2019-04-27 16:29:55 --> Config Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:29:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:29:55 --> URI Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Router Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Output Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Security Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Input Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:29:55 --> Language Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Loader Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Controller Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Session Class Initialized
DEBUG - 2019-04-27 16:29:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:29:55 --> Session routines successfully run
DEBUG - 2019-04-27 16:29:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:05 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:05 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:05 --> No URI present. Default controller set.
DEBUG - 2019-04-27 16:32:05 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:05 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:05 --> A session cookie was not found.
DEBUG - 2019-04-27 16:32:05 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:05 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:05 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:05 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:32:06 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:06 --> Total execution time: 0.1514
DEBUG - 2019-04-27 16:32:08 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:08 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:08 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:08 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:08 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:08 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 16:32:08 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:08 --> Total execution time: 0.0711
DEBUG - 2019-04-27 16:32:16 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:16 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:16 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:16 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:16 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:16 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:16 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:32:16 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:16 --> Total execution time: 0.1564
DEBUG - 2019-04-27 16:32:17 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:17 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:17 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:18 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:18 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:32:18 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:18 --> Total execution time: 0.1323
DEBUG - 2019-04-27 16:32:26 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:26 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:26 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:26 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:26 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:32:26 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:26 --> Total execution time: 0.0586
DEBUG - 2019-04-27 16:32:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:27 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:32:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:32:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:32:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:32:28 --> Session routines successfully run
DEBUG - 2019-04-27 16:32:28 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:28 --> Model Class Initialized
DEBUG - 2019-04-27 16:32:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:32:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:32:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:32:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:32:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:32:28 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:32:28 --> Final output sent to browser
DEBUG - 2019-04-27 16:32:28 --> Total execution time: 0.1153
DEBUG - 2019-04-27 16:36:31 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:31 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:31 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:31 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:31 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:31 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:36:31 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:31 --> Total execution time: 0.0736
DEBUG - 2019-04-27 16:36:32 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:32 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:32 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:32 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:32 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:36:32 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:32 --> Total execution time: 0.1155
DEBUG - 2019-04-27 16:36:43 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:43 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:43 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:43 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:36:43 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:43 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:43 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:43 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:44 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:44 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:44 --> A session cookie was not found.
DEBUG - 2019-04-27 16:36:44 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:44 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:36:44 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:44 --> Total execution time: 0.1342
DEBUG - 2019-04-27 16:36:45 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:45 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:45 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:45 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:45 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:45 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:45 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:45 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:45 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:45 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:45 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:45 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 16:36:45 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:45 --> Total execution time: 0.0539
DEBUG - 2019-04-27 16:36:55 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:55 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:55 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:55 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:55 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:55 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:55 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:56 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:56 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:56 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:36:56 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:56 --> Total execution time: 0.1851
DEBUG - 2019-04-27 16:36:58 --> Config Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:36:58 --> URI Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Router Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Output Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Security Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Input Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:36:58 --> Language Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Loader Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Controller Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Session Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:36:58 --> Session routines successfully run
DEBUG - 2019-04-27 16:36:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Model Class Initialized
DEBUG - 2019-04-27 16:36:58 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:36:58 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:36:58 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:36:58 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:36:58 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:36:58 --> File loaded: application/views/orderDetails.php
DEBUG - 2019-04-27 16:36:58 --> Final output sent to browser
DEBUG - 2019-04-27 16:36:58 --> Total execution time: 0.0872
DEBUG - 2019-04-27 16:38:01 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:01 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:01 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:01 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:01 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:01 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:01 --> A session cookie was not found.
DEBUG - 2019-04-27 16:38:01 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:38:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:38:01 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:38:01 --> Final output sent to browser
DEBUG - 2019-04-27 16:38:01 --> Total execution time: 0.1572
DEBUG - 2019-04-27 16:38:02 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:02 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:02 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:02 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:38:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:38:02 --> File loaded: application/views/logonUser.php
DEBUG - 2019-04-27 16:38:02 --> Final output sent to browser
DEBUG - 2019-04-27 16:38:02 --> Total execution time: 0.0712
DEBUG - 2019-04-27 16:38:09 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:09 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:09 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:09 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:38:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:38:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:38:10 --> Final output sent to browser
DEBUG - 2019-04-27 16:38:10 --> Total execution time: 0.1313
DEBUG - 2019-04-27 16:38:11 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:11 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:11 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:11 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:38:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:38:11 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:38:11 --> Final output sent to browser
DEBUG - 2019-04-27 16:38:11 --> Total execution time: 0.1501
DEBUG - 2019-04-27 16:38:21 --> Config Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:38:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:38:21 --> URI Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Router Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Output Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Security Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Input Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:38:21 --> Language Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Loader Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Controller Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:38:22 --> Session Class Initialized
DEBUG - 2019-04-27 16:38:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:38:22 --> Session routines successfully run
DEBUG - 2019-04-27 16:38:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:38:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:38:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:38:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:38:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:38:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:38:22 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:38:22 --> Final output sent to browser
DEBUG - 2019-04-27 16:38:22 --> Total execution time: 0.0971
DEBUG - 2019-04-27 16:39:00 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:00 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:00 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:00 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:00 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:39:00 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:00 --> Total execution time: 0.1309
DEBUG - 2019-04-27 16:39:01 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:01 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:01 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:01 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:01 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:39:01 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:01 --> Total execution time: 0.1031
DEBUG - 2019-04-27 16:39:02 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:02 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:02 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:02 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:02 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:39:02 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:02 --> Total execution time: 0.0464
DEBUG - 2019-04-27 16:39:04 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:04 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:04 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:04 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:04 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:04 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:39:04 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:04 --> Total execution time: 0.1173
DEBUG - 2019-04-27 16:39:05 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:05 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:05 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:05 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:05 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:05 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:05 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:05 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:05 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:05 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:39:05 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:05 --> Total execution time: 0.0572
DEBUG - 2019-04-27 16:39:10 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:10 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:10 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:10 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:10 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:39:10 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:10 --> Total execution time: 0.0740
DEBUG - 2019-04-27 16:39:14 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:14 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:14 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:14 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:14 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:14 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:14 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:14 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:14 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:14 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:14 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:39:14 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:14 --> Total execution time: 0.0529
DEBUG - 2019-04-27 16:39:16 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:16 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:16 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:16 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:16 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:16 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:16 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:16 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:16 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:16 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:39:16 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:16 --> Total execution time: 0.1036
DEBUG - 2019-04-27 16:39:38 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:38 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:38 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:38 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:38 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:39:38 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:38 --> Total execution time: 0.0648
DEBUG - 2019-04-27 16:39:43 --> Config Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:39:43 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:39:43 --> URI Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Router Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Output Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Security Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Input Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:39:43 --> Language Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Loader Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Controller Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Session Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:39:43 --> Session routines successfully run
DEBUG - 2019-04-27 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Model Class Initialized
DEBUG - 2019-04-27 16:39:43 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:39:43 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:39:43 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:39:43 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:39:43 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:39:43 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:39:43 --> Final output sent to browser
DEBUG - 2019-04-27 16:39:43 --> Total execution time: 0.0546
DEBUG - 2019-04-27 16:41:15 --> Config Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:41:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:41:15 --> URI Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Router Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Output Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Security Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Input Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:41:15 --> Language Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Loader Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Controller Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Session Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:41:15 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:41:15 --> Session routines successfully run
DEBUG - 2019-04-27 16:41:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:15 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:41:15 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:41:15 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:41:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:41:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:41:15 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:41:15 --> Final output sent to browser
DEBUG - 2019-04-27 16:41:15 --> Total execution time: 0.0527
DEBUG - 2019-04-27 16:41:19 --> Config Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:41:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:41:19 --> URI Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Router Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Output Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Security Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Input Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:41:19 --> Language Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Loader Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Controller Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Session Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:41:19 --> Session routines successfully run
DEBUG - 2019-04-27 16:41:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:41:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:41:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:41:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:41:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:41:19 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:41:19 --> Final output sent to browser
DEBUG - 2019-04-27 16:41:19 --> Total execution time: 0.0584
DEBUG - 2019-04-27 16:41:39 --> Config Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:41:39 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:41:39 --> URI Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Router Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Output Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Security Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Input Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:41:39 --> Language Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Loader Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Controller Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Session Class Initialized
DEBUG - 2019-04-27 16:41:39 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:41:39 --> Session routines successfully run
DEBUG - 2019-04-27 16:41:39 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:41:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:41:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:41:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:41:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:41:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:41:40 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:41:40 --> Final output sent to browser
DEBUG - 2019-04-27 16:41:40 --> Total execution time: 0.0624
DEBUG - 2019-04-27 16:42:04 --> Config Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:42:04 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:42:04 --> URI Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Router Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Output Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Security Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Input Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:42:04 --> Language Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Loader Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Controller Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Session Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:42:04 --> Session routines successfully run
DEBUG - 2019-04-27 16:42:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:42:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:42:04 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:42:04 --> Severity: Notice  --> Undefined index: type C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 190
DEBUG - 2019-04-27 16:42:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:42:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:42:04 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:42:04 --> Final output sent to browser
DEBUG - 2019-04-27 16:42:04 --> Total execution time: 0.1071
DEBUG - 2019-04-27 16:42:15 --> Config Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:42:15 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:42:15 --> URI Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Router Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Output Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Security Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Input Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:42:15 --> Language Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Loader Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Controller Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Session Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:42:15 --> Session routines successfully run
DEBUG - 2019-04-27 16:42:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Model Class Initialized
DEBUG - 2019-04-27 16:42:15 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:42:15 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:42:15 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:42:15 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:42:15 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:42:15 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:42:15 --> Final output sent to browser
DEBUG - 2019-04-27 16:42:15 --> Total execution time: 0.0581
DEBUG - 2019-04-27 16:43:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:43:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:43:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:43:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:43:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:43:28 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:43:28 --> Session routines successfully run
DEBUG - 2019-04-27 16:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:28 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:28 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:43:28 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:43:28 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:43:28 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:43:28 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:43:28 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:43:28 --> Final output sent to browser
DEBUG - 2019-04-27 16:43:28 --> Total execution time: 0.1175
DEBUG - 2019-04-27 16:43:35 --> Config Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:43:35 --> URI Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Router Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Output Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Security Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Input Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:43:35 --> Language Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Loader Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Controller Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Session Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:43:35 --> Session routines successfully run
DEBUG - 2019-04-27 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:43:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:43:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:43:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:43:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:43:35 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:43:35 --> Final output sent to browser
DEBUG - 2019-04-27 16:43:35 --> Total execution time: 0.1277
DEBUG - 2019-04-27 16:43:37 --> Config Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:43:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:43:37 --> URI Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Router Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Output Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Security Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Input Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:43:37 --> Language Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Loader Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Controller Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Session Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:43:37 --> Session routines successfully run
DEBUG - 2019-04-27 16:43:37 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Model Class Initialized
DEBUG - 2019-04-27 16:43:37 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:43:37 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:43:37 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:43:37 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:43:37 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:43:37 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:43:37 --> Final output sent to browser
DEBUG - 2019-04-27 16:43:37 --> Total execution time: 0.0453
DEBUG - 2019-04-27 16:44:32 --> Config Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:44:32 --> URI Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Router Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Output Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Security Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Input Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:44:32 --> Language Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Loader Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Controller Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Session Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:44:32 --> Session routines successfully run
DEBUG - 2019-04-27 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:44:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:44:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:44:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:44:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:44:32 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:44:32 --> Final output sent to browser
DEBUG - 2019-04-27 16:44:32 --> Total execution time: 0.0600
DEBUG - 2019-04-27 16:44:33 --> Config Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:44:33 --> URI Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Router Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Output Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Security Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Input Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:44:33 --> Language Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Loader Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Controller Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Session Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:44:33 --> Session routines successfully run
DEBUG - 2019-04-27 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:44:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:44:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:44:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:44:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:44:33 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:44:33 --> Final output sent to browser
DEBUG - 2019-04-27 16:44:33 --> Total execution time: 0.2036
DEBUG - 2019-04-27 16:44:34 --> Config Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:44:34 --> URI Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Router Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Output Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Security Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Input Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:44:34 --> Language Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Loader Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Controller Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Session Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:44:34 --> Session routines successfully run
DEBUG - 2019-04-27 16:44:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:44:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:44:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:44:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:44:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:44:34 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:44:34 --> Final output sent to browser
DEBUG - 2019-04-27 16:44:34 --> Total execution time: 0.0573
DEBUG - 2019-04-27 16:44:38 --> Config Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:44:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:44:38 --> URI Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Router Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Output Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Security Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Input Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:44:38 --> Language Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Loader Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Controller Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Session Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:44:38 --> Session routines successfully run
DEBUG - 2019-04-27 16:44:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:44:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:44:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:44:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:44:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:44:38 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:44:38 --> Final output sent to browser
DEBUG - 2019-04-27 16:44:38 --> Total execution time: 0.0649
DEBUG - 2019-04-27 16:44:44 --> Config Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:44:44 --> URI Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Router Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Output Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Security Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Input Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:44:44 --> Language Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Loader Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Controller Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Session Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:44:44 --> Session routines successfully run
DEBUG - 2019-04-27 16:44:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Model Class Initialized
DEBUG - 2019-04-27 16:44:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:44:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:44:44 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:44:44 --> Severity: Notice  --> Undefined property: User::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:44:44 --> DB Transaction Failure
ERROR - 2019-04-27 16:44:44 --> Query error: Unknown column 'largeImage' in 'field list'
DEBUG - 2019-04-27 16:44:44 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-27 16:45:10 --> Config Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:45:10 --> URI Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Router Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Output Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Security Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Input Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:45:10 --> Language Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Loader Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Controller Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Session Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:45:10 --> Session routines successfully run
DEBUG - 2019-04-27 16:45:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:45:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:45:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:45:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:45:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:45:10 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:45:10 --> Final output sent to browser
DEBUG - 2019-04-27 16:45:10 --> Total execution time: 0.1059
DEBUG - 2019-04-27 16:45:11 --> Config Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:45:11 --> URI Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Router Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Output Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Security Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Input Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:45:11 --> Language Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Loader Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Controller Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Session Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:45:11 --> Session routines successfully run
DEBUG - 2019-04-27 16:45:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:45:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:45:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:45:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:45:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:45:11 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:45:11 --> Final output sent to browser
DEBUG - 2019-04-27 16:45:11 --> Total execution time: 0.0462
DEBUG - 2019-04-27 16:45:13 --> Config Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:45:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:45:13 --> URI Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Router Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Output Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Security Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Input Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:45:13 --> Language Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Loader Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Controller Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Session Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:45:13 --> Session routines successfully run
DEBUG - 2019-04-27 16:45:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:45:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:45:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:45:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:45:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:45:13 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:45:13 --> Final output sent to browser
DEBUG - 2019-04-27 16:45:13 --> Total execution time: 0.0565
DEBUG - 2019-04-27 16:45:19 --> Config Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:45:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:45:19 --> URI Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Router Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Output Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Security Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Input Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:45:19 --> Language Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Loader Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Controller Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Session Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:45:19 --> Session routines successfully run
DEBUG - 2019-04-27 16:45:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Model Class Initialized
DEBUG - 2019-04-27 16:45:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:45:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:45:19 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:45:19 --> Severity: Notice  --> Undefined property: User::$Portrait C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:45:19 --> DB Transaction Failure
ERROR - 2019-04-27 16:45:19 --> Query error: Unknown column 'largeImage' in 'field list'
DEBUG - 2019-04-27 16:45:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2019-04-27 16:51:07 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:07 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:07 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:08 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:08 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:08 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:08 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:08 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:08 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:08 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:08 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:51:08 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:08 --> Total execution time: 0.1781
DEBUG - 2019-04-27 16:51:09 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:09 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:09 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:09 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:10 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:10 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:10 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:10 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:51:10 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:10 --> Total execution time: 0.0556
DEBUG - 2019-04-27 16:51:11 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:11 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:11 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:11 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:11 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:51:11 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:11 --> Total execution time: 0.0551
DEBUG - 2019-04-27 16:51:24 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:24 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:24 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:24 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:24 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:51:24 --> Severity: Notice  --> Undefined property: User::$Portrait C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:51:24 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:24 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:24 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:51:24 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:24 --> Total execution time: 0.0974
DEBUG - 2019-04-27 16:51:50 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:50 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:50 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:50 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:50 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:50 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:50 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:50 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:51:50 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:50 --> Total execution time: 0.1214
DEBUG - 2019-04-27 16:51:51 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:51 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:51 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:51 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:51 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:51:51 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:51 --> Total execution time: 0.0635
DEBUG - 2019-04-27 16:51:54 --> Config Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:51:54 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:51:54 --> URI Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Router Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Output Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Security Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Input Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:51:54 --> Language Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Loader Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Controller Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Session Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:51:54 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:51:54 --> Session routines successfully run
DEBUG - 2019-04-27 16:51:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Model Class Initialized
DEBUG - 2019-04-27 16:51:54 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:51:54 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:51:54 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:51:54 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:51:54 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:51:54 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:51:54 --> Final output sent to browser
DEBUG - 2019-04-27 16:51:54 --> Total execution time: 0.0732
DEBUG - 2019-04-27 16:52:02 --> Config Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:52:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:52:02 --> URI Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Router Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Output Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Security Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Input Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:52:02 --> Language Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Loader Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Controller Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Session Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:52:02 --> Session routines successfully run
DEBUG - 2019-04-27 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:52:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:52:02 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:52:02 --> Severity: Notice  --> Undefined property: User::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:52:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:52:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:52:02 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:52:02 --> Final output sent to browser
DEBUG - 2019-04-27 16:52:02 --> Total execution time: 0.1116
DEBUG - 2019-04-27 16:52:49 --> Config Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:52:49 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:52:49 --> URI Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Router Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Output Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Security Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Input Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:52:49 --> Language Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Loader Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Controller Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Session Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:52:49 --> Session routines successfully run
DEBUG - 2019-04-27 16:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:49 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:52:49 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:52:49 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:52:49 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:52:49 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:52:49 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:52:49 --> Final output sent to browser
DEBUG - 2019-04-27 16:52:49 --> Total execution time: 0.0591
DEBUG - 2019-04-27 16:52:50 --> Config Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:52:50 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:52:50 --> URI Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Router Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Output Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Security Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Input Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:52:50 --> Language Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Loader Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Controller Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Session Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:52:50 --> Session routines successfully run
DEBUG - 2019-04-27 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:50 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:52:50 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:52:50 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:52:50 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:52:50 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:52:50 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:52:50 --> Final output sent to browser
DEBUG - 2019-04-27 16:52:50 --> Total execution time: 0.0564
DEBUG - 2019-04-27 16:52:51 --> Config Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:52:51 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:52:51 --> URI Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Router Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Output Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Security Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Input Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:52:51 --> Language Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Loader Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Controller Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Session Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:52:51 --> Session routines successfully run
DEBUG - 2019-04-27 16:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:51 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:52:51 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:52:51 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:52:51 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:52:51 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:52:51 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:52:51 --> Final output sent to browser
DEBUG - 2019-04-27 16:52:51 --> Total execution time: 0.0605
DEBUG - 2019-04-27 16:52:59 --> Config Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:52:59 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:52:59 --> URI Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Router Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Output Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Security Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Input Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:52:59 --> Language Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Loader Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Controller Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Session Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:52:59 --> Session routines successfully run
DEBUG - 2019-04-27 16:52:59 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Model Class Initialized
DEBUG - 2019-04-27 16:52:59 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:52:59 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:52:59 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:52:59 --> Severity: Notice  --> Undefined property: User::$images C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:52:59 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:52:59 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:52:59 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:52:59 --> Final output sent to browser
DEBUG - 2019-04-27 16:52:59 --> Total execution time: 0.1270
DEBUG - 2019-04-27 16:53:29 --> Config Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:53:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:53:29 --> URI Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Router Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Output Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Security Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Input Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:53:29 --> Language Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Loader Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Controller Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Session Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:53:29 --> Session routines successfully run
DEBUG - 2019-04-27 16:53:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:53:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:53:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:53:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:53:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:53:29 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:53:29 --> Final output sent to browser
DEBUG - 2019-04-27 16:53:29 --> Total execution time: 0.1119
DEBUG - 2019-04-27 16:53:30 --> Config Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:53:30 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:53:30 --> URI Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Router Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Output Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Security Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Input Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:53:30 --> Language Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Loader Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Controller Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Session Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:53:30 --> Session routines successfully run
DEBUG - 2019-04-27 16:53:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:30 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:53:30 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:53:30 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:53:30 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:53:30 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:53:30 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:53:30 --> Final output sent to browser
DEBUG - 2019-04-27 16:53:30 --> Total execution time: 0.0698
DEBUG - 2019-04-27 16:53:32 --> Config Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:53:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:53:32 --> URI Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Router Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Output Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Security Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Input Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:53:32 --> Language Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Loader Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Controller Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Session Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:53:32 --> Session routines successfully run
DEBUG - 2019-04-27 16:53:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:53:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:53:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:53:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:53:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:53:32 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:53:32 --> Final output sent to browser
DEBUG - 2019-04-27 16:53:32 --> Total execution time: 0.0535
DEBUG - 2019-04-27 16:53:37 --> Config Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:53:37 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:53:37 --> URI Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Router Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Output Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Security Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Input Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:53:37 --> Language Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Loader Class Initialized
DEBUG - 2019-04-27 16:53:37 --> Controller Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Session Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:53:38 --> Session routines successfully run
DEBUG - 2019-04-27 16:53:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Model Class Initialized
DEBUG - 2019-04-27 16:53:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:53:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:53:38 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:53:38 --> Severity: Notice  --> Undefined property: User::$userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:53:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:53:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:53:38 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:53:38 --> Final output sent to browser
DEBUG - 2019-04-27 16:53:38 --> Total execution time: 0.1130
DEBUG - 2019-04-27 16:54:22 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:22 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:22 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:22 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:22 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:54:22 --> Severity: Notice  --> Undefined property: User::$userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:54:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:22 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:54:22 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:22 --> Total execution time: 0.1249
DEBUG - 2019-04-27 16:54:26 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:26 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:26 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:26 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:26 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:26 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:26 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:26 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:54:26 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:26 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:26 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 16:54:26 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:26 --> Total execution time: 0.0999
DEBUG - 2019-04-27 16:54:27 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:27 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:27 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:27 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:27 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:27 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:27 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:27 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:54:27 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:27 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:27 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 16:54:27 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:27 --> Total execution time: 0.0585
DEBUG - 2019-04-27 16:54:29 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:29 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:29 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:29 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 16:54:29 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:29 --> Total execution time: 0.0740
DEBUG - 2019-04-27 16:54:29 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:29 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:29 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:29 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:29 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:54:29 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:29 --> Total execution time: 0.0616
DEBUG - 2019-04-27 16:54:32 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:32 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:32 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:32 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:54:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:32 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:54:32 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:32 --> Total execution time: 0.0699
DEBUG - 2019-04-27 16:54:40 --> Config Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:54:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:54:40 --> URI Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Router Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Output Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Security Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Input Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:54:40 --> Language Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Loader Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Controller Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Session Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:54:40 --> Session routines successfully run
DEBUG - 2019-04-27 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:54:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:54:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:54:40 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:54:40 --> Severity: Notice  --> Undefined property: User::$userID C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:54:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:54:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:54:40 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:54:40 --> Final output sent to browser
DEBUG - 2019-04-27 16:54:40 --> Total execution time: 0.1183
DEBUG - 2019-04-27 16:56:25 --> Config Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:56:25 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:56:25 --> URI Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Router Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Output Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Security Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Input Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:56:25 --> Language Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Loader Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Controller Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Session Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:56:25 --> Session routines successfully run
DEBUG - 2019-04-27 16:56:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:25 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:56:25 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:56:25 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:56:25 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:56:25 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:56:25 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:56:25 --> Final output sent to browser
DEBUG - 2019-04-27 16:56:25 --> Total execution time: 0.1382
DEBUG - 2019-04-27 16:56:31 --> Config Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:56:31 --> URI Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Router Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Output Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Security Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Input Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:56:31 --> Language Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Loader Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Controller Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Session Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:56:31 --> Session routines successfully run
DEBUG - 2019-04-27 16:56:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:56:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:56:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:56:31 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:56:31 --> Severity: Notice  --> Undefined property: User::$user C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:57:03 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:03 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:03 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:03 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:03 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:03 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:04 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:04 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:04 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:04 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:04 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:04 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:57:04 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:04 --> Total execution time: 0.0684
DEBUG - 2019-04-27 16:57:05 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:05 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:05 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:05 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:06 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:06 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:06 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:06 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:06 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:06 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:57:06 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:06 --> Total execution time: 0.0591
DEBUG - 2019-04-27 16:57:07 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:07 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:07 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:07 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:07 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:57:07 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:07 --> Total execution time: 0.0522
DEBUG - 2019-04-27 16:57:10 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:10 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:10 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:10 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:10 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:10 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:10 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:10 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:57:10 --> Severity: Notice  --> Undefined index: Portrait C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:57:18 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:18 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:18 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:18 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:18 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:57:18 --> Severity: Notice  --> Undefined index: Portrait C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:57:29 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:29 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:29 --> No URI present. Default controller set.
DEBUG - 2019-04-27 16:57:29 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:29 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:29 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:29 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:29 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:29 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:29 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:29 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:29 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:57:29 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:29 --> Total execution time: 0.0842
DEBUG - 2019-04-27 16:57:31 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:31 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:31 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:31 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:31 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:31 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:31 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:31 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:31 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:31 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:57:31 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:31 --> Total execution time: 0.1233
DEBUG - 2019-04-27 16:57:34 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:34 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:34 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:34 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:34 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:34 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:34 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:57:34 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:57:34 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:57:34 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:57:34 --> Final output sent to browser
DEBUG - 2019-04-27 16:57:34 --> Total execution time: 0.0733
DEBUG - 2019-04-27 16:57:40 --> Config Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:57:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:57:40 --> URI Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Router Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Output Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Security Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Input Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:57:40 --> Language Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Loader Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Controller Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Session Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:57:40 --> Session garbage collection performed.
DEBUG - 2019-04-27 16:57:40 --> Session routines successfully run
DEBUG - 2019-04-27 16:57:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Model Class Initialized
DEBUG - 2019-04-27 16:57:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:57:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:57:40 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:57:40 --> Severity: Notice  --> Undefined index: Portrait C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:59:06 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:06 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:06 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:06 --> No URI present. Default controller set.
DEBUG - 2019-04-27 16:59:06 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:06 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:06 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:06 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:06 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:06 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:59:06 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:59:06 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:59:06 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 16:59:06 --> Final output sent to browser
DEBUG - 2019-04-27 16:59:06 --> Total execution time: 0.1177
DEBUG - 2019-04-27 16:59:07 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:07 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:07 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:07 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:07 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:07 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:07 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:07 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:59:07 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:59:07 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:59:07 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:59:07 --> Final output sent to browser
DEBUG - 2019-04-27 16:59:07 --> Total execution time: 0.0575
DEBUG - 2019-04-27 16:59:09 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:09 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:09 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:09 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:09 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:09 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:09 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:59:09 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:59:09 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:59:09 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:59:09 --> Final output sent to browser
DEBUG - 2019-04-27 16:59:09 --> Total execution time: 0.0606
DEBUG - 2019-04-27 16:59:17 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:17 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:17 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:17 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:17 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:17 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:17 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:17 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:17 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:59:17 --> Severity: Notice  --> Undefined property: User::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 16:59:21 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:21 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:21 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:21 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:22 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:22 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:22 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:22 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:22 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:22 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:59:22 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:59:22 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:59:22 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 16:59:22 --> Final output sent to browser
DEBUG - 2019-04-27 16:59:22 --> Total execution time: 0.0670
DEBUG - 2019-04-27 16:59:23 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:23 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:23 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:23 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:23 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:23 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:23 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:23 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:23 --> Form Validation Class Initialized
DEBUG - 2019-04-27 16:59:23 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 16:59:23 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 16:59:23 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 16:59:23 --> Final output sent to browser
DEBUG - 2019-04-27 16:59:23 --> Total execution time: 0.0570
DEBUG - 2019-04-27 16:59:34 --> Config Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Hooks Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Utf8 Class Initialized
DEBUG - 2019-04-27 16:59:34 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 16:59:34 --> URI Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Router Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Output Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Security Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Input Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 16:59:34 --> Language Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Loader Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Controller Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:34 --> Database Driver Class Initialized
DEBUG - 2019-04-27 16:59:35 --> Session Class Initialized
DEBUG - 2019-04-27 16:59:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 16:59:35 --> Session routines successfully run
DEBUG - 2019-04-27 16:59:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:35 --> Model Class Initialized
DEBUG - 2019-04-27 16:59:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 16:59:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 16:59:35 --> Form Validation Class Initialized
ERROR - 2019-04-27 16:59:35 --> Severity: Notice  --> Undefined property: User::$imageName C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 17:00:02 --> Config Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:00:02 --> URI Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Router Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Output Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Security Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Input Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:00:02 --> Language Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Loader Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Controller Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Session Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:00:02 --> Session routines successfully run
DEBUG - 2019-04-27 17:00:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:00:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:00:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:00:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:00:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:00:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:00:02 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 17:00:02 --> Final output sent to browser
DEBUG - 2019-04-27 17:00:02 --> Total execution time: 0.1109
DEBUG - 2019-04-27 17:01:18 --> Config Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:01:18 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:01:18 --> URI Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Router Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Output Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Security Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Input Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:01:18 --> Language Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Loader Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Controller Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Session Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:01:18 --> Session routines successfully run
DEBUG - 2019-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:18 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:01:18 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:01:18 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:01:18 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:01:18 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:01:18 --> File loaded: application/views/profile.php
DEBUG - 2019-04-27 17:01:18 --> Final output sent to browser
DEBUG - 2019-04-27 17:01:18 --> Total execution time: 0.0624
DEBUG - 2019-04-27 17:01:19 --> Config Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:01:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:01:19 --> URI Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Router Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Output Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Security Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Input Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:01:19 --> Language Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Loader Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Controller Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Session Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:01:19 --> Session routines successfully run
DEBUG - 2019-04-27 17:01:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:01:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:01:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:01:19 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:01:19 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:01:19 --> File loaded: application/views/updateUserDetails.php
DEBUG - 2019-04-27 17:01:19 --> Final output sent to browser
DEBUG - 2019-04-27 17:01:19 --> Total execution time: 0.0589
DEBUG - 2019-04-27 17:01:24 --> Config Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:01:24 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:01:24 --> URI Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Router Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Output Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Security Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Input Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:01:24 --> Language Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Loader Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Controller Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Session Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:01:24 --> Session routines successfully run
DEBUG - 2019-04-27 17:01:24 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:24 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:01:24 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:01:24 --> Form Validation Class Initialized
ERROR - 2019-04-27 17:01:24 --> Severity: Notice  --> Undefined property: User::$data C:\xampp\htdocs\K00243720\CodeIgniter\CIFYP2019\application\controllers\User.php 191
DEBUG - 2019-04-27 17:01:32 --> Config Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:01:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:01:32 --> URI Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Router Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Output Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Security Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Input Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:01:32 --> Language Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Loader Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Controller Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Session Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:01:32 --> Session routines successfully run
DEBUG - 2019-04-27 17:01:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:01:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:01:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:01:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:01:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:01:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:01:32 --> File loaded: application/views/usersHomePage.php
DEBUG - 2019-04-27 17:01:32 --> Final output sent to browser
DEBUG - 2019-04-27 17:01:32 --> Total execution time: 0.1736
DEBUG - 2019-04-27 17:08:38 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:38 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:38 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:38 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:38 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:38 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:38 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:38 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:38 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:08:38 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:08:38 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:08:38 --> Final output sent to browser
DEBUG - 2019-04-27 17:08:38 --> Total execution time: 0.1362
DEBUG - 2019-04-27 17:08:40 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:40 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:40 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:40 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:40 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:40 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:40 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:40 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:40 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:40 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:08:40 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:08:40 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:08:40 --> Final output sent to browser
DEBUG - 2019-04-27 17:08:40 --> Total execution time: 0.0665
DEBUG - 2019-04-27 17:08:41 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:41 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:41 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:41 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:41 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:41 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:41 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:41 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:41 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:41 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:08:41 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:08:41 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:08:41 --> Final output sent to browser
DEBUG - 2019-04-27 17:08:41 --> Total execution time: 0.0447
DEBUG - 2019-04-27 17:08:44 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:44 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:44 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:44 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:44 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:44 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:44 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:44 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:44 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:44 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:44 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:08:44 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:08:44 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:08:44 --> Final output sent to browser
DEBUG - 2019-04-27 17:08:44 --> Total execution time: 0.1077
DEBUG - 2019-04-27 17:08:57 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:57 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:57 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Router Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Output Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Security Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Input Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:08:57 --> Language Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Loader Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Controller Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Session Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:08:57 --> Session routines successfully run
DEBUG - 2019-04-27 17:08:57 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Model Class Initialized
DEBUG - 2019-04-27 17:08:57 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:08:57 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:08:57 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:08:57 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:08:57 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:08:57 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:08:57 --> Final output sent to browser
DEBUG - 2019-04-27 17:08:57 --> Total execution time: 0.0612
DEBUG - 2019-04-27 17:08:58 --> Config Class Initialized
DEBUG - 2019-04-27 17:08:58 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:08:58 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:08:58 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:08:58 --> URI Class Initialized
DEBUG - 2019-04-27 17:08:58 --> Router Class Initialized
ERROR - 2019-04-27 17:08:58 --> 404 Page Not Found --> Organic%20carrots%20
DEBUG - 2019-04-27 17:09:01 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:01 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:01 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:01 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:01 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:01 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:01 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:09:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:09:01 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:09:01 --> Final output sent to browser
DEBUG - 2019-04-27 17:09:01 --> Total execution time: 0.0780
DEBUG - 2019-04-27 17:09:05 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:05 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:05 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:05 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:05 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:05 --> Router Class Initialized
ERROR - 2019-04-27 17:09:05 --> 404 Page Not Found --> Organic%20carrots%20
DEBUG - 2019-04-27 17:09:11 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:11 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:11 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:11 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:11 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:11 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:11 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:11 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:11 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:11 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:09:11 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:09:11 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:09:11 --> Final output sent to browser
DEBUG - 2019-04-27 17:09:11 --> Total execution time: 0.1163
DEBUG - 2019-04-27 17:09:16 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:16 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:16 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:16 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:16 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:16 --> Router Class Initialized
ERROR - 2019-04-27 17:09:16 --> 404 Page Not Found --> Organic%20carrots%20
DEBUG - 2019-04-27 17:09:20 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:20 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:20 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:20 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:20 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Config Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:09:20 --> URI Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Router Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Output Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Security Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Input Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:09:20 --> Language Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Loader Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Controller Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Session Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:09:20 --> Session routines successfully run
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Model Class Initialized
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:09:20 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:09:20 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:09:20 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:09:20 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:09:20 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:09:20 --> Final output sent to browser
DEBUG - 2019-04-27 17:09:20 --> Total execution time: 0.1218
DEBUG - 2019-04-27 17:11:00 --> Config Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:11:00 --> URI Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Router Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Output Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Security Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Input Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:11:00 --> Language Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Loader Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Controller Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Session Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:11:00 --> Session routines successfully run
DEBUG - 2019-04-27 17:11:00 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:00 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:11:00 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:11:00 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:11:00 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:11:00 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:11:00 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:11:00 --> Final output sent to browser
DEBUG - 2019-04-27 17:11:00 --> Total execution time: 0.1475
DEBUG - 2019-04-27 17:11:01 --> Config Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:11:01 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:11:01 --> URI Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Router Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Output Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Security Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Input Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:11:01 --> Language Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Loader Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Controller Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Session Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:11:01 --> Session routines successfully run
DEBUG - 2019-04-27 17:11:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:01 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:11:01 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:11:01 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:11:01 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:11:01 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:11:01 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:11:01 --> Final output sent to browser
DEBUG - 2019-04-27 17:11:01 --> Total execution time: 0.0704
DEBUG - 2019-04-27 17:11:02 --> Config Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:11:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:11:02 --> URI Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Router Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Output Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Security Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Input Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:11:02 --> Language Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Loader Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Controller Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Session Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:11:02 --> Session routines successfully run
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:11:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Config Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:11:02 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:11:02 --> URI Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Router Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Output Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Security Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Input Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:11:02 --> Language Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Loader Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Controller Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Session Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:11:02 --> Session routines successfully run
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Model Class Initialized
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:11:02 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:11:02 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:11:02 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:11:02 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:11:02 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:11:02 --> Final output sent to browser
DEBUG - 2019-04-27 17:11:02 --> Total execution time: 0.1061
DEBUG - 2019-04-27 17:12:32 --> Config Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:12:32 --> URI Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Router Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Output Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Security Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Input Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:12:32 --> Language Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Loader Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Controller Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Session Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:12:32 --> Session routines successfully run
DEBUG - 2019-04-27 17:12:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:32 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:12:32 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:12:32 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:12:32 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:12:32 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:12:32 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:12:32 --> Final output sent to browser
DEBUG - 2019-04-27 17:12:32 --> Total execution time: 0.1336
DEBUG - 2019-04-27 17:12:33 --> Config Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:12:33 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:12:33 --> URI Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Router Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Output Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Security Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Input Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:12:33 --> Language Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Loader Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Controller Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Session Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:12:33 --> Session routines successfully run
DEBUG - 2019-04-27 17:12:33 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:33 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:12:33 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:12:33 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:12:33 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:12:33 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:12:33 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:12:33 --> Final output sent to browser
DEBUG - 2019-04-27 17:12:33 --> Total execution time: 0.0479
DEBUG - 2019-04-27 17:12:35 --> Config Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:12:35 --> URI Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Router Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Output Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Security Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Input Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:12:35 --> Language Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Loader Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Controller Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Session Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:12:35 --> Session routines successfully run
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:12:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Config Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:12:35 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:12:35 --> URI Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Router Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Output Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Security Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Input Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:12:35 --> Language Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Loader Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Controller Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Session Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:12:35 --> Session routines successfully run
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Model Class Initialized
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:12:35 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:12:35 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:12:35 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:12:35 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:12:35 --> File loaded: application/views/orderCustDetails.php
DEBUG - 2019-04-27 17:12:35 --> Final output sent to browser
DEBUG - 2019-04-27 17:12:35 --> Total execution time: 0.1762
DEBUG - 2019-04-27 17:14:12 --> Config Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:14:12 --> URI Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Router Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Output Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Security Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Input Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:14:12 --> Language Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Loader Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Controller Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Session Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:14:12 --> Session routines successfully run
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:14:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Config Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:14:12 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:14:12 --> URI Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Router Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Output Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Security Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Input Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:14:12 --> Language Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Loader Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Controller Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Session Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:14:12 --> A session cookie was not found.
DEBUG - 2019-04-27 17:14:12 --> Session routines successfully run
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:14:12 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:14:12 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:14:12 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:14:12 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:14:12 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 17:14:12 --> Final output sent to browser
DEBUG - 2019-04-27 17:14:12 --> Total execution time: 0.1419
DEBUG - 2019-04-27 17:14:13 --> Config Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:14:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:14:13 --> URI Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Router Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Output Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Security Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Input Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:14:13 --> Language Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Loader Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Controller Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Session Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:14:13 --> Session routines successfully run
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:14:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/homePage.php
DEBUG - 2019-04-27 17:14:13 --> Final output sent to browser
DEBUG - 2019-04-27 17:14:13 --> Total execution time: 0.1241
DEBUG - 2019-04-27 17:14:13 --> Config Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:14:13 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:14:13 --> URI Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Router Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Output Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Security Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Input Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:14:13 --> Language Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Loader Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Controller Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Session Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:14:13 --> Session routines successfully run
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:14:13 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:14:13 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/header.php
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/footer.php
DEBUG - 2019-04-27 17:14:13 --> File loaded: application/views/market.php
DEBUG - 2019-04-27 17:14:13 --> Final output sent to browser
DEBUG - 2019-04-27 17:14:13 --> Total execution time: 0.0607
DEBUG - 2019-04-27 17:14:19 --> Config Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:14:19 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:14:19 --> URI Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Router Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Output Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Security Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Input Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:14:19 --> Language Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Loader Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Controller Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Session Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:14:19 --> Session routines successfully run
DEBUG - 2019-04-27 17:14:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Model Class Initialized
DEBUG - 2019-04-27 17:14:19 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:14:19 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:14:19 --> Form Validation Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Config Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:17:20 --> URI Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Router Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Output Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Security Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Input Class Initialized
DEBUG - 2019-04-27 17:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:17:20 --> Language Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Config Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Hooks Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Utf8 Class Initialized
DEBUG - 2019-04-27 17:17:46 --> UTF-8 Support Enabled
DEBUG - 2019-04-27 17:17:46 --> URI Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Router Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Output Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Security Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Input Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2019-04-27 17:17:46 --> Language Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Loader Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Controller Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Model Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Model Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Database Driver Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Session Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Helper loaded: string_helper
DEBUG - 2019-04-27 17:17:46 --> Session routines successfully run
DEBUG - 2019-04-27 17:17:46 --> Model Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Model Class Initialized
DEBUG - 2019-04-27 17:17:46 --> Helper loaded: url_helper
DEBUG - 2019-04-27 17:17:46 --> Helper loaded: form_helper
DEBUG - 2019-04-27 17:17:46 --> Form Validation Class Initialized
