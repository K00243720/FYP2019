<?php 

class Order extends CI_Controller {
	var $imageName;
	public function __construct(){
		parent::__construct();
		$this->load->model('Order_Model');
		$this->load->model('User_Model');
		$this->load->library('session');
		$this->load->helper('url');
	}
	
	public function index() {
		$this->load->view('index');
	}
	
	public function saveOrderDetails($orderId) {
		$status = $this->doUpload();
		
		if($this->session->userdata('user')){
			$user = $this->session->userdata('user');
			$userId = $user['UserID'];
		}
		$order = array(
			"shortDescription"=> $_POST["shortDescription"],
			"largeImage"=>$this->imageName,
			"userId"=>$userId,
			"Order"=>$orderId,
			"Producer"=>$producerId,
			"Customer"=>$custId
		);
		
		//call the function in the model to do the update and get back a boolean flag	
	    //$flag holds true/false value depending on whether the update was successful or not
        $flag = $this->Order_Model->updateOrder($order);
		//pass $flag to function to determine whether success/failure page should be displayed
        if($flag){
			//update session to pick up new order data
			$data["AllOrders"] = $this->Order_Model->getOrdersByUserID($user['UserID']);	
			$orderData = array('orderData'  => $data["AllOrders"]);
			$this->session->set_userdata($orderData);
			$this->load->view("doOrder",$data);
		} else {
			$data['msg'] = "error on update to user details";
			$this->load->view('msgpage', $data);
        }
	}
	
	public function doEditOrder($orderId){   
		$data['order'] = $this->Order_Model->getOrder($orderId);
        if ($data['order'] != null){
			$this->load->view("editOrder",$data);
		}
		else {
			$data['msg'] = "Error on order update ";
		 	$this->load->view('msgpage', $data);
		 }
     }

	// function to allow the deletion of an order based on the $orderid
	public function deleteOrder($orderId) {
		//call the deleteOrder function in the model
		//if the deletion has been successful prepare a success page
		//otherwise prepare a failure message
		
		if($this->session->userdata('user')){
			$user = $this->session->userdata('user');
			$userId = $user['UserID'];
		}
		
	   if ($this->Order_Model->deleteOrder($orderId)){
		   redirect('User/doOrdersCust/'.$userId);
		}else{
			$data['msg']= "error on delete in order";
			$this->load->view('msgpage');
		}
		
	}
	
	public function doInsertOrder(){
		$this->load->view("insertOrder");
	}
	
	public function getDrillDownOrderAndUser($orderId) {
        $data['order'] = $this->Order_Model->getOrder($orderId);
		$order= $data['order'];
		$data['userOrder'] = $this->User_Model->getUserByID($order['userId']);
        if ( $data['order'] != null)
            $this->load->view('orderUserDetails', $data);
        else {
			$data['msg'] = "The Order You Searched For Could Not Be Found, Please Try Again";
		 	$this->load->view('msgpage', $data);
		 }
	}
	
	public function getDrillDownOrder($orderId) {
        $data['order'] = $this->Order_Model->getOrder($orderId);
		if ( $data['order'] != null)
            $this->load->view('orderDetails', $data);
        else {
			$data['msg'] = "The Order You Searched For Could Not Be Found, Please Try Again";
		 	$this->load->view('msgpage', $data);
		 }
    }
 
	public function insertOrder(){
	//call internal function doUpload and get back a status from it
		$status = $this->doUpload();
		//if the status = 1 there has been a problem uploading the image
		if ($status == 1 ) {
			$data['msg'] = "Problem Uploading Image"; //prepare the appropriate message
			//load the view with the appropriate message		
			$this->load->view('msgpage', $data);
			exit(); //exit the script
		}
		//if the status = 1 there has been a problem creating the thumbnail
		else if ($status == 2 ) {
			$data['msg'] =  "Problem With Thumbnail Creation"; //prepare the appropriate message
			exit(); //exit the script
		}
		
		//get user id out of session
		if($this->session->userdata('user')){
			$user = $this->session->userdata('user');
			$userId = $user['UserID'];
			$data['User'] = $user;
			$order = array(
				"shortDescription"=> $_POST["shortDescription"],
				"longDescription"=>$_POST["longDescription"],
				"largeImage"=>$this->imageName,
				"area"=>$_POST["area"],
				"dateExp"=>$_POST["dateExp"],
				"userId"=>$userId
			);
			$flag = $this->Order_Model->insertOrder($order);
		
			//update session to pick up new order data
			$data["AllOrders"] = $this->Order_Model->getOrdersByUserID($user['UserID']);	
			$orderData = array('orderData'  => $data["AllOrders"]);
			$this->session->set_userdata($orderData);
			if($flag){
				$this->load->view('usersHomePage',$data);
			}else{
				$this->handleflag($flag);
			}
		}else{
			echo "error on user id in order";
			exit();
		}
	}
	
	//internal function to allow the upload of an image as part of a product insertion/update
	public function doUpload() {
		//set config options for upload
		$config = array(
			'upload_path' 	=> './assets/images/notices/', //where the uploaded imgs are going
			'allowed_types' => 'gif|jpg|png', //only allow the user to upload 1 of three file types
			'overwrite'		=> 	'TRUE', //overwrite the file if it already exists
			'max_size'		=> '0',
			'max_width'		=> '0',
			'max_height'	=> '0'
		);
			
		//load upload library with the appropriate config options
		$this->load->library('upload', $config);
		
		//do upload and check for errors
		if ( ! $this->upload->do_upload()){
			echo "upload image";
			echo $this->upload->display_errors();
			return 1; //function stops executing here if theres a problem and returns 1
		}
		//get information from the upload function
		//all we really need from this is the image name so it can
		//be saved to the db.
		$upload_data = $this->upload->data();
		$this->imageName = $upload_data['file_name'];
		//set config options for thumbnail creation
		$config = array(
			'source_image' 		=> $upload_data['full_path'],
			'new_image' 		=> './assets/images/thumbs/',
			'width'				=> '140',
			'height'			=> '88'
		);	
				
		//load library to do the resizing and thumbnail creation
        $this->load->library('image_lib', $config);
			
		//call function resize in the image library to physically create the thumbnail	
		if (! $this->image_lib->resize()) {
			echo "make thumb nail";
			echo $this->image_lib->display_errors();
			return 2; //function stops executing here if theres a problem and returns 2
		}
		return 0; //if the upload has executed correctly the function returns 0
    
	}
	
	public function handleflag($flag){
		if($flag){
			$data["msg"] = "update saved in database";
		}else{
			$data["msg"] = "Error in database";
		}
	$this->load->view("msgpage",$data);
	}
	
}