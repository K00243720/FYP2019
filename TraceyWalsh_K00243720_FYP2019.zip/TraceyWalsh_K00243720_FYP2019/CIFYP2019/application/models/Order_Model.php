<?php

class Order_Model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function getAllOrders(){
		$query = $this->db->get('order');
		return $query->result_array();
	}
	
	//function to retrieve an order based on Producer
	public function getOrdersByProducer($UserID) {
		//query  orders table using $producer as its search criteria
		$resultSet = $this->db->get_where('Orders',array('Producer'=>$UserID));
		//if there are no rows in the resultSet then no orders matched the Producer
		if ($resultSet->num_rows() > 0) {
			return $resultSet->result_array(); //return resultSet as an array
		}
		else
			return null; //return null indicating that no orders were found
	}

	//function to retrieve an order based on Customer
	public function getOrdersByCustomer($UserID) {
		//query  orders table using Customer as its search criteria
		$resultSet = $this->db->get_where('Orders',array('Customer'=>$UserID));
		//if there are no rows in the resultSet then no orders matched the Customer
		if ($resultSet->num_rows() > 0) {
			return $resultSet->result_array(); //return resultSet as an array
		}
		else
			return null; //return null indicating that no orders were found
	}

	public function insertOrder($order){
		$flag = false;
		$this->db->insert('orders',$order);
		$affectedRows = $this->db->affected_rows();
		if($affectedRows==0){
			$flag = false;
		}else{
			$flag= true;
		}
		return $flag;
	}
	
	public function updateOrder($order) {
	//return true/false depending on whether the update was successful or not
		if ($this->db->where('orderId', $order['orderId']) && $this->db->update('orders',$order))
			return true;
		else 
			return false;
	}

	//function to delete a order based on its orderid
	public function deleteOrder($orderId) {
		//delete the order based on its orderid
		//if the deletion is successful return true (to the controller) otherwise return false
		if ($this->db->delete('orders',array('orderId'=>$orderId)))
			return true;
		else
			return false;
	}

	//function to retrieve a order based on its orderid
	public function getOrder($orderId) {
		//query order table using $orderId as its search criteria
		$resultSet = $this->db->get_where('orders',array('orderId'=>$orderId));
		//if there are no rows in the resultSet then no orders matched the orderId
		if ($resultSet->num_rows() > 0) {
			$row = $resultSet->row_array();   //return matching row from DB to controller
			return $row;
		}
		else
			return null; //return null indicating that no orders were found
	}
	/*
	//function to retrieve an order based on userid
	public function getOrdersByUserID($userid) {
		//query  orders table using $userid as its search criteria
		$resultSet = $this->db->get_where('orders',array('Customer'=>$userid));
		//if there are no rows in the resultSet then no orders matched the userid
		if ($resultSet->num_rows() > 0) {
			return $resultSet->result_array(); //return resultSet as an array
		}
		else
			return null; //return null indicating that no notices were found
	}*/
}
?>