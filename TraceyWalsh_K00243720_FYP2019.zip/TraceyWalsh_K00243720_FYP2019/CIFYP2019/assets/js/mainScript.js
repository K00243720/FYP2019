function validateForm() {
	   var x = document.forms["form1"]["FirstName"].value;
	   if (x == "") {
	   alert("First name must be filled out");
	   return false;
	   }
	   var x = document.forms["form1"]["Surname"].value;
	   if (x == "") {
	   alert("Last name must be filled out");
	   return false;
	   }
	   var x = document.forms["form1"]["AddressLine1"].value;
	   if (x == "") {
	   alert("Address must be filled out");
	   return false;
	   }
	   var x = document.forms["form1"]["AddressLine2"].value;
	   if (x == "") {
	   alert("Address must be filled out");
	   return false;
	   }
	   var x = document.forms["form1"]["Mobile"].value;
	   if (x == "") {
	   alert("Mobile must be filled out");
	   return false;
	   }
	   var x = document.forms["form1"]["email"].value;
	   if (x == "") {
	   alert("Email must be filled out");
	   return false;
	   }
	    var x = document.forms["form1"]["UserName"].value;
	   if (x == "") {
	   alert("User name must be filled out");
	   return false;
	   }
	    var x = document.forms["form1"]["Password"].value;
	   if (x == "") {
	   alert("Password must be filled out");
	   return false;
	   }
 }
 
 